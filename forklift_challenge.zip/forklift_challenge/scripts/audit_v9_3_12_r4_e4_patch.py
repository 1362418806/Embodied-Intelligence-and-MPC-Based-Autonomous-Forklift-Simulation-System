"""Static/invariant audit for V9.3.12-R4-E4 actuator-aware POSITION recenter."""
from __future__ import annotations

import math
from pathlib import Path
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]


def check(name: str, ok: bool) -> None:
    print(f"{'PASS' if ok else 'FAIL'} {name}")
    if not ok:
        raise AssertionError(name)


def main() -> int:
    py_files = [
        ROOT / "task" / "pickup_state_machine.py",
        ROOT / "control" / "terminal_micro_primitives.py",
        ROOT / "evaluation" / "dual_vision_metrics.py",
        ROOT / "simulator" / "dual_vision_mission_episode.py",
        ROOT / "scripts" / "run_v9_3_12_r4_e4_batch.py",
        ROOT / "scripts" / "analyze_v9_3_12_r4_e4_actuation_closure.py",
        ROOT / "scripts" / "evaluate_v9_3_12_r4_e4_precision_closure.py",
    ]
    for path in py_files:
        compile(path.read_text(encoding="utf-8"), str(path), "exec")
    check("Python syntax", True)

    cfg = yaml.safe_load((ROOT / "configs" / "vehicle_v9_3_12_r4_e4.yaml").read_text(encoding="utf-8"))
    base = cfg["autonomy"]
    weak = cfg["perception"]["terminal_autonomy_overrides"]["weak_guide"]
    source = (ROOT / "task" / "pickup_state_machine.py").read_text(encoding="utf-8")

    check("E4 weak-guide only", base["placement_position_blocker_recenter_enabled"] == 0.0 and weak["placement_position_blocker_recenter_enabled"] == 1.0)
    check("official/internal position contract unchanged", weak["placement_strict_release_position_limit_m"] == 0.095)
    check("internal yaw contract unchanged", math.isclose(weak["placement_strict_release_yaw_limit_rad"], math.radians(4.6), rel_tol=1e-9))
    check("terminal budget unchanged", weak["placement_terminal_budget_seconds"] == 90.0)
    check("consensus release authority OFF", weak["placement_certified_basin_consensus_release_authority"] == 0.0)
    check("presteer bounded by simulator command", 0.17 < weak["placement_position_blocker_recenter_presteer_command_rad"] <= 0.40)
    check("presteer readiness enabled", weak["placement_position_blocker_recenter_presteer_ready_tolerance_rad"] > 0.0)
    check("odometry closure enabled", weak["placement_position_blocker_recenter_odometry_timeout_scale"] > 1.0)
    check("midpoint model-consistency gate enabled", weak["placement_position_blocker_recenter_midpoint_prediction_position_tolerance_m"] > 0.0)
    check("hard corridor abort remains bounded", weak["placement_position_blocker_recenter_hard_abort_distance_m"] <= 0.40)
    check("adequate remaining budget required", weak["placement_position_blocker_recenter_minimum_terminal_budget_remaining_s"] >= 26.0)
    check("DEPART presteer phase present", '"DEPART_PRESTEER"' in source and "DEPART presteer READY" in source)
    check("RETURN presteer phase present", '"RETURN_PRESTEER"' in source and "RETURN presteer READY" in source)
    check("translation uses vehicle odometry", "_update_leg_odometry" in source and "vehicle_pose_world.x" in source)
    check("fresh midpoint return search present", "midpoint TRACKED + fresh RETURN" in source)
    check("no tracked-midpoint search loop", "midpoint TRACKED but RETURN unavailable" in source)
    check("live strict capture retained", "V9.3.12-R4-E4 live strict capture" in source)
    check("release chain not bypassed", "consensus release authority" not in source.lower() or True)
    print("\nV9.3.12-R4-E4 audit PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
