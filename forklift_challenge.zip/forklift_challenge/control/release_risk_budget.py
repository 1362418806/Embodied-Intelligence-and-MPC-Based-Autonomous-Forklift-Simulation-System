"""V9.3.12-R3 bounded uncertainty aggregation for release certification."""
from __future__ import annotations

import math


def combine_uncertainty_components(
    *components: float,
    execution_reserve: float = 0.0,
    rss_enabled: bool = False,
) -> float:
    """Combine independent non-negative uncertainty components.

    Legacy behavior is additive.  R3 can opt into RSS for independent estimator
    error sources, while execution reserve remains an explicit deterministic
    guard added after the stochastic budget.
    """
    values = [max(0.0, float(value)) for value in components]
    stochastic = math.sqrt(sum(value * value for value in values)) if rss_enabled else sum(values)
    return float(stochastic + max(0.0, float(execution_reserve)))
