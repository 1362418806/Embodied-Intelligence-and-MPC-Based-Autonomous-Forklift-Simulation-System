"""Interactive drive test for the forklift v1 MuJoCo model.

Controls
--------
W                 Increase forward speed target.
S                 Increase reverse speed target.
Space             Set speed target to zero.
A                 Increase left-turn command.
D                 Increase right-turn command.
C                 Center steering.
I / Up Arrow      Raise fork target.
K / Down Arrow    Lower fork target.
Home / End        Fork minimum / maximum target.
R                 Reset the complete simulation.
"""

from __future__ import annotations

import argparse
import math
import sys
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import glfw
import mujoco
import mujoco.viewer
import yaml


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from control.ackermann import (  # noqa: E402
    front_drive_angular_speeds,
    rear_ackermann_angles,
)

DEFAULT_CONFIG = PROJECT_ROOT / "configs" / "vehicle_v1.yaml"


@dataclass
class CommandState:
    """Thread-safe operator command snapshot."""

    speed_target: float
    steering_command: float
    lift_target: float
    reset_requested: bool = False


class SharedCommands:
    """Synchronized commands shared by GLFW callback and simulation loop."""

    def __init__(self, lift_target: float) -> None:
        self._state = CommandState(0.0, 0.0, lift_target)
        self._lock = threading.Lock()

    @staticmethod
    def _clamp(value: float, minimum: float, maximum: float) -> float:
        return min(max(value, minimum), maximum)

    def adjust_speed(self, delta: float, minimum: float, maximum: float) -> None:
        with self._lock:
            self._state.speed_target = self._clamp(
                self._state.speed_target + delta, minimum, maximum
            )

    def stop(self) -> None:
        with self._lock:
            self._state.speed_target = 0.0

    def adjust_steering(self, delta: float, maximum: float) -> None:
        with self._lock:
            self._state.steering_command = self._clamp(
                self._state.steering_command + delta, -maximum, maximum
            )

    def center_steering(self) -> None:
        with self._lock:
            self._state.steering_command = 0.0

    def adjust_lift(self, delta: float, minimum: float, maximum: float) -> None:
        with self._lock:
            self._state.lift_target = self._clamp(
                self._state.lift_target + delta, minimum, maximum
            )

    def set_lift(self, value: float, minimum: float, maximum: float) -> None:
        with self._lock:
            self._state.lift_target = self._clamp(value, minimum, maximum)

    def request_reset(self) -> None:
        with self._lock:
            self._state.reset_requested = True

    def reset_commands(self, lift_target: float) -> None:
        with self._lock:
            self._state.speed_target = 0.0
            self._state.steering_command = 0.0
            self._state.lift_target = lift_target
            self._state.reset_requested = False

    def snapshot(self) -> CommandState:
        with self._lock:
            result = CommandState(
                speed_target=self._state.speed_target,
                steering_command=self._state.steering_command,
                lift_target=self._state.lift_target,
                reset_requested=self._state.reset_requested,
            )
            self._state.reset_requested = False
            return result


def load_config(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise FileNotFoundError(f"Configuration file does not exist: {path}")
    with path.open("r", encoding="utf-8") as stream:
        config = yaml.safe_load(stream)
    if not isinstance(config, dict):
        raise ValueError("Configuration root must be a mapping")
    for section in ("model", "simulation", "drive", "lift"):
        if section not in config:
            raise KeyError(f"Missing required configuration section: {section}")
    return config


def validate_config(config: dict[str, Any]) -> None:
    simulation = config["simulation"]
    drive = config["drive"]
    lift = config["lift"]

    if float(simulation["realtime_factor"]) <= 0.0:
        raise ValueError("simulation.realtime_factor must be greater than zero")
    if float(simulation["status_interval_seconds"]) <= 0.0:
        raise ValueError(
            "simulation.status_interval_seconds must be greater than zero"
        )
    if float(drive["wheelbase"]) <= 0.0:
        raise ValueError("drive.wheelbase must be greater than zero")
    if float(drive["front_track"]) <= 0.0:
        raise ValueError("drive.front_track must be greater than zero")
    if float(drive["rear_track"]) <= 0.0:
        raise ValueError("drive.rear_track must be greater than zero")
    if float(drive["front_wheel_radius"]) <= 0.0:
        raise ValueError("drive.front_wheel_radius must be greater than zero")
    if float(drive["minimum_speed"]) > float(drive["maximum_speed"]):
        raise ValueError("drive.minimum_speed cannot exceed drive.maximum_speed")
    if float(lift["minimum_height"]) > float(lift["maximum_height"]):
        raise ValueError("lift.minimum_height cannot exceed lift.maximum_height")


def resolve_model_path(config: dict[str, Any]) -> Path:
    model_path = (PROJECT_ROOT / config["model"]["xml_path"]).resolve()
    if not model_path.is_file():
        raise FileNotFoundError(f"MJCF model does not exist: {model_path}")
    return model_path


def require_id(model: mujoco.MjModel, object_type: mujoco.mjtObj, name: str) -> int:
    object_id = mujoco.mj_name2id(model, object_type, name)
    if object_id < 0:
        raise RuntimeError(f"Required MuJoCo object was not found: {name}")
    return object_id


def yaw_from_freejoint(data: mujoco.MjData, qpos_address: int) -> float:
    """Extract yaw in radians from a free-joint quaternion."""
    w, x, y, z = data.qpos[qpos_address + 3 : qpos_address + 7]
    return math.atan2(2.0 * (w * z + x * y), 1.0 - 2.0 * (y * y + z * z))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    config = load_config(args.config.resolve())
    validate_config(config)
    model_path = resolve_model_path(config)

    drive = config["drive"]
    lift = config["lift"]
    simulation = config["simulation"]

    wheelbase = float(drive["wheelbase"])
    front_track = float(drive["front_track"])
    rear_track = float(drive["rear_track"])
    wheel_radius = float(drive["front_wheel_radius"])
    speed_min = float(drive["minimum_speed"])
    speed_max = float(drive["maximum_speed"])
    speed_step = float(drive["keyboard_speed_step"])
    steering_max = float(drive["maximum_steering_command"])
    steering_step = float(drive["keyboard_steering_step"])

    lift_min = float(lift["minimum_height"])
    lift_max = float(lift["maximum_height"])
    lift_initial = float(lift["initial_target"])
    lift_step = float(lift["keyboard_step"])

    realtime_factor = float(simulation["realtime_factor"])
    status_interval = float(simulation["status_interval_seconds"])

    model = mujoco.MjModel.from_xml_path(str(model_path))
    data = mujoco.MjData(model)

    actuator_names = (
        "front_left_drive_velocity",
        "front_right_drive_velocity",
        "rear_left_steer_position",
        "rear_right_steer_position",
        "lift_position",
    )
    actuator_ids = {
        name: require_id(model, mujoco.mjtObj.mjOBJ_ACTUATOR, name)
        for name in actuator_names
    }

    forklift_joint_id = require_id(
        model, mujoco.mjtObj.mjOBJ_JOINT, "forklift_free"
    )
    forklift_qpos_address = int(model.jnt_qposadr[forklift_joint_id])

    rear_left_joint_id = require_id(
        model, mujoco.mjtObj.mjOBJ_JOINT, "rear_left_steer_joint"
    )
    rear_right_joint_id = require_id(
        model, mujoco.mjtObj.mjOBJ_JOINT, "rear_right_steer_joint"
    )
    rear_left_qpos_address = int(model.jnt_qposadr[rear_left_joint_id])
    rear_right_qpos_address = int(model.jnt_qposadr[rear_right_joint_id])

    commands = SharedCommands(lift_target=lift_initial)

    def key_callback(keycode: int) -> None:
        if keycode == glfw.KEY_W:
            commands.adjust_speed(speed_step, speed_min, speed_max)
        elif keycode == glfw.KEY_S:
            commands.adjust_speed(-speed_step, speed_min, speed_max)
        elif keycode == glfw.KEY_SPACE:
            commands.stop()
        elif keycode == glfw.KEY_A:
            commands.adjust_steering(steering_step, steering_max)
        elif keycode == glfw.KEY_D:
            commands.adjust_steering(-steering_step, steering_max)
        elif keycode == glfw.KEY_C:
            commands.center_steering()
        elif keycode in (glfw.KEY_I, glfw.KEY_UP):
            commands.adjust_lift(lift_step, lift_min, lift_max)
        elif keycode in (glfw.KEY_K, glfw.KEY_DOWN):
            commands.adjust_lift(-lift_step, lift_min, lift_max)
        elif keycode == glfw.KEY_HOME:
            commands.set_lift(lift_min, lift_min, lift_max)
        elif keycode == glfw.KEY_END:
            commands.set_lift(lift_max, lift_min, lift_max)
        elif keycode == glfw.KEY_R:
            commands.request_reset()

    mujoco.mj_forward(model, data)
    print(f"Loaded model: {model_path}")
    print(f"MuJoCo version: {mujoco.__version__}")
    print("W/S speed, Space stop, A/D steer, C center, I/K lift, R reset.")
    print("Positive steering command means a left vehicle turn while moving forward.")

    with mujoco.viewer.launch_passive(
        model, data, key_callback=key_callback
    ) as viewer:
        with viewer.lock():
            viewer.cam.lookat[:] = (0.4, 0.0, 0.55)
            viewer.cam.distance = 5.8
            viewer.cam.azimuth = 135
            viewer.cam.elevation = -22
        viewer.sync()

        last_status_time = time.perf_counter()
        while viewer.is_running():
            step_start = time.perf_counter()
            command = commands.snapshot()

            if command.reset_requested:
                mujoco.mj_resetData(model, data)
                commands.reset_commands(lift_initial)
                command = commands.snapshot()
                mujoco.mj_forward(model, data)
                print("\nSimulation reset.")

            steer_angles = rear_ackermann_angles(
                command.steering_command, wheelbase, rear_track
            )
            left_omega, right_omega = front_drive_angular_speeds(
                command.speed_target,
                command.steering_command,
                wheelbase,
                front_track,
                wheel_radius,
            )

            data.ctrl[actuator_ids["front_left_drive_velocity"]] = left_omega
            data.ctrl[actuator_ids["front_right_drive_velocity"]] = right_omega
            data.ctrl[actuator_ids["rear_left_steer_position"]] = steer_angles.left
            data.ctrl[actuator_ids["rear_right_steer_position"]] = steer_angles.right
            data.ctrl[actuator_ids["lift_position"]] = command.lift_target

            mujoco.mj_step(model, data)
            viewer.sync()

            now = time.perf_counter()
            if now - last_status_time >= status_interval:
                x = float(data.qpos[forklift_qpos_address])
                y = float(data.qpos[forklift_qpos_address + 1])
                yaw = yaw_from_freejoint(data, forklift_qpos_address)
                rear_left_actual = float(data.qpos[rear_left_qpos_address])
                rear_right_actual = float(data.qpos[rear_right_qpos_address])

                print(
                    "\r"
                    f"speed_target={command.speed_target:+4.2f} m/s  "
                    f"steer_cmd={math.degrees(command.steering_command):+5.1f} deg  "
                    f"rear_target=({math.degrees(steer_angles.left):+5.1f},"
                    f"{math.degrees(steer_angles.right):+5.1f}) deg  "
                    f"rear_actual=({math.degrees(rear_left_actual):+5.1f},"
                    f"{math.degrees(rear_right_actual):+5.1f}) deg  "
                    f"pose=({x:+5.2f},{y:+5.2f},"
                    f"{math.degrees(yaw):+6.1f} deg)  "
                    f"contacts={data.ncon:2d}",
                    end="",
                    flush=True,
                )
                last_status_time = now

            target_wall_step = model.opt.timestep / realtime_factor
            elapsed = time.perf_counter() - step_start
            if elapsed < target_wall_step:
                time.sleep(target_wall_step - elapsed)

    print("\nForklift v1 viewer closed successfully.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (FileNotFoundError, KeyError, RuntimeError, ValueError, yaml.YAMLError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
