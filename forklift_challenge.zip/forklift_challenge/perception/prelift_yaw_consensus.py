from __future__ import annotations

from dataclasses import dataclass
import math
import statistics


def wrap_angle(value: float) -> float:
    return (float(value) + math.pi) % (2.0 * math.pi) - math.pi


@dataclass(frozen=True)
class PreliftYawConsensusConfig:
    enabled: bool = False
    window_seconds: float = 1.5
    minimum_samples: int = 5
    minimum_confidence: float = 0.82
    maximum_reprojection_error_px: float = 2.0
    maximum_spread_rad: float = math.radians(0.35)
    maximum_age_seconds: float = 3.2


@dataclass(frozen=True)
class PreliftYawConsensusSnapshot:
    ready: bool
    sample_count: int
    world_yaw_rad: float | None
    spread_rad: float | None
    newest_measurement_time: float | None
    age_seconds: float | None
    accepted_sample_count: int
    rejected_quality_count: int
    duplicate_count: int


class PreliftYawConsensus:
    """Quality-gated, de-duplicated pre-lift RGB world-yaw consensus.

    Only yaw is aggregated. Position still comes from the existing last visual
    handoff pose because the pallet can translate during INSERT. Measurement
    timestamps are de-duplicated so an RGB world-hold cannot fake temporal
    evidence by replaying the same rendered frame.
    """

    def __init__(self, config: PreliftYawConsensusConfig):
        self.config = config
        self._samples: list[tuple[float, float]] = []
        self._last_measurement_time: float | None = None
        self.accepted_sample_count = 0
        self.rejected_quality_count = 0
        self.duplicate_count = 0

    def reset(self) -> None:
        self._samples.clear()
        self._last_measurement_time = None
        self.accepted_sample_count = 0
        self.rejected_quality_count = 0
        self.duplicate_count = 0

    def observe(
        self,
        *,
        measurement_time: float,
        world_yaw_rad: float,
        confidence: float | None,
        reprojection_error_px: float | None,
    ) -> bool:
        if not self.config.enabled:
            return False
        t = float(measurement_time)
        if not math.isfinite(t) or not math.isfinite(float(world_yaw_rad)):
            return False
        if self._last_measurement_time is not None and abs(t - self._last_measurement_time) <= 1e-6:
            self.duplicate_count += 1
            return False
        self._last_measurement_time = t
        conf = float('-inf') if confidence is None else float(confidence)
        reproj = float('inf') if reprojection_error_px is None else float(reprojection_error_px)
        if (
            not math.isfinite(conf)
            or not math.isfinite(reproj)
            or conf < self.config.minimum_confidence
            or reproj > self.config.maximum_reprojection_error_px
        ):
            self.rejected_quality_count += 1
            return False
        self._samples.append((t, wrap_angle(world_yaw_rad)))
        self.accepted_sample_count += 1
        newest = t
        # Keep enough history for the configured consensus window and age audit.
        keep = max(self.config.window_seconds, self.config.maximum_age_seconds)
        self._samples = [item for item in self._samples if newest - item[0] <= keep + 1e-9]
        return True

    @staticmethod
    def _robust_center_and_spread(values: list[float]) -> tuple[float, float]:
        s = sum(math.sin(v) for v in values)
        c = sum(math.cos(v) for v in values)
        reference = math.atan2(s, c)
        unwrapped = [reference + wrap_angle(v - reference) for v in values]
        center = float(statistics.median(unwrapped))
        deltas = [abs(wrap_angle(v - center)) for v in values]
        # Robust sigma-like spread. It remains zero for repeated identical values
        # and is insensitive to an isolated valid-but-noisy pickup frame.
        mad = float(statistics.median(deltas)) if deltas else 0.0
        spread = 1.4826 * mad
        return wrap_angle(center), float(spread)

    def snapshot(self, *, now: float) -> PreliftYawConsensusSnapshot:
        if not self.config.enabled or not self._samples:
            return PreliftYawConsensusSnapshot(
                False, 0, None, None, None, None,
                self.accepted_sample_count, self.rejected_quality_count, self.duplicate_count,
            )
        newest = max(t for t, _ in self._samples)
        recent = [yaw for t, yaw in self._samples if newest - t <= self.config.window_seconds + 1e-9]
        center = None
        spread = None
        if recent:
            center, spread = self._robust_center_and_spread(recent)
        age = max(0.0, float(now) - newest)
        ready = bool(
            len(recent) >= self.config.minimum_samples
            and center is not None
            and spread is not None
            and spread <= self.config.maximum_spread_rad
            and age <= self.config.maximum_age_seconds
        )
        return PreliftYawConsensusSnapshot(
            ready=ready,
            sample_count=len(recent),
            world_yaw_rad=center,
            spread_rad=spread,
            newest_measurement_time=newest,
            age_seconds=age,
            accepted_sample_count=self.accepted_sample_count,
            rejected_quality_count=self.rejected_quality_count,
            duplicate_count=self.duplicate_count,
        )
