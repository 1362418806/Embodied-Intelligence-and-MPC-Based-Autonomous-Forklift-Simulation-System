import math

from forklift_v9_2_1_terminal_precision import (
    Pose2D,
    TerminalPrecisionConfig,
    TerminalPrecisionController,
    TerminalPrecisionMode,
    compose_pose,
    desired_base_delta,
    inverse_pose,
    predicted_release_error,
)


def _close(a, b, eps=1e-9):
    return abs(a - b) <= eps


def test_pose_inverse_identity():
    pose = Pose2D(1.2, -0.4, math.radians(31.0))
    identity = compose_pose(pose, inverse_pose(pose))
    assert _close(identity.x, 0.0)
    assert _close(identity.y, 0.0)
    assert _close(identity.yaw, 0.0)


def test_release_error_is_zero_when_measured_load_matches_target():
    carry = Pose2D(1.35, 0.04, math.radians(2.0))
    err = predicted_release_error(carry, carry)
    assert _close(err.x, 0.0)
    assert _close(err.y, 0.0)
    assert _close(err.yaw, 0.0)


def test_goal_is_measurement_driven_not_fixed_compensation():
    target = Pose2D(1.50, 0.10, math.radians(5.0))
    carry_a = Pose2D(1.30, 0.00, 0.0)
    carry_b = Pose2D(1.42, 0.00, 0.0)
    goal_a = desired_base_delta(target, carry_a)
    goal_b = desired_base_delta(target, carry_b)
    assert not _close(goal_a.x, goal_b.x)


def test_precision_release_requires_dwell():
    config = TerminalPrecisionConfig(release_dwell_s=0.30)
    controller = TerminalPrecisionController(config)
    carry = Pose2D(1.30, 0.0, 0.0)
    controller.reset(carry)

    target = Pose2D(1.33, 0.0, math.radians(1.0))
    first = controller.step(
        target_pose_in_base=target,
        dt_s=0.10,
        max_curvature_1pm=0.8,
    )
    assert first.mode == TerminalPrecisionMode.HOLD_FOR_RELEASE
    assert not first.release_ready

    controller.step(target_pose_in_base=target, dt_s=0.10, max_curvature_1pm=0.8)
    third = controller.step(target_pose_in_base=target, dt_s=0.10, max_curvature_1pm=0.8)
    assert third.mode == TerminalPrecisionMode.READY_TO_RELEASE
    assert third.release_ready


def test_stale_measurement_holds_vehicle():
    controller = TerminalPrecisionController()
    controller.reset(Pose2D(1.2, 0.0, 0.0))
    decision = controller.step(
        target_pose_in_base=Pose2D(1.3, 0.0, 0.0),
        dt_s=0.05,
        max_curvature_1pm=0.8,
        measurement_valid=True,
        measurement_age_s=1.0,
    )
    assert decision.mode == TerminalPrecisionMode.WAIT_FOR_MEASUREMENT
    assert decision.speed_mps == 0.0


def test_lattice_planner_supports_reverse_goal():
    controller = TerminalPrecisionController()
    controller.reset(Pose2D(1.30, 0.0, 0.0))
    decision = controller.step(
        target_pose_in_base=Pose2D(1.12, 0.0, 0.0),
        dt_s=0.05,
        max_curvature_1pm=1.0,
    )
    assert decision.authoritative
    assert decision.mode in {
        TerminalPrecisionMode.SERVO_REVERSE,
        TerminalPrecisionMode.DIRECTION_CHANGE_HOLD,
    }


def test_lattice_planner_finds_nonholonomic_local_pose():
    controller = TerminalPrecisionController()
    controller.reset(Pose2D(1.30, 0.0, 0.0))
    target = compose_pose(
        Pose2D(1.30, 0.0, 0.0),
        Pose2D(0.18, 0.10, math.radians(10.0)),
    )
    decision = controller.step(
        target_pose_in_base=target,
        dt_s=0.05,
        max_curvature_1pm=1.0,
    )
    assert decision.authoritative
    assert not decision.request_reentry
    assert decision.plan_length > 0
    assert decision.planner_expanded_nodes > 0


def test_large_terminal_error_requests_outer_reentry():
    controller = TerminalPrecisionController()
    controller.reset(Pose2D(1.30, 0.0, 0.0))
    decision = controller.step(
        target_pose_in_base=Pose2D(0.60, 0.0, 0.0),
        dt_s=0.05,
        max_curvature_1pm=1.0,
    )
    assert decision.mode == TerminalPrecisionMode.REQUEST_REENTRY
    assert decision.request_reentry


def _simulate_ideal_terminal(error: Pose2D, max_steps: int = 500):
    """Propagate the local controller in an ideal kinematic bicycle surrogate."""
    carry = Pose2D(1.30, 0.0, 0.0)
    target = compose_pose(carry, error)
    controller = TerminalPrecisionController()
    controller.reset(carry)
    actual_speed = 0.0

    for step_index in range(max_steps):
        decision = controller.step(
            target_pose_in_base=target,
            dt_s=0.05,
            max_curvature_1pm=1.0,
            actual_speed_mps=actual_speed,
        )
        if decision.release_ready:
            return decision
        assert not decision.request_reentry
        assert decision.authoritative

        actual_speed = decision.speed_mps
        curvature = decision.curvature_1pm
        dt_s = 0.05
        delta_yaw = actual_speed * curvature * dt_s
        if abs(curvature) <= 1e-10:
            motion = Pose2D(actual_speed * dt_s, 0.0, 0.0)
        else:
            radius = 1.0 / curvature
            motion = Pose2D(
                radius * math.sin(delta_yaw),
                radius * (1.0 - math.cos(delta_yaw)),
                delta_yaw,
            )
        target = compose_pose(inverse_pose(motion), target)

    raise AssertionError("terminal precision controller did not converge")


def test_typical_v9_2_precision_plateau_is_reduced_in_ideal_kinematics():
    # These cases represent the dominant ~0.14-0.15 m V9.2 release-error scale and
    # include both forward and behind-target conditions without any fixed compensation.
    cases = (
        Pose2D(0.15, 0.015, math.radians(2.0)),
        Pose2D(-0.15, 0.005, math.radians(-1.0)),
        Pose2D(0.14, -0.020, math.radians(4.0)),
    )
    for error in cases:
        decision = _simulate_ideal_terminal(error)
        assert decision.position_error_m <= 0.070
        assert decision.yaw_error_rad <= math.radians(3.0)


def test_release_dwell_must_be_continuous_after_accuracy_excursion():
    config = TerminalPrecisionConfig(release_dwell_s=0.30)
    controller = TerminalPrecisionController(config)
    carry = Pose2D(1.30, 0.0, 0.0)
    controller.reset(carry)

    inside = Pose2D(1.34, 0.0, math.radians(1.0))
    outside_strict_but_inside_legacy_hold = Pose2D(1.38, 0.0, math.radians(1.0))

    controller.step(target_pose_in_base=inside, dt_s=0.10, max_curvature_1pm=0.8)
    controller.step(target_pose_in_base=inside, dt_s=0.10, max_curvature_1pm=0.8)
    interrupted = controller.step(
        target_pose_in_base=outside_strict_but_inside_legacy_hold,
        dt_s=0.05,
        max_curvature_1pm=0.8,
    )
    assert not interrupted.release_ready

    first_after_interrupt = controller.step(
        target_pose_in_base=inside,
        dt_s=0.10,
        max_curvature_1pm=0.8,
    )
    second_after_interrupt = controller.step(
        target_pose_in_base=inside,
        dt_s=0.10,
        max_curvature_1pm=0.8,
    )
    assert not first_after_interrupt.release_ready
    assert not second_after_interrupt.release_ready

    third_after_interrupt = controller.step(
        target_pose_in_base=inside,
        dt_s=0.10,
        max_curvature_1pm=0.8,
    )
    assert third_after_interrupt.release_ready


def test_outer_approach_does_not_accumulate_precision_stagnation():
    config = TerminalPrecisionConfig(stagnation_timeout_s=0.25)
    controller = TerminalPrecisionController(config)
    controller.reset(Pose2D(1.30, 0.0, 0.0))

    # Stay outside the precision-entry basin longer than the local stagnation timeout.
    # The precision watchdog must remain dormant while the legacy outer approach owns motion.
    target = Pose2D(1.72, 0.0, 0.0)
    for _ in range(10):
        decision = controller.step(
            target_pose_in_base=target,
            dt_s=0.05,
            max_curvature_1pm=1.0,
        )
        assert decision.mode == TerminalPrecisionMode.INACTIVE
        assert not decision.authoritative
        assert not decision.request_reentry
        assert decision.stagnation_s == 0.0


def test_opposite_signed_motion_does_not_consume_planned_reverse_distance():
    controller = TerminalPrecisionController()
    controller.reset(Pose2D(1.30, 0.0, 0.0))
    decision = controller.step(
        target_pose_in_base=Pose2D(1.12, 0.05, math.radians(-3.0)),
        dt_s=0.05,
        max_curvature_1pm=1.0,
        actual_speed_mps=0.0,
    )
    assert decision.plan_length > 0

    # Force a reverse command state, then report that the chassis is still sliding forward.
    controller._last_speed_mps = -0.10
    remaining_before = controller._plan[0].remaining_m
    controller._consume_executed_distance(0.10, actual_speed_mps=+0.10)
    remaining_after = controller._plan[0].remaining_m
    assert _close(remaining_before, remaining_after)


def test_reverse_takeover_waits_until_forward_motion_has_settled():
    config = TerminalPrecisionConfig(direction_change_hold_s=0.10)
    controller = TerminalPrecisionController(config)
    controller.reset(Pose2D(1.30, 0.0, 0.0))
    reverse_target = Pose2D(1.12, 0.0, 0.0)

    # The precision controller is taking over while the outer controller still has
    # measurable forward motion. It must command neutral rather than immediate reverse.
    first = controller.step(
        target_pose_in_base=reverse_target,
        dt_s=0.05,
        max_curvature_1pm=1.0,
        actual_speed_mps=+0.08,
    )
    assert first.mode == TerminalPrecisionMode.DIRECTION_CHANGE_HOLD
    assert first.speed_mps == 0.0

    second = controller.step(
        target_pose_in_base=reverse_target,
        dt_s=0.05,
        max_curvature_1pm=1.0,
        actual_speed_mps=+0.05,
    )
    assert second.mode == TerminalPrecisionMode.DIRECTION_CHANGE_HOLD
    assert second.speed_mps == 0.0

    # Once the neutral dwell has elapsed and signed speed is close to zero, reverse is allowed.
    third = controller.step(
        target_pose_in_base=reverse_target,
        dt_s=0.05,
        max_curvature_1pm=1.0,
        actual_speed_mps=+0.005,
    )
    assert third.mode == TerminalPrecisionMode.SERVO_REVERSE
    assert third.speed_mps < 0.0


def test_nonfinite_target_measurement_is_fail_safe_hold():
    controller = TerminalPrecisionController()
    controller.reset(Pose2D(1.30, 0.0, 0.0))
    decision = controller.step(
        target_pose_in_base=Pose2D(math.nan, 0.0, 0.0),
        dt_s=0.05,
        max_curvature_1pm=1.0,
    )
    assert decision.mode == TerminalPrecisionMode.WAIT_FOR_MEASUREMENT
    assert decision.authoritative
    assert decision.speed_mps == 0.0


def test_reset_rejects_nonfinite_carried_pallet_pose():
    controller = TerminalPrecisionController()
    caught = False
    try:
        controller.reset(Pose2D(1.30, math.inf, 0.0))
    except ValueError:
        caught = True
    assert caught, "non-finite carried pallet pose must be rejected"


def test_longitudinal_precision_plateau_uses_direct_servo_without_planner():
    controller = TerminalPrecisionController()
    carry = Pose2D(1.30, 0.0, 0.0)
    controller.reset(carry)
    target = Pose2D(1.45, 0.010, math.radians(1.0))

    decision = controller.step(
        target_pose_in_base=target,
        dt_s=0.05,
        max_curvature_1pm=1.0,
        actual_speed_mps=0.0,
    )
    assert decision.mode == TerminalPrecisionMode.SERVO_FORWARD
    assert decision.speed_mps > 0.0
    assert decision.curvature_1pm == 0.0
    assert decision.planner_expanded_nodes == 0


def test_carried_pallet_pose_can_be_refreshed_from_trusted_measurement():
    controller = TerminalPrecisionController()
    controller.reset(Pose2D(1.30, 0.0, 0.0))
    controller.update_carried_pallet_pose(Pose2D(1.27, 0.01, math.radians(0.5)))
    assert _close(controller.carried_pallet_pose_in_base.x, 1.27)
    assert _close(controller.carried_pallet_pose_in_base.y, 0.01)
