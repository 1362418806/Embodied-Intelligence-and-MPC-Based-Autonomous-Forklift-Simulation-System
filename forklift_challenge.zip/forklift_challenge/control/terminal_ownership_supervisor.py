"""Terminal controller ownership policy for V9.3.5.

This module decides *which* already-existing controller should own the loaded
forklift in the final approach.  It intentionally does not compute steering or
vehicle geometry itself.  The policy prevents a forward-only PLACE_ALIGN stage
from retaining control for tens of seconds when the bidirectional terminal MPC
can already take over.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class TerminalOwnershipConfig:
    mpc_acquire_distance_m: float
    mpc_acquire_lateral_m: float
    mpc_acquire_yaw_rad: float
    mpc_force_distance_m: float
    mpc_force_lateral_m: float
    mpc_force_yaw_rad: float
    align_soft_timeout_seconds: float
    align_progress_window_seconds: float
    align_progress_improvement_m: float

    def validate(self) -> None:
        values = (
            self.mpc_acquire_distance_m,
            self.mpc_acquire_lateral_m,
            self.mpc_acquire_yaw_rad,
            self.mpc_force_distance_m,
            self.mpc_force_lateral_m,
            self.mpc_force_yaw_rad,
            self.align_soft_timeout_seconds,
            self.align_progress_window_seconds,
            self.align_progress_improvement_m,
        )
        if any(value < 0.0 for value in values):
            raise ValueError("terminal ownership parameters must be non-negative")
        if self.mpc_acquire_distance_m <= 0.0:
            raise ValueError("MPC acquisition distance must be positive")
        if self.mpc_force_distance_m < self.mpc_acquire_distance_m:
            raise ValueError("forced MPC distance cannot be smaller than direct acquisition")
        if self.mpc_force_lateral_m < self.mpc_acquire_lateral_m:
            raise ValueError("forced MPC lateral envelope cannot be smaller than direct acquisition")
        if self.mpc_force_yaw_rad < self.mpc_acquire_yaw_rad:
            raise ValueError("forced MPC yaw envelope cannot be smaller than direct acquisition")
        if self.align_soft_timeout_seconds <= 0.0:
            raise ValueError("PLACE_ALIGN soft timeout must be positive")
        if self.align_progress_window_seconds <= 0.0:
            raise ValueError("PLACE_ALIGN progress window must be positive")
        if self.align_progress_improvement_m <= 0.0:
            raise ValueError("PLACE_ALIGN progress improvement must be positive")


@dataclass(frozen=True)
class TerminalOwnershipUpdate:
    action: str
    align_elapsed_seconds: float
    no_progress_seconds: float
    progress_score: float


class TerminalOwnershipSupervisor:
    """Bound PLACE_ALIGN ownership and promote early bidirectional MPC takeover."""

    ALIGN = "ALIGN"
    DIRECT_MPC = "DIRECT_MPC"
    FORCE_MPC = "FORCE_MPC"
    REACQUIRE = "REACQUIRE"

    def __init__(self, config: TerminalOwnershipConfig) -> None:
        config.validate()
        self.config = config
        self.reset()

    def reset(self) -> None:
        self._align_start_time: float | None = None
        self._best_progress_score: float | None = None
        self._last_progress_time: float | None = None

    def begin_align(self, now: float, progress_score: float) -> None:
        now = float(now)
        score = float(progress_score)
        self._align_start_time = now
        self._best_progress_score = score
        self._last_progress_time = now

    @property
    def active(self) -> bool:
        return self._align_start_time is not None

    def _inside_acquire(self, distance: float, lateral: float, yaw: float) -> bool:
        c = self.config
        return bool(
            float(distance) <= c.mpc_acquire_distance_m
            and abs(float(lateral)) <= c.mpc_acquire_lateral_m
            and abs(float(yaw)) <= c.mpc_acquire_yaw_rad
        )

    def _inside_force(self, distance: float, lateral: float, yaw: float) -> bool:
        c = self.config
        return bool(
            float(distance) <= c.mpc_force_distance_m
            and abs(float(lateral)) <= c.mpc_force_lateral_m
            and abs(float(yaw)) <= c.mpc_force_yaw_rad
        )

    def acquisition_ready(self, *, distance: float, lateral: float, yaw: float) -> bool:
        return self._inside_acquire(distance, lateral, yaw)

    def force_envelope_ready(self, *, distance: float, lateral: float, yaw: float) -> bool:
        return self._inside_force(distance, lateral, yaw)

    def update(
        self,
        now: float,
        *,
        distance: float,
        lateral: float,
        yaw: float,
        progress_score: float,
    ) -> TerminalOwnershipUpdate:
        now = float(now)
        score = float(progress_score)
        if not self.active:
            self.begin_align(now, score)

        assert self._align_start_time is not None
        assert self._last_progress_time is not None
        if self._inside_acquire(distance, lateral, yaw):
            action = self.DIRECT_MPC
        else:
            best = self._best_progress_score
            if best is None or score <= best - self.config.align_progress_improvement_m:
                self._best_progress_score = score
                self._last_progress_time = now
            align_elapsed = max(0.0, now - self._align_start_time)
            no_progress = max(0.0, now - self._last_progress_time)
            ownership_expired = (
                align_elapsed >= self.config.align_soft_timeout_seconds
                or no_progress >= self.config.align_progress_window_seconds
            )
            if ownership_expired:
                action = (
                    self.FORCE_MPC
                    if self._inside_force(distance, lateral, yaw)
                    else self.REACQUIRE
                )
            else:
                action = self.ALIGN

        align_elapsed = max(0.0, now - self._align_start_time)
        no_progress = max(0.0, now - self._last_progress_time)
        return TerminalOwnershipUpdate(
            action=action,
            align_elapsed_seconds=align_elapsed,
            no_progress_seconds=no_progress,
            progress_score=score,
        )
