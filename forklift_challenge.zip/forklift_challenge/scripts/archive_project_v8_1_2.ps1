param(
    [switch]$IncludeOutputSummaries
)

$ErrorActionPreference = "Stop"
$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
Set-Location $ProjectRoot

$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$ArchiveRoot = Join-Path $ProjectRoot "archives"
$SnapshotName = "forklift_v8_1_2_$Timestamp"
$SnapshotDir = Join-Path $ArchiveRoot $SnapshotName
$ZipPath = Join-Path $ArchiveRoot "$SnapshotName.zip"

New-Item -ItemType Directory -Force -Path $SnapshotDir | Out-Null

git status --short | Out-File `
    (Join-Path $SnapshotDir "git_status.txt") -Encoding utf8
git log --oneline --decorate -n 100 | Out-File `
    (Join-Path $SnapshotDir "git_log.txt") -Encoding utf8
git diff | Out-File `
    (Join-Path $SnapshotDir "working_tree.patch") -Encoding utf8
git diff --cached | Out-File `
    (Join-Path $SnapshotDir "index.patch") -Encoding utf8
git tag --list | Out-File `
    (Join-Path $SnapshotDir "git_tags.txt") -Encoding utf8

$BundlePath = Join-Path $SnapshotDir "forklift_challenge.bundle"
git bundle create $BundlePath --all

Copy-Item `
    (Join-Path $ProjectRoot "PROJECT_PROGRESS_V8_1_2.md") `
    $SnapshotDir -Force

$ConfigDir = Join-Path $SnapshotDir "configs"
New-Item -ItemType Directory -Force -Path $ConfigDir | Out-Null
Get-ChildItem (Join-Path $ProjectRoot "configs") -Filter "vehicle_v*.yaml" |
    Copy-Item -Destination $ConfigDir -Force

$DocsDir = Join-Path $SnapshotDir "version_docs"
New-Item -ItemType Directory -Force -Path $DocsDir | Out-Null
Get-ChildItem $ProjectRoot -Filter "README_V*.md" |
    Copy-Item -Destination $DocsDir -Force
Get-ChildItem $ProjectRoot -Filter "TRACE_ANALYSIS_V*.md" |
    Copy-Item -Destination $DocsDir -Force

if ($IncludeOutputSummaries) {
    $SummaryDir = Join-Path $SnapshotDir "output_summaries"
    New-Item -ItemType Directory -Force -Path $SummaryDir | Out-Null
    Get-ChildItem (Join-Path $ProjectRoot "outputs") `
        -Recurse -Filter "summary.json" -ErrorAction SilentlyContinue |
        ForEach-Object {
            $Relative = $_.FullName.Substring(
                (Join-Path $ProjectRoot "outputs").Length
            ).TrimStart("\")
            $Target = Join-Path $SummaryDir $Relative
            New-Item -ItemType Directory -Force `
                -Path (Split-Path $Target) | Out-Null
            Copy-Item $_.FullName $Target -Force
        }
}

if (Test-Path $ZipPath) {
    Remove-Item $ZipPath -Force
}
Compress-Archive -Path (Join-Path $SnapshotDir "*") `
    -DestinationPath $ZipPath -CompressionLevel Optimal

Write-Host "Archive directory: $SnapshotDir"
Write-Host "Archive zip:       $ZipPath"
Write-Host "Git bundle:        $BundlePath"
