"""Static/invariant audit for V9.3.12-R4-E3 Position-Blocker Recenter Corridor."""
from __future__ import annotations

import math
from pathlib import Path
import py_compile
import sys

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from control.terminal_micro_primitives import (
    PositionBlockerRecenterConfig,
    PositionBlockerRecenterPlanner,
)


def check(name: str, condition: bool) -> None:
    print(f"{'PASS' if condition else 'FAIL'} {name}")
    if not condition:
        raise AssertionError(name)


def _planner() -> PositionBlockerRecenterPlanner:
    return PositionBlockerRecenterPlanner(
        PositionBlockerRecenterConfig(
            wheelbase_m=0.93,
            steering_limit_rad=0.17,
            speed_mps=0.06,
            filtered_position_activation_m=0.105,
            filtered_yaw_activation_rad=math.radians(6.5),
            certification_position_activation_m=0.13,
            certification_yaw_activation_rad=math.radians(7.0),
            minimum_lateral_fraction=0.75,
            strict_position_limit_m=0.095,
            strict_yaw_limit_rad=math.radians(4.6),
            predicted_position_headroom_m=0.004,
            predicted_yaw_headroom_rad=math.radians(0.5),
            maximum_predicted_filtered_excursion_m=0.38,
            final_filtered_position_guard_m=0.085,
            final_filtered_yaw_guard_rad=math.radians(5.0),
            departure_duration_options_s=(5.25, 5.50, 5.75),
            return_duration_options_s=(5.50, 5.75, 6.0),
            steering_fractions=(0.8, 1.0),
            maximum_speed_for_activation_mps=0.02,
            maximum_total_execution_seconds=12.0,
        )
    )


def main() -> int:
    files = [
        ROOT / "control" / "terminal_micro_primitives.py",
        ROOT / "task" / "pickup_state_machine.py",
        ROOT / "simulator" / "dual_vision_mission_episode.py",
        ROOT / "evaluation" / "dual_vision_metrics.py",
        ROOT / "scripts" / "run_v9_3_12_r4_e3_batch.py",
        ROOT / "scripts" / "analyze_v9_3_12_r4_e3_position_recenter.py",
        ROOT / "scripts" / "evaluate_v9_3_12_r4_e3_precision_closure.py",
    ]
    for path in files:
        py_compile.compile(str(path), doraise=True)
    check("Python syntax", True)

    cfg = yaml.safe_load(
        (ROOT / "configs" / "vehicle_v9_3_12_r4_e3.yaml").read_text(encoding="utf-8")
    )
    base = cfg["autonomy"]
    weak = cfg["perception"]["terminal_autonomy_overrides"]["weak_guide"]
    check("E3 disabled outside terminal override", base["placement_position_blocker_recenter_enabled"] == 0.0)
    check("E3 enabled in weak-guide", weak["placement_position_blocker_recenter_enabled"] == 1.0)
    check("strict position unchanged", weak["placement_strict_release_position_limit_m"] == 0.095)
    check(
        "strict yaw unchanged",
        math.isclose(
            weak["placement_strict_release_yaw_limit_rad"], math.radians(4.6), rel_tol=1e-9
        ),
    )
    check("90s terminal budget unchanged", weak["placement_terminal_budget_seconds"] == 90.0)
    check(
        "consensus release authority OFF",
        weak["placement_certified_basin_consensus_release_authority"] == 0.0,
    )
    check("E3 speed bounded at 0.06m/s", weak["placement_position_blocker_recenter_speed_mps"] <= 0.06)
    check("E3 one-macro execution <=12s", weak["placement_position_blocker_recenter_maximum_total_execution_seconds"] <= 12.0)
    check("E3 predicted excursion <=38cm", weak["placement_position_blocker_recenter_maximum_predicted_excursion_m"] <= 0.38)
    check("E3 hard abort <=42cm", weak["placement_position_blocker_recenter_hard_abort_distance_m"] <= 0.42)
    check(
        "E3 final position target has strict headroom",
        weak["placement_position_blocker_recenter_final_filtered_position_guard_m"] <= 0.085,
    )
    check(
        "E3 needs >=15s budget before activation",
        weak["placement_position_blocker_recenter_minimum_terminal_budget_remaining_s"] >= 15.0,
    )

    task_source = (ROOT / "task" / "pickup_state_machine.py").read_text(encoding="utf-8")
    primitive_source = (ROOT / "control" / "terminal_micro_primitives.py").read_text(encoding="utf-8")
    check("POSITION blocker has dedicated branch", 'self._strict_release_certification_last_blocker == "POSITION"' in task_source)
    check("E2 is YAW-only after E3", 'self._strict_release_certification_last_blocker == "YAW"' in task_source)
    check(
        "summed POSITION+YAW E2 trigger removed",
        'self._strict_release_certification_last_blocker in ("POSITION", "YAW")' not in task_source,
    )
    check("E3 midpoint requires fresh RGB", "V9.3.12-R4-E3 midpoint RGB settle" in task_source)
    check("E3 return is re-planned", "midpoint RGB return replan selected" in task_source)
    check("E3 return has live early-capture gate", "V9.3.12-R4-E3 live certification capture" in task_source)
    check("E3 Supervisor suppressed during corridor", "the POSITION-blocker corridor owns the chassis" in task_source)
    e3_primitive_source = primitive_source[primitive_source.index("class PositionBlockerRecenterPlanner"): ]
    check("E3 has no release authority", "ReleaseDecisionSupervisor" not in e3_primitive_source and "release" not in e3_primitive_source.lower())

    planner = _planner()
    plan = planner.search_departure(
        filtered_x_m=-0.022164236081235383,
        filtered_y_m=-0.08233360312049534,
        filtered_yaw_rad=math.radians(3.2781470176897116),
        certification_x_m=-0.004432910347421804,
        certification_y_m=-0.09282643661336783,
        certification_yaw_rad=math.radians(4.168936409823362),
        position_margin_m=0.017257359394876538,
        yaw_margin_rad=math.radians(0.9713000007537842),
        current_speed_mps=0.0,
        terminal_budget_remaining_s=27.0,
    )
    check("E2-trace POSITION state has a bounded corridor", plan is not None)
    assert plan is not None
    check("counterfactual targets >6mm POSITION headroom", plan.predicted_effective_position_m <= 0.089 + 1e-9)
    check("counterfactual clears strict YAW with >=0.5deg headroom", plan.predicted_effective_yaw_rad <= math.radians(4.1) + 1e-9)
    check("counterfactual apex stays inside 38cm model guard", plan.maximum_predicted_filtered_excursion_m <= 0.38 + 1e-9)

    returned = planner.search_return(
        filtered_x_m=plan.predicted_mid_filtered_x_m,
        filtered_y_m=plan.predicted_mid_filtered_y_m,
        filtered_yaw_rad=plan.predicted_mid_filtered_yaw_rad,
        certification_x_m=plan.predicted_mid_certification_x_m,
        certification_y_m=plan.predicted_mid_certification_y_m,
        certification_yaw_rad=plan.predicted_mid_certification_yaw_rad,
        position_margin_m=0.017257359394876538,
        yaw_margin_rad=math.radians(0.9713000007537842),
        preferred_speed_sign=-1 if plan.nominal_return_speed_mps < 0.0 else 1,
        terminal_budget_remaining_s=20.0,
    )
    check("fresh-midpoint return replan exists", returned is not None)
    assert returned is not None
    check("replanned return clears strict POSITION", returned.predicted_effective_position_m <= 0.091 + 1e-9)

    print("\nV9.3.12-R4-E3 audit PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
