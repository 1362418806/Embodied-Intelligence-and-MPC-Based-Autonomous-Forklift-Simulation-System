"""Interactive physical pickup test for forklift_v2.xml.

Controls
--------
W                 Increase forward speed target.
S                 Increase reverse speed target.
Space             Set speed target to zero.
A / D             Increase left/right turn command.
C                 Center steering.
I / Up Arrow      Raise fork target.
K / Down Arrow    Lower fork target.
Home / End        Fork minimum / maximum target.
R                 Reset the complete simulation.

The pallet is an independent free body. It is lifted only through physical
contact with the two forks; the script never attaches or teleports the load.
"""

from __future__ import annotations

import argparse
import math
import sys
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import glfw
import mujoco
import mujoco.viewer
import yaml


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from control.ackermann import (  # noqa: E402
    front_drive_angular_speeds,
    rear_ackermann_angles,
)
from control.safety import LiftDriveInterlock  # noqa: E402

DEFAULT_CONFIG = PROJECT_ROOT / "configs" / "vehicle_v2.yaml"


@dataclass
class CommandState:
    speed_target: float
    steering_command: float
    lift_target: float
    reset_requested: bool = False


class SharedCommands:
    def __init__(self, lift_target: float) -> None:
        self._state = CommandState(0.0, 0.0, lift_target)
        self._lock = threading.Lock()

    @staticmethod
    def _clamp(value: float, minimum: float, maximum: float) -> float:
        return min(max(value, minimum), maximum)

    def adjust_speed(self, delta: float, minimum: float, maximum: float) -> None:
        with self._lock:
            self._state.speed_target = self._clamp(
                self._state.speed_target + delta, minimum, maximum
            )

    def stop(self) -> None:
        with self._lock:
            self._state.speed_target = 0.0

    def adjust_steering(self, delta: float, maximum: float) -> None:
        with self._lock:
            self._state.steering_command = self._clamp(
                self._state.steering_command + delta, -maximum, maximum
            )

    def center_steering(self) -> None:
        with self._lock:
            self._state.steering_command = 0.0

    def adjust_lift(self, delta: float, minimum: float, maximum: float) -> None:
        with self._lock:
            self._state.lift_target = self._clamp(
                self._state.lift_target + delta, minimum, maximum
            )

    def set_lift(self, value: float, minimum: float, maximum: float) -> None:
        with self._lock:
            self._state.lift_target = self._clamp(value, minimum, maximum)

    def request_reset(self) -> None:
        with self._lock:
            self._state.reset_requested = True

    def reset_commands(self, lift_target: float) -> None:
        with self._lock:
            self._state = CommandState(0.0, 0.0, lift_target, False)

    def snapshot(self) -> CommandState:
        with self._lock:
            result = CommandState(
                speed_target=self._state.speed_target,
                steering_command=self._state.steering_command,
                lift_target=self._state.lift_target,
                reset_requested=self._state.reset_requested,
            )
            self._state.reset_requested = False
            return result


def load_config(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise FileNotFoundError(f"Configuration file does not exist: {path}")
    with path.open("r", encoding="utf-8") as stream:
        config = yaml.safe_load(stream)
    if not isinstance(config, dict):
        raise ValueError("Configuration root must be a mapping")
    for section in ("model", "simulation", "drive", "lift", "pickup", "safety"):
        if section not in config:
            raise KeyError(f"Missing required configuration section: {section}")
    return config


def validate_config(config: dict[str, Any]) -> None:
    simulation = config["simulation"]
    drive = config["drive"]
    lift = config["lift"]
    pickup = config["pickup"]
    safety = config["safety"]

    positive_values = {
        "simulation.realtime_factor": simulation["realtime_factor"],
        "simulation.status_interval_seconds": simulation["status_interval_seconds"],
        "drive.wheelbase": drive["wheelbase"],
        "drive.front_track": drive["front_track"],
        "drive.rear_track": drive["rear_track"],
        "drive.front_wheel_radius": drive["front_wheel_radius"],
        "pickup.lifted_height_threshold": pickup["lifted_height_threshold"],
        "pickup.tilt_warning_degrees": pickup["tilt_warning_degrees"],
    }
    for name, value in positive_values.items():
        if float(value) <= 0.0:
            raise ValueError(f"{name} must be greater than zero")

    if float(safety["lift_velocity_threshold"]) < 0.0:
        raise ValueError("safety.lift_velocity_threshold must be non-negative")
    if float(safety["lift_settle_time_seconds"]) < 0.0:
        raise ValueError("safety.lift_settle_time_seconds must be non-negative")

    if float(drive["minimum_speed"]) > float(drive["maximum_speed"]):
        raise ValueError("drive.minimum_speed cannot exceed drive.maximum_speed")
    if float(lift["minimum_height"]) > float(lift["maximum_height"]):
        raise ValueError("lift.minimum_height cannot exceed lift.maximum_height")


def resolve_model_path(config: dict[str, Any]) -> Path:
    model_path = (PROJECT_ROOT / config["model"]["xml_path"]).resolve()
    if not model_path.is_file():
        raise FileNotFoundError(f"MJCF model does not exist: {model_path}")
    return model_path


def require_id(model: mujoco.MjModel, object_type: mujoco.mjtObj, name: str) -> int:
    object_id = mujoco.mj_name2id(model, object_type, name)
    if object_id < 0:
        raise RuntimeError(f"Required MuJoCo object was not found: {name}")
    return object_id


def rpy_from_freejoint(
    data: mujoco.MjData, qpos_address: int
) -> tuple[float, float, float]:
    """Return roll, pitch, yaw from a free-joint quaternion."""
    w, x, y, z = data.qpos[qpos_address + 3 : qpos_address + 7]

    sinr_cosp = 2.0 * (w * x + y * z)
    cosr_cosp = 1.0 - 2.0 * (x * x + y * y)
    roll = math.atan2(sinr_cosp, cosr_cosp)

    sinp = 2.0 * (w * y - z * x)
    pitch = math.copysign(math.pi / 2.0, sinp) if abs(sinp) >= 1.0 else math.asin(sinp)

    siny_cosp = 2.0 * (w * z + x * y)
    cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
    yaw = math.atan2(siny_cosp, cosy_cosp)
    return roll, pitch, yaw


def count_cross_contacts(
    data: mujoco.MjData,
    first_group: Iterable[int],
    second_group: Iterable[int],
) -> int:
    first = set(first_group)
    second = set(second_group)
    count = 0
    for index in range(data.ncon):
        contact = data.contact[index]
        geom1 = int(contact.geom1)
        geom2 = int(contact.geom2)
        if (geom1 in first and geom2 in second) or (
            geom2 in first and geom1 in second
        ):
            count += 1
    return count


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    config = load_config(args.config.resolve())
    validate_config(config)
    model_path = resolve_model_path(config)

    simulation = config["simulation"]
    drive = config["drive"]
    lift = config["lift"]
    pickup = config["pickup"]
    safety = config["safety"]

    wheelbase = float(drive["wheelbase"])
    front_track = float(drive["front_track"])
    rear_track = float(drive["rear_track"])
    wheel_radius = float(drive["front_wheel_radius"])
    speed_min = float(drive["minimum_speed"])
    speed_max = float(drive["maximum_speed"])
    speed_step = float(drive["keyboard_speed_step"])
    steering_max = float(drive["maximum_steering_command"])
    steering_step = float(drive["keyboard_steering_step"])

    lift_min = float(lift["minimum_height"])
    lift_max = float(lift["maximum_height"])
    lift_initial = float(lift["initial_target"])
    lift_step = float(lift["keyboard_step"])

    realtime_factor = float(simulation["realtime_factor"])
    status_interval = float(simulation["status_interval_seconds"])
    camera_follow = bool(simulation.get("camera_follow", True))
    lifted_threshold = float(pickup["lifted_height_threshold"])
    tilt_warning = float(pickup["tilt_warning_degrees"])
    stop_drive_during_lift = bool(safety["stop_drive_during_lift"])
    lift_velocity_threshold = float(safety["lift_velocity_threshold"])
    lift_settle_time = float(safety["lift_settle_time_seconds"])

    model = mujoco.MjModel.from_xml_path(str(model_path))
    data = mujoco.MjData(model)

    actuator_names = (
        "front_left_drive_velocity",
        "front_right_drive_velocity",
        "rear_left_steer_position",
        "rear_right_steer_position",
        "lift_position",
    )
    actuator_ids = {
        name: require_id(model, mujoco.mjtObj.mjOBJ_ACTUATOR, name)
        for name in actuator_names
    }

    joint_names = (
        "forklift_free",
        "pallet_load_free",
        "rear_left_steer_joint",
        "rear_right_steer_joint",
        "lift_joint",
    )
    joint_ids = {
        name: require_id(model, mujoco.mjtObj.mjOBJ_JOINT, name)
        for name in joint_names
    }
    forklift_qpos = int(model.jnt_qposadr[joint_ids["forklift_free"]])
    pallet_qpos = int(model.jnt_qposadr[joint_ids["pallet_load_free"]])
    rear_left_qpos = int(model.jnt_qposadr[joint_ids["rear_left_steer_joint"]])
    rear_right_qpos = int(model.jnt_qposadr[joint_ids["rear_right_steer_joint"]])
    lift_qpos = int(model.jnt_qposadr[joint_ids["lift_joint"]])
    lift_dof = int(model.jnt_dofadr[joint_ids["lift_joint"]])

    fork_geom_ids = {
        require_id(model, mujoco.mjtObj.mjOBJ_GEOM, "left_fork"),
        require_id(model, mujoco.mjtObj.mjOBJ_GEOM, "right_fork"),
    }
    pallet_geom_ids = {
        require_id(model, mujoco.mjtObj.mjOBJ_GEOM, name)
        for name in (
            "pallet_center_runner",
            "pallet_left_runner",
            "pallet_right_runner",
            "pallet_deck",
            "cargo_box",
        )
    }

    commands = SharedCommands(lift_target=lift_initial)
    drive_interlock = LiftDriveInterlock(
        enabled=stop_drive_during_lift,
        velocity_threshold=lift_velocity_threshold,
        settle_time=lift_settle_time,
    )
    drive_interlock.reset(lift_target=lift_initial, sim_time=float(data.time))

    def key_callback(keycode: int) -> None:
        if keycode == glfw.KEY_W:
            commands.adjust_speed(speed_step, speed_min, speed_max)
        elif keycode == glfw.KEY_S:
            commands.adjust_speed(-speed_step, speed_min, speed_max)
        elif keycode == glfw.KEY_SPACE:
            commands.stop()
        elif keycode == glfw.KEY_A:
            commands.adjust_steering(steering_step, steering_max)
        elif keycode == glfw.KEY_D:
            commands.adjust_steering(-steering_step, steering_max)
        elif keycode == glfw.KEY_C:
            commands.center_steering()
        elif keycode in (glfw.KEY_I, glfw.KEY_UP):
            commands.stop()
            commands.adjust_lift(lift_step, lift_min, lift_max)
        elif keycode in (glfw.KEY_K, glfw.KEY_DOWN):
            commands.stop()
            commands.adjust_lift(-lift_step, lift_min, lift_max)
        elif keycode == glfw.KEY_HOME:
            commands.stop()
            commands.set_lift(lift_min, lift_min, lift_max)
        elif keycode == glfw.KEY_END:
            commands.stop()
            commands.set_lift(lift_max, lift_min, lift_max)
        elif keycode == glfw.KEY_R:
            commands.request_reset()

    mujoco.mj_forward(model, data)
    print(f"Loaded model: {model_path}")
    print(f"MuJoCo version: {mujoco.__version__}")
    print("W/S speed, Space stop, A/D steer, C center, I/K lift, R reset.")
    print("Use low speed, align both forks with the cyan pocket markers, insert, then lift.")
    print("The pallet is never attached by script; all lifting is contact-driven.")

    with mujoco.viewer.launch_passive(
        model, data, key_callback=key_callback
    ) as viewer:
        with viewer.lock():
            viewer.cam.lookat[:] = (1.3, 0.0, 0.55)
            viewer.cam.distance = 6.2
            viewer.cam.azimuth = 140
            viewer.cam.elevation = -24
        viewer.sync()

        last_status_time = time.perf_counter()
        while viewer.is_running():
            step_start = time.perf_counter()
            command = commands.snapshot()

            if command.reset_requested:
                mujoco.mj_resetData(model, data)
                commands.reset_commands(lift_initial)
                command = commands.snapshot()
                mujoco.mj_forward(model, data)
                drive_interlock.reset(
                    lift_target=lift_initial, sim_time=float(data.time)
                )
                print("\nSimulation reset.")

            interlock_result = drive_interlock.resolve(
                requested_speed=command.speed_target,
                lift_velocity=float(data.qvel[lift_dof]),
                lift_target=command.lift_target,
                sim_time=float(data.time),
            )

            steer_angles = rear_ackermann_angles(
                command.steering_command, wheelbase, rear_track
            )
            left_omega, right_omega = front_drive_angular_speeds(
                interlock_result.applied_speed,
                command.steering_command,
                wheelbase,
                front_track,
                wheel_radius,
            )

            data.ctrl[actuator_ids["front_left_drive_velocity"]] = left_omega
            data.ctrl[actuator_ids["front_right_drive_velocity"]] = right_omega
            data.ctrl[actuator_ids["rear_left_steer_position"]] = steer_angles.left
            data.ctrl[actuator_ids["rear_right_steer_position"]] = steer_angles.right
            data.ctrl[actuator_ids["lift_position"]] = command.lift_target

            mujoco.mj_step(model, data)
            viewer.sync()

            now = time.perf_counter()
            if now - last_status_time >= status_interval:
                vehicle_x = float(data.qpos[forklift_qpos])
                vehicle_y = float(data.qpos[forklift_qpos + 1])
                _, _, vehicle_yaw = rpy_from_freejoint(data, forklift_qpos)
                rear_left_actual = float(data.qpos[rear_left_qpos])
                rear_right_actual = float(data.qpos[rear_right_qpos])
                lift_actual = float(data.qpos[lift_qpos])

                load_x = float(data.qpos[pallet_qpos])
                load_y = float(data.qpos[pallet_qpos + 1])
                load_z = float(data.qpos[pallet_qpos + 2])
                load_roll, load_pitch, _ = rpy_from_freejoint(data, pallet_qpos)
                load_tilt_deg = max(
                    abs(math.degrees(load_roll)), abs(math.degrees(load_pitch))
                )
                fork_contacts = count_cross_contacts(
                    data, fork_geom_ids, pallet_geom_ids
                )
                lifted = load_z >= lifted_threshold
                state = "LIFTED" if lifted else (
                    "ENGAGED" if fork_contacts > 0 else "GROUND"
                )
                if load_tilt_deg >= tilt_warning:
                    state += "/TILT_WARNING"

                if camera_follow:
                    with viewer.lock():
                        viewer.cam.lookat[0] = vehicle_x + 1.0
                        viewer.cam.lookat[1] = vehicle_y
                        viewer.cam.lookat[2] = 0.55

                print(
                    "\r"
                    f"speed_req={interlock_result.requested_speed:+4.2f}  "
                    f"speed_applied={interlock_result.applied_speed:+4.2f}  "
                    f"steer={math.degrees(command.steering_command):+5.1f}deg  "
                    f"rear=({math.degrees(rear_left_actual):+5.1f},"
                    f"{math.degrees(rear_right_actual):+5.1f})deg  "
                    f"lift={lift_actual:4.2f}/{command.lift_target:4.2f}m  "
                    f"vehicle=({vehicle_x:+4.2f},{vehicle_y:+4.2f},"
                    f"{math.degrees(vehicle_yaw):+5.1f}deg)  "
                    f"load=({load_x:+4.2f},{load_y:+4.2f},{load_z:+4.2f})  "
                    f"tilt={load_tilt_deg:4.1f}deg  "
                    f"fork_contacts={fork_contacts}  state={state}  "
                    f"interlock={interlock_result.reason.upper()}",
                    end="",
                    flush=True,
                )
                last_status_time = now

            target_wall_step = model.opt.timestep / realtime_factor
            elapsed = time.perf_counter() - step_start
            if elapsed < target_wall_step:
                time.sleep(target_wall_step - elapsed)

    print("\nForklift v2 viewer closed successfully.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (FileNotFoundError, KeyError, RuntimeError, ValueError, yaml.YAMLError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
