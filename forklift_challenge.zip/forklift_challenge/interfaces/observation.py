"""Serializable observation types for the forklift challenge."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class Pose3D:
    """Position in metres and roll/pitch/yaw in radians."""

    x: float
    y: float
    z: float
    roll: float
    pitch: float
    yaw: float


@dataclass(frozen=True)
class ForkliftObservation:
    """One synchronized state observation produced by the simulator.

    Images are kept outside this dataclass because they are large arrays. The
    recorder stores image filenames alongside this JSON-serializable state.
    """

    sim_time: float
    vehicle_pose_world: Pose3D
    vehicle_linear_velocity: tuple[float, float, float]
    vehicle_angular_velocity: tuple[float, float, float]
    steering_left: float
    steering_right: float
    front_wheel_speed_left: float
    front_wheel_speed_right: float
    lift_position: float
    lift_velocity: float
    pallet_pose_world: Pose3D
    pallet_pose_in_base: Pose3D
    placement_pose_in_base: Pose3D
    fork_contact_count: int
    load_state: str

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable mapping."""
        return asdict(self)
