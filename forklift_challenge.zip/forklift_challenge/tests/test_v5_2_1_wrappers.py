"""Smoke tests for V5.2.1 wrapper paths."""

from __future__ import annotations

import importlib.util
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def load_wrapper(name: str):
    path = PROJECT_ROOT / "scripts" / name
    spec = importlib.util.spec_from_file_location(f"_test_{path.stem}", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_interactive_wrapper_config_path() -> None:
    module = load_wrapper("run_forklift_v5_2_1.py")
    assert module.DEFAULT_CONFIG == PROJECT_ROOT / "configs" / "vehicle_v5_2_1.yaml"


def test_batch_wrapper_config_path() -> None:
    module = load_wrapper("run_v5_2_1_batch.py")
    assert module.DEFAULT_CONFIG == PROJECT_ROOT / "configs" / "vehicle_v5_2_1.yaml"
