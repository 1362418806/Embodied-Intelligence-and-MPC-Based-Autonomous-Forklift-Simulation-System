"""Locate V9.2 terminal-control integration anchors without modifying source files."""

from __future__ import annotations

import argparse
from pathlib import Path

ANCHORS = (
    "terminal alignment budget exhausted after",
    "placement target moved behind the forward-only controller",
    "oracle_terminal",
    "placement_pose_in_base",
    "pallet_pose_in_base",
    "terminal recovery",
    "guard-brake",
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project_root", nargs="?", default=".")
    args = parser.parse_args()
    root = Path(args.project_root).resolve()

    for path in sorted(root.rglob("*.py")):
        if any(part in {"outputs", ".git", "archives", "__pycache__"} for part in path.parts):
            continue
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            continue
        matches = []
        for line_no, line in enumerate(lines, 1):
            lowered = line.lower()
            for anchor in ANCHORS:
                if anchor.lower() in lowered:
                    matches.append((line_no, anchor, line.strip()))
        if matches:
            print(f"\n{path.relative_to(root)}")
            for line_no, anchor, line in matches:
                print(f"  L{line_no}: [{anchor}] {line}")


if __name__ == "__main__":
    main()
