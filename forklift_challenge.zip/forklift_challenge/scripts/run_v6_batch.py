"""Batch evaluation for V6 pickup-transport-place missions."""
from __future__ import annotations
import argparse, sys
from datetime import datetime
from pathlib import Path
from typing import Any
import yaml
PROJECT_ROOT=Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path: sys.path.insert(0,str(PROJECT_ROOT))
from evaluation.mission_metrics import write_mission_results
from scenarios.randomization import ScenarioSampler
from simulator.mission_episode import run_mission_episode
DEFAULT_CONFIG=PROJECT_ROOT/'configs'/'vehicle_v6.yaml'
def load_config(path: Path)->dict[str,Any]:
    with path.open('r',encoding='utf-8') as f: c=yaml.safe_load(f)
    if not isinstance(c,dict): raise ValueError('configuration root must be a mapping')
    return c
def parse_args():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--config',type=Path,default=DEFAULT_CONFIG); p.add_argument('--episodes',type=int,default=20); p.add_argument('--seed',type=int); p.add_argument('--difficulty',choices=ScenarioSampler.difficulties()); p.add_argument('--output',type=Path); p.add_argument('--max-time',type=float); p.add_argument('--trace-failures',action='store_true'); p.add_argument('--require-success-rate',type=float,default=0.0); return p.parse_args()
def main()->int:
    a=parse_args(); c=load_config(a.config.resolve()); seed=int(a.seed if a.seed is not None else c['randomization']['default_seed']); diff=str(a.difficulty or c['randomization']['default_difficulty']); sampler=ScenarioSampler(seed=seed,difficulty=diff); scenarios=[sampler.sample() for _ in range(a.episodes)]; out=(a.output.resolve() if a.output else (PROJECT_ROOT/c['batch']['output_root']/f"batch_{datetime.now().strftime('%Y%m%d_%H%M%S')}").resolve()); out.mkdir(parents=True,exist_ok=True); results=[]
    print(f'Running {len(scenarios)} V6 missions | seed={seed} | difficulty={diff} | output={out}')
    for i,s in enumerate(scenarios,1):
        r=run_mission_episode(c,s,max_episode_seconds=a.max_time); results.append(r); verdict='PASS' if r.success else 'FAIL'; reason='' if r.success else f' | {r.failure_reason}'; print(f'[{i:02d}/{len(scenarios):02d}] {verdict} {s.scenario_id:<16} t={r.duration_seconds:5.1f}s path={r.path_length_m:4.2f}m place={r.final_placement_error_m:.3f}m{reason}')
        if a.trace_failures and not r.success: run_mission_episode(c,s,max_episode_seconds=a.max_time,trace_path=out/'failure_traces'/f'{s.scenario_id}.jsonl')
    summary=write_mission_results(out,results); print('\nMission summary'); print(f"  success: {summary['success_count']}/{summary['episode_count']}"); print(f"  success_rate: {summary['success_rate']:.1%}"); print(f"  avg_success_placement_error: {summary['average_success_placement_error_m']}"); print(f'  results: {out}'); return 2 if summary['success_rate']<a.require_success_rate else 0
if __name__=='__main__':
    try: raise SystemExit(main())
    except (FileNotFoundError,KeyError,RuntimeError,ValueError,yaml.YAMLError) as exc: print(f'ERROR: {exc}',file=sys.stderr); raise SystemExit(1) from exc
