"""Configuration checks for the V5.1 recovery controller."""

from __future__ import annotations

from pathlib import Path

import yaml

from task.pickup_state_machine import PickupParameters


PROJECT_ROOT = Path(__file__).resolve().parents[1]
CONFIG_PATH = PROJECT_ROOT / "configs" / "vehicle_v5_1.yaml"


def test_v5_1_config_enables_bounded_recovery() -> None:
    config = yaml.safe_load(CONFIG_PATH.read_text(encoding="utf-8"))
    parameters = PickupParameters.from_mapping(config["autonomy"])

    assert parameters.align_minimum_speed > 0.0
    assert parameters.alignment_hold_seconds > 0.0
    assert parameters.progress_timeout > 0.0
    assert parameters.progress_improvement > 0.0
    assert parameters.recovery_speed < 0.0
    assert parameters.recovery_distance > 0.0
    assert parameters.maximum_recoveries == 2
    assert parameters.overshoot_longitudinal_tolerance > 0.0
