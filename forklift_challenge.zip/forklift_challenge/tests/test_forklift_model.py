"""Automated structural and actuator checks for forklift_v0.xml."""

from __future__ import annotations

from pathlib import Path

import mujoco
import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = PROJECT_ROOT / "assets" / "forklift" / "forklift_v0.xml"


def load_model() -> tuple[mujoco.MjModel, mujoco.MjData]:
    model = mujoco.MjModel.from_xml_path(str(MODEL_PATH))
    return model, mujoco.MjData(model)


def named_id(model: mujoco.MjModel, object_type: mujoco.mjtObj, name: str) -> int:
    object_id = mujoco.mj_name2id(model, object_type, name)
    assert object_id >= 0, f"Missing MuJoCo object: {name}"
    return object_id


def test_model_compiles_and_contains_required_objects() -> None:
    model, _ = load_model()

    required_bodies = ("forklift", "fork_carriage", "cargo")
    required_joints = ("forklift_free", "lift_joint", "cargo_free")
    required_geoms = (
        "ground",
        "chassis",
        "front_left_wheel",
        "front_right_wheel",
        "rear_left_wheel",
        "rear_right_wheel",
        "left_fork",
        "right_fork",
        "cargo_box",
    )

    for name in required_bodies:
        named_id(model, mujoco.mjtObj.mjOBJ_BODY, name)
    for name in required_joints:
        named_id(model, mujoco.mjtObj.mjOBJ_JOINT, name)
    for name in required_geoms:
        named_id(model, mujoco.mjtObj.mjOBJ_GEOM, name)

    named_id(model, mujoco.mjtObj.mjOBJ_ACTUATOR, "lift_position")
    named_id(model, mujoco.mjtObj.mjOBJ_SITE, "fork_tip_center")


def test_lift_actuator_limits_match_joint_limits() -> None:
    model, _ = load_model()
    joint_id = named_id(model, mujoco.mjtObj.mjOBJ_JOINT, "lift_joint")
    actuator_id = named_id(model, mujoco.mjtObj.mjOBJ_ACTUATOR, "lift_position")

    np.testing.assert_allclose(model.jnt_range[joint_id], [0.0, 1.2])
    np.testing.assert_allclose(model.actuator_ctrlrange[actuator_id], [0.0, 1.2])


def test_lift_reaches_a_mid_height_target() -> None:
    model, data = load_model()
    joint_id = named_id(model, mujoco.mjtObj.mjOBJ_JOINT, "lift_joint")
    actuator_id = named_id(model, mujoco.mjtObj.mjOBJ_ACTUATOR, "lift_position")
    qpos_address = int(model.jnt_qposadr[joint_id])

    target = 0.60
    data.ctrl[actuator_id] = target

    for _ in range(2000):
        mujoco.mj_step(model, data)

    lift_position = float(data.qpos[qpos_address])
    assert 0.50 <= lift_position <= 0.70
    assert np.isfinite(data.qpos).all()
    assert np.isfinite(data.qvel).all()


def test_reset_restores_initial_lift_position() -> None:
    model, data = load_model()
    joint_id = named_id(model, mujoco.mjtObj.mjOBJ_JOINT, "lift_joint")
    actuator_id = named_id(model, mujoco.mjtObj.mjOBJ_ACTUATOR, "lift_position")
    qpos_address = int(model.jnt_qposadr[joint_id])

    data.ctrl[actuator_id] = 0.8
    for _ in range(1000):
        mujoco.mj_step(model, data)

    mujoco.mj_resetData(model, data)
    mujoco.mj_forward(model, data)

    assert abs(float(data.qpos[qpos_address])) < 1e-12
