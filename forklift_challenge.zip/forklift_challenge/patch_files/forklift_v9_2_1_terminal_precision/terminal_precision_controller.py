"""V9.2.1 terminal placement precision controller.

The controller intentionally uses no fixed terminal geometry compensation. Its target is
constructed from two measured quantities expressed in the forklift base frame:

* the carried-pallet pose latched immediately after a stable pickup/lift; and
* the live/fused placement-target pose.

The desired base displacement is computed as ``T_B_target * inv(T_B_pallet)``. This is a
measurement-driven SE(2) objective: when the base reaches that pose, the carried pallet
and placement target coincide. A direct longitudinal servo handles the dominant short
precision plateau cheaply, while a bidirectional local state-lattice planner is retained
for non-holonomic lateral/yaw corrections.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import heapq
import math
from typing import Dict, List, Optional, Sequence, Tuple


def wrap_angle(angle: float) -> float:
    """Wrap an angle to [-pi, pi)."""
    return (angle + math.pi) % (2.0 * math.pi) - math.pi


@dataclass(frozen=True)
class Pose2D:
    """Rigid SE(2) pose represented in a common parent frame."""

    x: float
    y: float
    yaw: float


def is_finite_pose(pose: Pose2D) -> bool:
    """Return True only when every pose component is finite."""
    return math.isfinite(pose.x) and math.isfinite(pose.y) and math.isfinite(pose.yaw)


def compose_pose(a: Pose2D, b: Pose2D) -> Pose2D:
    """Compose two SE(2) transforms, returning T = A * B."""
    c = math.cos(a.yaw)
    s = math.sin(a.yaw)
    return Pose2D(
        x=a.x + c * b.x - s * b.y,
        y=a.y + s * b.x + c * b.y,
        yaw=wrap_angle(a.yaw + b.yaw),
    )


def inverse_pose(pose: Pose2D) -> Pose2D:
    """Return the inverse SE(2) transform."""
    c = math.cos(pose.yaw)
    s = math.sin(pose.yaw)
    return Pose2D(
        x=-(c * pose.x + s * pose.y),
        y=-(-s * pose.x + c * pose.y),
        yaw=wrap_angle(-pose.yaw),
    )


def predicted_release_error(
    carried_pallet_pose_in_base: Pose2D,
    target_pose_in_base: Pose2D,
) -> Pose2D:
    """Return the target pose expressed in the measured carried-pallet frame.

    Identity means the predicted released pallet pose is aligned with the target pose.
    No empirical position or yaw offset is introduced.
    """
    return compose_pose(inverse_pose(carried_pallet_pose_in_base), target_pose_in_base)


def desired_base_delta(
    target_pose_in_base: Pose2D,
    carried_pallet_pose_in_base: Pose2D,
) -> Pose2D:
    """Compute the desired base pose delta for pallet-target coincidence.

    If ``C = T_B_pallet`` and ``T = T_B_target``, the desired world base pose is
    ``T_W_B* = T_W_B * T * inv(C)``. Therefore the desired base displacement from the
    current base is exactly ``T * inv(C)``.
    """
    return compose_pose(target_pose_in_base, inverse_pose(carried_pallet_pose_in_base))


class TerminalPrecisionMode(str, Enum):
    INACTIVE = "inactive"
    WAIT_FOR_MEASUREMENT = "wait_for_measurement"
    PLAN_LOCAL_PATH = "plan_local_path"
    SERVO_FORWARD = "servo_forward"
    SERVO_REVERSE = "servo_reverse"
    DIRECTION_CHANGE_HOLD = "direction_change_hold"
    HOLD_FOR_RELEASE = "hold_for_release"
    READY_TO_RELEASE = "ready_to_release"
    REQUEST_REENTRY = "request_reentry"


@dataclass(frozen=True)
class TerminalPrecisionConfig:
    """Configuration for the terminal precision phase.

    All position/yaw thresholds are control-quality gates. They are not geometry
    compensation terms and are never added to the target pose.
    """

    # Keep margin below the competition 0.10 m / 5 deg requirement because V9.2 logs
    # show roughly 8-14 mm of additional translation during lowering.
    release_position_m: float = 0.070
    release_yaw_rad: float = math.radians(3.0)
    release_dwell_s: float = 0.70

    # The new controller is intentionally local. Large errors remain owned by the proven
    # V9.2 terminal approach/recovery FSM.
    precision_entry_position_m: float = 0.35
    precision_entry_yaw_rad: float = math.radians(18.0)
    reentry_position_m: float = 0.55
    reentry_yaw_rad: float = math.radians(30.0)
    active_abort_position_m: float = 0.75
    active_abort_yaw_rad: float = math.radians(45.0)

    # Terminal motion is allowed only on a fresh accepted/fused target measurement.
    max_measurement_age_s: float = 0.40

    # Low speed protects the pallet and gives the visual estimator repeated observations.
    cruise_forward_speed_mps: float = 0.16
    cruise_reverse_speed_mps: float = 0.12
    fine_speed_mps: float = 0.075
    fine_speed_position_m: float = 0.13

    # The dominant V9.2 precision plateau is mostly a short terminal translation problem.
    # A narrow straight-line fast path avoids invoking the heavier lattice planner when
    # lateral/yaw residuals are already inside the release-quality neighborhood.
    direct_servo_lateral_m: float = 0.025
    direct_servo_yaw_rad: float = math.radians(2.0)
    direct_servo_min_speed_mps: float = 0.030
    direct_servo_kp: float = 0.90

    # Local state-lattice discretization. The planner uses curvature supplied by the
    # existing Ackermann controller, so wheelbase/steering geometry remains authoritative.
    primitive_length_m: float = 0.055
    planner_xy_resolution_m: float = 0.020
    planner_yaw_resolution_rad: float = math.radians(3.0)
    planner_goal_position_m: float = 0.040
    planner_goal_yaw_rad: float = math.radians(2.5)
    planner_search_bound_m: float = 0.75
    planner_max_nodes: int = 16000
    curvature_fractions: Tuple[float, ...] = (-1.0, -0.5, 0.0, 0.5, 1.0)

    # Cost terms only shape the path; they never shift the terminal target.
    reverse_path_cost: float = 0.16
    direction_switch_cost_m: float = 0.060
    curvature_path_cost: float = 0.05
    yaw_heuristic_m_per_rad: float = 0.30

    # Replan from fresh visual geometry instead of executing a stale open-loop path.
    replan_interval_s: float = 0.30

    # A short neutral hold prevents instantaneous forward/reverse switching. When a signed
    # measured longitudinal speed is supplied, reversal also waits until the chassis is
    # physically close to rest instead of trusting the previous command alone.
    direction_change_hold_s: float = 0.20
    direction_change_speed_epsilon_mps: float = 0.025

    # Local progress supervision is active only after the precision controller owns the
    # terminal phase. A normalized joint pose cost avoids independent x/yaw best values
    # repeatedly resetting stagnation while the overall terminal pose is not improving.
    progress_position_scale_m: float = 0.10
    progress_yaw_scale_rad: float = math.radians(5.0)
    progress_cost_improvement: float = 0.035
    stagnation_timeout_s: float = 15.0


@dataclass(frozen=True)
class TerminalPrecisionDecision:
    """One terminal precision decision."""

    mode: TerminalPrecisionMode
    authoritative: bool
    speed_mps: float
    curvature_1pm: float
    release_ready: bool
    request_reentry: bool
    position_error_m: float
    yaw_error_rad: float
    goal_x_m: float
    goal_y_m: float
    goal_yaw_rad: float
    best_position_error_m: float
    best_yaw_error_rad: float
    progress_cost: float
    best_progress_cost: float
    stagnation_s: float
    plan_length: int
    planner_expanded_nodes: int


@dataclass
class _Primitive:
    direction: int
    curvature_1pm: float
    remaining_m: float


class TerminalPrecisionController:
    """Measurement-driven local terminal controller with bidirectional lattice planning."""

    def __init__(self, config: Optional[TerminalPrecisionConfig] = None) -> None:
        self.config = config or TerminalPrecisionConfig()
        self._carried_pallet_pose_in_base: Optional[Pose2D] = None
        self._release_dwell_s = 0.0
        self._best_position_error_m = math.inf
        self._best_yaw_error_rad = math.inf
        self._progress_cost = math.inf
        self._best_progress_cost = math.inf
        self._stagnation_s = 0.0
        self._last_speed_mps = 0.0
        self._last_curvature_1pm = 0.0
        self._last_motion_direction = 0
        self._pending_direction = 0
        self._plan: List[_Primitive] = []
        self._plan_age_s = math.inf
        self._planner_expanded_nodes = 0
        self._direction_change_hold_remaining_s = 0.0
        self._precision_active = False

    @property
    def carried_pallet_pose_in_base(self) -> Optional[Pose2D]:
        return self._carried_pallet_pose_in_base

    def reset(self, carried_pallet_pose_in_base: Pose2D) -> None:
        """Start a terminal episode using a trusted measured/fused carried-pallet pose."""
        if not is_finite_pose(carried_pallet_pose_in_base):
            raise ValueError("carried_pallet_pose_in_base must contain only finite values")
        self._carried_pallet_pose_in_base = carried_pallet_pose_in_base
        self._reset_local_state()

    def clear(self) -> None:
        """Clear all terminal state after release or mission reset."""
        self._carried_pallet_pose_in_base = None
        self._reset_local_state()

    def update_carried_pallet_pose(self, carried_pallet_pose_in_base: Pose2D) -> None:
        """Refresh the carried-pallet pose from a trusted measured/fused observation.

        The update is optional. It exists so a post-pickup visual estimate can remove
        transport-induced pallet-on-fork drift when that measurement is available. MuJoCo
        truth must never be routed through this method in the competition controller.
        """
        if not is_finite_pose(carried_pallet_pose_in_base):
            raise ValueError("carried_pallet_pose_in_base must contain only finite values")
        self._carried_pallet_pose_in_base = carried_pallet_pose_in_base

    def mark_reentry_started(self) -> None:
        """Reset local planning/progress state when the outer FSM starts re-entry."""
        self._reset_local_state(preserve_carried_pose=True)

    def step(
        self,
        *,
        target_pose_in_base: Optional[Pose2D],
        dt_s: float,
        max_curvature_1pm: float,
        measurement_valid: bool = True,
        measurement_age_s: float = 0.0,
        actual_speed_mps: Optional[float] = None,
    ) -> TerminalPrecisionDecision:
        """Advance one precision-control step.

        The existing V9.2 safety/guard-brake layer must remain downstream. If available,
        pass measured vehicle speed as ``actual_speed_mps`` so motion-primitive progress
        remains correct when a guard brake suppresses the requested command.
        """
        dt_s = max(0.0, float(dt_s))
        self._consume_executed_distance(dt_s, actual_speed_mps)
        self._plan_age_s += dt_s
        self._planner_expanded_nodes = 0
        self._direction_change_hold_remaining_s = max(
            0.0, self._direction_change_hold_remaining_s - dt_s
        )

        if self._carried_pallet_pose_in_base is None:
            return self._inactive_decision()

        if (
            target_pose_in_base is None
            or not measurement_valid
            or measurement_age_s > self.config.max_measurement_age_s
            or not is_finite_pose(target_pose_in_base)
        ):
            self._release_dwell_s = 0.0
            self._set_command(0.0, 0.0)
            return self._decision_without_pose(TerminalPrecisionMode.WAIT_FOR_MEASUREMENT)

        release_error = predicted_release_error(
            self._carried_pallet_pose_in_base,
            target_pose_in_base,
        )
        position_error_m = math.hypot(release_error.x, release_error.y)
        yaw_error_rad = abs(wrap_angle(release_error.yaw))
        goal = desired_base_delta(
            target_pose_in_base,
            self._carried_pallet_pose_in_base,
        )

        inside_release_gate = (
            position_error_m <= self.config.release_position_m
            and yaw_error_rad <= self.config.release_yaw_rad
        )
        # Release readiness requires continuous residence inside the strict release gate.
        # A single accuracy excursion resets the dwell; release qualification must never
        # stitch together separated in-tolerance windows.
        if inside_release_gate:
            self._release_dwell_s += dt_s
        else:
            self._release_dwell_s = 0.0

        if self._release_dwell_s >= self.config.release_dwell_s:
            self._plan.clear()
            self._set_command(0.0, 0.0)
            return self._decision(
                mode=TerminalPrecisionMode.READY_TO_RELEASE,
                authoritative=True,
                release_ready=True,
                request_reentry=False,
                position_error_m=position_error_m,
                yaw_error_rad=yaw_error_rad,
                goal=goal,
            )

        if inside_release_gate:
            self._set_command(0.0, 0.0)
            return self._decision(
                mode=TerminalPrecisionMode.HOLD_FOR_RELEASE,
                authoritative=True,
                release_ready=False,
                request_reentry=False,
                position_error_m=position_error_m,
                yaw_error_rad=yaw_error_rad,
                goal=goal,
            )

        # Once precision ownership is active, a non-holonomic correction is allowed to
        # temporarily enlarge Euclidean error. Abort only at a wider safety envelope;
        # before precision ownership, keep the tighter outer-FSM re-entry envelope.
        position_abort_limit = (
            self.config.active_abort_position_m
            if self._precision_active
            else self.config.reentry_position_m
        )
        yaw_abort_limit = (
            self.config.active_abort_yaw_rad
            if self._precision_active
            else self.config.reentry_yaw_rad
        )
        outside_reentry_envelope = (
            position_error_m > position_abort_limit
            or yaw_error_rad > yaw_abort_limit
        )
        if outside_reentry_envelope:
            self._plan.clear()
            self._set_command(0.0, 0.0)
            return self._decision(
                mode=TerminalPrecisionMode.REQUEST_REENTRY,
                authoritative=True,
                release_ready=False,
                request_reentry=True,
                position_error_m=position_error_m,
                yaw_error_rad=yaw_error_rad,
                goal=goal,
            )

        # Enter the local precision controller only from the intended basin, then latch
        # ownership until release or explicit re-entry. A non-holonomic correction may
        # temporarily increase Euclidean position error while reducing yaw/lateral error;
        # dropping back to the outer controller during that maneuver would create chatter.
        if not self._precision_active:
            if (
                position_error_m > self.config.precision_entry_position_m
                or yaw_error_rad > self.config.precision_entry_yaw_rad
            ):
                self._set_command(0.0, 0.0)
                return self._decision(
                    mode=TerminalPrecisionMode.INACTIVE,
                    authoritative=False,
                    release_ready=False,
                    request_reentry=False,
                    position_error_m=position_error_m,
                    yaw_error_rad=yaw_error_rad,
                    goal=goal,
                )
            self._precision_active = True
            self._initialize_progress(position_error_m, yaw_error_rad)
        else:
            self._update_progress(position_error_m, yaw_error_rad, dt_s)

        if self._stagnation_s >= self.config.stagnation_timeout_s:
            self._plan.clear()
            self._set_command(0.0, 0.0)
            return self._decision(
                mode=TerminalPrecisionMode.REQUEST_REENTRY,
                authoritative=True,
                release_ready=False,
                request_reentry=True,
                position_error_m=position_error_m,
                yaw_error_rad=yaw_error_rad,
                goal=goal,
            )

        # Use a cheap closed-loop longitudinal servo when lateral and yaw residuals are
        # already small. This directly attacks the observed 0.14-0.15 m terminal plateau
        # without adding any fixed target offset and avoids unnecessary A* replanning.
        if (
            abs(goal.y) <= self.config.direct_servo_lateral_m
            and abs(wrap_angle(goal.yaw)) <= self.config.direct_servo_yaw_rad
            and abs(goal.x) > 1e-4
        ):
            desired_sign = 1 if goal.x >= 0.0 else -1
            if self._requires_direction_change_hold(desired_sign, actual_speed_mps):
                self._set_command(0.0, 0.0)
                return self._decision(
                    mode=TerminalPrecisionMode.DIRECTION_CHANGE_HOLD,
                    authoritative=True,
                    release_ready=False,
                    request_reentry=False,
                    position_error_m=position_error_m,
                    yaw_error_rad=yaw_error_rad,
                    goal=goal,
                )

            speed_limit = (
                self.config.cruise_forward_speed_mps
                if desired_sign > 0
                else self.config.cruise_reverse_speed_mps
            )
            if position_error_m <= self.config.fine_speed_position_m:
                speed_limit = min(speed_limit, self.config.fine_speed_mps)
            speed_mag = min(
                speed_limit,
                max(
                    self.config.direct_servo_min_speed_mps,
                    self.config.direct_servo_kp * abs(goal.x),
                ),
            )
            self._plan.clear()
            self._last_motion_direction = desired_sign
            self._set_command(desired_sign * speed_mag, 0.0)
            return self._decision(
                mode=(
                    TerminalPrecisionMode.SERVO_FORWARD
                    if desired_sign > 0
                    else TerminalPrecisionMode.SERVO_REVERSE
                ),
                authoritative=True,
                release_ready=False,
                request_reentry=False,
                position_error_m=position_error_m,
                yaw_error_rad=yaw_error_rad,
                goal=goal,
            )

        max_curvature_1pm = abs(float(max_curvature_1pm))
        if not math.isfinite(max_curvature_1pm) or max_curvature_1pm <= 1e-6:
            self._plan.clear()
            self._set_command(0.0, 0.0)
            return self._decision(
                mode=TerminalPrecisionMode.REQUEST_REENTRY,
                authoritative=True,
                release_ready=False,
                request_reentry=True,
                position_error_m=position_error_m,
                yaw_error_rad=yaw_error_rad,
                goal=goal,
            )

        if self._needs_replan():
            plan, expanded_nodes = self._plan_local_path(goal, max_curvature_1pm)
            self._planner_expanded_nodes = expanded_nodes
            self._plan_age_s = 0.0
            self._plan = plan
            if not self._plan:
                self._set_command(0.0, 0.0)
                return self._decision(
                    mode=TerminalPrecisionMode.REQUEST_REENTRY,
                    authoritative=True,
                    release_ready=False,
                    request_reentry=True,
                    position_error_m=position_error_m,
                    yaw_error_rad=yaw_error_rad,
                    goal=goal,
                )

        primitive = self._plan[0]
        desired_sign = 1 if primitive.direction >= 0 else -1

        if self._requires_direction_change_hold(desired_sign, actual_speed_mps):
            self._set_command(0.0, 0.0)
            return self._decision(
                mode=TerminalPrecisionMode.DIRECTION_CHANGE_HOLD,
                authoritative=True,
                release_ready=False,
                request_reentry=False,
                position_error_m=position_error_m,
                yaw_error_rad=yaw_error_rad,
                goal=goal,
            )

        speed_mag = (
            self.config.fine_speed_mps
            if position_error_m <= self.config.fine_speed_position_m
            else (
                self.config.cruise_forward_speed_mps
                if desired_sign > 0
                else self.config.cruise_reverse_speed_mps
            )
        )
        speed_mps = desired_sign * speed_mag
        self._last_motion_direction = desired_sign
        self._set_command(speed_mps, primitive.curvature_1pm)
        mode = (
            TerminalPrecisionMode.SERVO_FORWARD
            if desired_sign > 0
            else TerminalPrecisionMode.SERVO_REVERSE
        )
        return self._decision(
            mode=mode,
            authoritative=True,
            release_ready=False,
            request_reentry=False,
            position_error_m=position_error_m,
            yaw_error_rad=yaw_error_rad,
            goal=goal,
        )

    def _reset_local_state(self, preserve_carried_pose: bool = False) -> None:
        carried = self._carried_pallet_pose_in_base if preserve_carried_pose else None
        self._release_dwell_s = 0.0
        self._best_position_error_m = math.inf
        self._best_yaw_error_rad = math.inf
        self._progress_cost = math.inf
        self._best_progress_cost = math.inf
        self._stagnation_s = 0.0
        self._last_speed_mps = 0.0
        self._last_curvature_1pm = 0.0
        self._last_motion_direction = 0
        self._pending_direction = 0
        self._plan = []
        self._plan_age_s = math.inf
        self._planner_expanded_nodes = 0
        self._direction_change_hold_remaining_s = 0.0
        self._precision_active = False
        if preserve_carried_pose:
            self._carried_pallet_pose_in_base = carried

    def _set_command(self, speed_mps: float, curvature_1pm: float) -> None:
        self._last_speed_mps = float(speed_mps)
        self._last_curvature_1pm = float(curvature_1pm)

    def _consume_executed_distance(
        self,
        dt_s: float,
        actual_speed_mps: Optional[float],
    ) -> None:
        if not self._plan or dt_s <= 0.0:
            return
        if actual_speed_mps is None:
            distance = abs(self._last_speed_mps) * dt_s
        else:
            # Only consume the planned primitive when measured longitudinal motion agrees
            # with the commanded direction. Inertia during a direction change must not
            # advance a reverse primitive while the chassis is still moving forward.
            command_sign = 0.0
            if self._last_speed_mps > 1e-9:
                command_sign = 1.0
            elif self._last_speed_mps < -1e-9:
                command_sign = -1.0
            projected_speed = command_sign * float(actual_speed_mps)
            distance = max(0.0, projected_speed) * dt_s
        while self._plan and distance > 0.0:
            primitive = self._plan[0]
            consumed = min(distance, primitive.remaining_m)
            primitive.remaining_m -= consumed
            distance -= consumed
            if primitive.remaining_m <= 1e-5:
                self._plan.pop(0)

    def _pose_progress_cost(self, position_error_m: float, yaw_error_rad: float) -> float:
        cfg = self.config
        position_term = position_error_m / max(cfg.progress_position_scale_m, 1e-6)
        yaw_term = yaw_error_rad / max(cfg.progress_yaw_scale_rad, 1e-6)
        return math.hypot(position_term, yaw_term)

    def _initialize_progress(self, position_error_m: float, yaw_error_rad: float) -> None:
        self._best_position_error_m = position_error_m
        self._best_yaw_error_rad = yaw_error_rad
        self._progress_cost = self._pose_progress_cost(position_error_m, yaw_error_rad)
        self._best_progress_cost = self._progress_cost
        self._stagnation_s = 0.0

    def _update_progress(
        self,
        position_error_m: float,
        yaw_error_rad: float,
        dt_s: float,
    ) -> None:
        self._best_position_error_m = min(self._best_position_error_m, position_error_m)
        self._best_yaw_error_rad = min(self._best_yaw_error_rad, yaw_error_rad)
        self._progress_cost = self._pose_progress_cost(position_error_m, yaw_error_rad)
        if self._progress_cost <= self._best_progress_cost - self.config.progress_cost_improvement:
            self._best_progress_cost = self._progress_cost
            self._stagnation_s = 0.0
        else:
            self._best_progress_cost = min(self._best_progress_cost, self._progress_cost)
            self._stagnation_s += dt_s

    def _needs_replan(self) -> bool:
        # A saved local goal is expressed in the base frame that existed when the plan was
        # built. Comparing it directly with a later base-frame goal is frame-inconsistent:
        # normal ego motion alone changes the coordinates. Replanning is therefore driven
        # only by plan exhaustion and a bounded receding-horizon interval.
        if not self._plan:
            return True
        return self._plan_age_s >= self.config.replan_interval_s

    def _requires_direction_change_hold(
        self,
        desired_sign: int,
        actual_speed_mps: Optional[float],
    ) -> bool:
        cfg = self.config

        observed_direction = self._last_motion_direction
        if (
            observed_direction == 0
            and actual_speed_mps is not None
            and abs(float(actual_speed_mps)) > cfg.direction_change_speed_epsilon_mps
        ):
            observed_direction = 1 if float(actual_speed_mps) > 0.0 else -1

        if self._pending_direction == 0 and observed_direction not in (0, desired_sign):
            self._pending_direction = desired_sign
            self._direction_change_hold_remaining_s = cfg.direction_change_hold_s

        if self._pending_direction == 0:
            return False

        self._direction_change_hold_remaining_s = max(
            0.0,
            self._direction_change_hold_remaining_s,
        )

        moving = False
        if actual_speed_mps is not None:
            moving = abs(float(actual_speed_mps)) > cfg.direction_change_speed_epsilon_mps

        if self._direction_change_hold_remaining_s <= 0.0 and not moving:
            self._last_motion_direction = self._pending_direction
            self._pending_direction = 0
            return False

        return True

    def _plan_local_path(
        self,
        goal: Pose2D,
        max_curvature_1pm: float,
    ) -> Tuple[List[_Primitive], int]:
        """Plan a short bidirectional Ackermann-compatible local state-lattice path."""
        cfg = self.config
        step_m = cfg.primitive_length_m
        xy_res = cfg.planner_xy_resolution_m
        yaw_res = cfg.planner_yaw_resolution_rad
        search_bound = max(
            cfg.planner_search_bound_m,
            abs(goal.x) + 0.25,
            abs(goal.y) + 0.25,
        )
        curvatures = tuple(
            fraction * max_curvature_1pm for fraction in cfg.curvature_fractions
        )
        directions: Sequence[int] = (1, -1)

        def state_key(x: float, y: float, yaw: float, direction: int) -> Tuple[int, int, int, int]:
            return (
                round(x / xy_res),
                round(y / xy_res),
                round(wrap_angle(yaw) / yaw_res),
                direction,
            )

        def heuristic(x: float, y: float, yaw: float) -> float:
            return (
                math.hypot(goal.x - x, goal.y - y)
                + cfg.yaw_heuristic_m_per_rad * abs(wrap_angle(goal.yaw - yaw))
            )

        start_direction = -1 if self._last_speed_mps < -1e-6 else 1
        start_key = state_key(0.0, 0.0, 0.0, start_direction)
        queue: List[Tuple[float, float, int, float, float, float, int]] = []
        counter = 0
        heapq.heappush(
            queue,
            (heuristic(0.0, 0.0, 0.0), 0.0, counter, 0.0, 0.0, 0.0, start_direction),
        )
        best_cost: Dict[Tuple[int, int, int, int], float] = {start_key: 0.0}
        parent: Dict[
            Tuple[int, int, int, int],
            Tuple[Tuple[int, int, int, int], Tuple[int, float]],
        ] = {}
        expanded = 0
        goal_key: Optional[Tuple[int, int, int, int]] = None

        while queue and expanded < cfg.planner_max_nodes:
            _, cost, _, x, y, yaw, direction = heapq.heappop(queue)
            key = state_key(x, y, yaw, direction)
            if cost > best_cost.get(key, math.inf) + 1e-9:
                continue
            expanded += 1

            if (
                math.hypot(goal.x - x, goal.y - y) <= cfg.planner_goal_position_m
                and abs(wrap_angle(goal.yaw - yaw)) <= cfg.planner_goal_yaw_rad
            ):
                goal_key = key
                break

            for next_direction in directions:
                for curvature in curvatures:
                    next_pose = self._advance_pose(
                        Pose2D(x, y, yaw),
                        next_direction,
                        curvature,
                        step_m,
                    )
                    if (
                        abs(next_pose.x) > search_bound
                        or abs(next_pose.y) > search_bound
                    ):
                        continue

                    next_key = state_key(
                        next_pose.x,
                        next_pose.y,
                        next_pose.yaw,
                        next_direction,
                    )
                    normalized_curvature = abs(curvature) / max_curvature_1pm
                    step_cost = step_m * (
                        1.0
                        + (cfg.reverse_path_cost if next_direction < 0 else 0.0)
                        + cfg.curvature_path_cost * normalized_curvature
                    )
                    if next_direction != direction:
                        step_cost += cfg.direction_switch_cost_m
                    next_cost = cost + step_cost

                    if next_cost + 1e-9 >= best_cost.get(next_key, math.inf):
                        continue

                    best_cost[next_key] = next_cost
                    parent[next_key] = (key, (next_direction, curvature))
                    counter += 1
                    heapq.heappush(
                        queue,
                        (
                            next_cost
                            + heuristic(next_pose.x, next_pose.y, next_pose.yaw),
                            next_cost,
                            counter,
                            next_pose.x,
                            next_pose.y,
                            next_pose.yaw,
                            next_direction,
                        ),
                    )

        if goal_key is None:
            return [], expanded

        reversed_actions: List[Tuple[int, float]] = []
        current_key = goal_key
        while current_key != start_key:
            record = parent.get(current_key)
            if record is None:
                return [], expanded
            previous_key, action = record
            reversed_actions.append(action)
            current_key = previous_key
        reversed_actions.reverse()

        # Merge adjacent equal actions so the execution layer receives stable commands.
        plan: List[_Primitive] = []
        for direction, curvature in reversed_actions:
            if (
                plan
                and plan[-1].direction == direction
                and abs(plan[-1].curvature_1pm - curvature) <= 1e-9
            ):
                plan[-1].remaining_m += step_m
            else:
                plan.append(
                    _Primitive(
                        direction=direction,
                        curvature_1pm=curvature,
                        remaining_m=step_m,
                    )
                )
        return plan, expanded

    @staticmethod
    def _advance_pose(
        pose: Pose2D,
        direction: int,
        curvature_1pm: float,
        distance_m: float,
    ) -> Pose2D:
        signed_distance = float(direction) * distance_m
        if abs(curvature_1pm) <= 1e-10:
            return Pose2D(
                x=pose.x + signed_distance * math.cos(pose.yaw),
                y=pose.y + signed_distance * math.sin(pose.yaw),
                yaw=pose.yaw,
            )

        delta_yaw = signed_distance * curvature_1pm
        radius = 1.0 / curvature_1pm
        local_dx = radius * math.sin(delta_yaw)
        local_dy = radius * (1.0 - math.cos(delta_yaw))
        c = math.cos(pose.yaw)
        s = math.sin(pose.yaw)
        return Pose2D(
            x=pose.x + c * local_dx - s * local_dy,
            y=pose.y + s * local_dx + c * local_dy,
            yaw=wrap_angle(pose.yaw + delta_yaw),
        )

    def _decision(
        self,
        *,
        mode: TerminalPrecisionMode,
        authoritative: bool,
        release_ready: bool,
        request_reentry: bool,
        position_error_m: float,
        yaw_error_rad: float,
        goal: Pose2D,
    ) -> TerminalPrecisionDecision:
        return TerminalPrecisionDecision(
            mode=mode,
            authoritative=authoritative,
            speed_mps=self._last_speed_mps,
            curvature_1pm=self._last_curvature_1pm,
            release_ready=release_ready,
            request_reentry=request_reentry,
            position_error_m=position_error_m,
            yaw_error_rad=yaw_error_rad,
            goal_x_m=goal.x,
            goal_y_m=goal.y,
            goal_yaw_rad=goal.yaw,
            best_position_error_m=self._best_position_error_m,
            best_yaw_error_rad=self._best_yaw_error_rad,
            progress_cost=self._progress_cost,
            best_progress_cost=self._best_progress_cost,
            stagnation_s=self._stagnation_s,
            plan_length=len(self._plan),
            planner_expanded_nodes=self._planner_expanded_nodes,
        )

    def _decision_without_pose(self, mode: TerminalPrecisionMode) -> TerminalPrecisionDecision:
        return TerminalPrecisionDecision(
            mode=mode,
            authoritative=True,
            speed_mps=0.0,
            curvature_1pm=0.0,
            release_ready=False,
            request_reentry=False,
            position_error_m=math.inf,
            yaw_error_rad=math.inf,
            goal_x_m=math.nan,
            goal_y_m=math.nan,
            goal_yaw_rad=math.nan,
            best_position_error_m=self._best_position_error_m,
            best_yaw_error_rad=self._best_yaw_error_rad,
            progress_cost=self._progress_cost,
            best_progress_cost=self._best_progress_cost,
            stagnation_s=self._stagnation_s,
            plan_length=len(self._plan),
            planner_expanded_nodes=self._planner_expanded_nodes,
        )

    def _inactive_decision(self) -> TerminalPrecisionDecision:
        decision = self._decision_without_pose(TerminalPrecisionMode.INACTIVE)
        return TerminalPrecisionDecision(
            **{**decision.__dict__, "authoritative": False}
        )
