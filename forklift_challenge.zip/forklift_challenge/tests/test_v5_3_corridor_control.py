"""V5.3 corridor-reference steering and recovery-runway tests."""

from __future__ import annotations

import importlib.util
import math
from pathlib import Path
import xml.etree.ElementTree as ET

import pytest
import yaml

from control.docking_controller import DockingController
from interfaces.observation import ForkliftObservation, Pose3D
from task.pickup_state_machine import (
    PickupParameters,
    PickupState,
    PickupStateMachine,
)


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def pose(x=0.0, y=0.0, yaw=0.0):
    return Pose3D(
        x=float(x),
        y=float(y),
        z=0.0,
        roll=0.0,
        pitch=0.0,
        yaw=float(yaw),
    )


def pose_from_axis(*, x: float, lateral: float, yaw: float) -> Pose3D:
    y = (lateral + x * math.sin(yaw)) / math.cos(yaw)
    return pose(x=x, y=y, yaw=yaw)


def observation(
    *,
    sim_time: float,
    pallet_pose: Pose3D,
    vehicle_x: float = 0.0,
    steering_left: float = 0.0,
    steering_right: float = 0.0,
) -> ForkliftObservation:
    return ForkliftObservation(
        sim_time=float(sim_time),
        vehicle_pose_world=pose(vehicle_x, 0.0),
        vehicle_linear_velocity=(0.0, 0.0, 0.0),
        vehicle_angular_velocity=(0.0, 0.0, 0.0),
        steering_left=float(steering_left),
        steering_right=float(steering_right),
        front_wheel_speed_left=0.0,
        front_wheel_speed_right=0.0,
        lift_position=0.04,
        lift_velocity=0.0,
        pallet_pose_world=pose(3.2),
        pallet_pose_in_base=pallet_pose,
        placement_pose_in_base=pose(5.0, -1.0),
        fork_contact_count=0,
        load_state="GROUND",
    )


def load_config():
    return yaml.safe_load(
        (PROJECT_ROOT / "configs" / "vehicle_v5_3.yaml").read_text(
            encoding="utf-8"
        )
    )


def load_controller() -> DockingController:
    values = load_config()["controller"]
    return DockingController(
        distance_gain=float(values["distance_gain"]),
        heading_gain=float(values["heading_gain"]),
        yaw_gain=float(values["yaw_gain"]),
        lateral_gain=float(values["lateral_gain"]),
        lookahead_distance=float(values["lookahead_distance"]),
        maximum_steering=float(values["maximum_steering"]),
        minimum_creep_speed=float(values["minimum_creep_speed"]),
        heading_slowdown_angle=float(values["heading_slowdown_angle"]),
        yaw_slowdown_angle=float(values["yaw_slowdown_angle"]),
        minimum_alignment_scale=float(values["minimum_alignment_scale"]),
    )


def load_machine() -> PickupStateMachine:
    config = load_config()
    return PickupStateMachine(
        parameters=PickupParameters.from_mapping(config["autonomy"]),
        docking_controller=load_controller(),
    )


def test_reference_feedback_avoids_origin_yaw_control_conflict() -> None:
    controller = load_controller()
    pallet = pose_from_axis(
        x=3.284,
        lateral=0.233,
        yaw=math.radians(-5.82),
    )
    legacy = controller.axis_command(
        pallet,
        target_distance=2.1,
        maximum_speed=0.10,
        lift_target=0.04,
    )
    referenced = controller.axis_command(
        pallet,
        target_distance=2.1,
        maximum_speed=0.10,
        lift_target=0.04,
        lateral_reference_distance=1.54,
        lateral_gain_override=1.0,
        yaw_gain_override=0.8,
        lookahead_distance_override=0.8,
    )
    assert legacy.action.steering_command > 0.10
    assert abs(referenced.action.steering_command) < 0.05


def test_reference_feedback_countersteers_large_negative_yaw() -> None:
    controller = load_controller()
    pallet = pose_from_axis(
        x=3.282,
        lateral=0.272,
        yaw=math.radians(-10.95),
    )
    legacy = controller.axis_command(
        pallet,
        target_distance=2.1,
        maximum_speed=0.10,
        lift_target=0.04,
    )
    referenced = controller.axis_command(
        pallet,
        target_distance=2.1,
        maximum_speed=0.10,
        lift_target=0.04,
        lateral_reference_distance=1.54,
        lateral_gain_override=1.0,
        yaw_gain_override=0.8,
        lookahead_distance_override=0.8,
    )
    assert legacy.action.steering_command > 0.0
    assert referenced.action.steering_command < -0.10


def test_approach_state_uses_projected_fork_reference() -> None:
    machine = load_machine()
    machine.state = PickupState.APPROACH
    machine._state_enter_time = 0.0
    machine._reset_progress(0.0)
    pallet = pose_from_axis(
        x=3.50,
        lateral=0.233,
        yaw=math.radians(-5.82),
    )
    decision = machine.step(
        observation(sim_time=0.5, pallet_pose=pallet)
    )
    assert decision.state == PickupState.APPROACH
    assert decision.corridor_error is not None
    assert abs(decision.action.steering_command) < 0.05
    assert "projected fork corridor" in decision.status


def test_dynamic_recovery_accepts_rebuilt_runway() -> None:
    machine = load_machine()
    machine.state = PickupState.RECOVER_REVERSE
    machine._state_enter_time = 0.0
    machine._recovery_start_xy = (0.0, 0.0)
    machine._recovery_motion_start_time = 0.0
    machine._recovery_count = 1
    decision = machine.step(
        observation(
            sim_time=5.0,
            pallet_pose=pose(3.30, 0.10, 0.05),
            vehicle_x=-0.70,
        )
    )
    assert decision.state == PickupState.APPROACH
    assert decision.action.speed_target == 0.0
    assert "runway rebuilt" in decision.status


def test_v53_model_has_stronger_steering_actuators() -> None:
    model_path = (
        PROJECT_ROOT / "assets" / "forklift" / "forklift_v5_3.xml"
    )
    root = ET.parse(model_path).getroot()
    actuators = {
        element.attrib["name"]: element
        for element in root.findall("./actuator/position")
    }
    for name in (
        "rear_left_steer_position",
        "rear_right_steer_position",
    ):
        actuator = actuators[name]
        assert float(actuator.attrib["kp"]) >= 6000.0
        low, high = map(float, actuator.attrib["forcerange"].split())
        assert low <= -8000.0
        assert high >= 8000.0


@pytest.mark.parametrize(
    "filename, config_name",
    [
        ("run_forklift_v5_3.py", "vehicle_v5_3.yaml"),
        ("run_v5_3_batch.py", "vehicle_v5_3.yaml"),
    ],
)
def test_wrapper_uses_v53_config(filename: str, config_name: str) -> None:
    path = PROJECT_ROOT / "scripts" / filename
    spec = importlib.util.spec_from_file_location(
        f"_test_{path.stem}",
        path,
    )
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    assert module.DEFAULT_CONFIG.name == config_name
