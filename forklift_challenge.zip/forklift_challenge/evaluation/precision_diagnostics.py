"""V9.2.3 terminal-placement precision diagnostics.

This module is evaluation-only.  It never changes a control target.  It records
estimated and ground-truth placement error at physically meaningful milestones
so terminal-control, perception, lowering and fork-withdrawal error can be
separated before further controller tuning.
"""

from __future__ import annotations

import math
from typing import Any


def _wrap_angle(angle: float) -> float:
    return (float(angle) + math.pi) % (2.0 * math.pi) - math.pi


def placement_error_components(observation) -> dict[str, float]:
    """Return pallet error relative to placement target in the target frame."""
    target = observation.placement_pose_in_base
    pallet = observation.pallet_pose_in_base
    dx = float(pallet.x) - float(target.x)
    dy = float(pallet.y) - float(target.y)
    yaw = float(target.yaw)
    c = math.cos(yaw)
    s = math.sin(yaw)
    longitudinal = c * dx + s * dy
    lateral = -s * dx + c * dy
    yaw_error = _wrap_angle(float(pallet.yaw) - yaw)
    return {
        "position_error_m": math.hypot(dx, dy),
        "longitudinal_error_m": longitudinal,
        "lateral_error_m": lateral,
        "yaw_error_deg": math.degrees(yaw_error),
    }


def _pallet_world_pose(observation) -> dict[str, float]:
    pose = observation.pallet_pose_world
    return {
        "x": float(pose.x),
        "y": float(pose.y),
        "yaw": float(pose.yaw),
    }


def _translation(a: dict[str, Any] | None, b: dict[str, Any] | None) -> float | None:
    if a is None or b is None:
        return None
    pa = a.get("truth_pallet_world")
    pb = b.get("truth_pallet_world")
    if not isinstance(pa, dict) or not isinstance(pb, dict):
        return None
    return math.hypot(float(pb["x"]) - float(pa["x"]), float(pb["y"]) - float(pa["y"]))


class PrecisionDiagnosticsRecorder:
    """Capture one snapshot per terminal milestone and derive an error budget."""

    def __init__(
        self,
        *,
        enabled: bool = True,
        competition_position_limit_m: float = 0.10,
        competition_yaw_limit_deg: float = 5.0,
        capture_stages: list[str] | tuple[str, ...] | None = None,
    ) -> None:
        self.enabled = bool(enabled)
        self.competition_position_limit_m = float(competition_position_limit_m)
        self.competition_yaw_limit_deg = float(competition_yaw_limit_deg)
        self.capture_stages = (
            None if capture_stages is None
            else {str(stage) for stage in capture_stages}
        )
        self._stages: dict[str, dict[str, Any]] = {}

    @classmethod
    def from_mapping(cls, values: dict[str, Any] | None) -> "PrecisionDiagnosticsRecorder":
        values = values or {}
        return cls(
            enabled=bool(values.get("enabled", True)),
            competition_position_limit_m=float(
                values.get("competition_position_limit_m", 0.10)
            ),
            competition_yaw_limit_deg=float(
                values.get("competition_yaw_limit_deg", 5.0)
            ),
            capture_stages=values.get("capture_stages"),
        )

    def capture(self, stage: str, *, sim_time: float, truth, estimated) -> None:
        if not self.enabled or stage in self._stages:
            return
        if self.capture_stages is not None and stage not in self.capture_stages:
            return
        truth_error = placement_error_components(truth)
        estimated_error = placement_error_components(estimated)
        self._stages[str(stage)] = {
            "sim_time": float(sim_time),
            "truth": truth_error,
            "estimated": estimated_error,
            "truth_pallet_world": _pallet_world_pose(truth),
            "truth_competition_ready": (
                truth_error["position_error_m"] < self.competition_position_limit_m
                and abs(truth_error["yaw_error_deg"]) < self.competition_yaw_limit_deg
            ),
            "estimated_competition_ready": (
                estimated_error["position_error_m"] < self.competition_position_limit_m
                and abs(estimated_error["yaw_error_deg"])
                < self.competition_yaw_limit_deg
            ),
        }

    def has(self, stage: str) -> bool:
        return stage in self._stages

    def stage(self, stage: str) -> dict[str, Any] | None:
        return self._stages.get(stage)

    @staticmethod
    def _truth_position(stage: dict[str, Any] | None) -> float | None:
        if stage is None:
            return None
        return float(stage["truth"]["position_error_m"])

    def finalize(self) -> dict[str, Any]:
        stages = dict(self._stages)
        terminal_entry = stages.get("terminal_entry")
        release = stages.get("release_command")
        grounded = stages.get("grounded")
        retreat = stages.get("retreat_start")
        final = stages.get("final")

        release_estimation_position_gap = None
        release_estimation_yaw_gap = None
        if release is not None:
            release_estimation_position_gap = abs(
                float(release["estimated"]["position_error_m"])
                - float(release["truth"]["position_error_m"])
            )
            release_estimation_yaw_gap = abs(
                abs(float(release["estimated"]["yaw_error_deg"]))
                - abs(float(release["truth"]["yaw_error_deg"]))
            )

        def delta(a: dict[str, Any] | None, b: dict[str, Any] | None) -> float | None:
            va = self._truth_position(a)
            vb = self._truth_position(b)
            if va is None or vb is None:
                return None
            return vb - va

        release_false_positive = bool(
            release is not None
            and release.get("estimated_competition_ready", False)
            and not release.get("truth_competition_ready", False)
        )
        release_false_negative = bool(
            release is not None
            and release.get("truth_competition_ready", False)
            and not release.get("estimated_competition_ready", False)
        )

        return {
            "schema": "forklift_v9_3_0_precision_diagnostics_v1",
            "competition_position_limit_m": self.competition_position_limit_m,
            "competition_yaw_limit_deg": self.competition_yaw_limit_deg,
            "stages": stages,
            "derived": {
                "terminal_to_release_position_delta_m": delta(terminal_entry, release),
                "release_to_ground_position_delta_m": delta(release, grounded),
                "retreat_to_final_position_delta_m": delta(retreat, final),
                "lowering_pallet_translation_m": _translation(release, grounded),
                "withdrawal_pallet_translation_m": _translation(retreat, final),
                "release_estimation_position_gap_m": release_estimation_position_gap,
                "release_estimation_yaw_gap_deg": release_estimation_yaw_gap,
                "release_false_positive": release_false_positive,
                "release_false_negative": release_false_negative,
            },
        }
