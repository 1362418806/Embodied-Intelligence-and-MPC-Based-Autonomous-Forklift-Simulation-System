"""Ackermann steering helpers for a rear-steered counterbalanced forklift."""

from __future__ import annotations

from dataclasses import dataclass
import math


@dataclass(frozen=True)
class RearSteeringAngles:
    """Physical rear-wheel steering angles in radians.

    Positive joint angle turns a wheel toward vehicle-left. The public
    steering command uses the more intuitive convention that positive means
    the vehicle should curve left while moving forward. A rear-steered
    forklift therefore uses physical wheel angles with the opposite sign.
    """

    left: float
    right: float


def rear_ackermann_angles(
    steering_command: float,
    wheelbase: float,
    rear_track: float,
    epsilon: float = 1e-9,
) -> RearSteeringAngles:
    """Convert a virtual center steering command to rear-wheel angles.

    Args:
        steering_command: Virtual steering angle. Positive means a left turn
            for forward vehicle motion.
        wheelbase: Distance between front and rear axle centers in metres.
        rear_track: Distance between rear wheel centers in metres.
        epsilon: Small-angle threshold.
    """
    if wheelbase <= 0:
        raise ValueError("wheelbase must be positive")
    if rear_track <= 0:
        raise ValueError("rear_track must be positive")

    if abs(steering_command) <= epsilon:
        return RearSteeringAngles(0.0, 0.0)

    turn_sign = 1.0 if steering_command > 0 else -1.0
    center_angle = abs(steering_command)
    radius = wheelbase / math.tan(center_angle)

    half_track = rear_track / 2.0
    inner_denominator = max(radius - half_track, 1e-6)
    outer_denominator = radius + half_track

    inner = math.atan(wheelbase / inner_denominator)
    outer = math.atan(wheelbase / outer_denominator)

    # Rear steering is opposite to the desired body curvature sign.
    physical_sign = -turn_sign
    if turn_sign > 0:  # left turn: left rear wheel is inner
        return RearSteeringAngles(
            left=physical_sign * inner,
            right=physical_sign * outer,
        )

    # right turn: right rear wheel is inner
    return RearSteeringAngles(
        left=physical_sign * outer,
        right=physical_sign * inner,
    )


def front_drive_angular_speeds(
    vehicle_speed: float,
    steering_command: float,
    wheelbase: float,
    front_track: float,
    wheel_radius: float,
) -> tuple[float, float]:
    """Return left/right front-wheel angular speed targets in rad/s.

    Vehicle speed is defined at the front axle center. Positive vehicle speed
    means forward motion along the forklift +x axis. Positive steering command
    means left curvature while moving forward.
    """
    if wheelbase <= 0:
        raise ValueError("wheelbase must be positive")
    if front_track <= 0:
        raise ValueError("front_track must be positive")
    if wheel_radius <= 0:
        raise ValueError("wheel_radius must be positive")

    yaw_rate = vehicle_speed * math.tan(steering_command) / wheelbase
    half_track = front_track / 2.0
    left_linear_speed = vehicle_speed - yaw_rate * half_track
    right_linear_speed = vehicle_speed + yaw_rate * half_track
    return (
        left_linear_speed / wheel_radius,
        right_linear_speed / wheel_radius,
    )
