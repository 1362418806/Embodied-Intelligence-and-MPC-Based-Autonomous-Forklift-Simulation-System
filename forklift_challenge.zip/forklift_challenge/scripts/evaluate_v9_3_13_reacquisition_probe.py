"""Gate V9.3.13 physical progression on a real terminal observer handoff."""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("summary", type=Path)
    args = parser.parse_args()
    summary = json.loads(args.summary.read_text(encoding="utf-8"))
    raw = int(summary.get("total_terminal_load_reacquisition_raw_detection_count", 0))
    consensus = int(summary.get("total_terminal_load_reacquisition_consensus_update_count", 0))
    updates = int(summary.get("total_terminal_load_reacquisition_observer_update_count", 0))
    rejects = int(summary.get("total_terminal_load_reacquisition_observer_rejection_count", 0))
    consensus_entries = int(summary.get("total_certified_basin_consensus_enter_count", 999))
    witness_fp = int(summary.get("release_witness_false_positive_count", 999))
    execution_fp = int(summary.get("release_execution_false_positive_count", 999))
    derived = summary.get("precision_diagnostics", {}).get("derived", {})
    controller_fp = int(derived.get("controller_certified_release_false_positive_count", 999))
    checks = {
        "raw_detection>0": raw > 0,
        "temporal_consensus>0": consensus > 0,
        "observer_update>0": updates > 0,
        "observer_accounting": consensus == updates + rejects,
        "consensus_release_entries=0": consensus_entries == 0,
        "controller_fp=0": controller_fp == 0,
        "witness_fp=0": witness_fp == 0,
        "execution_fp=0": execution_fp == 0,
    }
    passed = all(checks.values())
    print(f"V9.3.13 reacquisition probe: {'PASS' if passed else 'FAIL'}")
    for name, ok in checks.items():
        print(f"  {'PASS' if ok else 'FAIL'} {name}")
    print(f"  chain: raw={raw} consensus={consensus} observer_accept={updates} observer_reject={rejects}")
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
