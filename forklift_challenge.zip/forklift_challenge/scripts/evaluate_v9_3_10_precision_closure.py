"""Evaluate the V9.3.10 weak-guide precision-closure promotion gate."""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("summary", type=Path, help="Path to batch summary.json")
    args = parser.parse_args()
    summary = json.loads(args.summary.read_text(encoding="utf-8"))
    episodes = int(summary.get("episode_count", 0))
    derived = (
        summary.get("precision_diagnostics", {}).get("derived", {})
        if isinstance(summary.get("precision_diagnostics", {}), dict)
        else {}
    )
    checks = {
        "episodes>=10": episodes >= 10,
        "mission>=90%": float(summary.get("success_rate", 0.0)) >= 0.90,
        "strict>=80%": float(summary.get("competition_precision_success_rate", 0.0)) >= 0.80,
        "terminal_budget<=10%": float(summary.get("terminal_budget_exhausted_rate", 1.0)) <= 0.10,
        "truth_ready_uncertified<=20%": float(
            derived.get("controller_truth_ready_uncertified_rate", 1.0)
        ) <= 0.20,
        "mpc_ownership>=90%": float(summary.get("terminal_mpc_ownership_rate", 0.0)) >= 0.90,
        "align_max<10s": float(summary.get("maximum_terminal_ownership_align_seconds", 1e9)) < 10.0,
        "first_cert_to_release<3s": (
            summary.get("average_release_supervisor_certification_to_release_seconds") is not None
            and float(summary["average_release_supervisor_certification_to_release_seconds"]) < 3.0
        ),
        "release_witness_truth_fp=0": int(summary.get("release_witness_false_positive_count", 999)) == 0,
        "release_execution_truth_fp<=1": int(summary.get("release_execution_false_positive_count", 999)) <= 1,
        "witness_to_execute<1s": (
            summary.get("average_release_witness_to_execute_seconds") is not None
            and float(summary["average_release_witness_to_execute_seconds"]) < 1.0
        ),
    }
    passed = all(checks.values())
    print(f"V9.3.10 precision closure: {'PASS' if passed else 'FAIL'}")
    for name, ok in checks.items():
        print(f"  {'PASS' if ok else 'FAIL'} {name}")
    print(
        "  metrics: "
        f"mission={float(summary.get('success_rate', 0.0)):.1%}, "
        f"strict={float(summary.get('competition_precision_success_rate', 0.0)):.1%}, "
        f"terminal_budget={float(summary.get('terminal_budget_exhausted_rate', 0.0)):.1%}, "
        f"ownership={float(summary.get('terminal_mpc_ownership_rate', 0.0)):.1%}, "
        f"truth_ready_uncertified={float(derived.get('controller_truth_ready_uncertified_rate', 0.0)):.1%}, "
        f"witness_fp={summary.get('release_witness_false_positive_count')}, "
        f"execution_fp={summary.get('release_execution_false_positive_count')}"
    )
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
