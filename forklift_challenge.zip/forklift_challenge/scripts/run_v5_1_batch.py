"""Run deterministic and randomized v5.1 pickup episodes without a viewer."""

from __future__ import annotations

import argparse
from datetime import datetime
from pathlib import Path
import sys
from typing import Any

import yaml


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from evaluation.metrics import EpisodeResult, write_results  # noqa: E402
from scenarios.randomization import (  # noqa: E402
    Scenario,
    ScenarioSampler,
    named_scenario,
)
from simulator.batch_episode import run_pickup_episode  # noqa: E402


DEFAULT_CONFIG = PROJECT_ROOT / "configs" / "vehicle_v5_1.yaml"
VALIDATION_SCENARIOS = (
    "baseline",
    "lateral_left",
    "lateral_right",
    "yaw_left",
    "yaw_right",
    "combined",
)


def load_config(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise FileNotFoundError(f"configuration file does not exist: {path}")
    with path.open("r", encoding="utf-8") as stream:
        config = yaml.safe_load(stream)
    if not isinstance(config, dict):
        raise ValueError("configuration root must be a mapping")
    for section in (
        "model",
        "drive",
        "lift",
        "pickup",
        "safety",
        "controller",
        "autonomy",
        "randomization",
        "batch",
    ):
        if section not in config:
            raise KeyError(f"missing required configuration section: {section}")
    return config


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--episodes", type=int, default=12)
    parser.add_argument("--seed", type=int)
    parser.add_argument(
        "--difficulty",
        choices=ScenarioSampler.difficulties(),
    )
    parser.add_argument(
        "--random-only",
        action="store_true",
        help="Do not prepend the six deterministic steering validation cases.",
    )
    parser.add_argument("--output", type=Path)
    parser.add_argument("--max-time", type=float)
    parser.add_argument(
        "--trace-failures",
        action="store_true",
        help="Re-run failed episodes with a 10 Hz JSONL trace.",
    )
    parser.add_argument(
        "--require-success-rate",
        type=float,
        default=0.0,
        help="Return exit code 2 when success rate is below this value [0,1].",
    )
    return parser.parse_args()


def build_scenarios(
    *,
    episode_count: int,
    seed: int,
    difficulty: str,
    random_only: bool,
) -> list[Scenario]:
    if episode_count <= 0:
        raise ValueError("episodes must be positive")
    scenarios: list[Scenario] = []
    if not random_only:
        for name in VALIDATION_SCENARIOS:
            if len(scenarios) >= episode_count:
                break
            scenarios.append(named_scenario(name))

    sampler = ScenarioSampler(seed=seed, difficulty=difficulty)
    while len(scenarios) < episode_count:
        scenarios.append(sampler.sample())
    return scenarios


def main() -> int:
    args = parse_args()
    config = load_config(args.config.resolve())
    randomization = config["randomization"]
    batch = config["batch"]
    seed = int(args.seed if args.seed is not None else randomization["default_seed"])
    difficulty = str(
        args.difficulty
        if args.difficulty is not None
        else randomization["default_difficulty"]
    )
    if not 0.0 <= args.require_success_rate <= 1.0:
        raise ValueError("require-success-rate must be between 0 and 1")

    if args.output is None:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_dir = (
            PROJECT_ROOT / str(batch["output_root"]) / f"batch_{timestamp}"
        ).resolve()
    else:
        output_dir = args.output.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    scenarios = build_scenarios(
        episode_count=args.episodes,
        seed=seed,
        difficulty=difficulty,
        random_only=args.random_only,
    )
    results: list[EpisodeResult] = []

    print(
        f"Running {len(scenarios)} episodes | seed={seed} | "
        f"difficulty={difficulty} | output={output_dir}"
    )
    for index, scenario in enumerate(scenarios, start=1):
        result = run_pickup_episode(
            config,
            scenario,
            max_episode_seconds=args.max_time,
        )
        results.append(result)
        verdict = "PASS" if result.success else "FAIL"
        reason = "" if result.success else f" | {result.failure_reason}"
        print(
            f"[{index:02d}/{len(scenarios):02d}] {verdict} "
            f"{scenario.scenario_id:<16} "
            f"t={result.duration_seconds:5.1f}s "
            f"path={result.path_length_m:4.2f}m "
            f"steer={result.max_abs_steering_deg:4.1f}deg{reason}"
        )

        if args.trace_failures and not result.success:
            trace_path = output_dir / "failure_traces" / f"{scenario.scenario_id}.jsonl"
            run_pickup_episode(
                config,
                scenario,
                max_episode_seconds=args.max_time,
                trace_path=trace_path,
            )

    summary = write_results(output_dir, results)
    print("\nBatch summary")
    print(f"  success: {summary['success_count']}/{summary['episode_count']}")
    print(f"  success_rate: {summary['success_rate']:.1%}")
    print(f"  steering_exercised_rate: {summary['steering_exercised_rate']:.1%}")
    print(f"  average_duration: {summary['average_duration_seconds']:.2f}s")
    print(f"  results: {output_dir}")

    if summary["success_rate"] < args.require_success_rate:
        return 2
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (FileNotFoundError, KeyError, RuntimeError, ValueError, yaml.YAMLError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
