"""Vehicle control utilities."""
