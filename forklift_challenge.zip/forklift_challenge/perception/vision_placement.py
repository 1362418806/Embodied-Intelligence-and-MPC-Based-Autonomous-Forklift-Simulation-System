"""Fuse RGB placement-marker detections into the noisy-pose observation.

The global V7 pose pipeline remains responsible for pickup and transport.  In
terminal placement states, V8.0 renders the front RGB camera and estimates the
known-colour fiducial pose.  Accepted detections are filtered in world space so
vehicle motion is compensated naturally.  Once lowering begins, the final
pallet-to-target relation is held to avoid single-frame visual dropouts or
jitter during physical release.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, replace
import math
from statistics import median
from typing import Any, Mapping

import numpy as np

from interfaces.observation import ForkliftObservation, Pose3D
from perception.color_marker_detector import (
    ColourPlacementMarkerDetector,
    MarkerDetection,
    wrap_angle,
)
from perception.pose_pipeline import PerceptionFrame


def _normalise_state(state: Any | None) -> str | None:
    if state is None:
        return None
    return str(getattr(state, "value", state))


def _pose_base_to_world(vehicle: Pose3D, pose: Pose3D) -> Pose3D:
    c = math.cos(float(vehicle.yaw))
    s = math.sin(float(vehicle.yaw))
    return Pose3D(
        x=float(vehicle.x) + c * float(pose.x) - s * float(pose.y),
        y=float(vehicle.y) + s * float(pose.x) + c * float(pose.y),
        z=float(vehicle.z) + float(pose.z),
        roll=float(pose.roll),
        pitch=float(pose.pitch),
        yaw=wrap_angle(float(vehicle.yaw) + float(pose.yaw)),
    )


def _pose_world_to_base(vehicle: Pose3D, pose: Pose3D) -> Pose3D:
    dx = float(pose.x) - float(vehicle.x)
    dy = float(pose.y) - float(vehicle.y)
    c = math.cos(float(vehicle.yaw))
    s = math.sin(float(vehicle.yaw))
    return Pose3D(
        x=c * dx + s * dy,
        y=-s * dx + c * dy,
        z=float(pose.z) - float(vehicle.z),
        roll=float(pose.roll),
        pitch=float(pose.pitch),
        yaw=wrap_angle(float(pose.yaw) - float(vehicle.yaw)),
    )


def _relative(source: Pose3D, target: Pose3D) -> tuple[float, float, float]:
    dx = float(target.x) - float(source.x)
    dy = float(target.y) - float(source.y)
    c = math.cos(float(source.yaw))
    s = math.sin(float(source.yaw))
    return (
        c * dx + s * dy,
        -s * dx + c * dy,
        wrap_angle(float(target.yaw) - float(source.yaw)),
    )


def _compose(source: Pose3D, relative: tuple[float, float, float]) -> Pose3D:
    dx, dy, dyaw = relative
    c = math.cos(float(source.yaw))
    s = math.sin(float(source.yaw))
    return Pose3D(
        x=float(source.x) + c * dx - s * dy,
        y=float(source.y) + s * dx + c * dy,
        z=float(source.z),
        roll=float(source.roll),
        pitch=float(source.pitch),
        yaw=wrap_angle(float(source.yaw) + dyaw),
    )


@dataclass(frozen=True)
class VisionPlacementProfile:
    enabled: bool
    update_hz: float
    active_states: frozenset[str]
    latch_states: frozenset[str]
    filter_alpha: float
    maximum_position_innovation_m: float
    maximum_yaw_innovation_rad: float
    maximum_stale_seconds: float
    require_detection_for_success: bool
    minimum_detections_for_success: int
    minimum_control_confidence: float = 0.0
    high_confidence_threshold: float = 0.0
    high_confidence_maximum_reprojection_error_px: float = float("inf")
    maximum_control_reprojection_error_px: float = float("inf")
    medium_filter_alpha_scale: float = 1.0
    maximum_measurement_guide_position_difference_m: float = float("inf")
    maximum_measurement_guide_yaw_difference_rad: float = float("inf")
    high_position_visual_weight: float = 1.0
    high_yaw_visual_weight: float = 1.0
    medium_position_visual_weight: float = 1.0
    medium_yaw_visual_weight: float = 1.0
    # R4-E7: independent colour-centre PnP yaw witness. The legacy 16-corner
    # solver remains the acceptance/position source; only the yaw component may
    # be replaced/blended when the two solutions are geometrically consistent.
    center_yaw_witness_enabled: bool = False
    center_yaw_witness_weight: float = 1.0
    center_yaw_witness_max_reprojection_error_px: float = float("inf")
    center_yaw_witness_max_position_disagreement_m: float = float("inf")
    center_yaw_witness_max_yaw_disagreement_rad: float = float("inf")
    # R4-E7 temporal witness consensus. A single centre-PnP frame never owns
    # yaw: the current-frame centre-vs-corner delta must agree with a short
    # online window before it is allowed to correct the legacy yaw.
    center_yaw_witness_window: int = 5
    center_yaw_witness_minimum_consistent_samples: int = 3
    center_yaw_witness_max_delta_spread_rad: float = math.radians(0.5)
    # R4-F4: release-only current-image yaw anchor. This never replaces the
    # FAST/MULTIVIEW x/y target used by control. A short, high-confidence
    # centre-PnP world-yaw cluster may temporarily replace only certification
    # target yaw, after the existing E7 geometry/temporal witness has matured.
    release_center_yaw_anchor_enabled: bool = False
    release_center_yaw_anchor_hold_seconds: float = 0.0
    release_center_yaw_anchor_window: int = 5
    release_center_yaw_anchor_minimum_samples: int = 3
    release_center_yaw_anchor_max_world_spread_rad: float = math.radians(0.5)
    # V9.3.1 weak-guide semantics: the structured guide may only be a coarse
    # prior. High-confidence RGB is allowed to take over inside a wider safety
    # envelope instead of being rejected by a 20 cm / 10 deg guide error.
    coarse_guide_prior: bool = False
    high_confidence_takeover_position_m: float = float("inf")
    high_confidence_takeover_yaw_rad: float = float("inf")
    # V9.3.2 visual authority latch: after consecutive high-confidence RGB
    # updates the coarse guide loses centimetre-level authority until the
    # visual track becomes stale.
    visual_authority_latch_enabled: bool = False
    visual_authority_acquire_high_count: int = 2
    visual_authority_release_stale_seconds: float = float("inf")
    release_consensus_window: int = 1
    release_consensus_minimum_samples: int = 1
    maximum_release_stale_seconds: float = float("inf")
    maximum_release_position_spread_m: float = float("inf")
    maximum_release_yaw_spread_rad: float = float("inf")
    # V9.3.9 certification-only multi-view target track. This never replaces
    # the FAST filtered target used by MPC. It samples accepted RGB world poses
    # only when the vehicle viewpoint has changed enough to add observability.
    certification_multiview_enabled: bool = False
    certification_multiview_window: int = 8
    certification_multiview_minimum_samples: int = 3
    certification_multiview_min_translation_m: float = 0.05
    certification_multiview_min_yaw_rad: float = math.radians(2.5)
    certification_multiview_maximum_age_seconds: float = 20.0
    certification_multiview_high_confidence_only: bool = True
    # V9.3.10: after a genuinely viewpoint-diverse SLOW target is established,
    # keep a world-frame certification anchor alive while recent high-confidence
    # RGB measurements continue to confirm it. This breaks the terminal
    # "must move to certify / must stop to release" observability deadlock
    # without relaxing the release geometry limits.
    certification_anchor_enabled: bool = False
    certification_anchor_confirmation_max_age_seconds: float = 1.5
    certification_anchor_max_position_disagreement_m: float = 0.045
    certification_anchor_max_yaw_disagreement_rad: float = math.radians(2.5)
    # V9.3.12-R1: a mature SLOW anchor can itself become a stale/bias latch.
    # If high-confidence, temporally stable FAST RGB persistently disagrees
    # with it, invalidate the SLOW evidence and rebuild from fresh viewpoints.
    # This never authorizes release; it only forces re-observation.
    certification_anchor_conflict_refresh_enabled: bool = False
    certification_anchor_conflict_position_m: float = 0.055
    certification_anchor_conflict_yaw_rad: float = math.radians(3.0)
    certification_anchor_conflict_evidence_seconds: float = 0.8
    certification_anchor_conflict_evidence_decay_rate: float = 0.5
    certification_anchor_conflict_cooldown_seconds: float = 6.0
    certification_anchor_conflict_max_resets: int = 2
    certification_anchor_conflict_max_raw_position_spread_m: float = 0.035
    certification_anchor_conflict_max_raw_yaw_spread_rad: float = math.radians(1.0)
    # R2 atomic shadow re-anchor mode; legacy R1 invalidation remains available.
    certification_anchor_conflict_refresh_mode: str = "invalidate"
    certification_anchor_conflict_max_reanchor_position_m: float = 0.080
    certification_anchor_conflict_max_reanchor_yaw_rad: float = math.radians(2.5)
    certification_anchor_conflict_reanchor_uncertainty_gain: float = 0.25

    @classmethod
    def from_mapping(cls, values: Mapping[str, Any]) -> "VisionPlacementProfile":
        result = cls(
            enabled=bool(values.get("enabled", True)),
            update_hz=float(values.get("update_hz", 10.0)),
            active_states=frozenset(
                str(value)
                for value in values.get(
                    "active_states",
                    ("PLACE_ALIGN", "PLACE_RECOVER_REVERSE", "LOWER_LOAD"),
                )
            ),
            latch_states=frozenset(
                str(value)
                for value in values.get(
                    "latch_states",
                    ("LOWER_LOAD", "RELEASE_VERIFY", "PLACE_RETREAT", "DONE"),
                )
            ),
            filter_alpha=float(values.get("filter_alpha", 0.55)),
            maximum_position_innovation_m=float(
                values.get("maximum_position_innovation_m", 0.80)
            ),
            maximum_yaw_innovation_rad=math.radians(
                float(values.get("maximum_yaw_innovation_deg", 35.0))
            ),
            maximum_stale_seconds=float(values.get("maximum_stale_seconds", 1.2)),
            require_detection_for_success=bool(
                values.get("require_detection_for_success", True)
            ),
            minimum_detections_for_success=int(
                values.get("minimum_detections_for_success", 5)
            ),
            minimum_control_confidence=float(
                values.get("minimum_control_confidence", 0.0)
            ),
            high_confidence_threshold=float(
                values.get("high_confidence_threshold", 0.0)
            ),
            high_confidence_maximum_reprojection_error_px=float(
                values.get(
                    "high_confidence_maximum_reprojection_error_px",
                    float("inf"),
                )
            ),
            maximum_control_reprojection_error_px=float(
                values.get(
                    "maximum_control_reprojection_error_px",
                    float("inf"),
                )
            ),
            medium_filter_alpha_scale=float(
                values.get("medium_filter_alpha_scale", 1.0)
            ),
            maximum_measurement_guide_position_difference_m=float(
                values.get(
                    "maximum_measurement_guide_position_difference_m",
                    float("inf"),
                )
            ),
            maximum_measurement_guide_yaw_difference_rad=math.radians(
                float(
                    values.get(
                        "maximum_measurement_guide_yaw_difference_deg",
                        float("inf"),
                    )
                )
            ),
            high_position_visual_weight=float(
                values.get("high_position_visual_weight", 1.0)
            ),
            high_yaw_visual_weight=float(
                values.get("high_yaw_visual_weight", 1.0)
            ),
            medium_position_visual_weight=float(
                values.get("medium_position_visual_weight", 1.0)
            ),
            medium_yaw_visual_weight=float(
                values.get("medium_yaw_visual_weight", 1.0)
            ),
            center_yaw_witness_enabled=bool(
                values.get("center_yaw_witness_enabled", False)
            ),
            center_yaw_witness_weight=float(
                values.get("center_yaw_witness_weight", 1.0)
            ),
            center_yaw_witness_max_reprojection_error_px=float(
                values.get("center_yaw_witness_max_reprojection_error_px", float("inf"))
            ),
            center_yaw_witness_max_position_disagreement_m=float(
                values.get("center_yaw_witness_max_position_disagreement_m", float("inf"))
            ),
            center_yaw_witness_max_yaw_disagreement_rad=math.radians(
                float(values.get("center_yaw_witness_max_yaw_disagreement_deg", float("inf")))
            ),
            center_yaw_witness_window=int(
                values.get("center_yaw_witness_window", 5)
            ),
            center_yaw_witness_minimum_consistent_samples=int(
                values.get("center_yaw_witness_minimum_consistent_samples", 3)
            ),
            center_yaw_witness_max_delta_spread_rad=math.radians(
                float(values.get("center_yaw_witness_max_delta_spread_deg", 0.5))
            ),
            release_center_yaw_anchor_enabled=bool(
                values.get("release_center_yaw_anchor_enabled", False)
            ),
            release_center_yaw_anchor_hold_seconds=float(
                values.get("release_center_yaw_anchor_hold_seconds", 0.0)
            ),
            release_center_yaw_anchor_window=int(
                values.get("release_center_yaw_anchor_window", 5)
            ),
            release_center_yaw_anchor_minimum_samples=int(
                values.get("release_center_yaw_anchor_minimum_samples", 3)
            ),
            release_center_yaw_anchor_max_world_spread_rad=math.radians(
                float(values.get("release_center_yaw_anchor_max_world_spread_deg", 0.5))
            ),
            coarse_guide_prior=bool(values.get("coarse_guide_prior", False)),
            high_confidence_takeover_position_m=float(
                values.get("high_confidence_takeover_position_m", float("inf"))
            ),
            high_confidence_takeover_yaw_rad=math.radians(
                float(values.get("high_confidence_takeover_yaw_deg", float("inf")))
            ),
            visual_authority_latch_enabled=bool(
                values.get("visual_authority_latch_enabled", False)
            ),
            visual_authority_acquire_high_count=int(
                values.get("visual_authority_acquire_high_count", 2)
            ),
            visual_authority_release_stale_seconds=float(
                values.get("visual_authority_release_stale_seconds", float("inf"))
            ),
            release_consensus_window=int(
                values.get("release_consensus_window", 1)
            ),
            release_consensus_minimum_samples=int(
                values.get("release_consensus_minimum_samples", 1)
            ),
            maximum_release_stale_seconds=float(
                values.get("maximum_release_stale_seconds", float("inf"))
            ),
            maximum_release_position_spread_m=float(
                values.get(
                    "maximum_release_position_spread_m",
                    float("inf"),
                )
            ),
            maximum_release_yaw_spread_rad=math.radians(
                float(
                    values.get(
                        "maximum_release_yaw_spread_deg",
                        float("inf"),
                    )
                )
            ),
            certification_multiview_enabled=bool(
                values.get("certification_multiview_enabled", False)
            ),
            certification_multiview_window=int(
                values.get("certification_multiview_window", 8)
            ),
            certification_multiview_minimum_samples=int(
                values.get("certification_multiview_minimum_samples", 3)
            ),
            certification_multiview_min_translation_m=float(
                values.get("certification_multiview_min_translation_m", 0.05)
            ),
            certification_multiview_min_yaw_rad=math.radians(
                float(values.get("certification_multiview_min_yaw_deg", 2.5))
            ),
            certification_multiview_maximum_age_seconds=float(
                values.get("certification_multiview_maximum_age_seconds", 20.0)
            ),
            certification_multiview_high_confidence_only=bool(
                values.get("certification_multiview_high_confidence_only", True)
            ),
            certification_anchor_enabled=bool(
                values.get("certification_anchor_enabled", False)
            ),
            certification_anchor_confirmation_max_age_seconds=float(
                values.get("certification_anchor_confirmation_max_age_seconds", 1.5)
            ),
            certification_anchor_max_position_disagreement_m=float(
                values.get("certification_anchor_max_position_disagreement_m", 0.045)
            ),
            certification_anchor_max_yaw_disagreement_rad=math.radians(
                float(values.get("certification_anchor_max_yaw_disagreement_deg", 2.5))
            ),
            certification_anchor_conflict_refresh_enabled=bool(
                values.get("certification_anchor_conflict_refresh_enabled", False)
            ),
            certification_anchor_conflict_position_m=float(
                values.get("certification_anchor_conflict_position_m", 0.055)
            ),
            certification_anchor_conflict_yaw_rad=math.radians(
                float(values.get("certification_anchor_conflict_yaw_deg", 3.0))
            ),
            certification_anchor_conflict_evidence_seconds=float(
                values.get("certification_anchor_conflict_evidence_seconds", 0.8)
            ),
            certification_anchor_conflict_evidence_decay_rate=float(
                values.get("certification_anchor_conflict_evidence_decay_rate", 0.5)
            ),
            certification_anchor_conflict_cooldown_seconds=float(
                values.get("certification_anchor_conflict_cooldown_seconds", 6.0)
            ),
            certification_anchor_conflict_max_resets=int(
                values.get("certification_anchor_conflict_max_resets", 2)
            ),
            certification_anchor_conflict_max_raw_position_spread_m=float(
                values.get("certification_anchor_conflict_max_raw_position_spread_m", 0.035)
            ),
            certification_anchor_conflict_max_raw_yaw_spread_rad=math.radians(
                float(values.get("certification_anchor_conflict_max_raw_yaw_spread_deg", 1.0))
            ),
            certification_anchor_conflict_refresh_mode=str(
                values.get("certification_anchor_conflict_refresh_mode", "invalidate")
            ).strip().lower(),
            certification_anchor_conflict_max_reanchor_position_m=float(
                values.get("certification_anchor_conflict_max_reanchor_position_m", 0.080)
            ),
            certification_anchor_conflict_max_reanchor_yaw_rad=math.radians(
                float(values.get("certification_anchor_conflict_max_reanchor_yaw_deg", 2.5))
            ),
            certification_anchor_conflict_reanchor_uncertainty_gain=float(
                values.get("certification_anchor_conflict_reanchor_uncertainty_gain", 0.25)
            ),
        )
        result.validate()
        return result

    def validate(self) -> None:
        if self.update_hz <= 0.0:
            raise ValueError("vision update_hz must be positive")
        if not self.active_states:
            raise ValueError("vision active_states must not be empty")
        if not self.latch_states:
            raise ValueError("vision latch_states must not be empty")
        if not 0.0 < self.filter_alpha <= 1.0:
            raise ValueError("vision filter_alpha must be in (0, 1]")
        if self.maximum_position_innovation_m <= 0.0:
            raise ValueError("maximum_position_innovation_m must be positive")
        if self.maximum_yaw_innovation_rad <= 0.0:
            raise ValueError("maximum_yaw_innovation_deg must be positive")
        if self.maximum_stale_seconds <= 0.0:
            raise ValueError("maximum_stale_seconds must be positive")
        if self.minimum_detections_for_success < 0:
            raise ValueError("minimum_detections_for_success must be non-negative")
        if not 0.0 <= self.minimum_control_confidence <= 1.0:
            raise ValueError("minimum_control_confidence must be in [0,1]")
        if not 0.0 <= self.high_confidence_threshold <= 1.0:
            raise ValueError("high_confidence_threshold must be in [0,1]")
        if self.high_confidence_threshold < self.minimum_control_confidence:
            raise ValueError("high confidence threshold must exceed minimum")
        if self.high_confidence_maximum_reprojection_error_px <= 0.0:
            raise ValueError("high confidence reprojection limit must be positive")
        if self.maximum_control_reprojection_error_px <= 0.0:
            raise ValueError("control reprojection limit must be positive")
        if (
            self.high_confidence_maximum_reprojection_error_px
            > self.maximum_control_reprojection_error_px
        ):
            raise ValueError("high reprojection limit must not exceed maximum")
        if not 0.0 < self.medium_filter_alpha_scale <= 1.0:
            raise ValueError("medium_filter_alpha_scale must be in (0,1]")
        if self.maximum_measurement_guide_position_difference_m <= 0.0:
            raise ValueError("placement guide position limit must be positive")
        if self.maximum_measurement_guide_yaw_difference_rad <= 0.0:
            raise ValueError("placement guide yaw limit must be positive")
        if self.coarse_guide_prior:
            if self.high_confidence_takeover_position_m <= self.maximum_measurement_guide_position_difference_m:
                raise ValueError("coarse-guide takeover position limit must exceed standard guide gate")
            if self.high_confidence_takeover_yaw_rad <= self.maximum_measurement_guide_yaw_difference_rad:
                raise ValueError("coarse-guide takeover yaw limit must exceed standard guide gate")
        if self.visual_authority_latch_enabled:
            if not self.coarse_guide_prior:
                raise ValueError("visual authority latch requires coarse_guide_prior")
            if self.visual_authority_acquire_high_count <= 0:
                raise ValueError("visual authority acquire count must be positive")
            if self.visual_authority_release_stale_seconds <= 0.0:
                raise ValueError("visual authority release stale seconds must be positive")
        for value, name in (
            (self.high_position_visual_weight, "high position visual weight"),
            (self.high_yaw_visual_weight, "high yaw visual weight"),
            (self.medium_position_visual_weight, "medium position visual weight"),
            (self.medium_yaw_visual_weight, "medium yaw visual weight"),
        ):
            if not 0.0 <= value <= 1.0:
                raise ValueError(f"{name} must be in [0,1]")
        if not 0.0 <= self.center_yaw_witness_weight <= 1.0:
            raise ValueError("center yaw witness weight must be in [0,1]")
        if self.center_yaw_witness_max_reprojection_error_px <= 0.0:
            raise ValueError("center yaw witness reprojection limit must be positive")
        if self.center_yaw_witness_max_position_disagreement_m <= 0.0:
            raise ValueError("center yaw witness position disagreement limit must be positive")
        if self.center_yaw_witness_max_yaw_disagreement_rad <= 0.0:
            raise ValueError("center yaw witness yaw disagreement limit must be positive")
        if self.center_yaw_witness_window <= 0:
            raise ValueError("center yaw witness window must be positive")
        if not (
            1 <= self.center_yaw_witness_minimum_consistent_samples
            <= self.center_yaw_witness_window
        ):
            raise ValueError("invalid center yaw witness sample count")
        if self.center_yaw_witness_max_delta_spread_rad <= 0.0:
            raise ValueError("center yaw witness delta spread must be positive")
        if self.release_center_yaw_anchor_enabled:
            if not self.center_yaw_witness_enabled:
                raise ValueError("release center yaw anchor requires center yaw witness")
            if self.release_center_yaw_anchor_hold_seconds <= 0.0:
                raise ValueError("release center yaw anchor hold seconds must be positive")
            if self.release_center_yaw_anchor_window <= 0:
                raise ValueError("release center yaw anchor window must be positive")
            if not (
                1 <= self.release_center_yaw_anchor_minimum_samples
                <= self.release_center_yaw_anchor_window
            ):
                raise ValueError("invalid release center yaw anchor sample count")
            if self.release_center_yaw_anchor_max_world_spread_rad <= 0.0:
                raise ValueError("release center yaw anchor spread must be positive")
        if self.release_consensus_window <= 0:
            raise ValueError("release consensus window must be positive")
        if not (
            1 <= self.release_consensus_minimum_samples
            <= self.release_consensus_window
        ):
            raise ValueError("invalid release consensus sample count")
        if self.certification_multiview_enabled:
            if self.certification_multiview_window < 3:
                raise ValueError("certification multiview window must be >= 3")
            if not (
                2 <= self.certification_multiview_minimum_samples
                <= self.certification_multiview_window
            ):
                raise ValueError("invalid certification multiview sample count")
            if self.certification_multiview_min_translation_m <= 0.0:
                raise ValueError("certification multiview translation baseline must be positive")
            if self.certification_multiview_min_yaw_rad <= 0.0:
                raise ValueError("certification multiview yaw baseline must be positive")
            if self.certification_multiview_maximum_age_seconds <= 0.0:
                raise ValueError("certification multiview age must be positive")
            if self.certification_anchor_enabled:
                if self.certification_anchor_confirmation_max_age_seconds <= 0.0:
                    raise ValueError("certification anchor confirmation age must be positive")
                if self.certification_anchor_max_position_disagreement_m <= 0.0:
                    raise ValueError("certification anchor position disagreement must be positive")
                if self.certification_anchor_max_yaw_disagreement_rad <= 0.0:
                    raise ValueError("certification anchor yaw disagreement must be positive")
                if self.certification_anchor_conflict_refresh_enabled:
                    if self.certification_anchor_conflict_position_m <= 0.0:
                        raise ValueError("anchor conflict position threshold must be positive")
                    if self.certification_anchor_conflict_yaw_rad <= 0.0:
                        raise ValueError("anchor conflict yaw threshold must be positive")
                    if self.certification_anchor_conflict_evidence_seconds <= 0.0:
                        raise ValueError("anchor conflict evidence time must be positive")
                    if self.certification_anchor_conflict_evidence_decay_rate < 0.0:
                        raise ValueError("anchor conflict evidence decay must be non-negative")
                    if self.certification_anchor_conflict_cooldown_seconds < 0.0:
                        raise ValueError("anchor conflict cooldown must be non-negative")
                    if self.certification_anchor_conflict_max_resets < 1:
                        raise ValueError("anchor conflict max resets must be >= 1")
                    if self.certification_anchor_conflict_max_raw_position_spread_m <= 0.0:
                        raise ValueError("anchor conflict raw position spread must be positive")
                    if self.certification_anchor_conflict_max_raw_yaw_spread_rad <= 0.0:
                        raise ValueError("anchor conflict raw yaw spread must be positive")
                    if self.certification_anchor_conflict_refresh_mode not in {"invalidate", "shadow_reanchor"}:
                        raise ValueError("invalid anchor conflict refresh mode")
                    if self.certification_anchor_conflict_max_reanchor_position_m <= 0.0:
                        raise ValueError("anchor conflict reanchor position limit must be positive")
                    if self.certification_anchor_conflict_max_reanchor_yaw_rad <= 0.0:
                        raise ValueError("anchor conflict reanchor yaw limit must be positive")
                    if not 0.0 <= self.certification_anchor_conflict_reanchor_uncertainty_gain <= 1.0:
                        raise ValueError("anchor conflict reanchor uncertainty gain must be in [0,1]")
        if self.maximum_release_stale_seconds <= 0.0:
            raise ValueError("release stale limit must be positive")
        if self.maximum_release_position_spread_m <= 0.0:
            raise ValueError("release position spread must be positive")
        if self.maximum_release_yaw_spread_rad <= 0.0:
            raise ValueError("release yaw spread must be positive")


@dataclass(frozen=True)
class VisionPlacementDiagnostics:
    enabled: bool
    active: bool
    controller_state: str | None
    status: str
    pose_source: str
    latched: bool
    sample_count: int
    detection_count: int
    rejection_count: int
    detection_rate: float
    stale_seconds: float
    confidence: float | None
    reprojection_error_px: float | None
    marker_distance_m: float | None
    vision_used_for_terminal: bool
    marker_status: str | None
    confidence_class: str | None = None
    high_confidence_count: int = 0
    medium_confidence_count: int = 0
    confidence_rejection_count: int = 0
    guide_rejection_count: int = 0
    innovation_rejection_count: int = 0
    release_ready: bool = False
    release_consensus_samples: int = 0
    release_position_spread_m: float | None = None
    release_yaw_spread_deg: float | None = None
    # V9.3.8 certification-only raw accepted measurement consensus. The
    # legacy filtered spread above continues to drive release_ready.
    raw_release_position_spread_m: float | None = None
    raw_release_yaw_spread_deg: float | None = None
    certification_multiview_ready: bool = False
    certification_multiview_samples: int = 0
    certification_multiview_position_spread_m: float | None = None
    certification_multiview_yaw_spread_deg: float | None = None
    certification_fast_slow_position_disagreement_m: float | None = None
    certification_fast_slow_yaw_disagreement_deg: float | None = None
    last_accepted_confidence_class: str | None = None
    visual_authority: str = "GLOBAL_POSE"
    visual_authority_lock_count: int = 0
    visual_authority_unlock_count: int = 0
    center_yaw_witness_applied_count: int = 0
    center_yaw_witness_rejected_count: int = 0
    center_yaw_witness_last_corner_yaw_deg: float | None = None
    center_yaw_witness_last_center_yaw_deg: float | None = None
    center_yaw_witness_last_disagreement_deg: float | None = None
    center_yaw_witness_last_center_reprojection_error_px: float | None = None
    center_yaw_witness_consensus_samples: int = 0
    center_yaw_witness_consensus_delta_deg: float | None = None
    center_yaw_witness_delta_spread_deg: float | None = None
    release_center_yaw_anchor_active: bool = False
    release_center_yaw_anchor_age_seconds: float | None = None
    release_center_yaw_anchor_samples: int = 0
    release_center_yaw_anchor_spread_deg: float | None = None
    release_center_yaw_anchor_target_yaw_deg: float | None = None
    release_center_yaw_anchor_update_count: int = 0
    certification_anchor_conflict_reset_count: int = 0
    certification_anchor_conflict_evidence_seconds: float = 0.0
    certification_anchor_conflict_active: bool = False
    certification_anchor_conflict_reanchor_count: int = 0
    certification_anchor_conflict_last_reanchor_position_m: float | None = None
    certification_anchor_conflict_last_reanchor_yaw_deg: float | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class VisionPlacementFrame:
    observation: ForkliftObservation
    diagnostics: VisionPlacementDiagnostics
    detection_pose_in_base: Pose3D | None
    detection: MarkerDetection | None
    certification_target_pose_in_base: Pose3D | None = None
    release_center_yaw_target_pose_in_base: Pose3D | None = None


class VisionPlacementPipeline:
    """State-aware RGB marker fusion with global-pose fallback."""

    def __init__(
        self,
        *,
        profile_name: str,
        profile: VisionPlacementProfile,
        camera_name: str,
        detector: ColourPlacementMarkerDetector,
    ) -> None:
        self.profile_name = str(profile_name)
        self.profile = profile
        self.camera_name = str(camera_name)
        self.detector = detector
        self.next_sample_time: float | None = None
        self.last_time: float | None = None
        self.last_detection_time: float | None = None
        self.filtered_target_world: Pose3D | None = None
        self.latched_relative: tuple[float, float, float] | None = None
        self.sample_count = 0
        self.detection_count = 0
        self.rejection_count = 0
        self.last_detection: MarkerDetection | None = None
        self.last_status = "disabled" if not profile.enabled else "waiting"
        self.last_confidence_class: str | None = None
        self.high_confidence_count = 0
        self.medium_confidence_count = 0
        self.confidence_rejection_count = 0
        self.guide_rejection_count = 0
        self.visual_takeover_count = 0
        self.visual_authority_locked = False
        self.visual_authority_high_streak = 0
        self.visual_authority_lock_count = 0
        self.visual_authority_unlock_count = 0
        self.center_yaw_witness_applied_count = 0
        self.center_yaw_witness_rejected_count = 0
        self.center_yaw_witness_last_corner_yaw_deg: float | None = None
        self.center_yaw_witness_last_center_yaw_deg: float | None = None
        self.center_yaw_witness_last_disagreement_deg: float | None = None
        self.center_yaw_witness_last_center_reprojection_error_px: float | None = None
        self.center_yaw_witness_delta_history_rad: list[float] = []
        self.center_yaw_witness_consensus_delta_rad: float | None = None
        self.center_yaw_witness_delta_spread_rad: float | None = None
        self.release_center_yaw_world_history: list[tuple[float, float]] = []
        self.release_center_yaw_anchor_world_rad: float | None = None
        self.release_center_yaw_anchor_last_confirmation_time: float | None = None
        self.release_center_yaw_anchor_spread_rad: float | None = None
        self.release_center_yaw_anchor_update_count = 0
        self.innovation_rejection_count = 0
        self.last_accepted_confidence_class: str | None = None
        self.release_history: list[tuple[float, Pose3D]] = []
        self.release_position_spread_m: float | None = None
        self.release_yaw_spread_rad: float | None = None
        self.raw_release_history: list[tuple[float, Pose3D]] = []
        self.raw_release_position_spread_m: float | None = None
        self.raw_release_yaw_spread_rad: float | None = None
        self.certification_multiview_history: list[tuple[float, Pose3D, Pose3D]] = []
        self.certification_target_world: Pose3D | None = None
        self.certification_multiview_position_spread_m: float | None = None
        self.certification_multiview_yaw_spread_rad: float | None = None
        self.certification_anchor_world: Pose3D | None = None
        self.certification_anchor_position_spread_m: float | None = None
        self.certification_anchor_yaw_spread_rad: float | None = None
        self.certification_anchor_sample_count: int = 0
        self.certification_anchor_last_confirmation_time: float | None = None
        self.certification_anchor_conflict_reset_count = 0
        self.certification_anchor_conflict_evidence_value = 0.0
        self.certification_anchor_conflict_last_eval_time: float | None = None
        self.certification_anchor_conflict_last_reset_time: float | None = None
        self.certification_anchor_conflict_reanchor_count = 0
        self.certification_anchor_conflict_last_reanchor_position_m: float | None = None
        self.certification_anchor_conflict_last_reanchor_yaw_rad: float | None = None
        self.certification_fast_slow_position_disagreement_m: float | None = None
        self.certification_fast_slow_yaw_disagreement_rad: float | None = None
        self.ever_applied = False
        self.maximum_stale_seconds_observed = 0.0

    @classmethod
    def from_config(
        cls,
        vision_config: Mapping[str, Any],
        *,
        profile_name: str,
        image_width: int,
        image_height: int,
        detector: ColourPlacementMarkerDetector | None = None,
    ) -> "VisionPlacementPipeline":
        profiles = vision_config.get("profiles", {})
        if profile_name not in profiles:
            raise KeyError(f"vision.profiles.{profile_name}")
        detector_instance = detector or ColourPlacementMarkerDetector.from_config(
            vision_config,
            image_width=image_width,
            image_height=image_height,
        )
        return cls(
            profile_name=profile_name,
            profile=VisionPlacementProfile.from_mapping(profiles[profile_name]),
            camera_name=str(vision_config.get("camera_name", "front_rgb")),
            detector=detector_instance,
        )

    def reset(self) -> None:
        self.next_sample_time = None
        self.last_time = None
        self.last_detection_time = None
        self.filtered_target_world = None
        self.latched_relative = None
        self.sample_count = 0
        self.detection_count = 0
        self.rejection_count = 0
        self.last_detection = None
        self.last_status = "disabled" if not self.profile.enabled else "waiting"
        self.last_confidence_class = None
        self.high_confidence_count = 0
        self.medium_confidence_count = 0
        self.confidence_rejection_count = 0
        self.guide_rejection_count = 0
        self.visual_takeover_count = 0
        self.visual_authority_locked = False
        self.visual_authority_high_streak = 0
        self.visual_authority_lock_count = 0
        self.visual_authority_unlock_count = 0
        self.center_yaw_witness_applied_count = 0
        self.center_yaw_witness_rejected_count = 0
        self.center_yaw_witness_last_corner_yaw_deg = None
        self.center_yaw_witness_last_center_yaw_deg = None
        self.center_yaw_witness_last_disagreement_deg = None
        self.center_yaw_witness_last_center_reprojection_error_px = None
        self.center_yaw_witness_delta_history_rad = []
        self.center_yaw_witness_consensus_delta_rad = None
        self.center_yaw_witness_delta_spread_rad = None
        self.release_center_yaw_world_history = []
        self.release_center_yaw_anchor_world_rad = None
        self.release_center_yaw_anchor_last_confirmation_time = None
        self.release_center_yaw_anchor_spread_rad = None
        self.release_center_yaw_anchor_update_count = 0
        self.innovation_rejection_count = 0
        self.last_accepted_confidence_class = None
        self.release_history = []
        self.release_position_spread_m = None
        self.release_yaw_spread_rad = None
        self.raw_release_history = []
        self.raw_release_position_spread_m = None
        self.raw_release_yaw_spread_rad = None
        self.certification_multiview_history = []
        self.certification_target_world = None
        self.certification_multiview_position_spread_m = None
        self.certification_multiview_yaw_spread_rad = None
        self.certification_anchor_world = None
        self.certification_anchor_position_spread_m = None
        self.certification_anchor_yaw_spread_rad = None
        self.certification_anchor_sample_count = 0
        self.certification_anchor_last_confirmation_time = None
        self.certification_anchor_conflict_reset_count = 0
        self.certification_anchor_conflict_evidence_value = 0.0
        self.certification_anchor_conflict_last_eval_time: float | None = None
        self.certification_anchor_conflict_last_reset_time: float | None = None
        self.certification_anchor_conflict_reanchor_count = 0
        self.certification_anchor_conflict_last_reanchor_position_m = None
        self.certification_anchor_conflict_last_reanchor_yaw_rad = None
        self.certification_fast_slow_position_disagreement_m = None
        self.certification_fast_slow_yaw_disagreement_rad = None
        self.ever_applied = False
        self.maximum_stale_seconds_observed = 0.0
        self.detector.reset()

    def wants_image(self, *, sim_time: float, controller_state: Any | None) -> bool:
        if not self.profile.enabled:
            return False
        state = _normalise_state(controller_state)
        if state not in self.profile.active_states:
            return False
        now = float(sim_time)
        if self.last_time is not None and now + 1e-9 < self.last_time:
            return True
        return self.next_sample_time is None or now + 1e-12 >= self.next_sample_time

    def _schedule_sample(self, now: float) -> None:
        period = 1.0 / self.profile.update_hz
        if self.next_sample_time is None:
            self.next_sample_time = now + period
            return
        while self.next_sample_time <= now + 1e-12:
            self.next_sample_time += period

    def _confidence_class(
        self,
        detection: MarkerDetection,
    ) -> str:
        confidence = float(detection.confidence)
        reprojection = (
            float("inf")
            if detection.reprojection_error_px is None
            else float(detection.reprojection_error_px)
        )
        if (
            confidence < self.profile.minimum_control_confidence
            or reprojection
            > self.profile.maximum_control_reprojection_error_px
        ):
            return "reject"
        if (
            confidence >= self.profile.high_confidence_threshold
            and reprojection
            <= self.profile.high_confidence_maximum_reprojection_error_px
        ):
            return "high"
        return "medium"

    def _center_yaw_witness_pose(self, detection: MarkerDetection) -> Pose3D:
        """Return legacy pose with an online-consensus centre-PnP yaw witness.

        The 16-corner PnP remains the primary acceptance and x/y/z source.
        The four labelled colour-patch centres provide an independent current
        RGB yaw witness. R4-E7 never uses a historical/fixed yaw offset:
        correction is the median centre-minus-corner yaw delta of a short,
        consecutive online window, and only after geometric + temporal gates.
        """
        legacy = detection.target_pose_in_base
        if legacy is None or not self.profile.center_yaw_witness_enabled:
            assert legacy is not None
            return legacy

        center = detection.center_target_pose_in_base
        center_reproj = detection.center_reprojection_error_px
        position_disagreement = detection.center_corner_position_disagreement_m
        yaw_disagreement_deg = detection.center_corner_yaw_disagreement_deg

        self.center_yaw_witness_last_corner_yaw_deg = math.degrees(float(legacy.yaw))
        self.center_yaw_witness_last_center_yaw_deg = (
            None if center is None else math.degrees(float(center.yaw))
        )
        self.center_yaw_witness_last_disagreement_deg = yaw_disagreement_deg
        self.center_yaw_witness_last_center_reprojection_error_px = center_reproj

        valid = bool(
            center is not None
            and center_reproj is not None
            and position_disagreement is not None
            and yaw_disagreement_deg is not None
            and float(center_reproj)
                <= self.profile.center_yaw_witness_max_reprojection_error_px
            and float(position_disagreement)
                <= self.profile.center_yaw_witness_max_position_disagreement_m
            and math.radians(float(yaw_disagreement_deg))
                <= self.profile.center_yaw_witness_max_yaw_disagreement_rad
        )
        if not valid:
            # Require a consecutive current-image witness sequence. A failed
            # geometry frame invalidates the short consensus window.
            self.center_yaw_witness_delta_history_rad = []
            self.center_yaw_witness_consensus_delta_rad = None
            self.center_yaw_witness_delta_spread_rad = None
            self.center_yaw_witness_rejected_count += 1
            return legacy

        delta = wrap_angle(float(center.yaw) - float(legacy.yaw))
        self.center_yaw_witness_delta_history_rad.append(float(delta))
        window = int(self.profile.center_yaw_witness_window)
        if len(self.center_yaw_witness_delta_history_rad) > window:
            self.center_yaw_witness_delta_history_rad = (
                self.center_yaw_witness_delta_history_rad[-window:]
            )

        # Deltas are explicitly bounded to <=3 deg in E7 weak-guide config, so
        # a scalar median is safe across the -pi/pi branch here.
        consensus_delta = float(median(self.center_yaw_witness_delta_history_rad))
        spread = max(
            (
                abs(wrap_angle(float(value) - consensus_delta))
                for value in self.center_yaw_witness_delta_history_rad
            ),
            default=float("inf"),
        )
        self.center_yaw_witness_consensus_delta_rad = consensus_delta
        self.center_yaw_witness_delta_spread_rad = float(spread)

        if (
            len(self.center_yaw_witness_delta_history_rad)
            < self.profile.center_yaw_witness_minimum_consistent_samples
            or spread > self.profile.center_yaw_witness_max_delta_spread_rad
        ):
            self.center_yaw_witness_rejected_count += 1
            return legacy

        weight = float(self.profile.center_yaw_witness_weight)
        witnessed_yaw = wrap_angle(
            float(legacy.yaw) + weight * consensus_delta
        )
        self.center_yaw_witness_applied_count += 1
        return Pose3D(
            x=float(legacy.x),
            y=float(legacy.y),
            z=float(legacy.z),
            roll=float(legacy.roll),
            pitch=float(legacy.pitch),
            yaw=float(witnessed_yaw),
        )

    def _update_release_center_yaw_anchor(
        self,
        *,
        now: float,
        vehicle_world: Pose3D,
        detection: MarkerDetection,
        confidence_class: str,
    ) -> None:
        """Update the F4 release-only centre-PnP world-yaw anchor.

        The anchor is intentionally downstream of the existing E7 witness: a
        current frame must have a geometrically valid centre pose, high RGB
        confidence, and a matured centre-vs-corner consensus.  The world-yaw
        cluster is then required to be stable on its own before it may be used
        by strict certification.  Invalid frames break the *candidate* cluster
        but do not erase an already matured anchor; that anchor expires through
        the short hold lease instead.
        """
        profile = self.profile
        if not profile.release_center_yaw_anchor_enabled:
            return
        center = detection.center_target_pose_in_base
        witness_ready = bool(
            center is not None
            and confidence_class == "high"
            and self.center_yaw_witness_consensus_delta_rad is not None
            and self.center_yaw_witness_delta_spread_rad is not None
            and len(self.center_yaw_witness_delta_history_rad)
            >= profile.center_yaw_witness_minimum_consistent_samples
            and self.center_yaw_witness_delta_spread_rad
            <= profile.center_yaw_witness_max_delta_spread_rad
        )
        if not witness_ready:
            self.release_center_yaw_world_history = []
            return

        center_world = _pose_base_to_world(vehicle_world, center)
        self.release_center_yaw_world_history.append((float(now), float(center_world.yaw)))
        window = int(profile.release_center_yaw_anchor_window)
        if len(self.release_center_yaw_world_history) > window:
            self.release_center_yaw_world_history = self.release_center_yaw_world_history[-window:]
        if len(self.release_center_yaw_world_history) < profile.release_center_yaw_anchor_minimum_samples:
            return

        values = [item[1] for item in self.release_center_yaw_world_history]
        sin_mean = sum(math.sin(value) for value in values) / len(values)
        cos_mean = sum(math.cos(value) for value in values) / len(values)
        circular_centre = math.atan2(sin_mean, cos_mean)
        residuals = [wrap_angle(value - circular_centre) for value in values]
        anchor = wrap_angle(circular_centre + float(median(residuals)))
        spread = max(abs(wrap_angle(value - anchor)) for value in values)
        if spread > profile.release_center_yaw_anchor_max_world_spread_rad:
            return

        self.release_center_yaw_anchor_world_rad = float(anchor)
        self.release_center_yaw_anchor_last_confirmation_time = float(now)
        self.release_center_yaw_anchor_spread_rad = float(spread)
        self.release_center_yaw_anchor_update_count += 1

    def _release_center_yaw_anchor_active(self, *, now: float) -> bool:
        profile = self.profile
        if not profile.release_center_yaw_anchor_enabled:
            return False
        if (
            self.release_center_yaw_anchor_world_rad is None
            or self.release_center_yaw_anchor_last_confirmation_time is None
        ):
            return False
        return (
            max(0.0, float(now) - self.release_center_yaw_anchor_last_confirmation_time)
            <= profile.release_center_yaw_anchor_hold_seconds
        )

    def _release_center_yaw_target_pose(
        self,
        *,
        now: float,
        vehicle_world: Pose3D,
        certification_target_base: Pose3D | None,
    ) -> Pose3D | None:
        if certification_target_base is None or not self._release_center_yaw_anchor_active(now=now):
            return None
        assert self.release_center_yaw_anchor_world_rad is not None
        yaw_base = wrap_angle(
            float(self.release_center_yaw_anchor_world_rad) - float(vehicle_world.yaw)
        )
        return Pose3D(
            x=float(certification_target_base.x),
            y=float(certification_target_base.y),
            z=float(certification_target_base.z),
            roll=float(certification_target_base.roll),
            pitch=float(certification_target_base.pitch),
            yaw=float(yaw_base),
        )

    def _measurement_matches_guide(
        self,
        measurement: Pose3D,
        guide: Pose3D,
    ) -> bool:
        return (
            math.hypot(
                float(measurement.x) - float(guide.x),
                float(measurement.y) - float(guide.y),
            )
            <= self.profile.maximum_measurement_guide_position_difference_m
            and abs(
                wrap_angle(
                    float(measurement.yaw) - float(guide.yaw)
                )
            )
            <= self.profile.maximum_measurement_guide_yaw_difference_rad
        )

    @staticmethod
    def _regularize_base_measurement(
        *,
        visual: Pose3D,
        guide: Pose3D,
        position_visual_weight: float,
        yaw_visual_weight: float,
    ) -> Pose3D:
        return Pose3D(
            x=float(guide.x)
            + float(position_visual_weight)
            * (float(visual.x) - float(guide.x)),
            y=float(guide.y)
            + float(position_visual_weight)
            * (float(visual.y) - float(guide.y)),
            z=float(visual.z),
            roll=0.0,
            pitch=0.0,
            yaw=wrap_angle(
                float(guide.yaw)
                + float(yaw_visual_weight)
                * wrap_angle(float(visual.yaw) - float(guide.yaw))
            ),
        )

    def _append_release_history(
        self,
        *,
        now: float,
        measurement_world: Pose3D,
    ) -> None:
        self.release_history.append((float(now), measurement_world))
        maximum = self.profile.release_consensus_window
        if len(self.release_history) > maximum:
            del self.release_history[:-maximum]
        poses = [item[1] for item in self.release_history]
        if not poses:
            self.release_position_spread_m = None
            self.release_yaw_spread_rad = None
            return
        mean_x = sum(float(p.x) for p in poses) / len(poses)
        mean_y = sum(float(p.y) for p in poses) / len(poses)
        self.release_position_spread_m = max(
            math.hypot(float(p.x) - mean_x, float(p.y) - mean_y)
            for p in poses
        )
        sin_mean = sum(math.sin(float(p.yaw)) for p in poses) / len(poses)
        cos_mean = sum(math.cos(float(p.yaw)) for p in poses) / len(poses)
        mean_yaw = math.atan2(sin_mean, cos_mean)
        self.release_yaw_spread_rad = max(
            abs(wrap_angle(float(p.yaw) - mean_yaw))
            for p in poses
        )

    def _append_raw_release_history(
        self, *, now: float, measurement_world: Pose3D
    ) -> None:
        """Track raw accepted RGB world-pose variability for certification.

        This history intentionally does not affect the existing filtered
        release_ready contract. It measures how much the accepted detector
        observations themselves move inside the same consensus window.
        """
        self.raw_release_history.append((float(now), measurement_world))
        maximum = self.profile.release_consensus_window
        if len(self.raw_release_history) > maximum:
            del self.raw_release_history[:-maximum]
        poses = [item[1] for item in self.raw_release_history]
        if not poses:
            self.raw_release_position_spread_m = None
            self.raw_release_yaw_spread_rad = None
            return
        mean_x = sum(float(p.x) for p in poses) / len(poses)
        mean_y = sum(float(p.y) for p in poses) / len(poses)
        self.raw_release_position_spread_m = max(
            math.hypot(float(p.x) - mean_x, float(p.y) - mean_y)
            for p in poses
        )
        sin_mean = sum(math.sin(float(p.yaw)) for p in poses) / len(poses)
        cos_mean = sum(math.cos(float(p.yaw)) for p in poses) / len(poses)
        mean_yaw = math.atan2(sin_mean, cos_mean)
        self.raw_release_yaw_spread_rad = max(
            abs(wrap_angle(float(p.yaw) - mean_yaw)) for p in poses
        )

    def _certification_anchor_recent(self, *, now: float | None = None) -> bool:
        """Return whether a latched multiview anchor still has recent RGB confirmation."""
        p = self.profile
        if not p.certification_anchor_enabled:
            return False
        if self.certification_anchor_world is None:
            return False
        if self.certification_anchor_last_confirmation_time is None:
            return False
        current = self.last_time if now is None else float(now)
        if current is None:
            return False
        return (
            max(0.0, float(current) - self.certification_anchor_last_confirmation_time)
            <= p.certification_anchor_confirmation_max_age_seconds
        )

    def _activate_certification_anchor(self) -> None:
        """Expose the persistent anchor through the existing SLOW-target contract."""
        if self.certification_anchor_world is None:
            return
        self.certification_target_world = self.certification_anchor_world
        self.certification_multiview_position_spread_m = (
            self.certification_anchor_position_spread_m
        )
        self.certification_multiview_yaw_spread_rad = (
            self.certification_anchor_yaw_spread_rad
        )

    def _confirm_certification_anchor(
        self,
        *,
        now: float,
        measurement_world: Pose3D,
        confidence_class: str,
    ) -> None:
        """Refresh a mature anchor with recent same-view high-confidence evidence.

        The confirmation does not create multiview observability by itself.  It
        can only extend an anchor that was previously built from viewpoint-diverse
        samples.  This is the liveness bridge needed once the vehicle stops for
        release.
        """
        p = self.profile
        if not p.certification_anchor_enabled or self.certification_anchor_world is None:
            return
        if p.certification_multiview_high_confidence_only and confidence_class != "high":
            return
        anchor = self.certification_anchor_world
        position_disagreement = math.hypot(
            float(measurement_world.x) - float(anchor.x),
            float(measurement_world.y) - float(anchor.y),
        )
        yaw_disagreement = abs(
            wrap_angle(float(measurement_world.yaw) - float(anchor.yaw))
        )
        if (
            position_disagreement
            <= p.certification_anchor_max_position_disagreement_m
            and yaw_disagreement
            <= p.certification_anchor_max_yaw_disagreement_rad
        ):
            self.certification_anchor_last_confirmation_time = float(now)
            self._activate_certification_anchor()

    def _stable_raw_release_target(self) -> Pose3D | None:
        """Robust recent FAST RGB target used only as a SLOW re-anchor candidate."""
        if len(self.raw_release_history) < self.profile.release_consensus_minimum_samples:
            return None
        poses = [item[1] for item in self.raw_release_history]
        x = float(median([float(item.x) for item in poses]))
        y = float(median([float(item.y) for item in poses]))
        z = float(median([float(item.z) for item in poses]))
        sin_mean = sum(math.sin(float(item.yaw)) for item in poses) / len(poses)
        cos_mean = sum(math.cos(float(item.yaw)) for item in poses) / len(poses)
        yaw0 = math.atan2(sin_mean, cos_mean)
        yaw = wrap_angle(
            yaw0 + float(median([wrap_angle(float(item.yaw) - yaw0) for item in poses]))
        )
        return Pose3D(x=x, y=y, z=z, roll=0.0, pitch=0.0, yaw=yaw)

    def _maybe_refresh_conflicting_certification_anchor(
        self,
        *,
        now: float,
    ) -> bool:
        """Invalidate a biased SLOW anchor after accumulated strong FAST conflict.

        Safety contract: this function can only *remove* certification evidence.
        It never substitutes FAST for SLOW and never returns release authority.
        A leaky evidence accumulator is used because the trace shows genuine
        anchor conflict interleaved with short sub-threshold frames; requiring
        a perfectly contiguous 0.8 s run would never trigger on easy_0001.
        """
        p = self.profile
        current = float(now)
        dt = 0.0 if self.certification_anchor_conflict_last_eval_time is None else max(
            0.0, current - self.certification_anchor_conflict_last_eval_time
        )
        self.certification_anchor_conflict_last_eval_time = current

        prerequisites = (
            p.certification_anchor_conflict_refresh_enabled
            and self.certification_anchor_world is not None
            and self.filtered_target_world is not None
            and self.certification_multiview_ready()
            and self.last_accepted_confidence_class == "high"
            and self.release_ready()
            and self.raw_release_position_spread_m is not None
            and self.raw_release_yaw_spread_rad is not None
            and self.certification_anchor_conflict_reset_count
            < p.certification_anchor_conflict_max_resets
            and not (
                self.certification_anchor_conflict_last_reset_time is not None
                and current - self.certification_anchor_conflict_last_reset_time
                < p.certification_anchor_conflict_cooldown_seconds
            )
        )
        stable_fast = bool(
            prerequisites
            and self.raw_release_position_spread_m
            <= p.certification_anchor_conflict_max_raw_position_spread_m
            and self.raw_release_yaw_spread_rad
            <= p.certification_anchor_conflict_max_raw_yaw_spread_rad
        )

        conflict = False
        if stable_fast:
            position_disagreement = math.hypot(
                float(self.filtered_target_world.x) - float(self.certification_anchor_world.x),
                float(self.filtered_target_world.y) - float(self.certification_anchor_world.y),
            )
            yaw_disagreement = abs(wrap_angle(
                float(self.filtered_target_world.yaw) - float(self.certification_anchor_world.yaw)
            ))
            conflict = (
                position_disagreement > p.certification_anchor_conflict_position_m
                or yaw_disagreement > p.certification_anchor_conflict_yaw_rad
            )

        if conflict:
            self.certification_anchor_conflict_evidence_value += dt
        else:
            self.certification_anchor_conflict_evidence_value = max(
                0.0,
                self.certification_anchor_conflict_evidence_value
                - p.certification_anchor_conflict_evidence_decay_rate * dt,
            )

        if (
            not conflict
            or self.certification_anchor_conflict_evidence_value
            < p.certification_anchor_conflict_evidence_seconds
        ):
            return False

        if p.certification_anchor_conflict_refresh_mode == "shadow_reanchor":
            candidate = self._stable_raw_release_target()
            if candidate is None or self.certification_anchor_world is None:
                return False
            old_anchor = self.certification_anchor_world
            shift_position = math.hypot(
                float(candidate.x) - float(old_anchor.x),
                float(candidate.y) - float(old_anchor.y),
            )
            shift_yaw = abs(wrap_angle(float(candidate.yaw) - float(old_anchor.yaw)))
            if (
                shift_position > p.certification_anchor_conflict_max_reanchor_position_m
                or shift_yaw > p.certification_anchor_conflict_max_reanchor_yaw_rad
            ):
                # Fail closed on large disagreements; do not silently trust FAST.
                return False

            extra_position = p.certification_anchor_conflict_reanchor_uncertainty_gain * shift_position
            extra_yaw = p.certification_anchor_conflict_reanchor_uncertainty_gain * shift_yaw
            raw_pos_spread = 0.0 if self.raw_release_position_spread_m is None else float(self.raw_release_position_spread_m)
            raw_yaw_spread = 0.0 if self.raw_release_yaw_spread_rad is None else float(self.raw_release_yaw_spread_rad)
            old_pos_spread = 0.0 if self.certification_anchor_position_spread_m is None else float(self.certification_anchor_position_spread_m)
            old_yaw_spread = 0.0 if self.certification_anchor_yaw_spread_rad is None else float(self.certification_anchor_yaw_spread_rad)

            # Atomic estimator replacement: preserve the mature multiview history
            # so a near-stationary forklift never falls into MULTIVIEW_UNREADY.
            self.certification_anchor_world = candidate
            self.certification_target_world = candidate
            self.certification_anchor_position_spread_m = max(old_pos_spread, raw_pos_spread, extra_position)
            self.certification_anchor_yaw_spread_rad = max(old_yaw_spread, raw_yaw_spread, extra_yaw)
            self.certification_multiview_position_spread_m = self.certification_anchor_position_spread_m
            self.certification_multiview_yaw_spread_rad = self.certification_anchor_yaw_spread_rad
            self.certification_anchor_sample_count = max(self.certification_anchor_sample_count, len(self.raw_release_history))
            self.certification_anchor_last_confirmation_time = current
            self.certification_fast_slow_position_disagreement_m = math.hypot(
                float(self.filtered_target_world.x) - float(candidate.x),
                float(self.filtered_target_world.y) - float(candidate.y),
            )
            self.certification_fast_slow_yaw_disagreement_rad = abs(wrap_angle(
                float(self.filtered_target_world.yaw) - float(candidate.yaw)
            ))
            self.certification_anchor_conflict_reset_count += 1
            self.certification_anchor_conflict_reanchor_count += 1
            self.certification_anchor_conflict_last_reanchor_position_m = float(shift_position)
            self.certification_anchor_conflict_last_reanchor_yaw_rad = float(shift_yaw)
            self.certification_anchor_conflict_last_reset_time = current
            self.certification_anchor_conflict_evidence_value = 0.0
            return True

        # Legacy R1 mode: destructive invalidation. Kept only for old configs.
        self.certification_multiview_history = []
        self.certification_target_world = None
        self.certification_multiview_position_spread_m = None
        self.certification_multiview_yaw_spread_rad = None
        self.certification_anchor_world = None
        self.certification_anchor_position_spread_m = None
        self.certification_anchor_yaw_spread_rad = None
        self.certification_anchor_sample_count = 0
        self.certification_anchor_last_confirmation_time = None
        self.certification_fast_slow_position_disagreement_m = None
        self.certification_fast_slow_yaw_disagreement_rad = None
        self.certification_anchor_conflict_reset_count += 1
        self.certification_anchor_conflict_last_reset_time = current
        self.certification_anchor_conflict_evidence_value = 0.0
        return True

    def certification_anchor_conflict_evidence_seconds(self, *, now: float | None = None) -> float:
        return float(self.certification_anchor_conflict_evidence_value)

    def _prune_certification_multiview_history(self, *, now: float) -> None:
        """Expire stale *diversity samples* without discarding a confirmed anchor.

        R1 correctly made the live multiview window age-aware.  V9.3.10 splits
        two notions that should not be conflated:
          1) old viewpoint samples stop contributing to a new diversity estimate;
          2) a mature world-frame target may remain valid if recent high-confidence
             RGB continues to agree with it.

        Therefore pruning can drop the live history below N while the mature
        anchor remains the active certification target for a short confirmation
        lease.
        """
        p = self.profile
        if not p.certification_multiview_enabled:
            return
        cutoff = float(now) - p.certification_multiview_maximum_age_seconds
        before = len(self.certification_multiview_history)
        self.certification_multiview_history = [
            item for item in self.certification_multiview_history if item[0] >= cutoff
        ]
        if len(self.certification_multiview_history) != before:
            self._recompute_certification_multiview_track()
        elif not self.certification_multiview_ready():
            # A confirmation lease may have expired even when the live history
            # length did not change on this exact frame.
            if (
                len(self.certification_multiview_history)
                < p.certification_multiview_minimum_samples
            ):
                self.certification_target_world = None
                self.certification_multiview_position_spread_m = None
                self.certification_multiview_yaw_spread_rad = None

    def _append_certification_multiview_history(
        self,
        *,
        now: float,
        vehicle_world: Pose3D,
        measurement_world: Pose3D,
        confidence_class: str,
    ) -> None:
        """Build a robust SLOW target track from viewpoint-diverse RGB poses."""
        p = self.profile
        if not p.certification_multiview_enabled:
            return

        # A mature anchor may be refreshed even if this frame does not add a
        # new viewpoint-diverse sample.
        self._confirm_certification_anchor(
            now=now,
            measurement_world=measurement_world,
            confidence_class=confidence_class,
        )

        if p.certification_multiview_high_confidence_only and confidence_class != "high":
            return
        self._prune_certification_multiview_history(now=now)
        if self.certification_multiview_history:
            _, last_vehicle, _ = self.certification_multiview_history[-1]
            translation = math.hypot(
                float(vehicle_world.x) - float(last_vehicle.x),
                float(vehicle_world.y) - float(last_vehicle.y),
            )
            yaw_delta = abs(
                wrap_angle(float(vehicle_world.yaw) - float(last_vehicle.yaw))
            )
            if (
                translation < p.certification_multiview_min_translation_m
                and yaw_delta < p.certification_multiview_min_yaw_rad
            ):
                return
        self.certification_multiview_history.append(
            (float(now), vehicle_world, measurement_world)
        )
        if len(self.certification_multiview_history) > p.certification_multiview_window:
            del self.certification_multiview_history[:-p.certification_multiview_window]
        self._recompute_certification_multiview_track()

    def _recompute_certification_multiview_track(self) -> None:
        items = self.certification_multiview_history
        p = self.profile
        if len(items) < p.certification_multiview_minimum_samples:
            if self._certification_anchor_recent():
                self._activate_certification_anchor()
            else:
                self.certification_target_world = None
                self.certification_multiview_position_spread_m = None
                self.certification_multiview_yaw_spread_rad = None
            return

        poses = [item[2] for item in items]
        centre_x = float(median([float(pose.x) for pose in poses]))
        centre_y = float(median([float(pose.y) for pose in poses]))
        centre_z = float(median([float(pose.z) for pose in poses]))
        sin_mean = sum(math.sin(float(pose.yaw)) for pose in poses) / len(poses)
        cos_mean = sum(math.cos(float(pose.yaw)) for pose in poses) / len(poses)
        circular_centre = math.atan2(sin_mean, cos_mean)
        residuals = [
            wrap_angle(float(pose.yaw) - circular_centre) for pose in poses
        ]
        centre_yaw = wrap_angle(circular_centre + float(median(residuals)))
        target_world = Pose3D(
            x=centre_x, y=centre_y, z=centre_z,
            roll=0.0, pitch=0.0, yaw=centre_yaw,
        )
        distances = sorted(
            math.hypot(float(pose.x) - centre_x, float(pose.y) - centre_y)
            for pose in poses
        )
        yaw_errors = sorted(
            abs(wrap_angle(float(pose.yaw) - centre_yaw)) for pose in poses
        )
        position_spread = float(median(distances))
        yaw_spread = float(median(yaw_errors))

        self.certification_target_world = target_world
        self.certification_multiview_position_spread_m = position_spread
        self.certification_multiview_yaw_spread_rad = yaw_spread

        if p.certification_anchor_enabled:
            self.certification_anchor_world = target_world
            self.certification_anchor_position_spread_m = position_spread
            self.certification_anchor_yaw_spread_rad = yaw_spread
            self.certification_anchor_sample_count = len(items)
            # The newest sample is itself a high-confidence confirmation.
            self.certification_anchor_last_confirmation_time = float(items[-1][0])

    def certification_multiview_ready(self) -> bool:
        live_ready = (
            self.profile.certification_multiview_enabled
            and self.certification_target_world is not None
            and len(self.certification_multiview_history)
            >= self.profile.certification_multiview_minimum_samples
        )
        if live_ready:
            return True
        return bool(
            self.profile.certification_multiview_enabled
            and self._certification_anchor_recent()
            and self.certification_anchor_world is not None
        )

    def certification_multiview_samples(self) -> int:
        if (
            len(self.certification_multiview_history)
            >= self.profile.certification_multiview_minimum_samples
        ):
            return len(self.certification_multiview_history)
        if self._certification_anchor_recent():
            return max(
                len(self.certification_multiview_history),
                self.certification_anchor_sample_count,
            )
        return len(self.certification_multiview_history)

    def release_ready(self) -> bool:
        if self.last_time is None or self.last_detection_time is None:
            return False
        if (
            self.last_time - self.last_detection_time
            > self.profile.maximum_release_stale_seconds
        ):
            return False
        if (
            len(self.release_history)
            < self.profile.release_consensus_minimum_samples
        ):
            return False
        if (
            self.release_position_spread_m is None
            or self.release_yaw_spread_rad is None
        ):
            return False
        return (
            self.release_position_spread_m
            <= self.profile.maximum_release_position_spread_m
            and self.release_yaw_spread_rad
            <= self.profile.maximum_release_yaw_spread_rad
        )

    def _filter_world(
        self,
        measurement: Pose3D,
        *,
        alpha_scale: float = 1.0,
    ) -> bool:
        if self.filtered_target_world is None:
            self.filtered_target_world = measurement
            return True
        old = self.filtered_target_world
        position_innovation = math.hypot(
            float(measurement.x) - float(old.x),
            float(measurement.y) - float(old.y),
        )
        yaw_innovation = abs(wrap_angle(float(measurement.yaw) - float(old.yaw)))
        if (
            position_innovation > self.profile.maximum_position_innovation_m
            or yaw_innovation > self.profile.maximum_yaw_innovation_rad
        ):
            return False
        alpha = self.profile.filter_alpha * float(alpha_scale)
        self.filtered_target_world = Pose3D(
            x=float(old.x) + alpha * (float(measurement.x) - float(old.x)),
            y=float(old.y) + alpha * (float(measurement.y) - float(old.y)),
            z=float(old.z) + alpha * (float(measurement.z) - float(old.z)),
            roll=0.0,
            pitch=0.0,
            yaw=wrap_angle(
                float(old.yaw)
                + alpha * wrap_angle(float(measurement.yaw) - float(old.yaw))
            ),
        )
        return True

    def meets_success_requirement(self) -> bool:
        if not self.profile.require_detection_for_success:
            return True
        return (
            self.detection_count >= self.profile.minimum_detections_for_success
            and self.ever_applied
        )

    def step(
        self,
        *,
        frame: PerceptionFrame,
        rgb: np.ndarray | None,
        controller_state: Any | None = None,
    ) -> VisionPlacementFrame:
        estimated = frame.observation
        now = float(estimated.sim_time)
        if self.last_time is not None and now + 1e-9 < self.last_time:
            self.reset()
        self.last_time = now
        self._prune_certification_multiview_history(now=now)
        state = _normalise_state(controller_state)
        active = self.profile.enabled and state in self.profile.active_states
        detection: MarkerDetection | None = None
        detection_pose: Pose3D | None = None
        accepted_now = False

        due = active and (
            self.next_sample_time is None or now + 1e-12 >= self.next_sample_time
        )
        if due:
            self._schedule_sample(now)
            self.sample_count += 1
            if rgb is None:
                self.rejection_count += 1
                self.last_status = "render_missing"
            else:
                detection = self.detector.detect(rgb)
                self.last_detection = detection
                if detection.success and detection.target_pose_in_base is not None:
                    visual_measurement = self._center_yaw_witness_pose(detection)
                    confidence_class = self._confidence_class(detection)
                    self.last_confidence_class = confidence_class
                    if confidence_class == "reject":
                        self.rejection_count += 1
                        self.confidence_rejection_count += 1
                        self.last_status = "confidence_rejected"
                    else:
                        guide_ok = self._measurement_matches_guide(
                            visual_measurement,
                            estimated.placement_pose_in_base,
                        )
                        if (
                            self.profile.coarse_guide_prior
                            and self.visual_authority_locked
                        ):
                            guide_ok = True
                        takeover = False
                        if (
                            not guide_ok
                            and self.profile.coarse_guide_prior
                            and confidence_class == "high"
                        ):
                            guide_position_difference = math.hypot(
                                float(visual_measurement.x)
                                - float(estimated.placement_pose_in_base.x),
                                float(visual_measurement.y)
                                - float(estimated.placement_pose_in_base.y),
                            )
                            guide_yaw_difference = abs(wrap_angle(
                                float(visual_measurement.yaw)
                                - float(estimated.placement_pose_in_base.yaw)
                            ))
                            takeover = (
                                guide_position_difference
                                <= self.profile.high_confidence_takeover_position_m
                                and guide_yaw_difference
                                <= self.profile.high_confidence_takeover_yaw_rad
                            )
                        if not guide_ok and not takeover:
                            self.rejection_count += 1
                            self.guide_rejection_count += 1
                            self.last_status = "guide_rejected"
                        else:
                            if takeover:
                                self.visual_takeover_count += 1
                                self.last_status = "coarse_guide_visual_takeover"
                            if confidence_class == "high":
                                self.high_confidence_count += 1
                                alpha_scale = 1.0
                                position_weight = (
                                    self.profile.high_position_visual_weight
                                )
                                yaw_weight = (
                                    self.profile.high_yaw_visual_weight
                                )
                            else:
                                self.medium_confidence_count += 1
                                alpha_scale = (
                                    self.profile.medium_filter_alpha_scale
                                )
                                position_weight = (
                                    self.profile.medium_position_visual_weight
                                )
                                yaw_weight = (
                                    self.profile.medium_yaw_visual_weight
                                )
                            if (
                                self.profile.coarse_guide_prior
                                and self.visual_authority_locked
                            ):
                                # Once visual authority is locked, the quantized
                                # structured guide is no longer a centimetre-
                                # level regularizer. Temporal innovation gating
                                # remains active below.
                                regularized_base = visual_measurement
                            else:
                                regularized_base = self._regularize_base_measurement(
                                    visual=visual_measurement,
                                    guide=estimated.placement_pose_in_base,
                                    position_visual_weight=position_weight,
                                    yaw_visual_weight=yaw_weight,
                                )
                            measurement_world = _pose_base_to_world(
                                estimated.vehicle_pose_world,
                                regularized_base,
                            )
                            if self._filter_world(
                                measurement_world,
                                alpha_scale=alpha_scale,
                            ):
                                self.detection_count += 1
                                self.last_detection_time = now
                                self.last_status = (
                                    "coarse_guide_visual_takeover"
                                    if takeover
                                    else "vision_accepted"
                                )
                                self.last_accepted_confidence_class = (
                                    confidence_class
                                )
                                self._append_release_history(
                                    now=now,
                                    measurement_world=self.filtered_target_world,
                                )
                                self._append_raw_release_history(
                                    now=now,
                                    measurement_world=measurement_world,
                                )
                                self._append_certification_multiview_history(
                                    now=now,
                                    vehicle_world=estimated.vehicle_pose_world,
                                    measurement_world=measurement_world,
                                    confidence_class=confidence_class,
                                )
                                # R4-F4: release-only centre yaw is updated only
                                # after the primary RGB measurement itself was
                                # accepted by the normal innovation/authority path.
                                self._update_release_center_yaw_anchor(
                                    now=now,
                                    vehicle_world=estimated.vehicle_pose_world,
                                    detection=detection,
                                    confidence_class=confidence_class,
                                )
                                detection_pose = regularized_base
                                accepted_now = True
                                if self.profile.visual_authority_latch_enabled:
                                    if confidence_class == "high":
                                        self.visual_authority_high_streak += 1
                                    else:
                                        self.visual_authority_high_streak = max(
                                            0, self.visual_authority_high_streak - 1
                                        )
                                    if (
                                        not self.visual_authority_locked
                                        and self.visual_authority_high_streak
                                        >= self.profile.visual_authority_acquire_high_count
                                    ):
                                        self.visual_authority_locked = True
                                        self.visual_authority_lock_count += 1
                            else:
                                self.rejection_count += 1
                                self.innovation_rejection_count += 1
                                self.last_status = "innovation_rejected"
                else:
                    self.rejection_count += 1
                    self.last_status = (
                        f"marker_{detection.status}" if detection is not None else "marker_failed"
                    )

        stale = (
            math.inf
            if self.last_detection_time is None
            else max(0.0, now - self.last_detection_time)
        )
        if (
            self.profile.visual_authority_latch_enabled
            and self.visual_authority_locked
            and stale > self.profile.visual_authority_release_stale_seconds
        ):
            self.visual_authority_locked = False
            self.visual_authority_high_streak = 0
            self.visual_authority_unlock_count += 1

        source = "global_pose"
        if math.isfinite(stale):
            self.maximum_stale_seconds_observed = max(
                self.maximum_stale_seconds_observed,
                stale,
            )

        if self.filtered_target_world is not None and stale <= self.profile.maximum_stale_seconds:
            visual_target_base = _pose_world_to_base(
                estimated.vehicle_pose_world,
                self.filtered_target_world,
            )
            estimated = replace(
                estimated,
                placement_pose_in_base=visual_target_base,
            )
            source = "rgb_marker" if accepted_now else "rgb_world_hold"
            self.ever_applied = True
        elif active and self.profile.enabled and self.filtered_target_world is not None:
            self.last_status = "vision_stale_fallback"

        if (
            state in self.profile.latch_states
            and self.latched_relative is None
            and self.filtered_target_world is not None
        ):
            target_base = _pose_world_to_base(
                estimated.vehicle_pose_world,
                self.filtered_target_world,
            )
            self.latched_relative = _relative(
                estimated.pallet_pose_in_base,
                target_base,
            )
            self.last_status = "vision_terminal_latched"

        if self.latched_relative is not None:
            estimated = replace(
                estimated,
                placement_pose_in_base=_compose(
                    estimated.pallet_pose_in_base,
                    self.latched_relative,
                ),
            )
            source = "vision_terminal_relative_hold"
            self.ever_applied = True
            if self.last_status != "vision_terminal_latched":
                self.last_status = "vision_terminal_relative_hold"

        certification_target_base: Pose3D | None = None
        if self.certification_multiview_ready():
            assert self.certification_target_world is not None
            certification_target_base = _pose_world_to_base(
                estimated.vehicle_pose_world,
                self.certification_target_world,
            )
            if self.filtered_target_world is not None:
                self.certification_fast_slow_position_disagreement_m = math.hypot(
                    float(self.filtered_target_world.x) - float(self.certification_target_world.x),
                    float(self.filtered_target_world.y) - float(self.certification_target_world.y),
                )
                self.certification_fast_slow_yaw_disagreement_rad = abs(
                    wrap_angle(
                        float(self.filtered_target_world.yaw)
                        - float(self.certification_target_world.yaw)
                    )
                )
            if self._maybe_refresh_conflicting_certification_anchor(now=now):
                certification_target_base = None
        else:
            self.certification_fast_slow_position_disagreement_m = None
            self.certification_fast_slow_yaw_disagreement_rad = None

        release_center_yaw_target_base = self._release_center_yaw_target_pose(
            now=now,
            vehicle_world=estimated.vehicle_pose_world,
            certification_target_base=certification_target_base,
        )
        release_center_anchor_active = release_center_yaw_target_base is not None
        release_center_anchor_age = (
            None
            if self.release_center_yaw_anchor_last_confirmation_time is None
            else max(0.0, now - self.release_center_yaw_anchor_last_confirmation_time)
        )

        last = detection or self.last_detection
        detection_rate = self.detection_count / max(1, self.sample_count)
        return VisionPlacementFrame(
            observation=estimated,
            diagnostics=VisionPlacementDiagnostics(
                enabled=self.profile.enabled,
                active=active,
                controller_state=state,
                status=self.last_status,
                pose_source=source,
                latched=self.latched_relative is not None,
                sample_count=self.sample_count,
                detection_count=self.detection_count,
                rejection_count=self.rejection_count,
                detection_rate=detection_rate,
                stale_seconds=stale,
                confidence=None if last is None else last.confidence,
                reprojection_error_px=(
                    None if last is None else last.reprojection_error_px
                ),
                marker_distance_m=None if last is None else last.marker_distance_m,
                vision_used_for_terminal=self.ever_applied,
                marker_status=None if last is None else last.status,
                confidence_class=self.last_confidence_class,
                high_confidence_count=self.high_confidence_count,
                medium_confidence_count=self.medium_confidence_count,
                confidence_rejection_count=self.confidence_rejection_count,
                guide_rejection_count=self.guide_rejection_count,
                innovation_rejection_count=self.innovation_rejection_count,
                release_ready=self.release_ready(),
                release_consensus_samples=len(self.release_history),
                release_position_spread_m=self.release_position_spread_m,
                release_yaw_spread_deg=(
                    None
                    if self.release_yaw_spread_rad is None
                    else math.degrees(self.release_yaw_spread_rad)
                ),
                raw_release_position_spread_m=self.raw_release_position_spread_m,
                raw_release_yaw_spread_deg=(
                    None
                    if self.raw_release_yaw_spread_rad is None
                    else math.degrees(self.raw_release_yaw_spread_rad)
                ),
                # V9.3.9-R1: these fields existed in the diagnostics schema
                # but V9.3.9 never populated them. The simulator forwards this
                # exact diagnostics object into the FSM, so the omission made
                # weak-guide certification see multiview_ready=False forever.
                certification_multiview_ready=self.certification_multiview_ready(),
                certification_multiview_samples=self.certification_multiview_samples(),
                certification_multiview_position_spread_m=(
                    self.certification_multiview_position_spread_m
                ),
                certification_multiview_yaw_spread_deg=(
                    None
                    if self.certification_multiview_yaw_spread_rad is None
                    else math.degrees(self.certification_multiview_yaw_spread_rad)
                ),
                certification_fast_slow_position_disagreement_m=(
                    self.certification_fast_slow_position_disagreement_m
                ),
                certification_fast_slow_yaw_disagreement_deg=(
                    None
                    if self.certification_fast_slow_yaw_disagreement_rad is None
                    else math.degrees(self.certification_fast_slow_yaw_disagreement_rad)
                ),
                last_accepted_confidence_class=(
                    self.last_accepted_confidence_class
                ),
                visual_authority=(
                    "VISUAL_LOCK"
                    if self.visual_authority_locked
                    else "VISUAL_TRACK"
                    if self.filtered_target_world is not None
                    and stale <= self.profile.maximum_stale_seconds
                    else "COARSE_GUIDE"
                    if self.profile.coarse_guide_prior
                    else "GLOBAL_POSE"
                ),
                visual_authority_lock_count=self.visual_authority_lock_count,
                visual_authority_unlock_count=self.visual_authority_unlock_count,
                center_yaw_witness_applied_count=self.center_yaw_witness_applied_count,
                center_yaw_witness_rejected_count=self.center_yaw_witness_rejected_count,
                center_yaw_witness_last_corner_yaw_deg=self.center_yaw_witness_last_corner_yaw_deg,
                center_yaw_witness_last_center_yaw_deg=self.center_yaw_witness_last_center_yaw_deg,
                center_yaw_witness_last_disagreement_deg=self.center_yaw_witness_last_disagreement_deg,
                center_yaw_witness_last_center_reprojection_error_px=(
                    self.center_yaw_witness_last_center_reprojection_error_px
                ),
                center_yaw_witness_consensus_samples=len(
                    self.center_yaw_witness_delta_history_rad
                ),
                center_yaw_witness_consensus_delta_deg=(
                    None if self.center_yaw_witness_consensus_delta_rad is None
                    else math.degrees(self.center_yaw_witness_consensus_delta_rad)
                ),
                center_yaw_witness_delta_spread_deg=(
                    None if self.center_yaw_witness_delta_spread_rad is None
                    else math.degrees(self.center_yaw_witness_delta_spread_rad)
                ),
                release_center_yaw_anchor_active=release_center_anchor_active,
                release_center_yaw_anchor_age_seconds=release_center_anchor_age,
                release_center_yaw_anchor_samples=len(self.release_center_yaw_world_history),
                release_center_yaw_anchor_spread_deg=(
                    None if self.release_center_yaw_anchor_spread_rad is None
                    else math.degrees(self.release_center_yaw_anchor_spread_rad)
                ),
                release_center_yaw_anchor_target_yaw_deg=(
                    None if release_center_yaw_target_base is None
                    else math.degrees(float(release_center_yaw_target_base.yaw))
                ),
                release_center_yaw_anchor_update_count=self.release_center_yaw_anchor_update_count,
                certification_anchor_conflict_reset_count=(
                    self.certification_anchor_conflict_reset_count
                ),
                certification_anchor_conflict_evidence_seconds=(
                    self.certification_anchor_conflict_evidence_seconds(now=now)
                ),
                certification_anchor_conflict_active=(
                    self.certification_anchor_conflict_evidence_value > 1e-9
                ),
                certification_anchor_conflict_reanchor_count=(
                    self.certification_anchor_conflict_reanchor_count
                ),
                certification_anchor_conflict_last_reanchor_position_m=(
                    self.certification_anchor_conflict_last_reanchor_position_m
                ),
                certification_anchor_conflict_last_reanchor_yaw_deg=(
                    None if self.certification_anchor_conflict_last_reanchor_yaw_rad is None
                    else math.degrees(self.certification_anchor_conflict_last_reanchor_yaw_rad)
                ),
            ),
            detection_pose_in_base=detection_pose,
            detection=detection,
            certification_target_pose_in_base=certification_target_base,
            release_center_yaw_target_pose_in_base=release_center_yaw_target_base,
        )
