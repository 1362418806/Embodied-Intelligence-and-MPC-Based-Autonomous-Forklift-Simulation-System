"""Path checks for V5.2.2 launch wrappers."""

from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_v5_2_2_files_exist() -> None:
    assert (
        PROJECT_ROOT / "scripts" / "run_forklift_v5_2_2.py"
    ).is_file()
    assert (
        PROJECT_ROOT / "scripts" / "run_v5_2_2_batch.py"
    ).is_file()
    assert (
        PROJECT_ROOT / "configs" / "vehicle_v5_2_2.yaml"
    ).is_file()


def test_v5_2_2_wrappers_do_not_require_scripts_package() -> None:
    for name in ("run_forklift_v5_2_2.py", "run_v5_2_2_batch.py"):
        text = (PROJECT_ROOT / "scripts" / name).read_text(encoding="utf-8")
        assert "importlib.util" in text
        assert "import scripts." not in text
