# V9.4.1-E1 Legacy Risk Replay

- Episodes: **10**
- Legacy strict certifications: **8**
- Would request yaw witness: **8**
- Would request position witness: **5**
- Would enter near-basin evidence hold: **8**
- Interpretation: old traces do not contain the new independent witnesses; blocked rows are expected.

## nominal_0001

- No legacy strict certification.

## nominal_0002

- t=120.002s source=MULTIVIEW pos=0.0637m yaw=2.329deg load-yaw-age=99.887999999902s blocker=POSITION_AND_YAW_EVIDENCE yaw-witness=True pos-witness=True hold=True

## nominal_0003

- t=120.802s source=CENTER_YAW_ANCHOR pos=0.0486m yaw=1.392deg load-yaw-age=101.18799999989986s blocker=YAW_EVIDENCE yaw-witness=True pos-witness=False hold=True

## nominal_0004

- t=144.602s source=MULTIVIEW pos=0.0731m yaw=2.576deg load-yaw-age=121.38599999996433s blocker=POSITION_AND_YAW_EVIDENCE yaw-witness=True pos-witness=True hold=True

## nominal_0005

- t=122.302s source=CENTER_YAW_ANCHOR pos=0.0636m yaw=0.383deg load-yaw-age=100.9879999998973s blocker=POSITION_AND_YAW_EVIDENCE yaw-witness=True pos-witness=True hold=True

## nominal_0006

- t=142.002s source=MULTIVIEW pos=0.0490m yaw=3.053deg load-yaw-age=118.88599999995186s blocker=YAW_EVIDENCE yaw-witness=True pos-witness=False hold=True

## nominal_0007

- t=138.802s source=CENTER_YAW_ANCHOR pos=0.0436m yaw=3.028deg load-yaw-age=115.68599999993658s blocker=YAW_EVIDENCE yaw-witness=True pos-witness=False hold=True

## nominal_0008

- t=174.200s source=CENTER_YAW_ANCHOR pos=0.0568m yaw=3.060deg load-yaw-age=150.48400000010594s blocker=POSITION_AND_YAW_EVIDENCE yaw-witness=True pos-witness=True hold=True

## nominal_0009

- t=127.602s source=CENTER_YAW_ANCHOR pos=0.0695m yaw=1.128deg load-yaw-age=94.88599999989s blocker=POSITION_AND_YAW_EVIDENCE yaw-witness=True pos-witness=True hold=True

## nominal_0010

- No legacy strict certification.
