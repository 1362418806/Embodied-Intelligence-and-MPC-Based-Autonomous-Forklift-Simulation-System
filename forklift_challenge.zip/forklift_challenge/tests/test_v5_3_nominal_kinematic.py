"""Kinematic sign/convergence smoke test for V5.3 corridor feedback.

This does not replace MuJoCo batch evaluation. It protects the fork-reference
steering law from sign regressions across difficult nominal relative poses.
"""

from __future__ import annotations

import math
from pathlib import Path

import yaml

from control.docking_controller import (
    DockingController,
    object_axis_corridor_error,
)
from interfaces.observation import Pose3D


PROJECT_ROOT = Path(__file__).resolve().parents[1]
WHEELBASE = 0.93


def wrap(angle: float) -> float:
    return (angle + math.pi) % (2.0 * math.pi) - math.pi


def pose_from_axis(*, x: float, lateral: float, yaw: float) -> Pose3D:
    y = (lateral + x * math.sin(yaw)) / math.cos(yaw)
    return Pose3D(
        x=x,
        y=y,
        z=0.0,
        roll=0.0,
        pitch=0.0,
        yaw=yaw,
    )


def load_components():
    config = yaml.safe_load(
        (PROJECT_ROOT / "configs" / "vehicle_v5_3.yaml").read_text(
            encoding="utf-8"
        )
    )
    values = config["controller"]
    controller = DockingController(
        distance_gain=float(values["distance_gain"]),
        heading_gain=float(values["heading_gain"]),
        yaw_gain=float(values["yaw_gain"]),
        lateral_gain=float(values["lateral_gain"]),
        lookahead_distance=float(values["lookahead_distance"]),
        maximum_steering=float(values["maximum_steering"]),
        minimum_creep_speed=float(values["minimum_creep_speed"]),
        heading_slowdown_angle=float(values["heading_slowdown_angle"]),
        yaw_slowdown_angle=float(values["yaw_slowdown_angle"]),
        minimum_alignment_scale=float(values["minimum_alignment_scale"]),
    )
    return controller, config["autonomy"]


def step_relative(
    pose: Pose3D,
    *,
    speed: float,
    steering: float,
    dt: float,
) -> Pose3D:
    yaw_rate = speed * math.tan(steering) / WHEELBASE
    x_dot = -speed + yaw_rate * pose.y
    y_dot = -yaw_rate * pose.x
    return Pose3D(
        x=pose.x + x_dot * dt,
        y=pose.y + y_dot * dt,
        z=0.0,
        roll=0.0,
        pitch=0.0,
        yaw=wrap(pose.yaw - yaw_rate * dt),
    )


def run_case(initial: Pose3D) -> None:
    controller, p = load_components()
    pose = initial
    speed = 0.0
    steering = 0.0
    state = "APPROACH"
    hold = 0.0
    dt = 0.01

    for _ in range(18000):
        if state == "APPROACH":
            target = float(p["approach_line_distance"])
            maximum_speed = float(p["approach_max_speed"])
            minimum_speed = None
            steering_limit = None
            if pose.x - target <= float(p["pre_position_tolerance"]):
                state = "ALIGN"

        if state == "ALIGN":
            target = float(p["alignment_abort_distance"])
            maximum_speed = float(p["align_max_speed"])
            minimum_speed = float(p["align_minimum_speed"])
            steering_limit = None
            corridor = object_axis_corridor_error(
                pose,
                fork_root_distance=float(p["fork_root_distance"]),
                fork_tip_distance=float(p["fork_tip_distance"]),
                object_half_length=float(p["pallet_half_length"]),
                object_center_distance=float(p["insertion_distance"]),
            )
            aligned = (
                pose.x - float(p["alignment_line_distance"])
                <= float(p["pre_position_tolerance"])
                and corridor.maximum_abs_lateral
                <= float(p["alignment_preview_tolerance"])
                and abs(pose.yaw) <= float(p["pre_yaw_tolerance"])
            )
            hold = hold + dt if aligned else 0.0
            if hold >= float(p["alignment_hold_seconds"]):
                state = "INSERT"
                hold = 0.0

        if state == "INSERT":
            target = float(p["insertion_abort_distance"])
            maximum_speed = float(p["insertion_max_speed"])
            minimum_speed = float(p["insertion_minimum_speed"])
            steering_limit = float(p["insertion_steering_limit"])
            corridor = object_axis_corridor_error(
                pose,
                fork_root_distance=float(p["fork_root_distance"]),
                fork_tip_distance=float(p["fork_tip_distance"]),
                object_half_length=float(p["pallet_half_length"]),
                object_center_distance=min(
                    pose.x,
                    float(p["insertion_distance"]),
                ),
            )
            inserted = (
                pose.x - float(p["insertion_distance"])
                <= float(p["insertion_position_tolerance"])
                and corridor.maximum_abs_lateral
                <= float(p["insertion_corridor_tolerance"])
                and abs(pose.yaw) <= float(p["insertion_yaw_tolerance"])
            )
            if inserted:
                return

        corridor = object_axis_corridor_error(
            pose,
            fork_root_distance=float(p["fork_root_distance"]),
            fork_tip_distance=float(p["fork_tip_distance"]),
            object_half_length=float(p["pallet_half_length"]),
            object_center_distance=(
                min(pose.x, float(p["insertion_distance"]))
                if state == "INSERT"
                else float(p["insertion_distance"])
            ),
        )
        reference = 0.5 * (
            corridor.near_reference + corridor.far_reference
        )
        command = controller.axis_command(
            pose,
            target_distance=target,
            maximum_speed=maximum_speed,
            lift_target=0.04,
            steering_limit=steering_limit,
            minimum_speed_override=minimum_speed,
            lateral_reference_distance=reference,
            lateral_gain_override=float(
                p["corridor_control_lateral_gain"]
            ),
            yaw_gain_override=float(p["corridor_control_yaw_gain"]),
            lookahead_distance_override=float(
                p["corridor_control_lookahead"]
            ),
        )

        # Deliberately slow steering response protects against a controller
        # that only works with unrealistically instantaneous joints.
        speed += (
            command.action.speed_target - speed
        ) * min(1.0, dt / 0.45)
        steering += (
            command.action.steering_command - steering
        ) * min(1.0, dt / 4.0)
        pose = step_relative(
            pose,
            speed=speed,
            steering=steering,
            dt=dt,
        )

    raise AssertionError(
        "V5.3 corridor controller did not converge from "
        f"x={initial.x:.3f}, y={initial.y:.3f}, "
        f"yaw={math.degrees(initial.yaw):.2f}deg"
    )


def test_difficult_nominal_trace_geometries_converge() -> None:
    cases = (
        pose_from_axis(x=4.18, lateral=0.195, yaw=math.radians(-4.60)),
        pose_from_axis(x=4.33, lateral=0.103, yaw=math.radians(9.16)),
        pose_from_axis(x=4.02, lateral=-0.343, yaw=math.radians(-3.50)),
        pose_from_axis(x=4.29, lateral=-0.174, yaw=math.radians(-8.02)),
        pose_from_axis(x=4.15, lateral=0.188, yaw=math.radians(-10.08)),
        pose_from_axis(x=3.96, lateral=0.420, yaw=math.radians(6.45)),
    )
    for case in cases:
        run_case(case)
