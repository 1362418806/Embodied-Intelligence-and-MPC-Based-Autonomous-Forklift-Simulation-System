"""Render one front-camera frame and verify the V8.0 colour marker."""

from __future__ import annotations

import argparse
import math
from pathlib import Path
import sys

import cv2
import mujoco
import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from perception.color_marker_detector import ColourPlacementMarkerDetector
from simulator.camera_renderer import MultiCameraRenderer


DEFAULT_CONFIG = PROJECT_ROOT / "configs" / "vehicle_v8_0.yaml"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--vehicle-x", type=float, default=3.20)
    parser.add_argument("--vehicle-y", type=float, default=-1.50)
    parser.add_argument("--vehicle-yaw-deg", type=float, default=0.0)
    parser.add_argument(
        "--output",
        type=Path,
        default=PROJECT_ROOT / "outputs" / "v8_0_vision_smoke",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    config_path = args.config.resolve()
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    model_path = (PROJECT_ROOT / config["model"]["xml_path"]).resolve()
    model = mujoco.MjModel.from_xml_path(str(model_path))
    data = mujoco.MjData(model)
    mujoco.mj_resetData(model, data)

    joint_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, "forklift_free")
    if joint_id < 0:
        raise RuntimeError("forklift_free joint was not found")
    qpos = int(model.jnt_qposadr[joint_id])
    data.qpos[qpos] = float(args.vehicle_x)
    data.qpos[qpos + 1] = float(args.vehicle_y)
    yaw = math.radians(float(args.vehicle_yaw_deg))
    data.qpos[qpos + 3 : qpos + 7] = [
        math.cos(0.5 * yaw),
        0.0,
        0.0,
        math.sin(0.5 * yaw),
    ]
    mujoco.mj_forward(model, data)

    camera = config["camera"]
    renderer = MultiCameraRenderer(
        model,
        width=int(camera["width"]),
        height=int(camera["height"]),
    )
    try:
        rgb = renderer.render(data, str(config["vision"]["camera_name"]))
    finally:
        renderer.close()

    detector = ColourPlacementMarkerDetector.from_config(
        config["vision"],
        image_width=int(camera["width"]),
        image_height=int(camera["height"]),
    )
    detection = detector.detect(rgb)
    annotated = detector.annotate(rgb, detection)
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(
        str(output / "front_rgb.png"),
        cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR),
    )
    cv2.imwrite(
        str(output / "front_rgb_marker.png"),
        cv2.cvtColor(annotated, cv2.COLOR_RGB2BGR),
    )

    print(f"marker_status: {detection.status}")
    print(f"confidence: {detection.confidence:.3f}")
    print(f"reprojection_error_px: {detection.reprojection_error_px}")
    print(f"marker_distance_m: {detection.marker_distance_m}")
    print(f"target_pose_in_base: {detection.target_pose_in_base}")
    print(f"images: {output}")
    return 0 if detection.success else 2


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (FileNotFoundError, KeyError, RuntimeError, ValueError, yaml.YAMLError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
