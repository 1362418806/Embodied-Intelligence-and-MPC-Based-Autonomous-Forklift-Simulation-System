"""Serializable episode metrics and aggregate reporting."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
import csv
import json
from pathlib import Path
from statistics import mean
from typing import Any, Iterable


@dataclass(frozen=True)
class EpisodeResult:
    scenario_id: str
    difficulty: str
    seed: int
    success: bool
    final_state: str
    failure_reason: str | None
    duration_seconds: float
    path_length_m: float
    max_abs_steering_deg: float
    max_load_tilt_deg: float
    initial_lateral_error_m: float
    initial_yaw_error_deg: float
    final_lateral_error_m: float
    final_yaw_error_deg: float
    steering_exercised: bool
    state_durations: dict[str, float] = field(default_factory=dict)
    scenario: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def summarize_results(results: Iterable[EpisodeResult]) -> dict[str, Any]:
    items = list(results)
    if not items:
        return {
            "episode_count": 0,
            "success_count": 0,
            "success_rate": 0.0,
            "steering_exercised_rate": 0.0,
            "average_duration_seconds": 0.0,
            "average_path_length_m": 0.0,
            "failure_reasons": {},
            "by_difficulty": {},
        }

    successes = [item for item in items if item.success]
    steering_count = sum(item.steering_exercised for item in items)
    failures: dict[str, int] = {}
    by_difficulty: dict[str, dict[str, Any]] = {}

    for item in items:
        if not item.success:
            reason = item.failure_reason or item.final_state or "unknown"
            failures[reason] = failures.get(reason, 0) + 1

        bucket = by_difficulty.setdefault(
            item.difficulty,
            {"episodes": 0, "successes": 0},
        )
        bucket["episodes"] += 1
        bucket["successes"] += int(item.success)

    for bucket in by_difficulty.values():
        bucket["success_rate"] = bucket["successes"] / bucket["episodes"]

    return {
        "episode_count": len(items),
        "success_count": len(successes),
        "success_rate": len(successes) / len(items),
        "steering_exercised_rate": steering_count / len(items),
        "average_duration_seconds": mean(item.duration_seconds for item in items),
        "average_path_length_m": mean(item.path_length_m for item in items),
        "average_success_duration_seconds": (
            mean(item.duration_seconds for item in successes) if successes else None
        ),
        "maximum_load_tilt_deg": max(item.max_load_tilt_deg for item in items),
        "failure_reasons": failures,
        "by_difficulty": by_difficulty,
    }


def write_results(
    output_dir: Path,
    results: Iterable[EpisodeResult],
) -> dict[str, Any]:
    """Write JSONL, CSV and summary JSON, then return the summary."""
    output_dir.mkdir(parents=True, exist_ok=True)
    items = list(results)
    summary = summarize_results(items)

    jsonl_path = output_dir / "episodes.jsonl"
    with jsonl_path.open("w", encoding="utf-8") as stream:
        for item in items:
            stream.write(json.dumps(item.to_dict(), ensure_ascii=False) + "\n")

    csv_path = output_dir / "episodes.csv"
    scalar_fields = [
        "scenario_id",
        "difficulty",
        "seed",
        "success",
        "final_state",
        "failure_reason",
        "duration_seconds",
        "path_length_m",
        "max_abs_steering_deg",
        "max_load_tilt_deg",
        "initial_lateral_error_m",
        "initial_yaw_error_deg",
        "final_lateral_error_m",
        "final_yaw_error_deg",
        "steering_exercised",
    ]
    with csv_path.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=scalar_fields)
        writer.writeheader()
        for item in items:
            row = item.to_dict()
            writer.writerow({name: row[name] for name in scalar_fields})

    summary_path = output_dir / "summary.json"
    summary_path.write_text(
        json.dumps(summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return summary
