"""Unit tests for the v4 geometric docking controller."""

from __future__ import annotations

import math

from control.docking_controller import DockingController, object_standoff_error
from interfaces.observation import Pose3D


def pose(x: float, y: float = 0.0, yaw: float = 0.0) -> Pose3D:
    return Pose3D(x=x, y=y, z=0.0, roll=0.0, pitch=0.0, yaw=yaw)


def controller() -> DockingController:
    return DockingController(
        distance_gain=0.75,
        heading_gain=1.35,
        yaw_gain=0.80,
        maximum_steering=0.30,
        minimum_creep_speed=0.04,
        heading_slowdown_angle=0.55,
    )


def test_standoff_error_is_zero_at_desired_aligned_pose() -> None:
    error = object_standoff_error(pose(2.70), standoff_distance=2.70)
    assert math.isclose(error.distance, 0.0, abs_tol=1e-9)
    assert math.isclose(error.lateral, 0.0, abs_tol=1e-9)
    assert math.isclose(error.yaw, 0.0, abs_tol=1e-9)


def test_straight_target_generates_forward_motion() -> None:
    result = controller().command(
        pose(3.20),
        standoff_distance=2.70,
        maximum_speed=0.30,
        lift_target=0.04,
    )
    assert result.action.speed_target > 0.0
    assert abs(result.action.steering_command) < 1e-9
    assert math.isclose(result.action.lift_target, 0.04)


def test_target_to_left_generates_left_turn_command() -> None:
    result = controller().command(
        pose(3.20, y=0.25),
        standoff_distance=2.70,
        maximum_speed=0.30,
        lift_target=0.04,
    )
    assert result.action.speed_target > 0.0
    assert result.action.steering_command > 0.0


def test_controller_stops_at_target_pose() -> None:
    result = controller().command(
        pose(1.55),
        standoff_distance=1.55,
        maximum_speed=0.10,
        lift_target=0.04,
    )
    assert result.action.speed_target == 0.0


def test_steering_and_speed_are_limited() -> None:
    result = controller().command(
        pose(4.0, y=3.0, yaw=0.5),
        standoff_distance=2.70,
        maximum_speed=0.14,
        lift_target=0.04,
        steering_limit=0.12,
    )
    assert 0.0 <= result.action.speed_target <= 0.14
    assert abs(result.action.steering_command) <= 0.12 + 1e-12
