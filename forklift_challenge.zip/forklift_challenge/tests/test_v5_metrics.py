"""Aggregation checks for v5 batch evaluation metrics."""

from __future__ import annotations

from evaluation.metrics import EpisodeResult, summarize_results


def result(*, success: bool, difficulty: str, steering: bool) -> EpisodeResult:
    return EpisodeResult(
        scenario_id="case",
        difficulty=difficulty,
        seed=1,
        success=success,
        final_state="DONE" if success else "FAILED",
        failure_reason=None if success else "timeout",
        duration_seconds=10.0 if success else 20.0,
        path_length_m=2.0,
        max_abs_steering_deg=5.0 if steering else 0.0,
        max_load_tilt_deg=1.0,
        initial_lateral_error_m=0.1,
        initial_yaw_error_deg=3.0,
        final_lateral_error_m=0.0,
        final_yaw_error_deg=0.0,
        steering_exercised=steering,
    )


def test_empty_summary_is_well_defined() -> None:
    summary = summarize_results([])
    assert summary["episode_count"] == 0
    assert summary["success_rate"] == 0.0


def test_summary_counts_success_steering_and_failure_reason() -> None:
    summary = summarize_results(
        [
            result(success=True, difficulty="easy", steering=True),
            result(success=False, difficulty="easy", steering=False),
        ]
    )
    assert summary["episode_count"] == 2
    assert summary["success_count"] == 1
    assert summary["success_rate"] == 0.5
    assert summary["steering_exercised_rate"] == 0.5
    assert summary["failure_reasons"] == {"timeout": 1}
    assert summary["by_difficulty"]["easy"]["success_rate"] == 0.5
