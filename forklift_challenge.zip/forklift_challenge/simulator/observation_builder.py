"""Build unified observations from MuJoCo state."""

from __future__ import annotations

import math
from dataclasses import dataclass

import mujoco
import numpy as np

from interfaces.observation import ForkliftObservation, Pose3D


def _require_id(
    model: mujoco.MjModel,
    object_type: mujoco.mjtObj,
    name: str,
) -> int:
    object_id = mujoco.mj_name2id(model, object_type, name)
    if object_id < 0:
        raise RuntimeError(f"Required MuJoCo object was not found: {name}")
    return object_id


def _rpy_from_matrix(rotation: np.ndarray) -> tuple[float, float, float]:
    """Convert a 3x3 rotation matrix to roll, pitch, yaw."""
    sy = math.hypot(float(rotation[0, 0]), float(rotation[1, 0]))
    singular = sy < 1e-8

    if not singular:
        roll = math.atan2(float(rotation[2, 1]), float(rotation[2, 2]))
        pitch = math.atan2(-float(rotation[2, 0]), sy)
        yaw = math.atan2(float(rotation[1, 0]), float(rotation[0, 0]))
    else:
        roll = math.atan2(-float(rotation[1, 2]), float(rotation[1, 1]))
        pitch = math.atan2(-float(rotation[2, 0]), sy)
        yaw = 0.0
    return roll, pitch, yaw


def _pose_from_world_transform(position: np.ndarray, rotation: np.ndarray) -> Pose3D:
    roll, pitch, yaw = _rpy_from_matrix(rotation)
    return Pose3D(
        x=float(position[0]),
        y=float(position[1]),
        z=float(position[2]),
        roll=roll,
        pitch=pitch,
        yaw=yaw,
    )


def _relative_pose(
    base_position: np.ndarray,
    base_rotation: np.ndarray,
    target_position: np.ndarray,
    target_rotation: np.ndarray,
) -> Pose3D:
    rotation_base_target = base_rotation.T @ target_rotation
    position_base_target = base_rotation.T @ (target_position - base_position)
    return _pose_from_world_transform(position_base_target, rotation_base_target)


@dataclass(frozen=True)
class ObservationNames:
    vehicle_body: str = "forklift"
    vehicle_free_joint: str = "forklift_free"
    pallet_body: str = "pallet_load"
    placement_site: str = "placement_target"
    rear_left_steer_joint: str = "rear_left_steer_joint"
    rear_right_steer_joint: str = "rear_right_steer_joint"
    front_left_wheel_joint: str = "front_left_wheel_joint"
    front_right_wheel_joint: str = "front_right_wheel_joint"
    lift_joint: str = "lift_joint"


class ObservationBuilder:
    """Resolve model indices once, then build observations efficiently."""

    def __init__(
        self,
        model: mujoco.MjModel,
        names: ObservationNames | None = None,
    ) -> None:
        self.model = model
        self.names = names or ObservationNames()

        self.vehicle_body = _require_id(
            model, mujoco.mjtObj.mjOBJ_BODY, self.names.vehicle_body
        )
        self.pallet_body = _require_id(
            model, mujoco.mjtObj.mjOBJ_BODY, self.names.pallet_body
        )
        self.placement_site = _require_id(
            model, mujoco.mjtObj.mjOBJ_SITE, self.names.placement_site
        )

        vehicle_joint = _require_id(
            model, mujoco.mjtObj.mjOBJ_JOINT, self.names.vehicle_free_joint
        )
        self.vehicle_dof = int(model.jnt_dofadr[vehicle_joint])

        self.rear_left_qpos = self._joint_qpos(self.names.rear_left_steer_joint)
        self.rear_right_qpos = self._joint_qpos(self.names.rear_right_steer_joint)
        self.front_left_dof = self._joint_dof(self.names.front_left_wheel_joint)
        self.front_right_dof = self._joint_dof(self.names.front_right_wheel_joint)
        self.lift_qpos = self._joint_qpos(self.names.lift_joint)
        self.lift_dof = self._joint_dof(self.names.lift_joint)

    def _joint_qpos(self, name: str) -> int:
        joint_id = _require_id(self.model, mujoco.mjtObj.mjOBJ_JOINT, name)
        return int(self.model.jnt_qposadr[joint_id])

    def _joint_dof(self, name: str) -> int:
        joint_id = _require_id(self.model, mujoco.mjtObj.mjOBJ_JOINT, name)
        return int(self.model.jnt_dofadr[joint_id])

    def build(
        self,
        data: mujoco.MjData,
        *,
        fork_contact_count: int,
        load_state: str,
    ) -> ForkliftObservation:
        vehicle_position = np.asarray(data.xpos[self.vehicle_body], dtype=float)
        vehicle_rotation = np.asarray(
            data.xmat[self.vehicle_body], dtype=float
        ).reshape(3, 3)
        pallet_position = np.asarray(data.xpos[self.pallet_body], dtype=float)
        pallet_rotation = np.asarray(
            data.xmat[self.pallet_body], dtype=float
        ).reshape(3, 3)
        placement_position = np.asarray(
            data.site_xpos[self.placement_site], dtype=float
        )
        placement_rotation = np.asarray(
            data.site_xmat[self.placement_site], dtype=float
        ).reshape(3, 3)

        generalized_velocity = data.qvel[self.vehicle_dof : self.vehicle_dof + 6]

        return ForkliftObservation(
            sim_time=float(data.time),
            vehicle_pose_world=_pose_from_world_transform(
                vehicle_position, vehicle_rotation
            ),
            vehicle_linear_velocity=tuple(
                float(value) for value in generalized_velocity[:3]
            ),
            vehicle_angular_velocity=tuple(
                float(value) for value in generalized_velocity[3:6]
            ),
            steering_left=float(data.qpos[self.rear_left_qpos]),
            steering_right=float(data.qpos[self.rear_right_qpos]),
            front_wheel_speed_left=float(data.qvel[self.front_left_dof]),
            front_wheel_speed_right=float(data.qvel[self.front_right_dof]),
            lift_position=float(data.qpos[self.lift_qpos]),
            lift_velocity=float(data.qvel[self.lift_dof]),
            pallet_pose_world=_pose_from_world_transform(
                pallet_position, pallet_rotation
            ),
            pallet_pose_in_base=_relative_pose(
                vehicle_position,
                vehicle_rotation,
                pallet_position,
                pallet_rotation,
            ),
            placement_pose_in_base=_relative_pose(
                vehicle_position,
                vehicle_rotation,
                placement_position,
                placement_rotation,
            ),
            fork_contact_count=int(fork_contact_count),
            load_state=str(load_state),
        )
