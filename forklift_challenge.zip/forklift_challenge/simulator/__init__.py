"""Simulator adapters and headless episode execution."""
