"""Configuration checks for V6.1 loaded transport."""

from pathlib import Path

import yaml

from task.pickup_state_machine import PickupParameters


def test_v6_1_transport_configuration_is_valid() -> None:
    root = Path(__file__).resolve().parents[1]
    config = yaml.safe_load(
        (root / "configs" / "vehicle_v6_1.yaml").read_text(encoding="utf-8")
    )
    parameters = PickupParameters.from_mapping(config["autonomy"])
    assert parameters.transport_runway_distance == 6.20
    assert parameters.transport_reposition_speed < 0.0
    assert parameters.transport_path_wheelbase == 0.93
    assert parameters.transport_path_samples >= 21
    assert parameters.transport_path_minimum_speed <= parameters.transport_max_speed
