"""Static audit for V9.3.12-R4-E Fresh-RGB Yaw Closure."""
from __future__ import annotations
from pathlib import Path
import ast, yaml
ROOT=Path(__file__).resolve().parents[1]

def need(text:str, token:str, label:str):
    if token not in text: raise AssertionError(f'{label}: missing {token}')
    print(f'PASS {label}')

def main()->int:
    task=(ROOT/'task/pickup_state_machine.py').read_text(encoding='utf-8')
    ctrl=(ROOT/'control/terminal_micro_primitives.py').read_text(encoding='utf-8')
    cfg=yaml.safe_load((ROOT/'configs/vehicle_v9_3_12_r4_e.yaml').read_text(encoding='utf-8'))
    ast.parse(task); ast.parse(ctrl)
    print('PASS syntax')
    for token,label in [
        ('class FreshRGBYawClosurePlanner','paired yaw closure planner'),
        ('predicted_mid','midpoint position guard'),
        ('V9.3.12-R4-E one-shot strict-evidence settle','one-shot settle'),
        ('_strict_recovery_retention_final_settle_consumed','settle consumed latch'),
        ('LoadSeedProvenance.TERMINAL_RGB','terminal RGB provenance gate'),
        ('placement_fresh_rgb_yaw_closure_maximum_rgb_stale_seconds','RGB freshness gate'),
        ('placement_fresh_rgb_yaw_closure_maximum_observer_yaw_sigma_rad','observer sigma gate'),
        ('placement_fresh_rgb_yaw_closure_maximum_target_fast_slow_yaw_disagreement_rad','target consistency gate'),
        ('post-motion RGB settle','post-motion feedback settle'),
    ]: need(task+ctrl,token,label)
    weak=cfg['perception']['terminal_autonomy_overrides']['weak_guide']
    assert weak['placement_fresh_rgb_yaw_closure_enabled']==1.0
    assert weak['placement_fresh_rgb_yaw_closure_max_activations']<=2
    assert weak['placement_strict_release_yaw_limit_rad']==0.08028514559173916
    assert weak['placement_terminal_budget_seconds']==90.0
    assert weak['placement_certified_basin_consensus_release_authority']==0.0
    print('PASS weak-guide R4-E enabled')
    print('PASS strict limit unchanged')
    print('PASS 90s budget unchanged')
    print('PASS consensus release authority OFF')
    print('R4-E audit PASS')
    return 0
if __name__=='__main__': raise SystemExit(main())
