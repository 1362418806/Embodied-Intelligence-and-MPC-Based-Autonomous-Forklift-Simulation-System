"""Forklift v5: randomized-pose autonomous pickup and steering validation.

Controls
--------
P                 Start/pause autonomous pickup.
N                 Sample a new randomized scenario and reset.
R                 Reset the current scenario.
W / S             Manual forward/reverse; pauses autonomy.
Space             Manual stop; pauses autonomy.
A / D / C         Manual left/right/center steering; pauses autonomy.
I / K             Manual fork raise/lower; pauses autonomy.

Use ``--scenario lateral_left`` or ``--scenario yaw_left`` to force a start
condition that visibly requires steering.
"""

from __future__ import annotations

import argparse
import math
import sys
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import cv2
import glfw
import mujoco
import mujoco.viewer
import numpy as np
import yaml


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from control.ackermann import (  # noqa: E402
    front_drive_angular_speeds,
    rear_ackermann_angles,
)
from control.docking_controller import DockingController  # noqa: E402
from control.safety import LiftDriveInterlock  # noqa: E402
from interfaces.action import ForkliftAction  # noqa: E402
from scenarios.randomization import (  # noqa: E402
    Scenario,
    ScenarioSampler,
    apply_scenario,
    named_scenario,
)
from simulator.camera_renderer import MultiCameraRenderer  # noqa: E402
from simulator.episode_recorder import EpisodeRecorder  # noqa: E402
from simulator.observation_builder import ObservationBuilder  # noqa: E402
from task.pickup_state_machine import (  # noqa: E402
    PickupDecision,
    PickupParameters,
    PickupStateMachine,
)


DEFAULT_CONFIG = PROJECT_ROOT / "configs" / "vehicle_v5.yaml"


@dataclass
class OperatorState:
    speed_target: float
    steering_command: float
    lift_target: float
    autonomy_enabled: bool
    reset_requested: bool = False
    new_scenario_requested: bool = False


class SharedOperatorControl:
    """Thread-safe manual commands and reset requests."""

    def __init__(self, *, lift_target: float, autostart: bool) -> None:
        self._state = OperatorState(0.0, 0.0, lift_target, autostart)
        self._lock = threading.Lock()

    @staticmethod
    def _clamp(value: float, minimum: float, maximum: float) -> float:
        return min(max(float(value), float(minimum)), float(maximum))

    def toggle_autonomy(self) -> None:
        with self._lock:
            self._state.autonomy_enabled = not self._state.autonomy_enabled
            self._state.speed_target = 0.0
            self._state.steering_command = 0.0

    def manual_speed(self, delta: float, minimum: float, maximum: float) -> None:
        with self._lock:
            self._state.autonomy_enabled = False
            self._state.speed_target = self._clamp(
                self._state.speed_target + delta,
                minimum,
                maximum,
            )

    def manual_stop(self) -> None:
        with self._lock:
            self._state.autonomy_enabled = False
            self._state.speed_target = 0.0
            self._state.steering_command = 0.0

    def manual_steering(self, delta: float, maximum: float) -> None:
        with self._lock:
            self._state.autonomy_enabled = False
            self._state.steering_command = self._clamp(
                self._state.steering_command + delta,
                -maximum,
                maximum,
            )

    def center_steering(self) -> None:
        with self._lock:
            self._state.autonomy_enabled = False
            self._state.steering_command = 0.0

    def manual_lift(self, delta: float, minimum: float, maximum: float) -> None:
        with self._lock:
            self._state.autonomy_enabled = False
            self._state.speed_target = 0.0
            self._state.lift_target = self._clamp(
                self._state.lift_target + delta,
                minimum,
                maximum,
            )

    def request_reset(self, *, new_scenario: bool) -> None:
        with self._lock:
            self._state.reset_requested = True
            self._state.new_scenario_requested = new_scenario

    def synchronize_lift_target(self, lift_target: float) -> None:
        with self._lock:
            self._state.lift_target = float(lift_target)

    def reset(self, *, lift_target: float, autostart: bool) -> None:
        with self._lock:
            self._state = OperatorState(0.0, 0.0, lift_target, autostart)

    def snapshot(self) -> OperatorState:
        with self._lock:
            result = OperatorState(
                speed_target=self._state.speed_target,
                steering_command=self._state.steering_command,
                lift_target=self._state.lift_target,
                autonomy_enabled=self._state.autonomy_enabled,
                reset_requested=self._state.reset_requested,
                new_scenario_requested=self._state.new_scenario_requested,
            )
            self._state.reset_requested = False
            self._state.new_scenario_requested = False
            return result


def load_config(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise FileNotFoundError(f"configuration file does not exist: {path}")
    with path.open("r", encoding="utf-8") as stream:
        config = yaml.safe_load(stream)
    if not isinstance(config, dict):
        raise ValueError("configuration root must be a mapping")
    for section in (
        "model",
        "simulation",
        "drive",
        "lift",
        "pickup",
        "safety",
        "camera",
        "recording",
        "controller",
        "autonomy",
        "randomization",
    ):
        if section not in config:
            raise KeyError(f"missing required configuration section: {section}")
    return config


def require_id(model: mujoco.MjModel, object_type: mujoco.mjtObj, name: str) -> int:
    object_id = mujoco.mj_name2id(model, object_type, name)
    if object_id < 0:
        raise RuntimeError(f"required MuJoCo object was not found: {name}")
    return int(object_id)


def rpy_from_freejoint(
    data: mujoco.MjData,
    qpos_address: int,
) -> tuple[float, float, float]:
    w, x, y, z = data.qpos[qpos_address + 3 : qpos_address + 7]
    sinr_cosp = 2.0 * (w * x + y * z)
    cosr_cosp = 1.0 - 2.0 * (x * x + y * y)
    roll = math.atan2(sinr_cosp, cosr_cosp)
    sinp = 2.0 * (w * y - z * x)
    pitch = math.copysign(math.pi / 2.0, sinp) if abs(sinp) >= 1.0 else math.asin(sinp)
    siny_cosp = 2.0 * (w * z + x * y)
    cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
    yaw = math.atan2(siny_cosp, cosy_cosp)
    return roll, pitch, yaw


def count_cross_contacts(
    data: mujoco.MjData,
    first_group: Iterable[int],
    second_group: Iterable[int],
) -> int:
    first = set(first_group)
    second = set(second_group)
    count = 0
    for index in range(data.ncon):
        contact = data.contact[index]
        geom1 = int(contact.geom1)
        geom2 = int(contact.geom2)
        if (geom1 in first and geom2 in second) or (
            geom2 in first and geom1 in second
        ):
            count += 1
    return count


def overlay_camera_text(
    rgb: np.ndarray,
    *,
    title: str,
    lines: list[str],
) -> np.ndarray:
    bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    height = min(bgr.shape[0], 31 + 23 * len(lines))
    cv2.rectangle(bgr, (0, 0), (bgr.shape[1], height), (0, 0, 0), -1)
    cv2.putText(
        bgr,
        title,
        (10, 22),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.62,
        (255, 255, 255),
        1,
        cv2.LINE_AA,
    )
    for index, line in enumerate(lines):
        cv2.putText(
            bgr,
            line,
            (10, 45 + index * 23),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.52,
            (255, 255, 255),
            1,
            cv2.LINE_AA,
        )
    return bgr


def controller_from_config(values: dict[str, Any]) -> DockingController:
    return DockingController(
        distance_gain=float(values["distance_gain"]),
        heading_gain=float(values["heading_gain"]),
        yaw_gain=float(values["yaw_gain"]),
        lateral_gain=float(values.get("lateral_gain", 0.0)),
        lookahead_distance=float(values.get("lookahead_distance", 0.75)),
        maximum_steering=float(values["maximum_steering"]),
        minimum_creep_speed=float(values["minimum_creep_speed"]),
        heading_slowdown_angle=float(values["heading_slowdown_angle"]),
        yaw_slowdown_angle=float(
            values.get("yaw_slowdown_angle", values["heading_slowdown_angle"])
        ),
        minimum_alignment_scale=float(values.get("minimum_alignment_scale", 0.20)),
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--autostart", action="store_true")
    parser.add_argument("--seed", type=int)
    parser.add_argument(
        "--difficulty",
        choices=ScenarioSampler.difficulties(),
    )
    parser.add_argument(
        "--scenario",
        choices=ScenarioSampler.named_scenarios(),
        help="Use a deterministic validation scenario instead of random sampling.",
    )
    parser.add_argument("--fixed-start", action="store_true")
    parser.add_argument("--no-camera-windows", action="store_true")
    parser.add_argument("--no-record", action="store_true")
    parser.add_argument("--record-images", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    config = load_config(args.config.resolve())
    model_path = (PROJECT_ROOT / config["model"]["xml_path"]).resolve()
    if not model_path.is_file():
        raise FileNotFoundError(f"MJCF model does not exist: {model_path}")

    simulation = config["simulation"]
    drive = config["drive"]
    lift = config["lift"]
    pickup = config["pickup"]
    safety = config["safety"]
    camera_config = config["camera"]
    recording_config = config["recording"]
    autonomy_config = config["autonomy"]
    randomization = config["randomization"]

    wheelbase = float(drive["wheelbase"])
    front_track = float(drive["front_track"])
    rear_track = float(drive["rear_track"])
    wheel_radius = float(drive["front_wheel_radius"])
    speed_min = float(drive["minimum_speed"])
    speed_max = float(drive["maximum_speed"])
    speed_step = float(drive["keyboard_speed_step"])
    steering_max = float(drive["maximum_steering_command"])
    steering_step = float(drive["keyboard_steering_step"])
    lift_min = float(lift["minimum_height"])
    lift_max = float(lift["maximum_height"])
    lift_initial = float(lift["initial_target"])
    lift_step = float(lift["keyboard_step"])
    realtime_factor = float(simulation["realtime_factor"])
    status_interval = float(simulation["status_interval_seconds"])
    observation_period = 1.0 / float(simulation["observation_hz"])
    camera_follow = bool(simulation.get("camera_follow", True))
    if realtime_factor <= 0.0 or observation_period <= 0.0:
        raise ValueError("simulation timing values must be positive")

    lifted_threshold = float(pickup["lifted_height_threshold"])
    tilt_warning = float(pickup["tilt_warning_degrees"])
    camera_enabled = bool(camera_config["enabled"])
    show_camera_windows = (
        camera_enabled
        and bool(camera_config["show_windows"])
        and not args.no_camera_windows
    )
    camera_width = int(camera_config["width"])
    camera_height = int(camera_config["height"])
    front_camera_name = str(camera_config["front_name"])
    fork_camera_name = str(camera_config["fork_name"])
    recording_enabled = bool(recording_config["enabled"]) and not args.no_record
    save_images = bool(recording_config["save_images"]) or args.record_images
    output_root = (PROJECT_ROOT / recording_config["output_root"]).resolve()
    autostart = bool(autonomy_config.get("autostart", False)) or args.autostart

    seed = int(args.seed if args.seed is not None else randomization["default_seed"])
    difficulty = str(
        args.difficulty
        if args.difficulty is not None
        else randomization["default_difficulty"]
    )
    sampler = ScenarioSampler(seed=seed, difficulty=difficulty)
    if args.scenario:
        current_scenario = named_scenario(args.scenario)
    elif args.fixed_start:
        current_scenario = named_scenario("baseline")
    else:
        current_scenario = sampler.sample()

    model = mujoco.MjModel.from_xml_path(str(model_path))
    data = mujoco.MjData(model)
    mujoco.mj_resetData(model, data)
    apply_scenario(model, data, current_scenario)

    actuator_ids = {
        name: require_id(model, mujoco.mjtObj.mjOBJ_ACTUATOR, name)
        for name in (
            "front_left_drive_velocity",
            "front_right_drive_velocity",
            "rear_left_steer_position",
            "rear_right_steer_position",
            "lift_position",
        )
    }
    joint_ids = {
        name: require_id(model, mujoco.mjtObj.mjOBJ_JOINT, name)
        for name in (
            "forklift_free",
            "pallet_load_free",
            "rear_left_steer_joint",
            "rear_right_steer_joint",
            "lift_joint",
        )
    }
    forklift_qpos = int(model.jnt_qposadr[joint_ids["forklift_free"]])
    pallet_qpos = int(model.jnt_qposadr[joint_ids["pallet_load_free"]])
    rear_left_qpos = int(model.jnt_qposadr[joint_ids["rear_left_steer_joint"]])
    rear_right_qpos = int(model.jnt_qposadr[joint_ids["rear_right_steer_joint"]])
    lift_qpos = int(model.jnt_qposadr[joint_ids["lift_joint"]])
    lift_dof = int(model.jnt_dofadr[joint_ids["lift_joint"]])
    fork_geom_ids = {
        require_id(model, mujoco.mjtObj.mjOBJ_GEOM, "left_fork"),
        require_id(model, mujoco.mjtObj.mjOBJ_GEOM, "right_fork"),
    }
    pallet_geom_ids = {
        require_id(model, mujoco.mjtObj.mjOBJ_GEOM, name)
        for name in (
            "pallet_center_runner",
            "pallet_left_runner",
            "pallet_right_runner",
            "pallet_deck",
            "cargo_box",
        )
    }

    observation_builder = ObservationBuilder(model)
    pickup_machine = PickupStateMachine(
        parameters=PickupParameters.from_mapping(autonomy_config),
        docking_controller=controller_from_config(config["controller"]),
    )
    pickup_machine.reset(float(data.time))
    operator = SharedOperatorControl(lift_target=lift_initial, autostart=autostart)
    drive_interlock = LiftDriveInterlock(
        enabled=bool(safety["stop_drive_during_lift"]),
        velocity_threshold=float(safety["lift_velocity_threshold"]),
        settle_time=float(safety["lift_settle_time_seconds"]),
    )
    drive_interlock.reset(lift_target=lift_initial, sim_time=float(data.time))
    camera_renderer = (
        MultiCameraRenderer(model, width=camera_width, height=camera_height)
        if camera_enabled
        else None
    )
    recorder = EpisodeRecorder(
        output_root,
        enabled=recording_enabled,
        save_images=save_images,
    )
    ground_load_z = float(data.qpos[pallet_qpos + 2])

    def key_callback(keycode: int) -> None:
        if keycode == glfw.KEY_P:
            operator.toggle_autonomy()
        elif keycode == glfw.KEY_N:
            operator.request_reset(new_scenario=True)
        elif keycode == glfw.KEY_R:
            operator.request_reset(new_scenario=False)
        elif keycode == glfw.KEY_W:
            operator.manual_speed(speed_step, speed_min, speed_max)
        elif keycode == glfw.KEY_S:
            operator.manual_speed(-speed_step, speed_min, speed_max)
        elif keycode == glfw.KEY_SPACE:
            operator.manual_stop()
        elif keycode == glfw.KEY_A:
            operator.manual_steering(steering_step, steering_max)
        elif keycode == glfw.KEY_D:
            operator.manual_steering(-steering_step, steering_max)
        elif keycode == glfw.KEY_C:
            operator.center_steering()
        elif keycode in (glfw.KEY_I, glfw.KEY_UP):
            operator.manual_lift(lift_step, lift_min, lift_max)
        elif keycode in (glfw.KEY_K, glfw.KEY_DOWN):
            operator.manual_lift(-lift_step, lift_min, lift_max)

    def current_load_status() -> tuple[int, str, float]:
        load_z = float(data.qpos[pallet_qpos + 2])
        load_roll, load_pitch, _ = rpy_from_freejoint(data, pallet_qpos)
        tilt_deg = max(abs(math.degrees(load_roll)), abs(math.degrees(load_pitch)))
        contacts = count_cross_contacts(data, fork_geom_ids, pallet_geom_ids)
        state = (
            "LIFTED"
            if load_z - ground_load_z >= lifted_threshold
            else ("ENGAGED" if contacts > 0 else "GROUND")
        )
        if tilt_deg >= tilt_warning:
            state += "/TILT_WARNING"
        return contacts, state, tilt_deg

    def reset_episode(*, new_scenario: bool) -> None:
        nonlocal current_scenario, ground_load_z
        if new_scenario and not args.scenario and not args.fixed_start:
            current_scenario = sampler.sample()
        mujoco.mj_resetData(model, data)
        apply_scenario(model, data, current_scenario)
        ground_load_z = float(data.qpos[pallet_qpos + 2])
        operator.reset(lift_target=lift_initial, autostart=autostart)
        pickup_machine.reset(float(data.time))
        drive_interlock.reset(lift_target=lift_initial, sim_time=float(data.time))
        print(f"\nScenario reset: {current_scenario.to_dict()}")

    print(f"Loaded model: {model_path}")
    print(f"MuJoCo version: {mujoco.__version__}")
    print(f"Scenario: {current_scenario.to_dict()}")
    print("P AUTO, N new scenario, R reset current, manual W/S/A/D/I/K.")
    if recorder.run_dir is not None:
        print(f"Recording directory: {recorder.run_dir}")

    next_observation_time = float(data.time)
    last_status_time = time.perf_counter()
    previous_auto = False
    decision: PickupDecision | None = None

    try:
        with mujoco.viewer.launch_passive(model, data, key_callback=key_callback) as viewer:
            with viewer.lock():
                viewer.cam.lookat[:] = (1.0, 0.0, 0.55)
                viewer.cam.distance = 7.0
                viewer.cam.azimuth = 140
                viewer.cam.elevation = -24
            viewer.sync()

            while viewer.is_running():
                step_start = time.perf_counter()
                operator_state = operator.snapshot()
                if operator_state.reset_requested:
                    reset_episode(new_scenario=operator_state.new_scenario_requested)
                    operator_state = operator.snapshot()
                    previous_auto = False
                    next_observation_time = float(data.time)

                fork_contacts, load_state, load_tilt_deg = current_load_status()
                observation = observation_builder.build(
                    data,
                    fork_contact_count=fork_contacts,
                    load_state=load_state,
                )

                if operator_state.autonomy_enabled and not previous_auto:
                    pickup_machine.reset(observation.sim_time)
                    print("\nAutonomous pickup started.")
                previous_auto = operator_state.autonomy_enabled

                if operator_state.autonomy_enabled:
                    decision = pickup_machine.step(observation)
                    requested_action = decision.action
                    operator.synchronize_lift_target(requested_action.lift_target)
                else:
                    decision = None
                    requested_action = ForkliftAction(
                        speed_target=operator_state.speed_target,
                        steering_command=operator_state.steering_command,
                        lift_target=operator_state.lift_target,
                    )

                requested_speed = (
                    0.0 if requested_action.emergency_stop else requested_action.speed_target
                )
                interlock = drive_interlock.resolve(
                    requested_speed=requested_speed,
                    lift_velocity=float(data.qvel[lift_dof]),
                    lift_target=requested_action.lift_target,
                    sim_time=float(data.time),
                )
                steering_command = max(
                    -steering_max,
                    min(steering_max, requested_action.steering_command),
                )
                steer_angles = rear_ackermann_angles(
                    steering_command,
                    wheelbase,
                    rear_track,
                )
                left_omega, right_omega = front_drive_angular_speeds(
                    interlock.applied_speed,
                    steering_command,
                    wheelbase,
                    front_track,
                    wheel_radius,
                )
                data.ctrl[actuator_ids["front_left_drive_velocity"]] = left_omega
                data.ctrl[actuator_ids["front_right_drive_velocity"]] = right_omega
                data.ctrl[actuator_ids["rear_left_steer_position"]] = steer_angles.left
                data.ctrl[actuator_ids["rear_right_steer_position"]] = steer_angles.right
                data.ctrl[actuator_ids["lift_position"]] = max(
                    lift_min,
                    min(lift_max, requested_action.lift_target),
                )
                mujoco.mj_step(model, data)
                viewer.sync()

                fork_contacts, load_state, load_tilt_deg = current_load_status()
                observation = observation_builder.build(
                    data,
                    fork_contact_count=fork_contacts,
                    load_state=load_state,
                )

                if float(data.time) + 1e-12 >= next_observation_time:
                    front_rgb: np.ndarray | None = None
                    fork_rgb: np.ndarray | None = None
                    if camera_renderer is not None:
                        front_rgb = camera_renderer.render(data, front_camera_name)
                        fork_rgb = camera_renderer.render(data, fork_camera_name)
                    mode = "AUTO" if operator_state.autonomy_enabled else "MANUAL"
                    extra: dict[str, Any] = {
                        "scenario": current_scenario.to_dict(),
                        "mode": mode,
                        "requested_action": requested_action.to_dict(),
                        "applied_speed": interlock.applied_speed,
                        "interlock_reason": interlock.reason,
                    }
                    if decision is not None:
                        extra["algorithm"] = decision.to_dict()
                    recorder.write(
                        observation,
                        front_rgb=front_rgb,
                        fork_rgb=fork_rgb,
                        extra=extra,
                    )

                    if show_camera_windows and front_rgb is not None and fork_rgb is not None:
                        state_name = decision.state.value if decision else "MANUAL"
                        pallet_rel = observation.pallet_pose_in_base
                        front_view = overlay_camera_text(
                            front_rgb,
                            title=f"v5 front | {current_scenario.scenario_id} | {state_name}",
                            lines=[
                                f"pallet x/y/yaw={pallet_rel.x:+.2f}/{pallet_rel.y:+.2f}/{math.degrees(pallet_rel.yaw):+.1f}deg",
                                f"action v/steer={requested_action.speed_target:+.2f}/{math.degrees(steering_command):+.1f}deg",
                                f"load={load_state} contacts={fork_contacts} tilt={load_tilt_deg:.1f}deg",
                            ],
                        )
                        fork_view = overlay_camera_text(
                            fork_rgb,
                            title=f"v5 fork | {mode}",
                            lines=[
                                f"task={state_name}",
                                f"lift={observation.lift_position:.3f}m vel={observation.lift_velocity:+.3f}m/s",
                                f"speed req/applied={requested_speed:+.2f}/{interlock.applied_speed:+.2f}",
                                f"interlock={interlock.reason}",
                            ],
                        )
                        cv2.imshow("Forklift v5 - front RGB", front_view)
                        cv2.imshow("Forklift v5 - fork RGB", fork_view)
                        cv2.waitKey(1)
                    while next_observation_time <= float(data.time):
                        next_observation_time += observation_period

                now = time.perf_counter()
                if now - last_status_time >= status_interval:
                    vehicle_x = float(data.qpos[forklift_qpos])
                    vehicle_y = float(data.qpos[forklift_qpos + 1])
                    _, _, vehicle_yaw = rpy_from_freejoint(data, forklift_qpos)
                    rear_left_actual = float(data.qpos[rear_left_qpos])
                    rear_right_actual = float(data.qpos[rear_right_qpos])
                    mode = "AUTO" if operator_state.autonomy_enabled else "MANUAL"
                    task_state = decision.state.value if decision else "MANUAL"
                    pallet_rel = observation.pallet_pose_in_base
                    if camera_follow:
                        with viewer.lock():
                            viewer.cam.lookat[0] = vehicle_x + 1.0
                            viewer.cam.lookat[1] = vehicle_y
                            viewer.cam.lookat[2] = 0.55
                    print(
                        "\r"
                        f"scenario={current_scenario.scenario_id:<14} "
                        f"mode={mode:<6} task={task_state:<12} "
                        f"speed={requested_speed:+.2f}/{interlock.applied_speed:+.2f} "
                        f"steer={math.degrees(steering_command):+5.1f}deg "
                        f"rear=({math.degrees(rear_left_actual):+5.1f},"
                        f"{math.degrees(rear_right_actual):+5.1f})deg "
                        f"pallet_rel=({pallet_rel.x:+.2f},{pallet_rel.y:+.2f},"
                        f"{math.degrees(pallet_rel.yaw):+4.1f}deg) "
                        f"vehicle=({vehicle_x:+.2f},{vehicle_y:+.2f},"
                        f"{math.degrees(vehicle_yaw):+5.1f}deg) load={load_state}",
                        end="",
                        flush=True,
                    )
                    last_status_time = now

                target_wall_step = model.opt.timestep / realtime_factor
                elapsed = time.perf_counter() - step_start
                if elapsed < target_wall_step:
                    time.sleep(target_wall_step - elapsed)
    finally:
        recorder.close()
        if camera_renderer is not None:
            camera_renderer.close()
        if show_camera_windows:
            cv2.destroyAllWindows()

    print("\nForklift v5 viewer closed successfully.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (FileNotFoundError, KeyError, RuntimeError, ValueError, yaml.YAMLError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
