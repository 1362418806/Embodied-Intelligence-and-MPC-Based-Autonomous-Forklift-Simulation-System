"""Geometric low-speed docking controller with fork-corridor feedback.

The public API remains backward compatible with v4-v5.2. V5.3 can move the
lateral steering feedback point from the vehicle origin to the actual fork
segment, preventing origin lateral error and relative yaw from fighting each
other near the pallet. Reverse recovery remains a state-machine responsibility.
"""

from __future__ import annotations

from dataclasses import dataclass
import math

from interfaces.action import ForkliftAction
from interfaces.observation import Pose3D


def wrap_angle(angle: float) -> float:
    """Wrap an angle to [-pi, pi)."""
    return (float(angle) + math.pi) % (2.0 * math.pi) - math.pi


def clamp(value: float, minimum: float, maximum: float) -> float:
    """Clamp a scalar to a closed interval."""
    return min(max(float(value), float(minimum)), float(maximum))


@dataclass(frozen=True)
class StandoffTarget:
    """Object-aligned pre-approach target expressed in the vehicle frame."""

    x: float
    y: float
    yaw: float


@dataclass(frozen=True)
class DockingError:
    """Vehicle-pose error relative to an object-aligned stand-off pose."""

    longitudinal: float
    lateral: float
    distance: float
    heading: float
    yaw: float


@dataclass(frozen=True)
class DockingCommand:
    """Controller output with errors retained for state logic and telemetry."""

    action: ForkliftAction
    error: DockingError


@dataclass(frozen=True)
class AxisCorridorError:
    """Lateral clearance of an object-aligned corridor at two references."""

    near_reference: float
    far_reference: float
    near_lateral: float
    far_lateral: float
    maximum_abs_lateral: float


def object_standoff_target(
    object_pose_in_base: Pose3D,
    *,
    standoff_distance: float,
) -> StandoffTarget:
    """Plan a pose behind an object along the object's local x-axis."""
    if standoff_distance <= 0.0:
        raise ValueError("standoff_distance must be positive")

    object_yaw = wrap_angle(object_pose_in_base.yaw)
    return StandoffTarget(
        x=float(
            object_pose_in_base.x
            - standoff_distance * math.cos(object_yaw)
        ),
        y=float(
            object_pose_in_base.y
            - standoff_distance * math.sin(object_yaw)
        ),
        yaw=object_yaw,
    )


def object_standoff_error(
    object_pose_in_base: Pose3D,
    *,
    standoff_distance: float,
) -> DockingError:
    """Return current-vehicle error to a planned object-aligned stand-off pose."""
    target = object_standoff_target(
        object_pose_in_base,
        standoff_distance=standoff_distance,
    )
    distance = math.hypot(target.x, target.y)
    heading = math.atan2(target.y, target.x) if distance > 1e-9 else 0.0

    return DockingError(
        longitudinal=target.x,
        lateral=target.y,
        distance=float(distance),
        heading=wrap_angle(heading),
        yaw=target.yaw,
    )


def object_axis_error(
    object_pose_in_base: Pose3D,
    *,
    target_distance: float,
) -> DockingError:
    """Return errors to the object's longitudinal centreline.

    Unlike :func:`object_standoff_error`, this error does not ask an
    Ackermann vehicle to converge to one exact Cartesian point.  It measures
    the signed distance to the object's local x-axis and the remaining
    longitudinal distance to a scalar gate.  This is better conditioned for
    forward-only pallet approach and insertion.
    """
    if target_distance <= 0.0:
        raise ValueError("target_distance must be positive")

    object_yaw = wrap_angle(object_pose_in_base.yaw)
    cosine = math.cos(object_yaw)
    sine = math.sin(object_yaw)

    # Signed perpendicular distance from the vehicle origin to the object's
    # local x-axis. Positive means the object centreline lies to vehicle-left.
    lateral = (
        float(object_pose_in_base.y) * cosine
        - float(object_pose_in_base.x) * sine
    )
    longitudinal = float(object_pose_in_base.x) - float(target_distance)
    heading = math.atan2(
        lateral,
        max(abs(float(object_pose_in_base.x)), 1e-9),
    )
    distance = math.hypot(max(longitudinal, 0.0), lateral)

    return DockingError(
        longitudinal=longitudinal,
        lateral=lateral,
        distance=distance,
        heading=wrap_angle(heading),
        yaw=object_yaw,
    )


def axis_lateral_at_reference(
    object_pose_in_base: Pose3D,
    *,
    reference_distance: float,
) -> float:
    """Return object-axis lateral displacement at a vehicle x reference.

    ``object_axis_error(...).lateral`` is the signed perpendicular distance at
    the vehicle origin. Fork-pocket clearance depends on the whole fork
    segment, so the same line is sampled at configurable near/far x positions.
    """
    if reference_distance < 0.0:
        raise ValueError("reference_distance must be non-negative")

    object_yaw = wrap_angle(object_pose_in_base.yaw)
    cosine = math.cos(object_yaw)
    sine = math.sin(object_yaw)
    origin_lateral = (
        float(object_pose_in_base.y) * cosine
        - float(object_pose_in_base.x) * sine
    )
    return float(origin_lateral + float(reference_distance) * sine)


def object_axis_corridor_error(
    object_pose_in_base: Pose3D,
    *,
    fork_root_distance: float,
    fork_tip_distance: float,
    object_half_length: float,
    object_center_distance: float | None = None,
) -> AxisCorridorError:
    """Measure axis clearance across the fork/pallet longitudinal overlap.

    During ALIGN, ``object_center_distance`` can be set to the planned lift
    distance to preview where the fork segment will lie inside the pockets.
    During INSERT, omit it to use the current object distance.
    """
    if fork_root_distance < 0.0:
        raise ValueError("fork_root_distance must be non-negative")
    if fork_tip_distance <= fork_root_distance:
        raise ValueError("fork_tip_distance must exceed fork_root_distance")
    if object_half_length <= 0.0:
        raise ValueError("object_half_length must be positive")

    center = (
        float(object_pose_in_base.x)
        if object_center_distance is None
        else float(object_center_distance)
    )
    near_reference = max(
        float(fork_root_distance),
        center - float(object_half_length),
    )
    far_reference = min(
        float(fork_tip_distance),
        center + float(object_half_length),
    )
    if near_reference > far_reference:
        raise ValueError(
            "fork and object have no longitudinal overlap at the requested "
            "object_center_distance"
        )

    near_lateral = axis_lateral_at_reference(
        object_pose_in_base,
        reference_distance=near_reference,
    )
    far_lateral = axis_lateral_at_reference(
        object_pose_in_base,
        reference_distance=far_reference,
    )
    return AxisCorridorError(
        near_reference=float(near_reference),
        far_reference=float(far_reference),
        near_lateral=float(near_lateral),
        far_lateral=float(far_lateral),
        maximum_abs_lateral=max(
            abs(float(near_lateral)),
            abs(float(far_lateral)),
        ),
    )


def shift_pose_along_local_x(pose: Pose3D, distance: float) -> Pose3D:
    """Shift a planar pose along its local x-axis."""
    yaw = wrap_angle(pose.yaw)
    return Pose3D(
        x=float(pose.x + float(distance) * math.cos(yaw)),
        y=float(pose.y + float(distance) * math.sin(yaw)),
        z=float(pose.z),
        roll=float(pose.roll),
        pitch=float(pose.pitch),
        yaw=yaw,
    )


def desired_vehicle_pose_for_load_target(
    target_load_pose_in_base: Pose3D,
    load_pose_in_base: Pose3D,
) -> Pose3D:
    """Return the vehicle pose that would place its carried load at a target.

    The current load-to-vehicle transform is treated as rigid. The calculation
    is planar and is refreshed every control step, so small load slip is fed
    back into the placement command.
    """
    desired_yaw = wrap_angle(
        float(target_load_pose_in_base.yaw) - float(load_pose_in_base.yaw)
    )
    cosine = math.cos(desired_yaw)
    sine = math.sin(desired_yaw)
    rotated_load_x = cosine * float(load_pose_in_base.x) - sine * float(load_pose_in_base.y)
    rotated_load_y = sine * float(load_pose_in_base.x) + cosine * float(load_pose_in_base.y)
    return Pose3D(
        x=float(target_load_pose_in_base.x) - rotated_load_x,
        y=float(target_load_pose_in_base.y) - rotated_load_y,
        z=0.0,
        roll=0.0,
        pitch=0.0,
        yaw=desired_yaw,
    )


def relative_pose_error(target_pose_in_base: Pose3D) -> DockingError:
    """Convert a desired vehicle pose in the current base frame to errors."""
    distance = math.hypot(float(target_pose_in_base.x), float(target_pose_in_base.y))
    heading = (
        math.atan2(float(target_pose_in_base.y), float(target_pose_in_base.x))
        if distance > 1e-9
        else 0.0
    )
    return DockingError(
        longitudinal=float(target_pose_in_base.x),
        lateral=float(target_pose_in_base.y),
        distance=float(distance),
        heading=wrap_angle(heading),
        yaw=wrap_angle(target_pose_in_base.yaw),
    )


class DockingController:
    """Generate low-speed rear-Ackermann commands from relative object pose.

    The controller tracks a virtual object-aligned stand-off pose.  The
    ``minimum_speed_override`` argument is used by V5.1 rolling alignment to
    keep the vehicle moving slowly while heading and lateral error are being
    corrected.  Overshoot is intentionally handled by the state machine's
    bounded reverse-recovery state.
    """

    def __init__(
        self,
        *,
        distance_gain: float,
        heading_gain: float,
        yaw_gain: float,
        maximum_steering: float,
        minimum_creep_speed: float,
        heading_slowdown_angle: float,
        lateral_gain: float = 0.0,
        lookahead_distance: float = 0.75,
        yaw_slowdown_angle: float | None = None,
        minimum_alignment_scale: float = 0.20,
    ) -> None:
        if distance_gain <= 0.0:
            raise ValueError("distance_gain must be positive")
        if heading_gain < 0.0 or yaw_gain < 0.0 or lateral_gain < 0.0:
            raise ValueError("heading, yaw and lateral gains must be non-negative")
        if maximum_steering <= 0.0:
            raise ValueError("maximum_steering must be positive")
        if minimum_creep_speed < 0.0:
            raise ValueError("minimum_creep_speed must be non-negative")
        if heading_slowdown_angle <= 0.0:
            raise ValueError("heading_slowdown_angle must be positive")
        if lookahead_distance <= 0.0:
            raise ValueError("lookahead_distance must be positive")
        if yaw_slowdown_angle is not None and yaw_slowdown_angle <= 0.0:
            raise ValueError("yaw_slowdown_angle must be positive when provided")
        if not 0.0 < minimum_alignment_scale <= 1.0:
            raise ValueError("minimum_alignment_scale must be in (0, 1]")

        self.distance_gain = float(distance_gain)
        self.heading_gain = float(heading_gain)
        self.yaw_gain = float(yaw_gain)
        self.lateral_gain = float(lateral_gain)
        self.maximum_steering = float(maximum_steering)
        self.minimum_creep_speed = float(minimum_creep_speed)
        self.heading_slowdown_angle = float(heading_slowdown_angle)
        self.lookahead_distance = float(lookahead_distance)
        self.yaw_slowdown_angle = (
            float(yaw_slowdown_angle)
            if yaw_slowdown_angle is not None
            else float(heading_slowdown_angle)
        )
        self.minimum_alignment_scale = float(minimum_alignment_scale)

    def axis_command(
        self,
        object_pose_in_base: Pose3D,
        *,
        target_distance: float,
        maximum_speed: float,
        lift_target: float,
        stop_longitudinal_tolerance: float = 0.0,
        steering_limit: float | None = None,
        minimum_speed_override: float | None = None,
        lateral_reference_distance: float | None = None,
        lateral_gain_override: float | None = None,
        yaw_gain_override: float | None = None,
        lookahead_distance_override: float | None = None,
    ) -> DockingCommand:
        """Follow the object's longitudinal axis to a distance gate.

        ``lateral_reference_distance`` moves the steering feedback point from
        the vehicle origin to a point along the fork axis. This is important
        when origin lateral error and relative yaw partially cancel at the
        actual fork segment. The default remains the legacy vehicle-origin
        feedback used by V5.2 and earlier.
        """
        if maximum_speed <= 0.0:
            raise ValueError("maximum_speed must be positive")
        if stop_longitudinal_tolerance < 0.0:
            raise ValueError(
                "stop_longitudinal_tolerance must be non-negative"
            )
        if minimum_speed_override is not None and minimum_speed_override < 0.0:
            raise ValueError("minimum_speed_override must be non-negative")
        if (
            lateral_reference_distance is not None
            and lateral_reference_distance < 0.0
        ):
            raise ValueError(
                "lateral_reference_distance must be non-negative"
            )
        if lateral_gain_override is not None and lateral_gain_override < 0.0:
            raise ValueError("lateral_gain_override must be non-negative")
        if yaw_gain_override is not None and yaw_gain_override < 0.0:
            raise ValueError("yaw_gain_override must be non-negative")
        if (
            lookahead_distance_override is not None
            and lookahead_distance_override <= 0.0
        ):
            raise ValueError(
                "lookahead_distance_override must be positive"
            )

        error = object_axis_error(
            object_pose_in_base,
            target_distance=target_distance,
        )

        limit = self.maximum_steering if steering_limit is None else min(
            abs(float(steering_limit)), self.maximum_steering
        )
        if limit <= 0.0:
            raise ValueError("steering limit must be positive")

        control_lateral = error.lateral
        if lateral_reference_distance is not None:
            control_lateral = axis_lateral_at_reference(
                object_pose_in_base,
                reference_distance=float(lateral_reference_distance),
            )
        lateral_gain = (
            self.lateral_gain
            if lateral_gain_override is None
            else float(lateral_gain_override)
        )
        yaw_gain = (
            self.yaw_gain
            if yaw_gain_override is None
            else float(yaw_gain_override)
        )
        lookahead = (
            self.lookahead_distance
            if lookahead_distance_override is None
            else float(lookahead_distance_override)
        )

        lateral_angle = math.atan2(
            lateral_gain * control_lateral,
            lookahead,
        )
        steering = clamp(
            self.heading_gain * lateral_angle
            + yaw_gain * error.yaw,
            -limit,
            limit,
        )

        minimum_speed = (
            self.minimum_creep_speed
            if minimum_speed_override is None
            else float(minimum_speed_override)
        )
        minimum_speed = min(minimum_speed, float(maximum_speed))

        if error.longitudinal <= stop_longitudinal_tolerance:
            speed = 0.0
        else:
            speed = min(
                float(maximum_speed),
                self.distance_gain * error.longitudinal,
            )
            steering_scale = max(
                self.minimum_alignment_scale,
                1.0 - 0.70 * abs(steering) / limit,
            )
            yaw_scale = max(
                self.minimum_alignment_scale,
                1.0 - abs(error.yaw) / self.yaw_slowdown_angle,
            )
            speed *= min(steering_scale, yaw_scale)
            if speed > 0.0:
                speed = max(min(speed, float(maximum_speed)), minimum_speed)

        return DockingCommand(
            action=ForkliftAction(
                speed_target=float(speed),
                steering_command=float(steering),
                lift_target=float(lift_target),
            ),
            error=error,
        )

    def pose_command(
        self,
        target_pose_in_base: Pose3D,
        *,
        maximum_speed: float,
        lift_target: float,
        stop_distance: float = 0.03,
        steering_limit: float | None = None,
        minimum_speed_override: float | None = None,
    ) -> DockingCommand:
        """Track an arbitrary desired vehicle pose using forward-only motion."""
        if maximum_speed <= 0.0:
            raise ValueError("maximum_speed must be positive")
        if stop_distance < 0.0:
            raise ValueError("stop_distance must be non-negative")
        if minimum_speed_override is not None and minimum_speed_override < 0.0:
            raise ValueError("minimum_speed_override must be non-negative")

        error = relative_pose_error(target_pose_in_base)
        limit = self.maximum_steering if steering_limit is None else min(
            abs(float(steering_limit)), self.maximum_steering
        )
        if limit <= 0.0:
            raise ValueError("steering limit must be positive")

        lateral_angle = math.atan2(
            error.lateral,
            max(abs(error.longitudinal), self.lookahead_distance),
        )
        steering = clamp(
            self.heading_gain * error.heading
            + self.lateral_gain * lateral_angle
            + self.yaw_gain * error.yaw,
            -limit,
            limit,
        )
        minimum_speed = (
            self.minimum_creep_speed
            if minimum_speed_override is None
            else float(minimum_speed_override)
        )
        minimum_speed = min(minimum_speed, float(maximum_speed))

        if error.distance <= stop_distance or error.longitudinal <= 0.0:
            speed = 0.0
        else:
            speed = min(float(maximum_speed), self.distance_gain * error.distance)
            heading_scale = max(
                self.minimum_alignment_scale,
                1.0 - abs(error.heading) / self.heading_slowdown_angle,
            )
            yaw_scale = max(
                self.minimum_alignment_scale,
                1.0 - abs(error.yaw) / self.yaw_slowdown_angle,
            )
            speed *= min(heading_scale, yaw_scale)
            if speed > 0.0:
                speed = max(min(speed, float(maximum_speed)), minimum_speed)

        return DockingCommand(
            action=ForkliftAction(
                speed_target=float(speed),
                steering_command=float(steering),
                lift_target=float(lift_target),
            ),
            error=error,
        )

    def command(
        self,
        object_pose_in_base: Pose3D,
        *,
        standoff_distance: float,
        maximum_speed: float,
        lift_target: float,
        stop_distance: float = 0.03,
        steering_limit: float | None = None,
        minimum_speed_override: float | None = None,
    ) -> DockingCommand:
        """Track an object-aligned vehicle pose using forward-only motion.

        ``minimum_speed_override`` does not bypass the overshoot guard.  When
        the planned pose is behind the vehicle, speed remains zero and the
        state machine can enter controlled reverse recovery.
        """
        if maximum_speed <= 0.0:
            raise ValueError("maximum_speed must be positive")
        if stop_distance < 0.0:
            raise ValueError("stop_distance must be non-negative")
        if minimum_speed_override is not None and minimum_speed_override < 0.0:
            raise ValueError("minimum_speed_override must be non-negative")

        error = object_standoff_error(
            object_pose_in_base,
            standoff_distance=standoff_distance,
        )

        limit = self.maximum_steering if steering_limit is None else min(
            abs(float(steering_limit)), self.maximum_steering
        )

        lateral_angle = math.atan2(
            error.lateral,
            max(abs(error.longitudinal), self.lookahead_distance),
        )
        steering = clamp(
            self.heading_gain * error.heading
            + self.lateral_gain * lateral_angle
            + self.yaw_gain * error.yaw,
            -limit,
            limit,
        )

        minimum_speed = (
            self.minimum_creep_speed
            if minimum_speed_override is None
            else float(minimum_speed_override)
        )
        minimum_speed = min(minimum_speed, float(maximum_speed))

        if error.distance <= stop_distance or error.longitudinal <= 0.0:
            speed = 0.0
        else:
            speed = min(float(maximum_speed), self.distance_gain * error.distance)
            heading_scale = max(
                self.minimum_alignment_scale,
                1.0 - abs(error.heading) / self.heading_slowdown_angle,
            )
            yaw_scale = max(
                self.minimum_alignment_scale,
                1.0 - abs(error.yaw) / self.yaw_slowdown_angle,
            )
            speed *= min(heading_scale, yaw_scale)
            if speed > 0.0:
                speed = max(min(speed, float(maximum_speed)), minimum_speed)

        return DockingCommand(
            action=ForkliftAction(
                speed_target=float(speed),
                steering_command=float(steering),
                lift_target=float(lift_target),
            ),
            error=error,
        )
