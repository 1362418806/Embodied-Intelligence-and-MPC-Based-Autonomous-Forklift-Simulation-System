"""Analyze R4-F2 carried-load terminal yaw-authority decoupling and certification liveness.

Ground truth is used only for offline diagnosis. Runtime controller behavior is
summarized separately from diagnostic truth attribution.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from statistics import median
from typing import Any


def wrap_rad(v: float) -> float:
    return (float(v) + math.pi) % (2.0 * math.pi) - math.pi


def load_rows(path: Path) -> list[dict[str, Any]]:
    return [json.loads(x) for x in path.read_text(encoding="utf-8").splitlines() if x.strip()]


def reconstruct_anchor(rows: list[dict[str, Any]]) -> dict[str, Any]:
    accepted: list[tuple[float, float, float, float, float]] = []
    last_count = -1
    last_world_yaw = None
    last_truth_world_yaw = None
    for row in rows:
        pv = row.get("pickup_vision") or {}
        decision = row.get("decision") or {}
        if decision.get("state") != "INSERT":
            continue
        count = int(pv.get("detection_count") or 0)
        if count <= last_count:
            continue
        last_count = count
        est = row.get("estimated_observation") or {}
        gt = row.get("ground_truth_observation") or {}
        load = est.get("pallet_pose_in_base") or {}
        veh = est.get("vehicle_pose_world") or {}
        gtload = gt.get("pallet_pose_world") or {}
        if load.get("yaw") is None or veh.get("yaw") is None:
            continue
        t = float(gt.get("sim_time") or 0.0)
        world = wrap_rad(float(load["yaw"]) + float(veh["yaw"]))
        conf = pv.get("last_accepted_confidence")
        repr_px = pv.get("last_accepted_reprojection_error_px")
        if conf is None or repr_px is None:
            continue
        accepted.append((t, world, float(conf), float(repr_px), float(gtload.get("yaw", 0.0))))
        last_world_yaw = world
        last_truth_world_yaw = float(gtload.get("yaw", 0.0))
    if not accepted:
        return {"available": False}
    newest_t = accepted[-1][0]
    quality = [x for x in accepted if newest_t - x[0] <= 1.2 + 1e-9 and x[2] >= 0.80 and x[3] <= 2.0]
    if len(quality) < 4:
        return {"available": False, "quality_samples": len(quality)}
    sy = sum(math.sin(x[1]) for x in quality)
    cy = sum(math.cos(x[1]) for x in quality)
    yaw = math.atan2(sy, cy)
    spread = max(abs(wrap_rad(x[1] - yaw)) for x in quality)
    delta = wrap_rad(yaw - float(last_world_yaw))
    out = {
        "available": spread <= math.radians(0.5),
        "quality_samples": len(quality),
        "anchor_world_yaw_deg": math.degrees(yaw),
        "anchor_spread_deg": math.degrees(spread),
        "latest_world_yaw_deg": math.degrees(float(last_world_yaw)),
        "anchor_minus_latest_deg": math.degrees(delta),
        "latest_confidence": accepted[-1][2],
        "latest_reprojection_error_px": accepted[-1][3],
    }
    if last_truth_world_yaw is not None:
        out["diagnostic_latest_world_yaw_error_deg"] = math.degrees(wrap_rad(float(last_world_yaw) - last_truth_world_yaw))
        out["diagnostic_anchor_world_yaw_error_deg"] = math.degrees(wrap_rad(yaw - last_truth_world_yaw))
    return out


def analyze(path: Path) -> dict[str, Any]:
    rows = load_rows(path)
    anchor = reconstruct_anchor(rows)
    truth_strict = []
    target_biases: list[float] = []
    load_biases: list[float] = []
    relative_biases: list[float] = []
    terminal_measurement_yaws: list[float] = []
    terminal_posterior_yaws: list[float] = []
    raw_yaw_pass = 0
    risk_yaw_pass = 0
    cf_risk_yaw_pass = 0
    cf_delta = float(anchor.get("anchor_minus_latest_deg") or 0.0)
    for row in rows:
        gt = row.get("ground_truth_observation") or {}
        d = row.get("decision") or {}
        myaw = d.get("terminal_load_reacquisition_last_measurement_yaw_deg")
        pyaw = d.get("terminal_load_reacquisition_last_posterior_yaw_deg")
        if myaw is not None:
            terminal_measurement_yaws.append(float(myaw))
        if pyaw is not None:
            terminal_posterior_yaws.append(float(pyaw))
        gt_load = gt.get("pallet_pose_in_base") or {}
        gt_target = gt.get("placement_pose_in_base") or {}
        if not gt_load or not gt_target:
            continue
        dx = float(gt_target.get("x", 0.0)) - float(gt_load.get("x", 0.0))
        dy = float(gt_target.get("y", 0.0)) - float(gt_load.get("y", 0.0))
        gt_pos = math.hypot(dx, dy)
        gt_yaw = abs(math.degrees(wrap_rad(float(gt_target.get("yaw", 0.0)) - float(gt_load.get("yaw", 0.0)))))
        cyaw = d.get("strict_release_certification_yaw_error_deg")
        cpos = d.get("strict_release_certification_position_error_m")
        ymargin = d.get("strict_release_yaw_margin_deg")
        pmargin = d.get("strict_release_position_margin_m")
        if gt_pos < 0.095 and gt_yaw < 4.6 and cyaw is not None and cpos is not None:
            truth_strict.append((gt_pos, gt_yaw, float(cpos), float(cyaw), float(pmargin or 0.0), float(ymargin or 0.0)))
            raw_yaw_pass += int(float(cyaw) < 4.6)
            risk_yaw_pass += int(float(cyaw) + float(ymargin or 0.0) < 4.6)
            cf_yaw = max(0.0, float(cyaw) - max(0.0, cf_delta))
            cf_risk_yaw_pass += int(cf_yaw + float(ymargin or 0.0) < 4.6)

        # R4-F2 exact controller-side attribution telemetry, absent in E7 replay.
        ctl_load = d.get("strict_release_certification_load_yaw_deg")
        ctl_target = d.get("strict_release_certification_target_yaw_deg")
        if ctl_load is not None and ctl_target is not None:
            truth_load_deg = math.degrees(float(gt_load.get("yaw", 0.0)))
            truth_target_deg = math.degrees(float(gt_target.get("yaw", 0.0)))
            target_biases.append(math.degrees(wrap_rad(math.radians(float(ctl_target) - truth_target_deg))))
            load_biases.append(math.degrees(wrap_rad(math.radians(float(ctl_load) - truth_load_deg))))
            ctl_rel = math.degrees(wrap_rad(math.radians(float(ctl_target) - float(ctl_load))))
            truth_rel = math.degrees(wrap_rad(float(gt_target.get("yaw", 0.0)) - float(gt_load.get("yaw", 0.0))))
            relative_biases.append(math.degrees(wrap_rad(math.radians(ctl_rel - truth_rel))))

    last = (rows[-1].get("decision") or {}) if rows else {}
    result = {
        "trace": str(path),
        "samples": len(rows),
        "anchor": anchor,
        "truth_strict_cert_samples": len(truth_strict),
        "raw_cert_yaw_pass_count": raw_yaw_pass,
        "risk_cert_yaw_pass_count": risk_yaw_pass,
        "counterfactual_anchor_risk_yaw_pass_count": cf_risk_yaw_pass,
        "strict_certified_final": bool(last.get("strict_release_certified", False)),
        "strict_blocker_final": last.get("strict_release_certification_blocker"),
        "supervisor_intent_count": int(last.get("placement_release_supervisor_intent_count") or 0),
        "release_witness_capture_count": int(last.get("release_witness_capture_count") or 0),
        "terminal_budget_exhausted": bool(last.get("placement_terminal_budget_exhausted", False)),
        "f1_anchor_used_final": bool(last.get("carried_load_yaw_anchor_used", False)),
        "f1_anchor_sample_count_final": int(last.get("carried_load_yaw_anchor_sample_count") or 0),
        "f1_anchor_spread_deg_final": last.get("carried_load_yaw_anchor_spread_deg"),
        "f1_anchor_delta_from_latest_deg_final": last.get("carried_load_yaw_anchor_delta_from_latest_deg"),
        "f2_yaw_authority_enabled_final": bool(last.get("terminal_load_reacquisition_yaw_authority_enabled", True)),
        "f2_position_only_update_count_final": int(last.get("terminal_load_reacquisition_position_only_update_count") or 0),
        "f2_yaw_suppressed_count_final": int(last.get("terminal_load_reacquisition_yaw_suppressed_count") or 0),
        "f2_last_measurement_yaw_deg": last.get("terminal_load_reacquisition_last_measurement_yaw_deg"),
        "f2_last_posterior_yaw_deg": last.get("terminal_load_reacquisition_last_posterior_yaw_deg"),
        "f2_terminal_measurement_yaw_range_deg": (max(terminal_measurement_yaws) - min(terminal_measurement_yaws)) if terminal_measurement_yaws else None,
        "f2_terminal_posterior_yaw_range_deg": (max(terminal_posterior_yaws) - min(terminal_posterior_yaws)) if terminal_posterior_yaws else None,
        "diagnostic_target_yaw_bias_median_deg": median(target_biases) if target_biases else None,
        "diagnostic_load_yaw_bias_median_deg": median(load_biases) if load_biases else None,
        "diagnostic_relative_yaw_bias_median_deg": median(relative_biases) if relative_biases else None,
    }
    if truth_strict:
        result.update({
            "truth_strict_position_median_m": median(x[0] for x in truth_strict),
            "truth_strict_yaw_median_deg": median(x[1] for x in truth_strict),
            "cert_position_median_m": median(x[2] for x in truth_strict),
            "cert_yaw_median_deg": median(x[3] for x in truth_strict),
            "cert_position_margin_median_m": median(x[4] for x in truth_strict),
            "cert_yaw_margin_median_deg": median(x[5] for x in truth_strict),
        })
    return result


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("trace", type=Path)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()
    r = analyze(args.trace)
    if args.json:
        print(json.dumps(r, indent=2, ensure_ascii=False))
    else:
        a = r["anchor"]
        print("V9.3.12-R4-F2 yaw attribution")
        print(f"trace: {r['trace']}")
        print(f"anchor available: {a.get('available')} samples={a.get('quality_samples')} spread={a.get('anchor_spread_deg')} deg")
        print(f"anchor-latest: {a.get('anchor_minus_latest_deg')} deg | latest conf/reproj={a.get('latest_confidence')}/{a.get('latest_reprojection_error_px')} px")
        print(f"GT diagnostic seed error latest -> anchor: {a.get('diagnostic_latest_world_yaw_error_deg')} -> {a.get('diagnostic_anchor_world_yaw_error_deg')} deg")
        print(f"truth-strict cert samples: {r['truth_strict_cert_samples']}")
        print(f"yaw pass raw/risk/counterfactual-anchor-risk: {r['raw_cert_yaw_pass_count']}/{r['risk_cert_yaw_pass_count']}/{r['counterfactual_anchor_risk_yaw_pass_count']}")
        print(f"F1 runtime anchor used: {r['f1_anchor_used_final']} n={r['f1_anchor_sample_count_final']} delta={r['f1_anchor_delta_from_latest_deg_final']} deg")
        print(f"F2 yaw authority enabled: {r['f2_yaw_authority_enabled_final']} | position-only updates={r['f2_position_only_update_count_final']} yaw-suppressed={r['f2_yaw_suppressed_count_final']}")
        print(f"F2 terminal yaw measurement/posterior range: {r['f2_terminal_measurement_yaw_range_deg']} / {r['f2_terminal_posterior_yaw_range_deg']} deg")
        print(f"F2 last measurement/posterior yaw: {r['f2_last_measurement_yaw_deg']} / {r['f2_last_posterior_yaw_deg']} deg")
        print(f"GT diagnostic target/load/relative bias medians: {r['diagnostic_target_yaw_bias_median_deg']} / {r['diagnostic_load_yaw_bias_median_deg']} / {r['diagnostic_relative_yaw_bias_median_deg']} deg")
        print(f"strict={r['strict_certified_final']} blocker={r['strict_blocker_final']} witness={r['release_witness_capture_count']} budget_exhausted={r['terminal_budget_exhausted']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
