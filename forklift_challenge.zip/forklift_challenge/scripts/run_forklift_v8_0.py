"""Run V8.0 with a real front-RGB placement-marker detector."""

from __future__ import annotations

from dataclasses import replace
import importlib.util
from pathlib import Path
import sys
from types import ModuleType
from typing import Any

import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from perception.pose_pipeline import PosePipeline
from perception.terminal_fusion import apply_terminal_autonomy_overrides
from perception.vision_placement import VisionPlacementPipeline
from simulator.camera_renderer import MultiCameraRenderer
from simulator.observation_builder import ObservationBuilder as TruthObservationBuilder
from task.pickup_state_machine import PickupStateMachine as BasePickupStateMachine


BASE_SCRIPT = PROJECT_ROOT / "scripts" / "run_forklift_v5_1.py"
DEFAULT_CONFIG = PROJECT_ROOT / "configs" / "vehicle_v8_0.yaml"


def _consume_option(name: str) -> str | None:
    if name not in sys.argv:
        return None
    index = sys.argv.index(name)
    if index + 1 >= len(sys.argv):
        raise ValueError(f"{name} requires a value")
    value = sys.argv[index + 1]
    del sys.argv[index : index + 2]
    return value


def _config_path_from_argv() -> Path:
    if "--config" in sys.argv:
        index = sys.argv.index("--config")
        if index + 1 >= len(sys.argv):
            raise ValueError("--config requires a value")
        return Path(sys.argv[index + 1]).resolve()
    return DEFAULT_CONFIG


def _load_application() -> ModuleType:
    if not BASE_SCRIPT.is_file():
        raise FileNotFoundError(f"base interactive script does not exist: {BASE_SCRIPT}")
    name = "_forklift_v8_0_interactive_base"
    spec = importlib.util.spec_from_file_location(name, BASE_SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load base script: {BASE_SCRIPT}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main() -> int:
    profile_override = _consume_option("--perception-profile")
    seed_override = _consume_option("--perception-seed")
    config_path = _config_path_from_argv()
    with config_path.open("r", encoding="utf-8") as stream:
        config: dict[str, Any] = yaml.safe_load(stream)

    perception = config["perception"]
    vision_config = config["vision"]
    camera_config = config["camera"]
    profile_name = str(profile_override or perception["default_profile"])
    seed = int(
        seed_override
        if seed_override is not None
        else config["randomization"]["default_seed"]
    )
    autonomy_overrides = perception.get(
        "terminal_autonomy_overrides", {}
    ).get(profile_name, {})
    runtime_state: dict[str, str | None] = {"controller_state": None}

    class VisionObservationBuilder:
        def __init__(self, model) -> None:
            self.truth_builder = TruthObservationBuilder(model)
            self.pipeline = PosePipeline.from_config(
                perception,
                profile_name=profile_name,
                seed=seed,
            )
            self.vision = VisionPlacementPipeline.from_config(
                vision_config,
                profile_name=profile_name,
                image_width=int(camera_config["width"]),
                image_height=int(camera_config["height"]),
            )
            self.renderer = MultiCameraRenderer(
                model,
                width=int(camera_config["width"]),
                height=int(camera_config["height"]),
            )

        def build(self, data, *, fork_contact_count: int, load_state: str):
            truth = self.truth_builder.build(
                data,
                fork_contact_count=fork_contact_count,
                load_state=load_state,
            )
            frame = self.pipeline.step(truth)
            rgb = None
            if self.vision.wants_image(
                sim_time=truth.sim_time,
                controller_state=runtime_state["controller_state"],
            ):
                rgb = self.renderer.render(data, self.vision.camera_name)
            return self.vision.step(
                frame=frame,
                rgb=rgb,
                controller_state=runtime_state["controller_state"],
            ).observation

        def close(self) -> None:
            self.renderer.close()

        def __del__(self) -> None:
            try:
                self.close()
            except Exception:
                pass

    class ProfileAwarePickupStateMachine(BasePickupStateMachine):
        def __init__(self, *, parameters, docking_controller) -> None:
            if autonomy_overrides:
                parameters = replace(parameters, **autonomy_overrides)
                parameters.validate()
            super().__init__(
                parameters=parameters,
                docking_controller=docking_controller,
            )
            runtime_state["controller_state"] = self.state.value

        def reset(self, sim_time: float) -> None:
            super().reset(sim_time)
            runtime_state["controller_state"] = self.state.value

        def step(self, observation):
            decision = super().step(observation)
            runtime_state["controller_state"] = decision.state.value
            return decision

    application = _load_application()
    application.DEFAULT_CONFIG = config_path
    application.ObservationBuilder = VisionObservationBuilder
    application.PickupStateMachine = ProfileAwarePickupStateMachine
    print(
        f"V8.0 profile: {profile_name} | seed={seed} | "
        "front RGB known-colour placement marker enabled"
    )
    return int(application.main())


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (FileNotFoundError, KeyError, RuntimeError, ValueError, yaml.YAMLError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
