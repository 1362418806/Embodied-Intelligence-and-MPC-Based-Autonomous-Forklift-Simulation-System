"""Run V6.2 high-authority smooth loaded transport interactively."""

from __future__ import annotations

import importlib.util
from pathlib import Path
import sys
from types import ModuleType

PROJECT_ROOT = Path(__file__).resolve().parents[1]
BASE_SCRIPT = PROJECT_ROOT / "scripts" / "run_forklift_v6.py"
DEFAULT_CONFIG = PROJECT_ROOT / "configs" / "vehicle_v6_2.yaml"


def load_base_application() -> ModuleType:
    if not BASE_SCRIPT.is_file():
        raise FileNotFoundError(f"Base V6 script does not exist: {BASE_SCRIPT}")
    name = "_forklift_v6_2_interactive_base"
    spec = importlib.util.spec_from_file_location(name, BASE_SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load base script: {BASE_SCRIPT}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main() -> int:
    application = load_base_application()
    application.DEFAULT_CONFIG = DEFAULT_CONFIG
    return int(application.main())


if __name__ == "__main__":
    raise SystemExit(main())
