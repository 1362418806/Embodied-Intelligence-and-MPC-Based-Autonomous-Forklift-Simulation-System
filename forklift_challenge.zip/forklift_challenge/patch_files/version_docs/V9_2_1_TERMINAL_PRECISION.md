# V9.2.1 Terminal Precision

## Goal

Resolve the dominant V9.2 terminal placement precision plateau without fixed geometry compensation and reduce terminal deadlocks caused by forward-only local control.

## Scope

Changed only the terminal placement precision layer and its tests/diagnostics. Pickup perception, RGB detector implementation, rendering, MuJoCo contact physics, lowering physics, withdrawal physics, and global navigation are intentionally untouched.

## Algorithm

1. Use a trusted measured/fused carried-pallet pose in the forklift base frame.
2. Use the live accepted/fused placement target pose in the same base frame.
3. Build the desired base displacement with `T_B_target * inverse(T_B_pallet)`.
4. Use a lightweight direct longitudinal servo for small lateral/yaw residuals.
5. Use the bidirectional Ackermann lattice only when a non-holonomic correction is actually required.
6. Require a continuous `< 0.070 m / < 3 deg` dwell before precision release.
7. Keep V9.2 hard terminal budgets as final watchdogs; local stagnation starts only after the precision controller owns the phase.
8. Route all motion through the existing downstream safety/guard-brake layer.

## Important review fixes

- Release dwell is now strictly continuous; leaving the precision gate resets it.
- Precision stagnation cannot accumulate while the outer V9.2 approach controller still owns motion.
- Old-plan goal coordinates are no longer compared across different moving base frames.
- Planned primitive progress is consumed only when signed measured motion agrees with the commanded direction.
- Forward/reverse switching waits for both neutral dwell and near-zero signed longitudinal speed when that measurement is supplied.
- Non-finite target measurements fail safe to a zero-speed measurement-wait state.
- Progress supervision uses one normalized joint pose cost instead of two independently improving minima.
- A direct low-cost path bypasses lattice planning for the common short longitudinal precision plateau.
- A trusted post-pickup carried-pallet observation can refresh the carried-pallet pose; truth feedback remains forbidden.

## Controller truth policy

MuJoCo ground truth must never be passed to `reset()`, `update_carried_pallet_pose()`, or `step()`. Ground truth remains evaluator-only.
