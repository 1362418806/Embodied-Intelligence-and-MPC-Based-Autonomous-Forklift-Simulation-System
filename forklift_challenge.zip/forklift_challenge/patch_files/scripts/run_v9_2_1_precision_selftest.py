"""Run deterministic V9.2.1 terminal precision controller smoke checks."""

from __future__ import annotations

import math
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from forklift_v9_2_1_terminal_precision import (  # noqa: E402
    Pose2D,
    TerminalPrecisionController,
    TerminalPrecisionMode,
    compose_pose,
    inverse_pose,
)


def propagate_target(target: Pose2D, speed_mps: float, curvature_1pm: float, dt_s: float) -> Pose2D:
    """Propagate a fixed world target into the next forklift base frame."""
    delta_yaw = speed_mps * curvature_1pm * dt_s
    if abs(curvature_1pm) <= 1e-10:
        motion = Pose2D(speed_mps * dt_s, 0.0, 0.0)
    else:
        radius = 1.0 / curvature_1pm
        motion = Pose2D(
            radius * math.sin(delta_yaw),
            radius * (1.0 - math.cos(delta_yaw)),
            delta_yaw,
        )
    return compose_pose(inverse_pose(motion), target)


def run_case(name: str, error: Pose2D, max_steps: int = 500) -> None:
    """Run one ideal-kinematic terminal case and fail on re-entry or non-convergence."""
    carried = Pose2D(1.30, 0.0, 0.0)
    target = compose_pose(carried, error)
    controller = TerminalPrecisionController()
    controller.reset(carried)
    actual_speed = 0.0

    for step_index in range(max_steps):
        decision = controller.step(
            target_pose_in_base=target,
            dt_s=0.05,
            max_curvature_1pm=1.0,
            actual_speed_mps=actual_speed,
        )
        if decision.release_ready:
            print(
                f"PASS {name}: t={step_index * 0.05:.2f}s "
                f"position={decision.position_error_m:.4f}m "
                f"yaw={math.degrees(decision.yaw_error_rad):.3f}deg"
            )
            return
        if decision.request_reentry:
            raise RuntimeError(
                f"{name}: unexpected re-entry at {step_index * 0.05:.2f}s "
                f"position={decision.position_error_m:.4f}m "
                f"yaw={math.degrees(decision.yaw_error_rad):.3f}deg"
            )
        if decision.mode == TerminalPrecisionMode.INACTIVE:
            raise RuntimeError(f"{name}: controller unexpectedly relinquished precision ownership")

        actual_speed = decision.speed_mps
        target = propagate_target(target, decision.speed_mps, decision.curvature_1pm, 0.05)

    raise RuntimeError(f"{name}: did not converge within {max_steps * 0.05:.1f}s")


def main() -> int:
    """Run the deterministic precision smoke suite."""
    cases = {
        "forward_plateau": Pose2D(0.15, 0.015, math.radians(2.0)),
        "reverse_plateau": Pose2D(-0.15, 0.005, math.radians(-1.0)),
        "yaw_coupled_plateau": Pose2D(0.14, -0.020, math.radians(4.0)),
    }
    for name, error in cases.items():
        run_case(name, error)
    print("V9.2.1 terminal precision smoke: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
