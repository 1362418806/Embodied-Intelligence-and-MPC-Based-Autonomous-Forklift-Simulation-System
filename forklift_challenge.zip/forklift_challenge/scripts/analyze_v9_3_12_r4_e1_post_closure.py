"""Analyze V9.3.12-R4-E1 post-closure basin ownership from a trace JSONL.

Ground Truth is used here only for offline diagnosis; none of these values are
fed back into the controller.
"""
from __future__ import annotations
import argparse, json, math
from pathlib import Path

def wrap(a: float) -> float:
    return (float(a)+math.pi)%(2.0*math.pi)-math.pi

def truth_task_error(row: dict) -> tuple[float|None,float|None]:
    o=row.get("ground_truth_observation",{})
    load=o.get("pallet_pose_in_base")
    target=o.get("placement_pose_in_base")
    if not isinstance(load,dict) or not isinstance(target,dict):
        return None,None
    dx=float(target["x"])-float(load["x"])
    dy=float(target["y"])-float(load["y"])
    c=math.cos(float(target["yaw"])); s=math.sin(float(target["yaw"]))
    lon=c*dx+s*dy; lat=-s*dx+c*dy
    return math.hypot(lon,lat), math.degrees(wrap(float(target["yaw"])-float(load["yaw"])))

def main() -> int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("trace", type=Path)
    p.add_argument("--output-json", type=Path)
    args=p.parse_args()
    rows=[json.loads(line) for line in args.trace.read_text(encoding="utf-8").splitlines() if line.strip()]
    owned=[]; veto=[]; handoff=[]; strict=[]; release=[]
    for r in rows:
        d=r.get("decision",{})
        t=float(r.get("ground_truth_observation",{}).get("sim_time",0.0))
        truth_pos,truth_yaw=truth_task_error(r)
        item={
            "t":t,
            "status":d.get("status"),
            "filtered_position_m":d.get("placement_precision_filtered_position_error_m"),
            "filtered_yaw_deg":d.get("placement_precision_filtered_yaw_error_deg"),
            "certification_position_m":d.get("placement_post_closure_last_certification_position_m"),
            "certification_yaw_deg":d.get("placement_post_closure_last_certification_yaw_deg"),
            "mpc_predicted_position_m":d.get("placement_mpc_predicted_position_error_m"),
            "mpc_predicted_yaw_deg":d.get("placement_mpc_predicted_yaw_error_deg"),
            "truth_position_m":truth_pos,
            "truth_yaw_deg":truth_yaw,
        }
        if d.get("placement_post_closure_basin_ownership_active"):
            owned.append(item)
        if "R4-E1 post-closure MPC veto" in str(d.get("status","")):
            veto.append(item)
        if int(d.get("placement_post_closure_certification_handoff_count",0) or 0)>0:
            handoff.append(item)
        if d.get("strict_release_certified") is True:
            strict.append(item)
        if d.get("placement_release_commit_active") or d.get("state")=="LOWER_LOAD":
            release.append(item)
    last=rows[-1].get("decision",{}) if rows else {}
    fpos=[x["filtered_position_m"] for x in owned if x["filtered_position_m"] is not None]
    tpos=[x["truth_position_m"] for x in owned if x["truth_position_m"] is not None]
    truth_escape=[
        x for x in owned
        if x["truth_position_m"] is not None and x["truth_yaw_deg"] is not None
        and (x["truth_position_m"]>=0.10 or abs(x["truth_yaw_deg"])>=5.0)
    ]
    result={
        "owned_frames":len(owned),
        "ownership_entry_count":last.get("placement_post_closure_basin_ownership_entry_count",0),
        "mpc_veto_count":last.get("placement_post_closure_mpc_veto_count",0),
        "safe_mpc_allow_count":last.get("placement_post_closure_mpc_safe_allow_count",0),
        "certification_handoff_count":last.get("placement_post_closure_certification_handoff_count",0),
        "continuation_search_count":last.get("placement_post_closure_continuation_search_count",0),
        "continuation_activation_count":last.get("placement_post_closure_continuation_activation_count",0),
        "fresh_rgb_closure_activations":last.get("placement_fresh_rgb_yaw_closure_activation_count",0),
        "fresh_rgb_total_candidates":last.get("placement_fresh_rgb_yaw_closure_total_candidate_count",0),
        "fresh_rgb_no_candidate_searches":last.get("placement_fresh_rgb_yaw_closure_no_candidate_search_count",0),
        "max_filtered_position_while_owned_m":max(fpos) if fpos else None,
        "max_truth_position_while_owned_m":max(tpos) if tpos else None,
        "truth_competition_basin_escape_frames_while_owned":len(truth_escape),
        "strict_frames":len(strict),
        "release_frames":len(release),
        "first_veto":veto[0] if veto else None,
        "first_handoff":handoff[0] if handoff else None,
    }
    print(json.dumps(result,indent=2,ensure_ascii=False))
    if args.output_json:
        args.output_json.parent.mkdir(parents=True,exist_ok=True)
        args.output_json.write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding="utf-8")
    return 0

if __name__=="__main__":
    raise SystemExit(main())
