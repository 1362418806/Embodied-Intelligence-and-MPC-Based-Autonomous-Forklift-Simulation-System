from __future__ import annotations

import argparse
import json
import math
import tempfile
import zipfile
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Iterable

OFFICIAL_POSITION_LIMIT_M = 0.10
OFFICIAL_YAW_LIMIT_DEG = 5.0
INTERNAL_POSITION_LIMIT_M = 0.095
INTERNAL_YAW_LIMIT_DEG = 4.6


def _wrap_rad(value: float) -> float:
    return (float(value) + math.pi) % (2.0 * math.pi) - math.pi


def _wrap_deg(value: float) -> float:
    return (float(value) + 180.0) % 360.0 - 180.0


def _truth_error(row: dict[str, Any]) -> tuple[float | None, float | None]:
    gt = row.get("ground_truth_observation") or {}
    pallet = gt.get("pallet_pose_in_base")
    target = gt.get("placement_pose_in_base")
    if not pallet or not target:
        return None, None
    position = math.hypot(float(target["x"]) - float(pallet["x"]), float(target["y"]) - float(pallet["y"]))
    yaw = abs(math.degrees(_wrap_rad(float(target["yaw"]) - float(pallet["yaw"]))))
    return float(position), float(yaw)


def _truth_components(row: dict[str, Any]) -> dict[str, float] | None:
    gt = row.get("ground_truth_observation") or {}
    pallet = gt.get("pallet_pose_in_base")
    target = gt.get("placement_pose_in_base")
    if not pallet or not target:
        return None
    load = math.degrees(float(pallet["yaw"]))
    target_yaw = math.degrees(float(target["yaw"]))
    relative = _wrap_deg(target_yaw - load)
    return {"load_yaw_deg": load, "target_yaw_deg": target_yaw, "relative_yaw_deg": relative}


def _pass_official(position_m: float | None, yaw_deg: float | None) -> bool | None:
    if position_m is None or yaw_deg is None:
        return None
    return bool(position_m < OFFICIAL_POSITION_LIMIT_M and yaw_deg < OFFICIAL_YAW_LIMIT_DEG)


def _pass_internal(position_m: float | None, yaw_deg: float | None) -> bool | None:
    if position_m is None or yaw_deg is None:
        return None
    return bool(position_m < INTERNAL_POSITION_LIMIT_M and yaw_deg < INTERNAL_YAW_LIMIT_DEG)


def _load_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def _resolve_root(path: Path, workdir: Path) -> Path:
    if path.is_file() and path.suffix.lower() == ".zip":
        with zipfile.ZipFile(path) as archive:
            archive.extractall(workdir)
        candidates = [p.parent for p in workdir.rglob("episodes.jsonl") if (p.parent / "summary.json").exists()]
        if len(candidates) != 1:
            raise RuntimeError(f"expected exactly one qualification root in zip, found {len(candidates)}")
        return candidates[0]
    if path.is_dir():
        if (path / "episodes.jsonl").exists():
            return path
        candidates = [p.parent for p in path.rglob("episodes.jsonl") if (p.parent / "summary.json").exists()]
        if len(candidates) == 1:
            return candidates[0]
    raise FileNotFoundError(f"could not resolve qualification root from {path}")


def _find_last_transition_before(rows: list[dict[str, Any]], field: str, event_time: float) -> dict[str, Any] | None:
    previous = False
    last = None
    for row in rows:
        t = float((row.get("ground_truth_observation") or {}).get("sim_time", -math.inf))
        if t > event_time + 1e-6:
            break
        decision = row.get("decision") or {}
        current = bool(decision.get(field))
        if current and not previous:
            last = row
        previous = current
    return last


def _find_first_transition(rows: list[dict[str, Any]], field: str) -> dict[str, Any] | None:
    previous = False
    for row in rows:
        decision = row.get("decision") or {}
        current = bool(decision.get(field))
        if current and not previous:
            return row
        previous = current
    return None


def _find_first_state(rows: list[dict[str, Any]], state: str) -> dict[str, Any] | None:
    for row in rows:
        if (row.get("decision") or {}).get("state") == state:
            return row
    return None


def _find_first_official_pass(rows: list[dict[str, Any]], start_time: float) -> dict[str, Any] | None:
    for row in rows:
        t = float((row.get("ground_truth_observation") or {}).get("sim_time", -math.inf))
        if t + 1e-9 < start_time:
            continue
        p, y = _truth_error(row)
        if _pass_official(p, y):
            return row
    return None


def _event_snapshot(row: dict[str, Any] | None) -> dict[str, Any] | None:
    if row is None:
        return None
    gt = row.get("ground_truth_observation") or {}
    decision = row.get("decision") or {}
    marker = row.get("vision_marker") or {}
    p, y = _truth_error(row)
    truth = _truth_components(row)
    estimated_load = decision.get("strict_release_certification_load_yaw_deg")
    estimated_target = decision.get("strict_release_certification_target_yaw_deg")
    estimated_relative = decision.get("strict_release_certification_yaw_error_deg")
    bias: dict[str, float] = {}
    if truth is not None and estimated_load is not None:
        bias["load_yaw_bias_deg"] = _wrap_deg(float(estimated_load) - truth["load_yaw_deg"])
    if truth is not None and estimated_target is not None:
        bias["target_yaw_bias_deg"] = _wrap_deg(float(estimated_target) - truth["target_yaw_deg"])
    if truth is not None and estimated_load is not None and estimated_target is not None:
        signed_est_rel = _wrap_deg(float(estimated_target) - float(estimated_load))
        bias["relative_yaw_bias_deg"] = _wrap_deg(signed_est_rel - truth["relative_yaw_deg"])
        bias["estimated_relative_yaw_signed_deg"] = signed_est_rel
    return {
        "sim_time": gt.get("sim_time"),
        "state": decision.get("state"),
        "truth_position_error_m": p,
        "truth_yaw_error_deg": y,
        "truth_official_pass": _pass_official(p, y),
        "truth_internal_pass": _pass_internal(p, y),
        "estimated_position_error_m": decision.get("strict_release_certification_position_error_m"),
        "estimated_yaw_error_deg": estimated_relative,
        "estimated_load_yaw_deg": estimated_load,
        "estimated_target_yaw_deg": estimated_target,
        "target_source": decision.get("strict_release_certification_target_source"),
        "yaw_risk_mode": decision.get("strict_release_yaw_risk_budget_mode"),
        "position_margin_m": decision.get("strict_release_position_margin_m"),
        "yaw_margin_deg": decision.get("strict_release_yaw_margin_deg"),
        "center_anchor_active": decision.get("strict_release_center_yaw_anchor_active"),
        "center_anchor_age_seconds": marker.get("release_center_yaw_anchor_age_seconds"),
        "center_anchor_spread_deg": marker.get("release_center_yaw_anchor_spread_deg"),
        "load_yaw_evidence_stale_seconds": decision.get("carried_load_yaw_evidence_stale_seconds"),
        "motion_yaw_sigma_deg": decision.get("carried_load_motion_yaw_sigma_deg"),
        "release_yaw_sigma_deg": decision.get("carried_load_release_yaw_sigma_deg"),
        "bias": bias,
    }


def _largest_anchor_jump(rows: list[dict[str, Any]]) -> dict[str, Any] | None:
    previous: tuple[float, float] | None = None
    best: dict[str, Any] | None = None
    for row in rows:
        gt = row.get("ground_truth_observation") or {}
        marker = row.get("vision_marker") or {}
        if not marker.get("release_center_yaw_anchor_active"):
            continue
        value = marker.get("release_center_yaw_anchor_target_yaw_deg")
        if value is None:
            continue
        t = float(gt.get("sim_time", 0.0))
        value = float(value)
        if previous is not None:
            jump = abs(_wrap_deg(value - previous[1]))
            if best is None or jump > float(best["jump_deg"]):
                best = {
                    "sim_time": t,
                    "jump_deg": jump,
                    "previous_target_yaw_deg": previous[1],
                    "new_target_yaw_deg": value,
                    "anchor_age_seconds": marker.get("release_center_yaw_anchor_age_seconds"),
                }
        previous = (t, value)
    return best




def _anchor_jump_into_event(rows: list[dict[str, Any]], event_time: float) -> dict[str, Any] | None:
    previous_value: float | None = None
    event_value: float | None = None
    event_age: float | None = None
    event_row_time: float | None = None
    for row in rows:
        gt = row.get("ground_truth_observation") or {}
        t = float(gt.get("sim_time", -math.inf))
        if t > event_time + 1e-6:
            break
        marker = row.get("vision_marker") or {}
        if not marker.get("release_center_yaw_anchor_active"):
            continue
        value = marker.get("release_center_yaw_anchor_target_yaw_deg")
        if value is None:
            continue
        value = float(value)
        if t < event_time - 1e-6:
            previous_value = value
        else:
            event_value = value
            event_age = marker.get("release_center_yaw_anchor_age_seconds")
            event_row_time = t
    if previous_value is None or event_value is None:
        return None
    return {
        "sim_time": event_row_time,
        "jump_deg": abs(_wrap_deg(event_value - previous_value)),
        "previous_target_yaw_deg": previous_value,
        "new_target_yaw_deg": event_value,
        "anchor_age_seconds": event_age,
    }


def _effective_certified_yaw(event: dict[str, Any] | None) -> float | None:
    if not event:
        return None
    raw = event.get("estimated_yaw_error_deg")
    margin = event.get("yaw_margin_deg")
    if raw is None or margin is None:
        return None
    return float(raw) + float(margin)

def _find_preceding_additive(rows: list[dict[str, Any]], event_time: float, window_seconds: float = 1.5) -> dict[str, Any] | None:
    candidate = None
    for row in rows:
        gt = row.get("ground_truth_observation") or {}
        t = float(gt.get("sim_time", -math.inf))
        if t > event_time:
            break
        if event_time - t > window_seconds:
            continue
        d = row.get("decision") or {}
        if d.get("strict_release_yaw_risk_budget_mode") == "ADDITIVE":
            candidate = row
    return candidate


def _classification(episode: dict[str, Any], release_event: dict[str, Any] | None, witness_event: dict[str, Any] | None) -> dict[str, Any]:
    any_fp = any(
        bool(episode.get(k))
        for k in (
            "controller_certified_release_false_positive",
            "release_witness_false_positive",
            "release_execution_false_positive",
        )
    )
    if not any_fp:
        return {"primary": "NONE", "secondary": [], "freeze_impact": "NONE"}

    event = release_event or witness_event
    if event is None:
        primary = "C_TRACE_EVENT_MISSING"
    elif event.get("truth_official_pass") is False:
        primary = "B_REAL_RELEASE_RISK"
    elif event.get("truth_internal_pass") is False:
        primary = "A_INTERNAL_BUFFER_ONLY"
    else:
        primary = "C_SUMMARY_TRACE_MISMATCH"

    secondary: list[str] = []
    source = episode.get("controller_release_target_source")
    risk = episode.get("controller_release_yaw_risk_budget_mode")
    if source == "CENTER_YAW_ANCHOR":
        secondary.append("D_F4_CENTER_TARGET_ASSOCIATED")
    if risk == "CENTER_YAW_RSS":
        secondary.append("D_F4_CENTER_RSS_ASSOCIATED")
    if source != "CENTER_YAW_ANCHOR" and risk != "CENTER_YAW_RSS":
        secondary.append("E_BASELINE_RELEASE_PATH_ASSOCIATED")

    freeze_impact = "HOLD_FOR_MINIMAL_SAFETY_PATCH" if primary == "B_REAL_RELEASE_RISK" else "AUDIT_REQUIRED"
    return {"primary": primary, "secondary": secondary, "freeze_impact": freeze_impact}


def analyze(root: Path) -> dict[str, Any]:
    episodes = _load_jsonl(root / "episodes.jsonl")
    summary = json.loads((root / "summary.json").read_text(encoding="utf-8"))
    reports: list[dict[str, Any]] = []

    for episode in episodes:
        scenario_id = str(episode.get("scenario_id") or "")
        trace_path = root / "traces" / f"{scenario_id}.jsonl"
        rows = _load_jsonl(trace_path) if trace_path.exists() else []
        first_cert = _find_first_transition(rows, "strict_release_certified") if rows else None
        witness = _find_first_transition(rows, "release_witness_active") if rows else None
        lower = _find_first_state(rows, "LOWER_LOAD") if rows else None
        release_snapshot = _find_first_transition(rows, "release_snapshot_active") if rows else None
        release_event_row = release_snapshot or lower or witness
        release_event = _event_snapshot(release_event_row)
        witness_event = _event_snapshot(witness)
        first_cert_event = _event_snapshot(first_cert)
        gate_time = None
        if witness is not None:
            gate_time = float((witness.get("ground_truth_observation") or {}).get("sim_time", 0.0))
        elif release_event is not None and release_event.get("sim_time") is not None:
            gate_time = float(release_event["sim_time"])
        release_cert_transition_row = _find_last_transition_before(rows, "strict_release_certified", gate_time) if rows and gate_time is not None else first_cert
        release_cert_transition_event = _event_snapshot(release_cert_transition_row)
        first_official_after = None
        if release_event is not None and release_event.get("sim_time") is not None and rows:
            first_official_after = _event_snapshot(_find_first_official_pass(rows, float(release_event["sim_time"])))

        precision = episode.get("precision_diagnostics") or {}
        stages = precision.get("stages") or {}
        release_stage = (stages.get("release_command") or {}).get("truth") or {}
        grounded_stage = (stages.get("grounded") or {}).get("truth") or {}
        final_stage = (stages.get("final") or {}).get("truth") or {}
        release_stage_pos = release_stage.get("position_error_m")
        release_stage_yaw = abs(float(release_stage.get("yaw_error_deg"))) if release_stage.get("yaw_error_deg") is not None else None

        classification = _classification(episode, release_event, witness_event)
        preceding_additive = None
        if release_cert_transition_event is not None and release_cert_transition_event.get("sim_time") is not None and rows:
            preceding_additive = _event_snapshot(_find_preceding_additive(rows, float(release_cert_transition_event["sim_time"])))
        cert_transition = None
        if release_cert_transition_event is not None:
            cert_transition = {
                "preceding_additive_effective_yaw_deg": _effective_certified_yaw(preceding_additive),
                "first_cert_effective_yaw_deg": _effective_certified_yaw(release_cert_transition_event),
                "effective_yaw_drop_deg": None,
                "raw_yaw_drop_deg": None,
                "margin_drop_deg": None,
                "anchor_jump_into_first_cert": _anchor_jump_into_event(rows, float(release_cert_transition_event["sim_time"])) if rows and release_cert_transition_event.get("sim_time") is not None else None,
            }
            if preceding_additive and preceding_additive.get("estimated_yaw_error_deg") is not None and release_cert_transition_event.get("estimated_yaw_error_deg") is not None:
                cert_transition["raw_yaw_drop_deg"] = float(preceding_additive["estimated_yaw_error_deg"]) - float(release_cert_transition_event["estimated_yaw_error_deg"])
            if preceding_additive and preceding_additive.get("yaw_margin_deg") is not None and release_cert_transition_event.get("yaw_margin_deg") is not None:
                cert_transition["margin_drop_deg"] = float(preceding_additive["yaw_margin_deg"]) - float(release_cert_transition_event["yaw_margin_deg"])
            if cert_transition["preceding_additive_effective_yaw_deg"] is not None and cert_transition["first_cert_effective_yaw_deg"] is not None:
                cert_transition["effective_yaw_drop_deg"] = float(cert_transition["preceding_additive_effective_yaw_deg"]) - float(cert_transition["first_cert_effective_yaw_deg"])

        reports.append(
            {
                "scenario_id": scenario_id,
                "success": bool(episode.get("success")),
                "controller_fp": bool(episode.get("controller_certified_release_false_positive")),
                "witness_fp": bool(episode.get("release_witness_false_positive")),
                "execution_fp": bool(episode.get("release_execution_false_positive")),
                "controller_target_source": episode.get("controller_release_target_source"),
                "controller_yaw_risk_mode": episode.get("controller_release_yaw_risk_budget_mode"),
                "release_stage_truth": {
                    "position_error_m": release_stage_pos,
                    "yaw_error_deg": release_stage_yaw,
                    "official_pass": _pass_official(release_stage_pos, release_stage_yaw),
                    "official_position_excess_m": None if release_stage_pos is None else max(0.0, float(release_stage_pos) - OFFICIAL_POSITION_LIMIT_M),
                    "official_yaw_excess_deg": None if release_stage_yaw is None else max(0.0, float(release_stage_yaw) - OFFICIAL_YAW_LIMIT_DEG),
                },
                "grounded_truth": {
                    "position_error_m": grounded_stage.get("position_error_m"),
                    "yaw_error_deg": abs(float(grounded_stage.get("yaw_error_deg"))) if grounded_stage.get("yaw_error_deg") is not None else None,
                    "official_pass": bool((stages.get("grounded") or {}).get("truth_competition_ready")),
                },
                "final_truth": {
                    "position_error_m": final_stage.get("position_error_m"),
                    "yaw_error_deg": abs(float(final_stage.get("yaw_error_deg"))) if final_stage.get("yaw_error_deg") is not None else None,
                    "official_pass": bool((stages.get("final") or {}).get("truth_competition_ready")),
                },
                "first_cert_event": first_cert_event,
                "release_cert_transition_event": release_cert_transition_event,
                "witness_event": witness_event,
                "release_event": release_event,
                "first_official_pass_after_release": first_official_after,
                "preceding_additive_event": preceding_additive,
                "certification_transition": cert_transition,
                "largest_center_anchor_jump": _largest_anchor_jump(rows) if rows else None,
                "classification": classification,
            }
        )

    fp_reports = [r for r in reports if r["controller_fp"] or r["witness_fp"] or r["execution_fp"]]
    real_risk = [r for r in fp_reports if r["classification"]["primary"] == "B_REAL_RELEASE_RISK"]
    center_associated = [
        r
        for r in real_risk
        if "D_F4_CENTER_TARGET_ASSOCIATED" in r["classification"]["secondary"]
        or "D_F4_CENTER_RSS_ASSOCIATED" in r["classification"]["secondary"]
    ]

    decision = "FREEZE_ELIGIBLE"
    if real_risk:
        decision = "SAFETY_HOLD_MINIMAL_PATCH_REQUIRED"
    elif fp_reports:
        decision = "SAFETY_HOLD_DIAGNOSTIC_REVIEW_REQUIRED"

    recommendations: list[str] = []
    if real_risk:
        recommendations.append("Do not reopen MPC, recenter topology, or carried-load terminal yaw authority.")
        recommendations.append("Keep F4 liveness path, but gate release against the observed release-time yaw false-positive before V9.3 freeze.")
    if center_associated:
        recommendations.append("Next runtime patch should audit centre-yaw re-anchor continuity and carried-load yaw-anchor staleness together; do not blame RSS alone.")
        recommendations.append("A safe candidate is an online conflict/continuity guard that falls back to the existing MULTIVIEW/ADDITIVE path when a fresh centre anchor changes the certified relative yaw too abruptly or conflicts with the pre-anchor certification estimate.")
    if not fp_reports:
        recommendations.append("No release false-positive found; V9.3 meets the zero-FP diagnostic gate for this batch.")

    return {
        "schema": "v9_3_12_r4_f4_s1_fp_audit_v1",
        "qualification_root": str(root),
        "episode_count": len(reports),
        "success_count": int(summary.get("success_count", sum(int(r["success"]) for r in reports))),
        "competition_precision_success_count": int(summary.get("competition_precision_success_count", 0)),
        "fp_episode_count": len(fp_reports),
        "real_release_risk_episode_count": len(real_risk),
        "f4_center_path_real_risk_episode_count": len(center_associated),
        "freeze_decision": decision,
        "official_limits": {"position_m": OFFICIAL_POSITION_LIMIT_M, "yaw_deg": OFFICIAL_YAW_LIMIT_DEG},
        "internal_limits": {"position_m": INTERNAL_POSITION_LIMIT_M, "yaw_deg": INTERNAL_YAW_LIMIT_DEG},
        "recommendations": recommendations,
        "episodes": reports,
    }


def _markdown(report: dict[str, Any]) -> str:
    lines = [
        "# V9.3.12-R4-F4-S1 False-Positive Safety Audit",
        "",
        f"- Episodes: **{report['episode_count']}**",
        f"- Success: **{report['success_count']}**",
        f"- Competition precision success: **{report['competition_precision_success_count']}**",
        f"- FP episodes: **{report['fp_episode_count']}**",
        f"- Real release-risk episodes: **{report['real_release_risk_episode_count']}**",
        f"- Freeze decision: **{report['freeze_decision']}**",
        "",
        "## False-positive episodes",
        "",
    ]
    fps = [e for e in report["episodes"] if e["controller_fp"] or e["witness_fp"] or e["execution_fp"]]
    if not fps:
        lines.append("None.")
    for e in fps:
        rel = e.get("release_event") or {}
        wit = e.get("witness_event") or {}
        lines += [
            f"### {e['scenario_id']}",
            "",
            f"- Classification: **{e['classification']['primary']}**; secondary={', '.join(e['classification']['secondary']) or 'none'}",
            f"- Controller/Witness/Execution FP: `{e['controller_fp']}/{e['witness_fp']}/{e['execution_fp']}`",
            f"- Release path: `{e['controller_target_source']} / {e['controller_yaw_risk_mode']}`",
            f"- Release-stage truth: position={e['release_stage_truth']['position_error_m']:.6f} m, yaw={e['release_stage_truth']['yaw_error_deg']:.6f} deg",
            f"- Official yaw excess: **{e['release_stage_truth']['official_yaw_excess_deg']:.6f} deg**",
        ]
        if wit:
            bias = wit.get("bias") or {}
            lines += [
                f"- Witness t={wit.get('sim_time')}: truth yaw={wit.get('truth_yaw_error_deg'):.6f} deg, estimated yaw={wit.get('estimated_yaw_error_deg'):.6f} deg",
                f"- Witness load/target/relative yaw bias: `{bias.get('load_yaw_bias_deg')} / {bias.get('target_yaw_bias_deg')} / {bias.get('relative_yaw_bias_deg')} deg`",
                f"- Carried-load yaw evidence stale: `{wit.get('load_yaw_evidence_stale_seconds')} s`",
            ]
        first_after = e.get("first_official_pass_after_release") or {}
        if first_after:
            lines.append(
                f"- First official pass after release starts: t={first_after.get('sim_time')}, yaw={first_after.get('truth_yaw_error_deg'):.6f} deg"
            )
        transition = e.get("certification_transition") or {}
        if transition:
            lines.append(
                "- Certification switch effective yaw (preceding additive -> first strict): "
                f"`{transition.get('preceding_additive_effective_yaw_deg')} -> {transition.get('first_cert_effective_yaw_deg')} deg`"
            )
            lines.append(
                "- Switch decomposition raw-yaw/margin/effective drop: "
                f"`{transition.get('raw_yaw_drop_deg')} / {transition.get('margin_drop_deg')} / {transition.get('effective_yaw_drop_deg')} deg`"
            )
            aj = transition.get("anchor_jump_into_first_cert") or {}
            if aj:
                lines.append(f"- Centre-anchor jump into first strict frame: **{aj.get('jump_deg'):.6f} deg**")
        jump = e.get("largest_center_anchor_jump") or {}
        if jump:
            lines.append(f"- Largest centre-anchor target-yaw jump: `{jump.get('jump_deg'):.6f} deg` at t={jump.get('sim_time')}")
        lines.append("")
    lines += ["## Recommendations", ""]
    lines.extend(f"- {r}" for r in report.get("recommendations", []))
    lines.append("")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="V9.3.12-R4-F4-S1 isolate release false-positive episodes")
    parser.add_argument("qualification", type=Path, help="qualification directory or zip")
    parser.add_argument("--json-out", type=Path, default=None)
    parser.add_argument("--md-out", type=Path, default=None)
    parser.add_argument("--fail-on-real-fp", action="store_true", help="return exit code 2 when a real release-time official FP is found")
    args = parser.parse_args()

    with tempfile.TemporaryDirectory(prefix="f4_s1_audit_") as tmp:
        root = _resolve_root(args.qualification, Path(tmp))
        report = analyze(root)

    text = _markdown(report)
    print(text)
    if args.json_out:
        args.json_out.parent.mkdir(parents=True, exist_ok=True)
        args.json_out.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    if args.md_out:
        args.md_out.parent.mkdir(parents=True, exist_ok=True)
        args.md_out.write_text(text, encoding="utf-8")
    if args.fail_on_real_fp and report["real_release_risk_episode_count"]:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
