"""Run V7 interactively with noisy, delayed and filtered relative poses.

The existing V6.3 viewer is reused. Only its ObservationBuilder is replaced by
an estimator-backed builder. Use ``--perception-profile clean|moderate|finals``
to select a profile; the argument is removed before the legacy parser runs.
"""

from __future__ import annotations

import importlib.util
from pathlib import Path
import sys
from types import ModuleType
from typing import Any

import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from perception.pose_pipeline import PosePipeline
from simulator.observation_builder import ObservationBuilder as TruthObservationBuilder


BASE_SCRIPT = PROJECT_ROOT / "scripts" / "run_forklift_v5_1.py"
DEFAULT_CONFIG = PROJECT_ROOT / "configs" / "vehicle_v7.yaml"


def _consume_option(name: str) -> str | None:
    if name not in sys.argv:
        return None
    index = sys.argv.index(name)
    if index + 1 >= len(sys.argv):
        raise ValueError(f"{name} requires a value")
    value = sys.argv[index + 1]
    del sys.argv[index : index + 2]
    return value


def _config_path_from_argv() -> Path:
    if "--config" in sys.argv:
        index = sys.argv.index("--config")
        if index + 1 >= len(sys.argv):
            raise ValueError("--config requires a value")
        return Path(sys.argv[index + 1]).resolve()
    return DEFAULT_CONFIG


def _load_application() -> ModuleType:
    if not BASE_SCRIPT.is_file():
        raise FileNotFoundError(f"base interactive script does not exist: {BASE_SCRIPT}")
    name = "_forklift_v7_interactive_base"
    spec = importlib.util.spec_from_file_location(name, BASE_SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load base script: {BASE_SCRIPT}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main() -> int:
    profile_override = _consume_option("--perception-profile")
    seed_override = _consume_option("--perception-seed")
    config_path = _config_path_from_argv()
    with config_path.open("r", encoding="utf-8") as stream:
        config: dict[str, Any] = yaml.safe_load(stream)
    perception = config["perception"]
    profile_name = profile_override or str(perception["default_profile"])
    seed = int(
        seed_override
        if seed_override is not None
        else config["randomization"]["default_seed"]
    )

    class EstimatedObservationBuilder:
        def __init__(self, model) -> None:
            self.truth_builder = TruthObservationBuilder(model)
            self.pipeline = PosePipeline.from_config(
                perception,
                profile_name=profile_name,
                seed=seed,
            )

        def build(self, data, *, fork_contact_count: int, load_state: str):
            truth = self.truth_builder.build(
                data,
                fork_contact_count=fork_contact_count,
                load_state=load_state,
            )
            return self.pipeline.step(truth).observation

    application = _load_application()
    application.DEFAULT_CONFIG = config_path
    application.ObservationBuilder = EstimatedObservationBuilder
    print(f"V7 perception profile: {profile_name} | seed={seed}")
    return int(application.main())


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (FileNotFoundError, KeyError, RuntimeError, ValueError, yaml.YAMLError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
