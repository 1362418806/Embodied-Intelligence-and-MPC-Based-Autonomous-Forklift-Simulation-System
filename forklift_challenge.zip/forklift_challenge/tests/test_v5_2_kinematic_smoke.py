"""Kinematic sign-and-convergence smoke test for V5.2.

This is not a substitute for MuJoCo batch evaluation. It protects the
centreline controller from sign regressions across representative easy poses.
"""

from __future__ import annotations

import math

from control.docking_controller import DockingController
from interfaces.observation import Pose3D


WHEELBASE = 0.93


def wrap(angle: float) -> float:
    return (angle + math.pi) % (2.0 * math.pi) - math.pi


def relative_pose(
    vehicle_x: float,
    vehicle_y: float,
    vehicle_yaw: float,
    object_x: float,
    object_y: float,
    object_yaw: float,
) -> Pose3D:
    dx = object_x - vehicle_x
    dy = object_y - vehicle_y
    cosine = math.cos(vehicle_yaw)
    sine = math.sin(vehicle_yaw)
    return Pose3D(
        x=cosine * dx + sine * dy,
        y=-sine * dx + cosine * dy,
        z=0.0,
        roll=0.0,
        pitch=0.0,
        yaw=wrap(object_yaw - vehicle_yaw),
    )


def controller() -> DockingController:
    return DockingController(
        distance_gain=0.68,
        heading_gain=1.0,
        yaw_gain=1.4,
        lateral_gain=0.8,
        lookahead_distance=0.60,
        maximum_steering=0.28,
        minimum_creep_speed=0.03,
        heading_slowdown_angle=0.70,
        yaw_slowdown_angle=0.55,
        minimum_alignment_scale=0.25,
    )


def run_case(
    object_x: float,
    object_y: float,
    yaw_deg: float,
) -> tuple[float, float, float]:
    vehicle_x = 0.0
    vehicle_y = 0.0
    vehicle_yaw = 0.0
    object_yaw = math.radians(yaw_deg)
    speed = 0.0
    steering = 0.0
    stage = "APPROACH"
    ctrl = controller()
    dt = 0.01

    for _ in range(12000):
        relative = relative_pose(
            vehicle_x,
            vehicle_y,
            vehicle_yaw,
            object_x,
            object_y,
            object_yaw,
        )
        if stage == "APPROACH":
            target = 3.20
            maximum_speed = 0.26
            steering_limit = 0.28
            if relative.x <= 3.285:
                stage = "ALIGN"
        elif stage == "ALIGN":
            target = 2.70
            maximum_speed = 0.09
            steering_limit = 0.24
            error = ctrl.axis_command(
                relative,
                target_distance=target,
                maximum_speed=maximum_speed,
                lift_target=0.04,
                steering_limit=steering_limit,
                minimum_speed_override=0.03,
            ).error
            if (
                relative.x <= 2.785
                and abs(error.lateral) <= 0.10
                and abs(error.yaw) <= 0.105
            ):
                stage = "INSERT"
        else:
            target = 1.60
            maximum_speed = 0.075
            steering_limit = 0.14

        command = ctrl.axis_command(
            relative,
            target_distance=target,
            maximum_speed=maximum_speed,
            lift_target=0.04,
            steering_limit=steering_limit,
            minimum_speed_override=0.03,
        )

        speed += (command.action.speed_target - speed) * min(1.0, dt / 0.45)
        steering += (
            command.action.steering_command - steering
        ) * min(1.0, dt / 0.60)

        vehicle_x += speed * math.cos(vehicle_yaw) * dt
        vehicle_y += speed * math.sin(vehicle_yaw) * dt
        vehicle_yaw = wrap(
            vehicle_yaw
            + speed * math.tan(steering) / WHEELBASE * dt
        )

        if stage == "INSERT":
            error = command.error
            if (
                relative.x <= 1.665
                and abs(error.lateral) <= 0.060
                and abs(error.yaw) <= 0.087
            ):
                return relative.x, error.lateral, error.yaw

    raise AssertionError(
        "controller did not converge for "
        f"object=({object_x}, {object_y}, {yaw_deg}deg)"
    )


def test_representative_easy_offsets_converge_in_kinematic_surrogate() -> None:
    # Representative relative pallet poses spanning the observed easy range:
    # lateral offsets up to about 0.26 m and yaw offsets up to about 4.6 deg.
    cases = (
        (3.914, -0.010, -2.12),
        (4.018, 0.263, 4.15),
        (3.776, 0.345, 3.30),
        (3.889, -0.226, -4.57),
        (3.919, -0.281, -2.02),
    )
    for object_x, object_y, yaw_deg in cases:
        x, line_error, yaw = run_case(
            object_x,
            object_y,
            yaw_deg,
        )
        assert x <= 1.665
        assert abs(line_error) <= 0.060
        assert abs(yaw) <= 0.087
