"""Regression tests for the v5.1.1 two-phase recovery state."""

from __future__ import annotations

from dataclasses import replace

from control.docking_controller import DockingController
from interfaces.observation import ForkliftObservation, Pose3D
from task.pickup_state_machine import (
    PickupParameters,
    PickupState,
    PickupStateMachine,
)


def pose(x: float = 0.0, y: float = 0.0, yaw: float = 0.0) -> Pose3D:
    return Pose3D(x=x, y=y, z=0.0, roll=0.0, pitch=0.0, yaw=yaw)


def obs(
    *,
    sim_time: float,
    pallet_x: float = 4.0,
    pallet_y: float = 0.2,
    vehicle_x: float = 0.0,
    steering_left: float = 0.0,
    steering_right: float = 0.0,
) -> ForkliftObservation:
    return ForkliftObservation(
        sim_time=sim_time,
        vehicle_pose_world=pose(vehicle_x, 0.0),
        vehicle_linear_velocity=(0.0, 0.0, 0.0),
        vehicle_angular_velocity=(0.0, 0.0, 0.0),
        steering_left=steering_left,
        steering_right=steering_right,
        front_wheel_speed_left=0.0,
        front_wheel_speed_right=0.0,
        lift_position=0.04,
        lift_velocity=0.0,
        pallet_pose_world=pose(3.2, 0.0),
        pallet_pose_in_base=pose(pallet_x, pallet_y),
        placement_pose_in_base=pose(5.0, -1.0),
        fork_contact_count=0,
        load_state="GROUND",
    )


def params() -> PickupParameters:
    return PickupParameters(
        insertion_lift_target=0.04,
        transport_lift_target=0.30,
        pre_approach_distance=2.85,
        insertion_distance=1.60,
        approach_max_speed=0.32,
        align_max_speed=0.13,
        insertion_max_speed=0.09,
        retreat_speed=-0.18,
        retreat_distance=0.75,
        approach_capture_distance=0.42,
        pre_position_tolerance=0.085,
        pre_lateral_tolerance=0.060,
        pre_yaw_tolerance=0.075,
        insertion_position_tolerance=0.055,
        insertion_lateral_tolerance=0.045,
        insertion_yaw_tolerance=0.060,
        lift_position_tolerance=0.055,
        lift_velocity_tolerance=0.015,
        lifted_minimum_fork_height=0.12,
        verify_lift_seconds=0.60,
        maximum_load_tilt=0.175,
        lower_timeout=4.0,
        approach_timeout=35.0,
        align_timeout=20.0,
        insert_timeout=18.0,
        lift_timeout=8.0,
        retreat_timeout=10.0,
        align_minimum_speed=0.075,
        alignment_hold_seconds=0.35,
        progress_timeout=1.0,
        progress_improvement=0.018,
        recovery_speed=-0.22,
        recovery_distance=0.34,
        recovery_timeout=10.0,
        maximum_recoveries=2,
        overshoot_longitudinal_tolerance=0.14,
        recovery_steering_tolerance=0.052,
        recovery_center_hold_seconds=0.18,
        recovery_center_timeout=3.0,
    )


def machine() -> PickupStateMachine:
    return PickupStateMachine(
        parameters=params(),
        docking_controller=DockingController(
            distance_gain=0.78,
            heading_gain=1.45,
            yaw_gain=0.72,
            lateral_gain=0.82,
            lookahead_distance=0.95,
            maximum_steering=0.36,
            minimum_creep_speed=0.055,
            heading_slowdown_angle=0.75,
            yaw_slowdown_angle=0.52,
            minimum_alignment_scale=0.32,
        ),
    )


def enter_recovery(sm: PickupStateMachine) -> None:
    sm.reset(0.0)
    assert sm.step(obs(sim_time=0.30)).state == PickupState.APPROACH
    sm.step(obs(sim_time=0.40))
    decision = sm.step(
        obs(
            sim_time=1.41,
            steering_left=-0.30,
            steering_right=-0.22,
        )
    )
    assert decision.state == PickupState.RECOVER_REVERSE


def test_recovery_stops_while_real_steering_is_not_centered() -> None:
    sm = machine()
    enter_recovery(sm)
    decision = sm.step(
        obs(
            sim_time=1.80,
            steering_left=-0.12,
            steering_right=-0.08,
        )
    )
    assert decision.state == PickupState.RECOVER_REVERSE
    assert decision.action.speed_target == 0.0
    assert "centering steering" in decision.status


def test_reverse_timeout_does_not_include_centering_time() -> None:
    sm = machine()
    enter_recovery(sm)

    # Spend most of the old six-second timeout centering.
    decision = sm.step(
        obs(
            sim_time=6.00,
            steering_left=-0.04,
            steering_right=-0.03,
        )
    )
    assert decision.state == PickupState.RECOVER_REVERSE
    assert decision.action.speed_target == 0.0

    # Hold centred long enough to start motion.
    decision = sm.step(
        obs(
            sim_time=6.20,
            steering_left=-0.01,
            steering_right=-0.01,
        )
    )
    assert decision.state == PickupState.RECOVER_REVERSE
    assert decision.action.speed_target < 0.0

    # Ten seconds are measured from 6.20, not from recovery entry.
    decision = sm.step(
        obs(
            sim_time=12.0,
            vehicle_x=-0.20,
            steering_left=0.0,
            steering_right=0.0,
        )
    )
    assert decision.state == PickupState.RECOVER_REVERSE
    assert decision.failure_reason is None


def test_recovery_replans_after_shorter_reverse_distance() -> None:
    sm = machine()
    enter_recovery(sm)
    sm.step(
        obs(
            sim_time=1.60,
            steering_left=0.0,
            steering_right=0.0,
        )
    )
    sm.step(
        obs(
            sim_time=1.80,
            steering_left=0.0,
            steering_right=0.0,
        )
    )
    decision = sm.step(
        obs(
            sim_time=4.0,
            vehicle_x=-0.35,
            steering_left=0.0,
            steering_right=0.0,
        )
    )
    assert decision.state == PickupState.APPROACH
    assert decision.action.speed_target == 0.0


def test_motion_timeout_reports_measured_reverse_distance() -> None:
    sm = machine()
    enter_recovery(sm)
    sm.step(obs(sim_time=1.60))
    sm.step(obs(sim_time=1.80))
    decision = sm.step(obs(sim_time=11.81, vehicle_x=-0.10))
    assert decision.state == PickupState.FAILED
    assert decision.failure_reason is not None
    assert "moved only" in decision.failure_reason
