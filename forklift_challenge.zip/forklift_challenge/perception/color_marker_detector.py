"""Known-colour four-corner placement-marker detection from an RGB image.

V8.0 uses a real rendered camera image for the close-range placement target.
Four uniquely coloured square patches define a planar fiducial.  Their pixel
centres are segmented in HSV space and passed to OpenCV ``solvePnP``.  The
resulting marker pose is converted from OpenCV camera coordinates into the
forklift base frame, then offset to the actual floor placement target.

Coordinate conventions
----------------------
Forklift base: +x forward, +y left, +z up.
OpenCV camera: +x image right, +y image down, +z forward.
Marker frame: +x image right, +y up, +z points out of the board toward the
approaching forklift.  Therefore the physical placement-target forward axis
is ``-marker_z``.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
import math
from typing import Any, Mapping, Sequence

import cv2
import numpy as np

from interfaces.observation import Pose3D


def wrap_angle(angle: float) -> float:
    return (float(angle) + math.pi) % (2.0 * math.pi) - math.pi


def _as_vector(values: Sequence[float], *, name: str, length: int) -> np.ndarray:
    array = np.asarray(values, dtype=float)
    if array.shape != (length,):
        raise ValueError(f"{name} must contain exactly {length} values")
    return array


def _rotation_matrix(values: Sequence[Sequence[float]], *, name: str) -> np.ndarray:
    array = np.asarray(values, dtype=float)
    if array.shape != (3, 3):
        raise ValueError(f"{name} must be a 3x3 matrix")
    if not np.allclose(array.T @ array, np.eye(3), atol=1e-6):
        raise ValueError(f"{name} must be orthonormal")
    if np.linalg.det(array) < 0.999:
        raise ValueError(f"{name} must be right-handed")
    return array


@dataclass(frozen=True)
class HSVRange:
    lower: tuple[int, int, int]
    upper: tuple[int, int, int]

    @classmethod
    def from_mapping(cls, values: Mapping[str, Any]) -> "HSVRange":
        lower = tuple(int(value) for value in values["lower"])
        upper = tuple(int(value) for value in values["upper"])
        if len(lower) != 3 or len(upper) != 3:
            raise ValueError("HSV lower/upper bounds must contain three values")
        for index, (lo, hi, maximum) in enumerate(zip(lower, upper, (179, 255, 255))):
            if not 0 <= lo <= hi <= maximum:
                raise ValueError(f"invalid HSV range component {index}: {lo}..{hi}")
        return cls(lower=lower, upper=upper)


@dataclass(frozen=True)
class MarkerGeometry:
    corner_half_width_m: float
    corner_half_height_m: float
    target_forward_offset_m: float
    marker_center_height_m: float
    patch_half_size_m: float

    @classmethod
    def from_mapping(cls, values: Mapping[str, Any]) -> "MarkerGeometry":
        result = cls(
            corner_half_width_m=float(values["corner_half_width_m"]),
            corner_half_height_m=float(values["corner_half_height_m"]),
            target_forward_offset_m=float(values["target_forward_offset_m"]),
            marker_center_height_m=float(values["marker_center_height_m"]),
            patch_half_size_m=float(values.get("patch_half_size_m", 0.09)),
        )
        for name, value in asdict(result).items():
            if value <= 0.0:
                raise ValueError(f"marker.{name} must be positive")
        return result

    @property
    def object_points(self) -> np.ndarray:
        """Patch centres in TL, TR, BR, BL order in marker coordinates."""
        x = self.corner_half_width_m
        y = self.corner_half_height_m
        return np.asarray(
            [
                (-x, +y, 0.0),
                (+x, +y, 0.0),
                (+x, -y, 0.0),
                (-x, -y, 0.0),
            ],
            dtype=np.float64,
        )

    @property
    def marker_to_target(self) -> np.ndarray:
        # Marker +y points up and +z points toward the vehicle.  The target is
        # below the marker and behind it in marker coordinates.
        return np.asarray(
            [0.0, -self.marker_center_height_m, self.target_forward_offset_m],
            dtype=np.float64,
        )


@dataclass(frozen=True)
class MarkerDetectorParameters:
    image_width: int
    image_height: int
    fovy_degrees: float
    minimum_blob_area_px: int
    morphology_kernel_px: int
    roi_top_fraction: float
    roi_bottom_fraction: float
    maximum_reprojection_error_px: float
    minimum_confidence: float
    minimum_distance_m: float
    maximum_distance_m: float
    expected_target_height_in_base_m: float
    maximum_target_height_error_m: float
    minimum_upright_cosine: float
    camera_position_in_base: tuple[float, float, float]
    camera_rotation_base_from_cv: tuple[tuple[float, float, float], ...]

    @classmethod
    def from_mapping(
        cls,
        values: Mapping[str, Any],
        *,
        image_width: int,
        image_height: int,
    ) -> "MarkerDetectorParameters":
        result = cls(
            image_width=int(image_width),
            image_height=int(image_height),
            fovy_degrees=float(values["fovy_degrees"]),
            minimum_blob_area_px=int(values.get("minimum_blob_area_px", 12)),
            morphology_kernel_px=int(values.get("morphology_kernel_px", 3)),
            roi_top_fraction=float(values.get("roi_top_fraction", 0.20)),
            roi_bottom_fraction=float(values.get("roi_bottom_fraction", 0.62)),
            maximum_reprojection_error_px=float(
                values.get("maximum_reprojection_error_px", 5.0)
            ),
            minimum_confidence=float(values.get("minimum_confidence", 0.25)),
            minimum_distance_m=float(values.get("minimum_distance_m", 0.5)),
            maximum_distance_m=float(values.get("maximum_distance_m", 8.0)),
            expected_target_height_in_base_m=float(
                values.get("expected_target_height_in_base_m", -0.56)
            ),
            maximum_target_height_error_m=float(
                values.get("maximum_target_height_error_m", 0.20)
            ),
            minimum_upright_cosine=float(values.get("minimum_upright_cosine", 0.70)),
            camera_position_in_base=tuple(
                float(value) for value in values["camera_position_in_base"]
            ),
            camera_rotation_base_from_cv=tuple(
                tuple(float(value) for value in row)
                for row in values["camera_rotation_base_from_cv"]
            ),
        )
        if result.image_width <= 0 or result.image_height <= 0:
            raise ValueError("image dimensions must be positive")
        if not 1.0 < result.fovy_degrees < 179.0:
            raise ValueError("fovy_degrees must be between 1 and 179")
        if result.minimum_blob_area_px <= 0:
            raise ValueError("minimum_blob_area_px must be positive")
        if result.morphology_kernel_px <= 0:
            raise ValueError("morphology_kernel_px must be positive")
        if not 0.0 <= result.roi_top_fraction < result.roi_bottom_fraction <= 1.0:
            raise ValueError("invalid detector vertical ROI fractions")
        if result.maximum_reprojection_error_px <= 0.0:
            raise ValueError("maximum_reprojection_error_px must be positive")
        if not 0.0 <= result.minimum_confidence <= 1.0:
            raise ValueError("minimum_confidence must be in [0, 1]")
        if not 0.0 < result.minimum_distance_m < result.maximum_distance_m:
            raise ValueError("invalid marker distance limits")
        if result.maximum_target_height_error_m <= 0.0:
            raise ValueError("maximum_target_height_error_m must be positive")
        if not 0.0 < result.minimum_upright_cosine <= 1.0:
            raise ValueError("minimum_upright_cosine must be in (0, 1]")
        _as_vector(result.camera_position_in_base, name="camera_position_in_base", length=3)
        _rotation_matrix(
            result.camera_rotation_base_from_cv,
            name="camera_rotation_base_from_cv",
        )
        return result


@dataclass(frozen=True)
class ColourBlob:
    colour: str
    center_x: float
    center_y: float
    area_px: int
    corners: tuple[tuple[float, float], ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class MarkerDetection:
    success: bool
    status: str
    target_pose_in_base: Pose3D | None
    confidence: float
    reprojection_error_px: float | None
    marker_distance_m: float | None
    blobs: tuple[ColourBlob, ...]
    # R4-E7 passive independent pose witness from the four colour-patch
    # centres. The legacy 16-corner PnP remains the primary pose/acceptance
    # source; downstream weak-guide fusion may use only this witness yaw after
    # explicit consistency gates.
    center_target_pose_in_base: Pose3D | None = None
    center_reprojection_error_px: float | None = None
    center_corner_position_disagreement_m: float | None = None
    center_corner_yaw_disagreement_deg: float | None = None

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        if self.target_pose_in_base is not None:
            result["target_pose_in_base"] = asdict(self.target_pose_in_base)
        if self.center_target_pose_in_base is not None:
            result["center_target_pose_in_base"] = asdict(self.center_target_pose_in_base)
        return result


class ColourPlacementMarkerDetector:
    """Segment four coloured patches and estimate the floor target pose."""

    COLOUR_ORDER = ("red", "green", "blue", "yellow")

    def __init__(
        self,
        *,
        parameters: MarkerDetectorParameters,
        geometry: MarkerGeometry,
        colour_ranges: Mapping[str, Sequence[HSVRange]],
    ) -> None:
        self.parameters = parameters
        self.geometry = geometry
        self.colour_ranges = {
            name: tuple(colour_ranges[name]) for name in self.COLOUR_ORDER
        }
        if any(not ranges for ranges in self.colour_ranges.values()):
            raise ValueError("each marker colour requires at least one HSV range")

        fovy = math.radians(parameters.fovy_degrees)
        focal = 0.5 * parameters.image_height / math.tan(0.5 * fovy)
        self.camera_matrix = np.asarray(
            [
                [focal, 0.0, 0.5 * (parameters.image_width - 1)],
                [0.0, focal, 0.5 * (parameters.image_height - 1)],
                [0.0, 0.0, 1.0],
            ],
            dtype=np.float64,
        )
        self.distortion = np.zeros((5, 1), dtype=np.float64)
        self.camera_position = _as_vector(
            parameters.camera_position_in_base,
            name="camera_position_in_base",
            length=3,
        )
        self.rotation_base_from_cv = _rotation_matrix(
            parameters.camera_rotation_base_from_cv,
            name="camera_rotation_base_from_cv",
        )
        self._previous_rvec: np.ndarray | None = None
        self._previous_tvec: np.ndarray | None = None

    @classmethod
    def from_config(
        cls,
        vision_config: Mapping[str, Any],
        *,
        image_width: int,
        image_height: int,
    ) -> "ColourPlacementMarkerDetector":
        detector_values = vision_config["detector"]
        ranges: dict[str, tuple[HSVRange, ...]] = {}
        for colour in cls.COLOUR_ORDER:
            ranges[colour] = tuple(
                HSVRange.from_mapping(item)
                for item in detector_values["hsv_ranges"][colour]
            )
        return cls(
            parameters=MarkerDetectorParameters.from_mapping(
                detector_values,
                image_width=image_width,
                image_height=image_height,
            ),
            geometry=MarkerGeometry.from_mapping(vision_config["marker"]),
            colour_ranges=ranges,
        )

    def reset(self) -> None:
        self._previous_rvec = None
        self._previous_tvec = None

    def _mask(self, hsv: np.ndarray, ranges: Sequence[HSVRange]) -> np.ndarray:
        result = np.zeros(hsv.shape[:2], dtype=np.uint8)
        for item in ranges:
            result = cv2.bitwise_or(
                result,
                cv2.inRange(
                    hsv,
                    np.asarray(item.lower, dtype=np.uint8),
                    np.asarray(item.upper, dtype=np.uint8),
                ),
            )
        top = int(round(self.parameters.roi_top_fraction * result.shape[0]))
        bottom = int(round(self.parameters.roi_bottom_fraction * result.shape[0]))
        result[:top, :] = 0
        result[bottom:, :] = 0
        size = self.parameters.morphology_kernel_px
        if size > 1:
            kernel = np.ones((size, size), dtype=np.uint8)
            result = cv2.morphologyEx(result, cv2.MORPH_OPEN, kernel)
            result = cv2.morphologyEx(result, cv2.MORPH_CLOSE, kernel)
        return result

    @staticmethod
    def _order_quad(points: np.ndarray) -> np.ndarray:
        points = np.asarray(points, dtype=np.float64).reshape(4, 2)
        ordered = np.empty((4, 2), dtype=np.float64)
        sums = points.sum(axis=1)
        differences = points[:, 0] - points[:, 1]
        ordered[0] = points[np.argmin(sums)]  # top-left
        ordered[2] = points[np.argmax(sums)]  # bottom-right
        ordered[1] = points[np.argmax(differences)]  # top-right
        ordered[3] = points[np.argmin(differences)]  # bottom-left
        return ordered

    def _blob(self, mask: np.ndarray, colour: str) -> ColourBlob | None:
        count, labels, stats, centroids = cv2.connectedComponentsWithStats(
            mask, connectivity=8
        )
        if count <= 1:
            return None
        candidates = range(1, count)
        index = max(candidates, key=lambda item: int(stats[item, cv2.CC_STAT_AREA]))
        area = int(stats[index, cv2.CC_STAT_AREA])
        if area < self.parameters.minimum_blob_area_px:
            return None
        center = centroids[index]
        component = np.where(labels == index, 255, 0).astype(np.uint8)
        contours, _ = cv2.findContours(
            component, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )
        corners: tuple[tuple[float, float], ...] = ()
        if contours:
            contour = max(contours, key=cv2.contourArea)
            perimeter = cv2.arcLength(contour, True)
            polygon = cv2.approxPolyDP(contour, 0.035 * perimeter, True)
            if len(polygon) == 4:
                quad = self._order_quad(polygon.reshape(4, 2))
            else:
                quad = self._order_quad(cv2.boxPoints(cv2.minAreaRect(contour)))
            corners = tuple((float(point[0]), float(point[1])) for point in quad)
        return ColourBlob(
            colour=colour,
            center_x=float(center[0]),
            center_y=float(center[1]),
            area_px=area,
            corners=corners,
        )

    def _solve_pose(
        self,
        object_points: np.ndarray,
        image_points: np.ndarray,
    ) -> tuple[np.ndarray, np.ndarray, float] | None:
        use_guess = self._previous_rvec is not None and self._previous_tvec is not None
        try:
            success, rvec, tvec = cv2.solvePnP(
                object_points,
                image_points,
                self.camera_matrix,
                self.distortion,
                rvec=None if not use_guess else self._previous_rvec.copy(),
                tvec=None if not use_guess else self._previous_tvec.copy(),
                useExtrinsicGuess=use_guess,
                flags=cv2.SOLVEPNP_ITERATIVE,
            )
        except cv2.error:
            return None
        if not success:
            return None
        projected, _ = cv2.projectPoints(
            object_points,
            rvec,
            tvec,
            self.camera_matrix,
            self.distortion,
        )
        residual = projected.reshape(-1, 2) - image_points
        error = float(np.sqrt(np.mean(np.sum(residual * residual, axis=1))))
        return rvec, tvec, error

    def _target_pose(
        self,
        rvec: np.ndarray,
        tvec: np.ndarray,
    ) -> tuple[Pose3D, float, bool]:
        rotation_cv_from_marker, _ = cv2.Rodrigues(rvec)
        marker_position_cv = tvec.reshape(3)
        marker_distance = float(np.linalg.norm(marker_position_cv))
        marker_position_base = (
            self.camera_position
            + self.rotation_base_from_cv @ marker_position_cv
        )
        rotation_base_from_marker = (
            self.rotation_base_from_cv @ rotation_cv_from_marker
        )
        target_position = (
            marker_position_base
            + rotation_base_from_marker @ self.geometry.marker_to_target
        )
        marker_up = rotation_base_from_marker[:, 1]
        marker_outward = rotation_base_from_marker[:, 2]
        target_forward = -marker_outward
        target_yaw = math.atan2(float(target_forward[1]), float(target_forward[0]))
        upright = float(marker_up[2]) >= self.parameters.minimum_upright_cosine
        front_facing = float(rotation_cv_from_marker[2, 2]) < -0.15
        target_height_ok = (
            abs(
                float(target_position[2])
                - self.parameters.expected_target_height_in_base_m
            )
            <= self.parameters.maximum_target_height_error_m
        )
        valid_geometry = upright and front_facing and target_height_ok
        return (
            Pose3D(
                x=float(target_position[0]),
                y=float(target_position[1]),
                z=float(target_position[2]),
                roll=0.0,
                pitch=0.0,
                yaw=wrap_angle(target_yaw),
            ),
            marker_distance,
            valid_geometry,
        )

    def detect(self, rgb: np.ndarray) -> MarkerDetection:
        if rgb.ndim != 3 or rgb.shape[2] != 3:
            raise ValueError("rgb image must have shape (height, width, 3)")
        if rgb.shape[1] != self.parameters.image_width or rgb.shape[0] != self.parameters.image_height:
            raise ValueError(
                "rgb image dimensions do not match detector configuration: "
                f"{rgb.shape[1]}x{rgb.shape[0]}"
            )
        hsv = cv2.cvtColor(np.asarray(rgb, dtype=np.uint8), cv2.COLOR_RGB2HSV)
        blobs: list[ColourBlob] = []
        for colour in self.COLOUR_ORDER:
            blob = self._blob(self._mask(hsv, self.colour_ranges[colour]), colour)
            if blob is None:
                return MarkerDetection(
                    success=False,
                    status=f"missing_{colour}",
                    target_pose_in_base=None,
                    confidence=0.0,
                    reprojection_error_px=None,
                    marker_distance_m=None,
                    blobs=tuple(blobs),
                )
            blobs.append(blob)

        if all(len(blob.corners) == 4 for blob in blobs):
            object_rows: list[tuple[float, float, float]] = []
            image_rows: list[tuple[float, float]] = []
            patch = self.geometry.patch_half_size_m
            patch_offsets = (
                (-patch, +patch, 0.0),
                (+patch, +patch, 0.0),
                (+patch, -patch, 0.0),
                (-patch, -patch, 0.0),
            )
            for center, blob in zip(self.geometry.object_points, blobs):
                for offset, pixel in zip(patch_offsets, blob.corners):
                    object_rows.append(
                        (
                            float(center[0]) + offset[0],
                            float(center[1]) + offset[1],
                            0.0,
                        )
                    )
                    image_rows.append(pixel)
            object_points = np.asarray(object_rows, dtype=np.float64)
            image_points = np.asarray(image_rows, dtype=np.float64)
        else:
            object_points = self.geometry.object_points
            image_points = np.asarray(
                [(blob.center_x, blob.center_y) for blob in blobs],
                dtype=np.float64,
            )
        solved = self._solve_pose(object_points, image_points)
        if solved is None:
            return MarkerDetection(
                success=False,
                status="pnp_failed",
                target_pose_in_base=None,
                confidence=0.0,
                reprojection_error_px=None,
                marker_distance_m=None,
                blobs=tuple(blobs),
            )
        rvec, tvec, reprojection_error = solved
        target_pose, marker_distance, valid_geometry = self._target_pose(rvec, tvec)

        # R4-E7: solve a second pose from colour-patch CENTRES only. Patch
        # contours can be clipped/warped by blur, morphology and partial
        # occlusion, which biases the 16-corner board orientation while all
        # four labelled centres remain geometrically well conditioned. This is
        # passive here: primary acceptance still uses the legacy solution.
        center_target_pose = None
        center_reprojection_error = None
        center_corner_position_disagreement = None
        center_corner_yaw_disagreement_deg = None
        center_points = np.asarray(
            [(blob.center_x, blob.center_y) for blob in blobs], dtype=np.float64
        )
        center_solved = self._solve_pose(self.geometry.object_points, center_points)
        if center_solved is not None:
            center_rvec, center_tvec, center_reprojection_error = center_solved
            center_pose, _center_distance, center_valid_geometry = self._target_pose(
                center_rvec, center_tvec
            )
            if center_valid_geometry:
                center_target_pose = center_pose
                center_corner_position_disagreement = math.hypot(
                    float(center_pose.x) - float(target_pose.x),
                    float(center_pose.y) - float(target_pose.y),
                )
                center_corner_yaw_disagreement_deg = math.degrees(abs(wrap_angle(
                    float(center_pose.yaw) - float(target_pose.yaw)
                )))

        area_score = min(
            1.0,
            min(blob.area_px for blob in blobs)
            / float(max(1, 3 * self.parameters.minimum_blob_area_px)),
        )
        reprojection_score = max(
            0.0,
            1.0
            - reprojection_error
            / self.parameters.maximum_reprojection_error_px,
        )
        confidence = float(0.45 * area_score + 0.55 * reprojection_score)

        distance_ok = (
            self.parameters.minimum_distance_m
            <= marker_distance
            <= self.parameters.maximum_distance_m
        )
        accepted = (
            valid_geometry
            and distance_ok
            and reprojection_error <= self.parameters.maximum_reprojection_error_px
            and confidence >= self.parameters.minimum_confidence
        )
        if accepted:
            self._previous_rvec = rvec.copy()
            self._previous_tvec = tvec.copy()
            status = "accepted"
        elif not valid_geometry:
            status = "geometry_rejected"
        elif not distance_ok:
            status = "distance_rejected"
        elif reprojection_error > self.parameters.maximum_reprojection_error_px:
            status = "reprojection_rejected"
        else:
            status = "confidence_rejected"

        return MarkerDetection(
            success=accepted,
            status=status,
            target_pose_in_base=target_pose if accepted else None,
            confidence=confidence,
            reprojection_error_px=reprojection_error,
            marker_distance_m=marker_distance,
            blobs=tuple(blobs),
            center_target_pose_in_base=center_target_pose,
            center_reprojection_error_px=(
                None if center_reprojection_error is None
                else float(center_reprojection_error)
            ),
            center_corner_position_disagreement_m=(
                None if center_corner_position_disagreement is None
                else float(center_corner_position_disagreement)
            ),
            center_corner_yaw_disagreement_deg=(
                None if center_corner_yaw_disagreement_deg is None
                else float(center_corner_yaw_disagreement_deg)
            ),
        )

    def annotate(self, rgb: np.ndarray, detection: MarkerDetection) -> np.ndarray:
        """Return an RGB diagnostic image with blob centres and status text."""
        bgr = cv2.cvtColor(np.asarray(rgb, dtype=np.uint8), cv2.COLOR_RGB2BGR)
        draw_colours = {
            "red": (0, 0, 255),
            "green": (0, 255, 0),
            "blue": (255, 0, 0),
            "yellow": (0, 255, 255),
        }
        for blob in detection.blobs:
            point = (int(round(blob.center_x)), int(round(blob.center_y)))
            cv2.circle(bgr, point, 7, draw_colours[blob.colour], 2)
            if blob.corners:
                polygon = np.asarray(blob.corners, dtype=np.int32).reshape(-1, 1, 2)
                cv2.polylines(bgr, [polygon], True, draw_colours[blob.colour], 1)
            cv2.putText(
                bgr,
                blob.colour[0].upper(),
                (point[0] + 7, point[1] - 7),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.45,
                draw_colours[blob.colour],
                1,
                cv2.LINE_AA,
            )
        cv2.putText(
            bgr,
            f"marker: {detection.status} conf={detection.confidence:.2f}",
            (10, 24),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.58,
            (255, 255, 255),
            2,
            cv2.LINE_AA,
        )
        return cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
