"""JSONL and optional RGB frame recorder for simulation episodes."""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Mapping, TextIO

import cv2
import numpy as np

from interfaces.observation import ForkliftObservation


class EpisodeRecorder:
    """Write synchronized observations, actions, and optional images."""

    def __init__(
        self,
        output_root: Path,
        *,
        enabled: bool,
        save_images: bool,
    ) -> None:
        self.enabled = enabled
        self.save_images = enabled and save_images
        self.frame_index = 0
        self.run_dir: Path | None = None
        self._stream: TextIO | None = None

        if not enabled:
            return

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.run_dir = output_root / f"episode_{timestamp}"
        self.run_dir.mkdir(parents=True, exist_ok=False)
        self._stream = (self.run_dir / "observations.jsonl").open(
            "w", encoding="utf-8"
        )
        if self.save_images:
            (self.run_dir / "front_rgb").mkdir()
            (self.run_dir / "fork_rgb").mkdir()

    def write(
        self,
        observation: ForkliftObservation,
        *,
        front_rgb: np.ndarray | None,
        fork_rgb: np.ndarray | None,
        extra: Mapping[str, Any] | None = None,
    ) -> None:
        if not self.enabled or self._stream is None:
            return

        record = observation.to_dict()
        record["frame_index"] = self.frame_index
        if extra:
            record.update(dict(extra))

        if self.save_images and front_rgb is not None and fork_rgb is not None:
            assert self.run_dir is not None
            filename = f"{self.frame_index:06d}.jpg"
            front_path = self.run_dir / "front_rgb" / filename
            fork_path = self.run_dir / "fork_rgb" / filename
            cv2.imwrite(str(front_path), cv2.cvtColor(front_rgb, cv2.COLOR_RGB2BGR))
            cv2.imwrite(str(fork_path), cv2.cvtColor(fork_rgb, cv2.COLOR_RGB2BGR))
            record["front_rgb"] = str(front_path.relative_to(self.run_dir))
            record["fork_rgb"] = str(fork_path.relative_to(self.run_dir))

        self._stream.write(json.dumps(record, ensure_ascii=False) + "\n")
        self._stream.flush()
        self.frame_index += 1

    def close(self) -> None:
        if self._stream is not None:
            self._stream.close()
            self._stream = None

    def __enter__(self) -> "EpisodeRecorder":
        return self

    def __exit__(self, exc_type: object, exc: object, traceback: object) -> None:
        self.close()
