"""Tests for the V5.2 object-axis docking controller."""

from __future__ import annotations

import math

from control.docking_controller import (
    DockingController,
    object_axis_error,
)
from interfaces.observation import Pose3D


def pose(x: float, y: float, yaw: float) -> Pose3D:
    return Pose3D(x=x, y=y, z=0.0, roll=0.0, pitch=0.0, yaw=yaw)


def controller() -> DockingController:
    return DockingController(
        distance_gain=0.68,
        heading_gain=1.00,
        yaw_gain=1.40,
        lateral_gain=0.80,
        lookahead_distance=0.60,
        maximum_steering=0.28,
        minimum_creep_speed=0.03,
        heading_slowdown_angle=0.70,
        yaw_slowdown_angle=0.55,
        minimum_alignment_scale=0.25,
    )


def test_axis_error_uses_object_centreline_not_a_point() -> None:
    error = object_axis_error(
        pose(4.0, 0.0, math.radians(3.0)),
        target_distance=3.2,
    )
    assert math.isclose(error.longitudinal, 0.8)
    # A left-rotated pallet axis crosses to the vehicle-right at x=0.
    assert error.lateral < 0.0
    assert math.isclose(error.yaw, math.radians(3.0))


def test_axis_command_steers_toward_left_and_right_centrelines() -> None:
    left = controller().axis_command(
        pose(4.0, 0.18, 0.0),
        target_distance=3.2,
        maximum_speed=0.25,
        lift_target=0.04,
    )
    right = controller().axis_command(
        pose(4.0, -0.18, 0.0),
        target_distance=3.2,
        maximum_speed=0.25,
        lift_target=0.04,
    )
    assert left.action.steering_command > 0.0
    assert right.action.steering_command < 0.0
    assert left.action.speed_target > 0.0
    assert right.action.speed_target > 0.0


def test_axis_command_stops_on_longitudinal_gate_even_with_lateral_error() -> None:
    command = controller().axis_command(
        pose(2.69, 0.08, 0.0),
        target_distance=2.70,
        maximum_speed=0.09,
        lift_target=0.04,
    )
    assert command.action.speed_target == 0.0
    assert command.error.lateral != 0.0


def test_axis_command_reduces_speed_when_steering_is_large() -> None:
    straight = controller().axis_command(
        pose(4.0, 0.0, 0.0),
        target_distance=3.2,
        maximum_speed=0.26,
        lift_target=0.04,
    )
    offset = controller().axis_command(
        pose(4.0, 0.30, math.radians(4.0)),
        target_distance=3.2,
        maximum_speed=0.26,
        lift_target=0.04,
    )
    assert offset.action.speed_target < straight.action.speed_target
