"""Batch evaluation for V9.3.11 dual-colour pocket pickup and placement missions."""

from __future__ import annotations

import argparse
from datetime import datetime
from pathlib import Path
import sys
from typing import Any

import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from evaluation.dual_vision_metrics import write_dual_vision_results
from scenarios.randomization import ScenarioSampler
from simulator.dual_vision_mission_episode import run_vision_mission_episode


DEFAULT_CONFIG = PROJECT_ROOT / "configs" / "vehicle_v9_3_11.yaml"


def load_config(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise FileNotFoundError(f"configuration file does not exist: {path}")
    with path.open("r", encoding="utf-8") as stream:
        config = yaml.safe_load(stream)
    if not isinstance(config, dict):
        raise ValueError("configuration root must be a mapping")
    if "perception" not in config:
        raise KeyError("perception")
    return config


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--episodes", type=int, default=20)
    parser.add_argument("--seed", type=int)
    parser.add_argument("--difficulty", choices=ScenarioSampler.difficulties())
    parser.add_argument("--profile", choices=("clean", "moderate", "finals", "weak_guide"))
    parser.add_argument(
        "--appearance-profile",
        choices=("clean", "moderate", "finals", "combined"),
    )
    parser.add_argument("--output", type=Path)
    parser.add_argument("--max-time", type=float)
    parser.add_argument("--trace-failures", action="store_true")
    parser.add_argument("--trace-all", action="store_true")
    parser.add_argument(
        "--oracle-terminal-geometry",
        action="store_true",
        help="Diagnostic only: feed truth pallet/placement geometry to terminal control.",
    )
    parser.add_argument("--require-success-rate", type=float, default=0.0)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    config = load_config(args.config.resolve())
    seed = int(
        args.seed
        if args.seed is not None
        else config["randomization"]["default_seed"]
    )
    difficulty = str(
        args.difficulty
        if args.difficulty is not None
        else config["randomization"]["default_difficulty"]
    )
    profile = str(
        args.profile
        if args.profile is not None
        else config["perception"]["default_profile"]
    )
    appearance_profile = str(
        args.appearance_profile
        if args.appearance_profile is not None
        else config["appearance_stress"]["default_profile"]
    )
    sampler = ScenarioSampler(seed=seed, difficulty=difficulty)
    scenarios = [sampler.sample() for _ in range(args.episodes)]
    output = (
        args.output.resolve()
        if args.output
        else (
            PROJECT_ROOT
            / config["batch"]["output_root"]
            / (
                f"batch_{datetime.now().strftime('%Y%m%d_%H%M%S')}_"
                f"{profile}_{appearance_profile}"
            )
        ).resolve()
    )
    output.mkdir(parents=True, exist_ok=True)
    results = []
    print(
        f"Running {len(scenarios)} V9.3.11 dual-vision missions | seed={seed} | "
        f"difficulty={difficulty} | profile={profile} | "
        f"appearance={appearance_profile} | "
        f"oracle_terminal={args.oracle_terminal_geometry} | output={output}"
    )
    for index, scenario in enumerate(scenarios, 1):
        trace = (
            output / "traces" / f"{scenario.scenario_id}.jsonl"
            if args.trace_all
            else None
        )
        result = run_vision_mission_episode(
            config,
            scenario,
            profile_name=profile,
            appearance_profile_name=appearance_profile,
            max_episode_seconds=args.max_time,
            trace_path=trace,
            terminal_oracle_geometry=args.oracle_terminal_geometry,
        )
        results.append(result)
        verdict = "PASS" if result.success else "FAIL"
        reason = "" if result.success else f" | {result.failure_reason}"
        print(
            f"[{index:02d}/{len(scenarios):02d}] {verdict} "
            f"{scenario.scenario_id:<16} t={result.duration_seconds:5.1f}s "
            f"place={result.final_placement_error_m:.3f}m "
            f"vision={result.vision_detection_rate:.0%} "
            f"vision_rmse="
            f"{result.vision_position_rmse_m if result.vision_position_rmse_m is not None else float('nan'):.3f}m "
            f"pose_rmse={result.pallet_position_rmse_m:.3f}/"
            f"{result.placement_position_rmse_m:.3f}m{reason}"
        )
        if args.trace_failures and not result.success and trace is None:
            run_vision_mission_episode(
                config,
                scenario,
                profile_name=profile,
                appearance_profile_name=appearance_profile,
                max_episode_seconds=args.max_time,
                trace_path=output
                / "failure_traces"
                / f"{scenario.scenario_id}.jsonl",
                terminal_oracle_geometry=args.oracle_terminal_geometry,
            )

    summary = write_dual_vision_results(output, results)
    print("\nV9.3.11 appearance-stress mission summary")
    print(f"  success: {summary['success_count']}/{summary['episode_count']}")
    print(f"  success_rate: {summary['success_rate']:.1%}")
    print(
        "  avg_success_placement_error: "
        f"{summary['average_success_placement_error_m']}"
    )
    print(
        "  estimate_rmse pallet/placement: "
        f"{summary['average_pallet_position_rmse_m']:.3f}/"
        f"{summary['average_placement_position_rmse_m']:.3f}m"
    )
    print(
        "  pallet-pocket overall/opportunity/use: "
        f"{summary['average_pickup_vision_detection_rate']:.1%}/"
        f"{summary['average_pickup_vision_opportunity_detection_rate']:.1%}/"
        f"{summary['pickup_vision_use_rate']:.1%}"
    )
    print(
        "  pallet-pocket raw/fused RMSE: "
        f"{summary['average_pickup_vision_position_rmse_m']}/"
        f"{summary['average_pickup_vision_fused_position_rmse_m']}m"
    )
    print(
        "  pallet-pocket APPROACH/ALIGN/INSERT: "
        f"{summary['average_pickup_vision_detection_rate_approach']:.1%}/"
        f"{summary['average_pickup_vision_detection_rate_align']:.1%}/"
        f"{summary['average_pickup_vision_detection_rate_insert']:.1%}"
    )
    print(
        "  pickup acquisition/preinsert ready/first preinsert: "
        f"{summary['pickup_vision_acquisition_rate']:.1%}/"
        f"{summary['pickup_vision_preinsert_ready_rate']:.1%}/"
        f"{summary['pickup_vision_first_detection_preinsert_rate']:.1%}"
    )
    print(
        "  pickup measurement raw/rejected/control exceedances: "
        f"{summary['total_pickup_vision_raw_outlier_count']}/"
        f"{summary['total_pickup_vision_innovation_rejected_count']}/"
        f"{summary['total_pickup_vision_control_accepted_outlier_count']}"
    )
    print(
        "  pickup guide/innovation rejections: "
        f"{summary['total_pickup_vision_measurement_guide_rejected_count']}/"
        f"{summary['total_pickup_vision_innovation_rejected_count']}"
    )
    print(
        "  pickup accepted measurements/severe outliers: "
        f"{summary['total_pickup_vision_control_accepted_measurement_count']}/"
        f"{summary['total_pickup_vision_control_accepted_severe_outlier_count']}"
    )
    print(
        "  detector-only position/yaw RMSE: "
        f"{summary['average_pickup_detector_raw_position_rmse_m']}/"
        f"{summary['average_pickup_detector_raw_yaw_rmse_deg']}"
    )
    print(
        "  pickup raw/fused yaw RMSE and P95: "
        f"{summary['average_pickup_vision_yaw_rmse_deg']}/"
        f"{summary['average_pickup_vision_fused_yaw_rmse_deg']} deg | "
        f"{summary['average_pickup_vision_raw_yaw_p95_deg']}/"
        f"{summary['average_pickup_vision_fused_yaw_p95_deg']} deg"
    )
    print(
        "  RGB marker detection/rmse/use: "
        f"{summary['average_vision_detection_rate']:.1%}/"
        f"{summary['average_vision_position_rmse_m']}/"
        f"{summary['vision_terminal_use_rate']:.1%}"
    )
    print(
        "  render retries/failures/context warnings: "
        f"{summary['render_retry_count']}/"
        f"{summary['render_failure_count']}/"
        f"{summary['render_context_warning_count']}"
    )
    print(
        "  appearance frames/dropout/blur/occlusion: "
        f"{summary['appearance_frame_count']}/"
        f"{summary['appearance_dropout_count']}/"
        f"{summary['appearance_blur_count']}/"
        f"{summary['appearance_occlusion_count']}"
    )
    print(
        "  pickup arbitration high/medium/reject: "
        f"{summary['pickup_vision_high_confidence_count']}/"
        f"{summary['pickup_vision_medium_confidence_count']}/"
        f"{summary['pickup_vision_confidence_rejection_count']}"
    )
    print(
        "  placement arbitration high/medium/reject/guide: "
        f"{summary['vision_high_confidence_count']}/"
        f"{summary['vision_medium_confidence_count']}/"
        f"{summary['vision_confidence_rejection_count']}/"
        f"{summary['vision_guide_rejection_count']}"
    )
    print(
        "  terminal recovery/guard-brakes/settle-frames/exits: "
        f"{summary['total_placement_recovery_count']}/"
        f"{summary['total_placement_guard_brake_count']}/"
        f"{summary['total_placement_precision_settle_frame_count']}/"
        f"{summary['total_placement_precision_settle_exit_count']}"
    )
    print(
        "  competition precision forward/reverse/hold/reentry frames: "
        f"{summary['total_placement_precision_forward_frame_count']}/"
        f"{summary['total_placement_precision_reverse_frame_count']}/"
        f"{summary['total_placement_precision_hold_frame_count']}/"
        f"{summary['total_placement_precision_reentry_count']}"
    )
    print(
        "  precision recenter-cycles/recenter-frames/direction-switches: "
        f"{summary['total_placement_precision_recenter_cycle_count']}/"
        f"{summary['total_placement_precision_recenter_frame_count']}/"
        f"{summary['total_placement_precision_direction_switch_count']}"
    )
    print(
        "  terminal MPC solves/fallback-frames/infeasible-solves/regression-rejects: "
        f"{summary['total_placement_mpc_solve_count']}/"
        f"{summary['total_placement_mpc_fallback_count']}/"
        f"{summary['total_placement_mpc_infeasible_solve_count']}/"
        f"{summary['total_placement_mpc_regression_reject_solve_count']}"
    )
    print(
        "  release candidate/commit/abort/prebrake/prebrake-abort: "
        f"{summary['total_placement_release_candidate_count']}/"
        f"{summary['total_placement_release_commit_count']}/"
        f"{summary['total_placement_release_commit_abort_count']}/"
        f"{summary['total_placement_release_prebrake_count']}/"
        f"{summary['total_placement_release_prebrake_abort_count']}"
    )
    print(
        "  release blockers position/yaw/speed/vision/observer frames: "
        f"{summary['total_placement_release_block_position_frames']}/"
        f"{summary['total_placement_release_block_yaw_frames']}/"
        f"{summary['total_placement_release_block_speed_frames']}/"
        f"{summary['total_placement_release_block_vision_frames']}/"
        f"{summary['total_placement_release_block_observer_frames']}"
    )
    print(
        "  carried-load observer active/samples/spread/update/reject/disagreement: "
        f"{100.0 * summary['placement_carried_observer_active_rate']:.1f}%/"
        f"{summary['average_placement_carried_observer_sample_count']:.1f}/"
        f"{summary['average_placement_carried_observer_position_std_m']:.3f}m/"
        f"{summary['average_placement_carried_observer_yaw_std_deg']:.2f}deg/"
        f"{summary['average_placement_carried_observer_update_count']:.1f}/"
        f"{summary['total_placement_carried_observer_rejection_count']}/"
        f"{summary['average_placement_carried_observer_disagreement_position_m']:.3f}m/"
        f"{summary['average_placement_carried_observer_disagreement_yaw_deg']:.2f}deg"
    )
    print(
        "  MPC model-id samples/RMSE long-lat-yaw: "
        f"{summary['total_placement_mpc_model_id_sample_count']}/"
        f"{summary['average_placement_mpc_model_id_longitudinal_rmse_m']:.4f}/"
        f"{summary['average_placement_mpc_model_id_lateral_rmse_m']:.4f}m/"
        f"{summary['average_placement_mpc_model_id_yaw_rmse_deg']:.3f}deg"
    )
    print(
        "  axis-corridor entry-replans/axis-frames/axis-resets: "
        f"{summary['total_terminal_corridor_entry_replan_count']}/"
        f"{summary['total_terminal_corridor_axis_frame_count']}/"
        f"{summary['total_terminal_corridor_axis_reset_count']}"
    )
    print(
        "  rolling-corridor frames/handoffs/timeout-handoffs/reacquire/coarse/stale: "
        f"{summary['total_terminal_corridor_rolling_frame_count']}/"
        f"{summary['total_terminal_corridor_handoff_count']}/"
        f"{summary['total_terminal_corridor_timeout_handoff_count']}/"
        f"{summary['total_terminal_corridor_reacquire_count']}/"
        f"{summary['total_terminal_corridor_visual_coarse_frame_count']}/"
        f"{summary['total_terminal_corridor_visual_stale_frame_count']}"
    )
    print(
        "  rolling handoff mean distance/|lat|/|yaw|: "
        f"{summary['average_terminal_corridor_handoff_distance_m']}/"
        f"{summary['average_terminal_corridor_handoff_abs_lateral_m']}m/"
        f"{summary['average_terminal_corridor_handoff_abs_yaw_deg']}deg"
    )
    print(
        "  weak-guide visual takeover placement/pickup: "
        f"{summary['total_vision_visual_takeover_count']}/"
        f"{summary['total_pickup_vision_visual_takeover_count']}"
    )
    print(
        "  visual authority lock/unlock placement/pickup: "
        f"{summary['total_vision_authority_lock_count']}/"
        f"{summary['total_vision_authority_unlock_count']} | "
        f"{summary['total_pickup_vision_authority_lock_count']}/"
        f"{summary['total_pickup_vision_authority_unlock_count']}"
    )
    print(
        "  carried-load visual authority active/locks/rgb-updates/guide-rejects/rigid-predict/handoff-seeds: "
        f"{summary['carried_load_visual_authority_active_rate']:.1%}/"
        f"{summary['total_carried_load_visual_lock_count']}/"
        f"{summary['total_carried_load_visual_rgb_update_count']}/"
        f"{summary['total_carried_load_visual_guide_reject_count']}/"
        f"{summary['total_carried_load_visual_rigid_prediction_count']}/"
        f"{summary['total_carried_load_visual_handoff_seed_count']}"
    )
    print(
        "  strict release certification pass/reject | timeout-handoff guard rejects: "
        f"{summary['total_strict_release_certification_pass_count']}/"
        f"{summary['total_strict_release_certification_reject_count']} | "
        f"{summary['total_terminal_corridor_timeout_handoff_guard_reject_count']}"
    )
    print(
        "  release supervisor settle/intent/intent-abort/settle-timeout/mpc-resume: "
        f"{summary['total_release_supervisor_settle_count']}/"
        f"{summary['total_release_supervisor_intent_count']}/"
        f"{summary['total_release_supervisor_intent_abort_count']}/"
        f"{summary['total_release_supervisor_settle_timeout_count']}/"
        f"{summary['total_release_supervisor_mpc_resume_count']}"
    )
    print(
        "  release supervisor hold/certified-hold/first-cert->release: "
        f"{summary['total_release_supervisor_hold_seconds']:.2f}s/"
        f"{summary['total_release_supervisor_certified_hold_seconds']:.2f}s/"
        f"{summary['average_release_supervisor_certification_to_release_seconds']}s"
    )
    print(
        "  carried-load fallback handoff seeds: "
        f"{summary['total_carried_load_visual_handoff_fallback_seed_count']}"
    )
    print(
        "  terminal ownership MPC-rate/direct/forced/align-timeout/reacquire: "
        f"{summary['terminal_mpc_ownership_rate']:.1%}/"
        f"{summary['total_terminal_ownership_direct_mpc_count']}/"
        f"{summary['total_terminal_ownership_forced_mpc_count']}/"
        f"{summary['total_terminal_ownership_align_timeout_count']}/"
        f"{summary['total_terminal_ownership_reacquire_count']}"
    )
    print(
        "  terminal ownership ALIGN avg/max: "
        f"{summary['average_terminal_ownership_align_seconds']:.2f}s/"
        f"{summary['maximum_terminal_ownership_align_seconds']:.2f}s"
    )
    print(
        "  carried-load belief sigma pos/yaw | since-visual distance/turn | scaled-frames: "
        f"{summary['average_carried_load_belief_position_sigma_m']:.4f}m/"
        f"{summary['average_carried_load_belief_yaw_sigma_deg']:.2f}deg | "
        f"{summary['average_carried_load_belief_distance_since_visual_m']:.2f}m/"
        f"{summary['average_carried_load_belief_turn_since_visual_deg']:.1f}deg | "
        f"{summary['total_carried_load_belief_transport_scaled_frames']}"
    )
    print(
        "  certified target raw-spread pos/yaw | target margin pos/yaw | yaw-escrow activations: "
        f"{summary['average_controller_release_target_raw_position_spread_m']}/"
        f"{summary['average_controller_release_target_raw_yaw_spread_deg']}deg | "
        f"{summary['average_controller_release_target_position_margin_m']}/"
        f"{summary['average_controller_release_target_yaw_margin_deg']}deg | "
        f"{summary['total_placement_mpc_yaw_escrow_activation_count']}"
    )
    print(
        "  target multiview ready/samples/spread-pos-yaw/fast-slow-pos-yaw: "
        f"{summary['placement_target_multiview_ready_rate']:.1%}/"
        f"{summary['average_placement_target_multiview_samples']:.1f}/"
        f"{summary['average_placement_target_multiview_position_spread_m']}/"
        f"{summary['average_placement_target_multiview_yaw_spread_deg']}deg/"
        f"{summary['average_placement_target_fast_slow_position_disagreement_m']}/"
        f"{summary['average_placement_target_fast_slow_yaw_disagreement_deg']}deg"
    )
    print(
        "  certified basin enter/strict/consensus/exit/persisted/max-active: "
        f"{summary['total_certified_basin_enter_count']}/"
        f"{summary['total_certified_basin_strict_enter_count']}/"
        f"{summary['total_certified_basin_consensus_enter_count']}/"
        f"{summary['total_certified_basin_exit_count']}/"
        f"{summary['total_certified_basin_persisted_pass_count']}/"
        f"{summary['maximum_certified_basin_active_seconds']:.3f}s"
    )
    print(
        "  certified basin consensus truth-FP: "
        f"{summary['certified_basin_consensus_false_positive_count']}"
    )
    print(
        "  certification blocker counts: "
        f"{summary['strict_release_certification_blocker_counts']}"
    )
    print(
        "  near-basin escrow activations/accepted/last-deficit-improvement: "
        f"{summary['total_placement_mpc_near_basin_escrow_activation_count']}/"
        f"{summary['total_placement_mpc_near_basin_escrow_accepted_plan_count']}/"
        f"{summary['average_placement_mpc_near_basin_last_deficit_improvement']:.3f}"
    )
    print(
        "  release witness captures/drift-aborts/truth-FP/execution-FP/witness->execute: "
        f"{summary['total_release_witness_capture_count']}/"
        f"{summary['total_release_witness_drift_abort_count']}/"
        f"{summary['release_witness_false_positive_count']}/"
        f"{summary['release_execution_false_positive_count']}/"
        f"{summary['average_release_witness_to_execute_seconds']}s"
    )
    print(
        "  episode timeout/long/terminal-budget: "
        f"{summary['episode_timeout_count']}/"
        f"{summary['long_episode_count']}/"
        f"{summary['terminal_budget_exhausted_count']} "
        f"| duration p50/p95/max="
        f"{summary['duration_p50_seconds']:.1f}/"
        f"{summary['duration_p95_seconds']:.1f}/"
        f"{summary['maximum_duration_seconds']:.1f}s"
    )
    release_diag = summary["precision_diagnostics"]["stages"]["release_command"]
    ground_diag = summary["precision_diagnostics"]["stages"]["grounded"]
    final_diag = summary["precision_diagnostics"]["stages"]["final"]
    print(
        "  precision truth mean @ release/ground/final: "
        f"{release_diag['truth_position_mean_m']}/"
        f"{ground_diag['truth_position_mean_m']}/"
        f"{final_diag['truth_position_mean_m']}m"
    )
    drift = summary["precision_diagnostics"]["derived"]
    print(
        "  physical pallet drift lowering/withdrawal mean: "
        f"{drift['lowering_pallet_translation_m']['mean']}/"
        f"{drift['withdrawal_pallet_translation_m']['mean']}m"
    )
    print(
        "  controller-certified release truth-FP/truth-ready-uncertified: "
        f"{drift['controller_certified_release_false_positive_count']}/"
        f"{drift['controller_truth_ready_uncertified_count']}"
    )
    print(
        "  legacy raw-estimate release false-positive/false-negative: "
        f"{drift['release_false_positive_count']}/"
        f"{drift['release_false_negative_count']}"
    )
    print(
        "  competition precision <0.10m/<5deg: "
        f"{summary['competition_precision_success_count']}/"
        f"{summary['episode_count']} = "
        f"{summary['competition_precision_success_rate']:.1%} "
        f"(position={summary['competition_position_pass_rate']:.1%}, "
        f"yaw={summary['competition_yaw_pass_rate']:.1%})"
    )
    print(f"  results: {output}")
    return 2 if summary["success_rate"] < args.require_success_rate else 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (FileNotFoundError, KeyError, RuntimeError, ValueError, yaml.YAMLError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
