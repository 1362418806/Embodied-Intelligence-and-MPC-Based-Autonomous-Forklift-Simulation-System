"""Structural checks for the v5 randomized-pose model."""

from __future__ import annotations

from pathlib import Path

import mujoco


PROJECT_ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = PROJECT_ROOT / "assets" / "forklift" / "forklift_v5.xml"


def named_id(model: mujoco.MjModel, object_type: mujoco.mjtObj, name: str) -> int:
    object_id = mujoco.mj_name2id(model, object_type, name)
    assert object_id >= 0, f"missing MuJoCo object: {name}"
    return int(object_id)


def test_v5_model_compiles() -> None:
    model = mujoco.MjModel.from_xml_path(str(MODEL_PATH))
    assert model.nbody > 0
    assert model.ngeom > 0


def test_v5_keeps_required_free_joints_cameras_and_actuators() -> None:
    model = mujoco.MjModel.from_xml_path(str(MODEL_PATH))
    for name in ("forklift_free", "pallet_load_free", "lift_joint"):
        named_id(model, mujoco.mjtObj.mjOBJ_JOINT, name)
    for name in ("front_rgb", "fork_rgb"):
        named_id(model, mujoco.mjtObj.mjOBJ_CAMERA, name)
    for name in (
        "front_left_drive_velocity",
        "front_right_drive_velocity",
        "rear_left_steer_position",
        "rear_right_steer_position",
        "lift_position",
    ):
        named_id(model, mujoco.mjtObj.mjOBJ_ACTUATOR, name)
