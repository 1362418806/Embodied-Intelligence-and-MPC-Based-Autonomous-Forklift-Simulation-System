"""V9.3.12-R3 contact-conditioned rigid carried-load constraint.

This module never changes the carried-load mean.  It only reports when runtime
contact/lift observations support using a calibrated upper bound on relative
load uncertainty during terminal release certification.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class RigidLoadConstraintConfig:
    minimum_fork_contacts: int
    maximum_abs_lift_velocity: float
    minimum_stable_seconds: float

    def validate(self) -> None:
        if self.minimum_fork_contacts <= 0:
            raise ValueError("rigid-load constraint requires positive fork contacts")
        if self.maximum_abs_lift_velocity < 0.0:
            raise ValueError("maximum lift velocity must be non-negative")
        if self.minimum_stable_seconds <= 0.0:
            raise ValueError("minimum stable seconds must be positive")


class RigidLoadConstraintMonitor:
    """Latch only while a lifted load remains stably supported by the forks."""

    def __init__(self, config: RigidLoadConstraintConfig) -> None:
        config.validate()
        self.config = config
        self.reset()

    def reset(self) -> None:
        self.stable_since: float | None = None
        self.active = False
        self.activation_count = 0
        self.total_active_seconds = 0.0
        self._last_time: float | None = None

    def update(
        self,
        *,
        now: float,
        load_state: str,
        fork_contact_count: int,
        lift_velocity: float,
    ) -> bool:
        now = float(now)
        if self._last_time is not None and self.active:
            self.total_active_seconds += max(0.0, now - self._last_time)
        self._last_time = now

        supported = bool(
            str(load_state).startswith("LIFTED")
            and int(fork_contact_count) >= self.config.minimum_fork_contacts
            and abs(float(lift_velocity)) <= self.config.maximum_abs_lift_velocity
        )
        if not supported:
            self.stable_since = None
            self.active = False
            return False
        if self.stable_since is None:
            self.stable_since = now
            self.active = False
            return False
        ready = now - self.stable_since >= self.config.minimum_stable_seconds
        if ready and not self.active:
            self.activation_count += 1
        self.active = bool(ready)
        return self.active
