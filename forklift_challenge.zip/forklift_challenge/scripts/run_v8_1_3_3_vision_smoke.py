"""Render the fork camera and verify V8.1 pallet-pocket detection."""
from __future__ import annotations
import argparse
from pathlib import Path
import sys
import cv2,mujoco,yaml
PROJECT_ROOT=Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path: sys.path.insert(0,str(PROJECT_ROOT))
from perception.pallet_pocket_detector import PalletPocketDetector
from scenarios.randomization import ScenarioSampler,apply_scenario
from simulator.camera_renderer import MultiCameraRenderer
DEFAULT_CONFIG=PROJECT_ROOT/'configs'/'vehicle_v8_1_3_3.yaml'
def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--config',type=Path,default=DEFAULT_CONFIG); p.add_argument('--seed',type=int,default=20260803); p.add_argument('--difficulty',choices=ScenarioSampler.difficulties(),default='easy'); p.add_argument('--output',type=Path,default=PROJECT_ROOT/'outputs'/'v8_1_3_3_vision_smoke'); a=p.parse_args()
    config=yaml.safe_load(a.config.read_text(encoding='utf-8')); model=mujoco.MjModel.from_xml_path(str((PROJECT_ROOT/config['model']['xml_path']).resolve())); data=mujoco.MjData(model); mujoco.mj_resetData(model,data)
    scenario=ScenarioSampler(seed=a.seed,difficulty=a.difficulty).sample(); apply_scenario(model,data,scenario)
    lift_id=mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_ACTUATOR,'lift_position'); data.ctrl[lift_id]=float(config['autonomy']['insertion_lift_target'])
    for _ in range(int(round(.8/model.opt.timestep))): mujoco.mj_step(model,data)
    renderer=MultiCameraRenderer(model,width=int(config['camera']['width']),height=int(config['camera']['height']))
    try: rgb=renderer.render(data,str(config['pickup_vision']['camera_name']))
    finally: renderer.close()
    detector=PalletPocketDetector.from_config(config['pickup_vision'],image_width=int(config['camera']['width']),image_height=int(config['camera']['height'])); detection=detector.detect(rgb); annotated=detector.annotate(rgb,detection)
    masks=detector.debug_masks(rgb)
    a.output.mkdir(parents=True,exist_ok=True); cv2.imwrite(str(a.output/'fork_rgb.png'),cv2.cvtColor(rgb,cv2.COLOR_RGB2BGR)); cv2.imwrite(str(a.output/'fork_rgb_pockets.png'),cv2.cvtColor(annotated,cv2.COLOR_RGB2BGR))
    cv2.imwrite(str(a.output/'fork_rgb_left_mask.png'),masks['left'])
    cv2.imwrite(str(a.output/'fork_rgb_right_mask.png'),masks['right'])
    print(f'scenario: {scenario.scenario_id}'); print(f'pocket_status: {detection.status}'); print(f'confidence: {detection.confidence:.3f}'); print(f'reprojection_error_px: {detection.reprojection_error_px}'); print(f'pallet_pose_in_base: {detection.pallet_pose_in_base}')
    print(f'left/right mask pixels: {int((masks["left"]>0).sum())}/{int((masks["right"]>0).sum())}')
    print(f'images: {a.output.resolve()}')
    return 0 if detection.success else 2
if __name__=='__main__': raise SystemExit(main())
