"""Headless V8.0 mission execution with RGB placement-marker fusion."""

from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any, Iterable

import mujoco
import numpy as np

from control.ackermann import front_drive_angular_speeds, rear_ackermann_angles
from control.docking_controller import DockingController
from control.safety import LiftDriveInterlock
from evaluation.vision_metrics import VisionMissionResult
from evaluation.terminal_validation import validate_terminal_mission
from perception.pose_pipeline import PosePipeline, wrap_angle
from perception.terminal_fusion import apply_terminal_autonomy_overrides
from perception.vision_placement import VisionPlacementPipeline
from scenarios.randomization import Scenario, apply_scenario
from simulator.camera_renderer import MultiCameraRenderer
from simulator.observation_builder import ObservationBuilder
from task.pickup_state_machine import PickupParameters, PickupState, PickupStateMachine


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _require_id(model: mujoco.MjModel, object_type: mujoco.mjtObj, name: str) -> int:
    object_id = mujoco.mj_name2id(model, object_type, name)
    if object_id < 0:
        raise RuntimeError(f"required MuJoCo object was not found: {name}")
    return int(object_id)


def _rpy(data: mujoco.MjData, qpos_address: int) -> tuple[float, float, float]:
    w, x, y, z = data.qpos[qpos_address + 3 : qpos_address + 7]
    sinr_cosp = 2.0 * (w * x + y * z)
    cosr_cosp = 1.0 - 2.0 * (x * x + y * y)
    roll = math.atan2(sinr_cosp, cosr_cosp)
    sinp = 2.0 * (w * y - z * x)
    pitch = math.copysign(math.pi / 2.0, sinp) if abs(sinp) >= 1.0 else math.asin(sinp)
    siny_cosp = 2.0 * (w * z + x * y)
    cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
    return roll, pitch, math.atan2(siny_cosp, cosy_cosp)


def _contacts(
    data: mujoco.MjData,
    first: Iterable[int],
    second: Iterable[int],
) -> int:
    a = set(first)
    b = set(second)
    count = 0
    for index in range(data.ncon):
        geom1 = int(data.contact[index].geom1)
        geom2 = int(data.contact[index].geom2)
        count += int(
            (geom1 in a and geom2 in b) or (geom2 in a and geom1 in b)
        )
    return count


def _controller(values: dict[str, Any]) -> DockingController:
    return DockingController(
        distance_gain=float(values["distance_gain"]),
        heading_gain=float(values["heading_gain"]),
        yaw_gain=float(values["yaw_gain"]),
        lateral_gain=float(values.get("lateral_gain", 0.0)),
        lookahead_distance=float(values.get("lookahead_distance", 0.75)),
        maximum_steering=float(values["maximum_steering"]),
        minimum_creep_speed=float(values["minimum_creep_speed"]),
        heading_slowdown_angle=float(values["heading_slowdown_angle"]),
        yaw_slowdown_angle=float(
            values.get("yaw_slowdown_angle", values["heading_slowdown_angle"])
        ),
        minimum_alignment_scale=float(values.get("minimum_alignment_scale", 0.2)),
    )


def _placement_error(observation) -> tuple[float, float]:
    dx = observation.placement_pose_in_base.x - observation.pallet_pose_in_base.x
    dy = observation.placement_pose_in_base.y - observation.pallet_pose_in_base.y
    yaw = wrap_angle(
        observation.placement_pose_in_base.yaw
        - observation.pallet_pose_in_base.yaw
    )
    return math.hypot(dx, dy), abs(math.degrees(yaw))


class _ErrorAccumulator:
    def __init__(self) -> None:
        self.frames = 0
        self.pallet_position_sq = 0.0
        self.pallet_yaw_sq = 0.0
        self.placement_position_sq = 0.0
        self.placement_yaw_sq = 0.0
        self.maximum_stale = 0.0

    def add(self, frame) -> None:
        self.frames += 1
        self.pallet_position_sq += frame.pallet.filtered_position_error_m**2
        self.pallet_yaw_sq += frame.pallet.filtered_yaw_error_deg**2
        self.placement_position_sq += frame.placement.filtered_position_error_m**2
        self.placement_yaw_sq += frame.placement.filtered_yaw_error_deg**2
        self.maximum_stale = max(
            self.maximum_stale,
            frame.pallet.stale_seconds,
            frame.placement.stale_seconds,
        )

    def rmse(self) -> tuple[float, float, float, float]:
        denominator = max(1, self.frames)
        return (
            math.sqrt(self.pallet_position_sq / denominator),
            math.sqrt(self.pallet_yaw_sq / denominator),
            math.sqrt(self.placement_position_sq / denominator),
            math.sqrt(self.placement_yaw_sq / denominator),
        )


class _VisionErrorAccumulator:
    def __init__(self) -> None:
        self.frames = 0
        self.position_sq = 0.0
        self.yaw_sq = 0.0
        self.confidences: list[float] = []
        self.reprojection_errors: list[float] = []

    def add(self, frame, truth) -> None:
        pose = frame.detection_pose_in_base
        if pose is None:
            return
        self.frames += 1
        dx = float(pose.x) - float(truth.placement_pose_in_base.x)
        dy = float(pose.y) - float(truth.placement_pose_in_base.y)
        yaw = wrap_angle(
            float(pose.yaw) - float(truth.placement_pose_in_base.yaw)
        )
        self.position_sq += dx * dx + dy * dy
        self.yaw_sq += math.degrees(yaw) ** 2
        detection = frame.detection
        if detection is not None:
            self.confidences.append(float(detection.confidence))
            if detection.reprojection_error_px is not None:
                self.reprojection_errors.append(
                    float(detection.reprojection_error_px)
                )

    def metrics(self) -> dict[str, float | None]:
        if self.frames <= 0:
            return {
                "position_rmse_m": None,
                "yaw_rmse_deg": None,
                "average_confidence": None,
                "maximum_reprojection_error_px": None,
            }
        return {
            "position_rmse_m": math.sqrt(self.position_sq / self.frames),
            "yaw_rmse_deg": math.sqrt(self.yaw_sq / self.frames),
            "average_confidence": (
                sum(self.confidences) / len(self.confidences)
                if self.confidences
                else None
            ),
            "maximum_reprojection_error_px": (
                max(self.reprojection_errors)
                if self.reprojection_errors
                else None
            ),
        }


def run_vision_mission_episode(
    config: dict[str, Any],
    scenario: Scenario,
    *,
    profile_name: str | None = None,
    max_episode_seconds: float | None = None,
    trace_path: Path | None = None,
) -> VisionMissionResult:
    model_path = (PROJECT_ROOT / config["model"]["xml_path"]).resolve()
    if not model_path.is_file():
        raise FileNotFoundError(f"MJCF model does not exist: {model_path}")

    model = mujoco.MjModel.from_xml_path(str(model_path))
    data = mujoco.MjData(model)
    mujoco.mj_resetData(model, data)
    apply_scenario(model, data, scenario)

    drive = config["drive"]
    lift = config["lift"]
    pickup = config["pickup"]
    safety = config["safety"]
    autonomy = config["autonomy"]
    batch = config.get("batch", {})
    perception_config = config["perception"]
    vision_config = config["vision"]
    camera_config = config["camera"]

    actuator_ids = {
        name: _require_id(model, mujoco.mjtObj.mjOBJ_ACTUATOR, name)
        for name in (
            "front_left_drive_velocity",
            "front_right_drive_velocity",
            "rear_left_steer_position",
            "rear_right_steer_position",
            "lift_position",
        )
    }
    joint_ids = {
        name: _require_id(model, mujoco.mjtObj.mjOBJ_JOINT, name)
        for name in ("forklift_free", "pallet_load_free", "lift_joint")
    }
    forklift_qpos = int(model.jnt_qposadr[joint_ids["forklift_free"]])
    pallet_qpos = int(model.jnt_qposadr[joint_ids["pallet_load_free"]])
    lift_dof = int(model.jnt_dofadr[joint_ids["lift_joint"]])
    fork_geoms = {
        _require_id(model, mujoco.mjtObj.mjOBJ_GEOM, name)
        for name in ("left_fork", "right_fork")
    }
    pallet_geoms = {
        _require_id(model, mujoco.mjtObj.mjOBJ_GEOM, name)
        for name in (
            "pallet_center_runner",
            "pallet_left_runner",
            "pallet_right_runner",
            "pallet_deck",
            "cargo_box",
        )
    }

    initial_lift = float(lift["initial_target"])
    data.ctrl[actuator_ids["lift_position"]] = initial_lift
    settle_steps = int(
        round(float(batch.get("settle_seconds", 0.5)) / model.opt.timestep)
    )
    for _ in range(settle_steps):
        mujoco.mj_step(model, data)

    ground_load_z = float(data.qpos[pallet_qpos + 2])
    builder = ObservationBuilder(model)
    selected_profile = str(
        profile_name
        if profile_name is not None
        else perception_config["default_profile"]
    )
    pipeline = PosePipeline.from_config(
        perception_config,
        profile_name=selected_profile,
        seed=scenario.seed,
    )
    vision = VisionPlacementPipeline.from_config(
        vision_config,
        profile_name=selected_profile,
        image_width=int(camera_config["width"]),
        image_height=int(camera_config["height"]),
    )
    renderer = MultiCameraRenderer(
        model,
        width=int(camera_config["width"]),
        height=int(camera_config["height"]),
    )
    effective_autonomy = apply_terminal_autonomy_overrides(
        autonomy,
        perception_config,
        profile_name=selected_profile,
    )
    machine = PickupStateMachine(
        parameters=PickupParameters.from_mapping(effective_autonomy),
        docking_controller=_controller(config["controller"]),
    )
    machine.reset(float(data.time))
    interlock = LiftDriveInterlock(
        enabled=bool(safety["stop_drive_during_lift"]),
        velocity_threshold=float(safety["lift_velocity_threshold"]),
        settle_time=float(safety["lift_settle_time_seconds"]),
    )
    interlock.reset(lift_target=initial_lift, sim_time=float(data.time))

    def load_status() -> tuple[int, str, float]:
        load_z = float(data.qpos[pallet_qpos + 2])
        roll, pitch, _ = _rpy(data, pallet_qpos)
        tilt = max(abs(math.degrees(roll)), abs(math.degrees(pitch)))
        contacts = _contacts(data, fork_geoms, pallet_geoms)
        lifted = load_z - ground_load_z >= float(pickup["lifted_height_threshold"])
        state = "LIFTED" if lifted else ("ENGAGED" if contacts else "GROUND")
        return contacts, state, tilt

    start = float(data.time)
    time_limit = float(
        max_episode_seconds
        if max_episode_seconds is not None
        else batch.get("max_episode_seconds", 390.0)
    )
    trace_hz = float(batch.get("trace_hz", 10.0))
    next_trace = start
    trace_period = 1.0 / trace_hz
    stream = None
    if trace_path is not None:
        trace_path.parent.mkdir(parents=True, exist_ok=True)
        stream = trace_path.open("w", encoding="utf-8")

    current_state = machine.state.value
    state_enter = start
    state_durations: dict[str, float] = {}
    previous_xy = (
        float(data.qpos[forklift_qpos]),
        float(data.qpos[forklift_qpos + 1]),
    )
    path_length = 0.0
    max_steering = 0.0
    max_tilt = 0.0
    final_state = PickupState.FAILED.value
    failure_reason: str | None = None
    release_start: tuple[float, float] | None = None
    release_motion = 0.0
    accumulator = _ErrorAccumulator()
    vision_accumulator = _VisionErrorAccumulator()
    last_frame = None
    last_vision_frame = None

    try:
        while float(data.time) - start <= time_limit:
            contacts, load_state, tilt = load_status()
            truth = builder.build(
                data,
                fork_contact_count=contacts,
                load_state=load_state,
            )
            frame = pipeline.step(truth)
            rgb = None
            if vision.wants_image(
                sim_time=truth.sim_time,
                controller_state=machine.state.value,
            ):
                rgb = renderer.render(data, vision.camera_name)
            vision_frame = vision.step(
                frame=frame,
                rgb=rgb,
                controller_state=machine.state.value,
            )
            last_frame = frame
            last_vision_frame = vision_frame
            accumulator.add(frame)
            vision_accumulator.add(vision_frame, truth)
            estimated = vision_frame.observation
            decision = machine.step(estimated)
            max_tilt = max(max_tilt, tilt)

            if decision.state.value != current_state:
                state_durations[current_state] = state_durations.get(
                    current_state, 0.0
                ) + float(data.time) - state_enter
                current_state = decision.state.value
                state_enter = float(data.time)
                if current_state == PickupState.PLACE_RETREAT.value:
                    release_start = (
                        truth.pallet_pose_world.x,
                        truth.pallet_pose_world.y,
                    )

            if release_start is not None:
                release_motion = max(
                    release_motion,
                    math.hypot(
                        truth.pallet_pose_world.x - release_start[0],
                        truth.pallet_pose_world.y - release_start[1],
                    ),
                )

            action = decision.action
            requested_speed = 0.0 if action.emergency_stop else action.speed_target
            resolved = interlock.resolve(
                requested_speed=requested_speed,
                lift_velocity=float(data.qvel[lift_dof]),
                lift_target=action.lift_target,
                sim_time=float(data.time),
            )
            steering = max(
                -float(drive["maximum_steering_command"]),
                min(
                    float(drive["maximum_steering_command"]),
                    action.steering_command,
                ),
            )
            angles = rear_ackermann_angles(
                steering,
                float(drive["wheelbase"]),
                float(drive["rear_track"]),
            )
            left_omega, right_omega = front_drive_angular_speeds(
                resolved.applied_speed,
                steering,
                float(drive["wheelbase"]),
                float(drive["front_track"]),
                float(drive["front_wheel_radius"]),
            )
            data.ctrl[actuator_ids["front_left_drive_velocity"]] = left_omega
            data.ctrl[actuator_ids["front_right_drive_velocity"]] = right_omega
            data.ctrl[actuator_ids["rear_left_steer_position"]] = angles.left
            data.ctrl[actuator_ids["rear_right_steer_position"]] = angles.right
            data.ctrl[actuator_ids["lift_position"]] = max(
                float(lift["minimum_height"]),
                min(float(lift["maximum_height"]), action.lift_target),
            )
            max_steering = max(max_steering, abs(math.degrees(steering)))

            if stream is not None and float(data.time) + 1e-12 >= next_trace:
                stream.write(
                    json.dumps(
                        {
                            "ground_truth_observation": truth.to_dict(),
                            "estimated_observation": estimated.to_dict(),
                            "perception": frame.to_dict(),
                            "vision_marker": vision_frame.diagnostics.to_dict(),
                            "decision": decision.to_dict(),
                            "applied_speed": resolved.applied_speed,
                            "interlock_reason": resolved.reason,
                        },
                        ensure_ascii=False,
                    )
                    + "\n"
                )
                while next_trace <= float(data.time):
                    next_trace += trace_period

            if decision.state in (PickupState.DONE, PickupState.FAILED):
                final_state = decision.state.value
                failure_reason = decision.failure_reason
                break

            mujoco.mj_step(model, data)
            current_xy = (
                float(data.qpos[forklift_qpos]),
                float(data.qpos[forklift_qpos + 1]),
            )
            path_length += math.hypot(
                current_xy[0] - previous_xy[0],
                current_xy[1] - previous_xy[1],
            )
            previous_xy = current_xy
            if not np.isfinite(data.qpos).all() or not np.isfinite(data.qvel).all():
                failure_reason = "non-finite MuJoCo state"
                break
        else:
            failure_reason = f"episode exceeded {time_limit:.1f}s"
    finally:
        if stream is not None:
            stream.close()
        renderer.close()

    end = float(data.time)
    state_durations[current_state] = state_durations.get(current_state, 0.0) + max(
        0.0, end - state_enter
    )
    contacts, load_state, tilt = load_status()
    final_truth = builder.build(
        data,
        fork_contact_count=contacts,
        load_state=load_state,
    )
    placement_error, placement_yaw_error = _placement_error(final_truth)
    mission_done = final_state == PickupState.DONE.value
    validation = validate_terminal_mission(
        mission_done=mission_done,
        placement_error_m=placement_error,
        placement_yaw_error_rad=math.radians(placement_yaw_error),
        release_motion_m=release_motion,
        load_state=load_state,
        position_tolerance_m=float(
            effective_autonomy["placement_post_release_position_tolerance"]
        ),
        yaw_tolerance_rad=float(
            effective_autonomy["placement_post_release_yaw_tolerance"]
        ),
        release_motion_tolerance_m=float(
            effective_autonomy["placement_load_motion_tolerance"]
        ),
    )
    success = mission_done and validation.passed
    if mission_done and not validation.passed:
        final_state = PickupState.FAILED.value
        failure_reason = validation.failure_reason
    if success and not vision.meets_success_requirement():
        success = False
        final_state = PickupState.FAILED.value
        failure_reason = (
            "RGB placement marker was not acquired often enough "
            f"({vision.detection_count}/"
            f"{vision.profile.minimum_detections_for_success})"
        )
    pallet_rmse, pallet_yaw_rmse, placement_rmse, placement_yaw_rmse = (
        accumulator.rmse()
    )

    if last_frame is None:
        dropout_rate = 0.0
        rejection_rate = 0.0
        selected_profile = profile_name or str(perception_config["default_profile"])
    else:
        samples = max(
            1,
            last_frame.pallet.sample_count + last_frame.placement.sample_count,
        )
        dropout_rate = (
            last_frame.pallet.dropout_count + last_frame.placement.dropout_count
        ) / samples
        rejection_rate = (
            last_frame.pallet.rejected_count + last_frame.placement.rejected_count
        ) / samples
        selected_profile = last_frame.profile_name

    vision_metrics = vision_accumulator.metrics()
    vision_stale = vision.maximum_stale_seconds_observed

    return VisionMissionResult(
        scenario_id=scenario.scenario_id,
        difficulty=scenario.difficulty,
        seed=scenario.seed,
        perception_profile=selected_profile,
        success=success,
        final_state=final_state,
        failure_reason=None if success else (failure_reason or "unknown failure"),
        duration_seconds=max(0.0, end - start),
        path_length_m=path_length,
        max_abs_steering_deg=max_steering,
        max_load_tilt_deg=max(max_tilt, tilt),
        final_placement_error_m=placement_error,
        final_placement_yaw_error_deg=placement_yaw_error,
        release_pallet_motion_m=release_motion,
        steering_exercised=max_steering
        >= float(batch.get("steering_exercised_degrees", 1.0)),
        recovery_count=machine.recovery_count,
        pallet_position_rmse_m=pallet_rmse,
        pallet_yaw_rmse_deg=pallet_yaw_rmse,
        placement_position_rmse_m=placement_rmse,
        placement_yaw_rmse_deg=placement_yaw_rmse,
        maximum_stale_seconds=accumulator.maximum_stale,
        measurement_dropout_rate=dropout_rate,
        measurement_rejection_rate=rejection_rate,
        vision_sample_count=vision.sample_count,
        vision_detection_count=vision.detection_count,
        vision_rejection_count=vision.rejection_count,
        vision_detection_rate=vision.detection_count / max(1, vision.sample_count),
        vision_position_rmse_m=vision_metrics["position_rmse_m"],
        vision_yaw_rmse_deg=vision_metrics["yaw_rmse_deg"],
        vision_average_confidence=vision_metrics["average_confidence"],
        vision_maximum_reprojection_error_px=vision_metrics[
            "maximum_reprojection_error_px"
        ],
        vision_maximum_stale_seconds=vision_stale,
        vision_used_for_terminal=vision.ever_applied,
        state_durations={key: round(value, 6) for key, value in state_durations.items()},
        scenario=scenario.to_dict(),
    )
