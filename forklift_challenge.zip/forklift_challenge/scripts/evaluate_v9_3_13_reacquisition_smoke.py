"""Evaluate the V9.3.13 terminal carried-load visual reacquisition liveness gate."""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("summary", type=Path, help="Path to smoke-run summary.json")
    args = parser.parse_args()
    summary = json.loads(args.summary.read_text(encoding="utf-8"))

    raw = int(summary.get("total_terminal_load_reacquisition_raw_detection_count", 0))
    low_conf = int(summary.get("total_terminal_load_reacquisition_low_confidence_reject_count", 0))
    appends = int(summary.get("total_terminal_load_reacquisition_history_append_count", 0))
    saturation = int(summary.get("total_terminal_load_reacquisition_search_saturation_count", 0))
    consensus = int(summary.get("total_terminal_load_reacquisition_consensus_update_count", 0))
    observer = int(summary.get("total_terminal_load_reacquisition_observer_update_count", 0))
    observer_reject = int(summary.get("total_terminal_load_reacquisition_observer_rejection_count", 0))

    checks = {
        "raw detections > 0": raw > 0,
        "history appends > 0": appends > 0,
        "temporal consensus > 0": consensus > 0,
        "carried-load observer updates > 0": observer > 0,
        "consensus release authority remains closed": int(
            summary.get("total_certified_basin_consensus_enter_count", 999)
        ) == 0,
        "controller release truth FP = 0": int(
            summary.get("precision_diagnostics", {})
            .get("derived", {})
            .get("controller_certified_release_false_positive_count", 999)
        ) == 0,
        "witness truth FP = 0": int(summary.get("release_witness_false_positive_count", 999)) == 0,
        "execution truth FP = 0": int(summary.get("release_execution_false_positive_count", 999)) == 0,
    }
    passed = all(checks.values())
    print(f"V9.3.13 reacquisition smoke: {'PASS' if passed else 'FAIL'}")
    for name, ok in checks.items():
        print(f"  {'PASS' if ok else 'FAIL'} {name}")
    print(
        "  chain: "
        f"raw={raw}, low_conf={low_conf}, appends={appends}, "
        f"search_saturation={saturation}, consensus={consensus}, "
        f"observer_updates={observer}, observer_rejects={observer_reject}"
    )
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
