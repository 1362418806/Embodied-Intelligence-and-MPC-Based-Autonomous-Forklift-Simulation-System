"""Static/invariant audit for V9.3.12-R4-F2 yaw-authority decoupling."""
from __future__ import annotations

import copy
import math
from pathlib import Path
import py_compile
import sys

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def check(name: str, ok: bool) -> None:
    print(f"{'PASS' if ok else 'FAIL'} {name}")
    if not ok:
        raise AssertionError(name)


def main() -> int:
    for rel in (
        "control/carried_load_observer.py",
        "control/carried_load_yaw_anchor.py",
        "task/pickup_state_machine.py",
        "evaluation/dual_vision_metrics.py",
        "simulator/dual_vision_mission_episode.py",
        "scripts/analyze_v9_3_12_r4_f2_yaw_authority.py",
        "scripts/run_v9_3_12_r4_f2_batch.py",
        "scripts/evaluate_v9_3_12_r4_f2_precision_closure.py",
    ):
        py_compile.compile(str(ROOT / rel), doraise=True)
        check(f"compile:{rel}", True)

    f1 = yaml.safe_load((ROOT / "configs" / "vehicle_v9_3_12_r4_f1.yaml").read_text(encoding="utf-8"))
    f2 = yaml.safe_load((ROOT / "configs" / "vehicle_v9_3_12_r4_f2.yaml").read_text(encoding="utf-8"))
    base = f2["autonomy"]
    weak = f2["perception"]["terminal_autonomy_overrides"]["weak_guide"]

    check("legacy/base terminal yaw authority remains on", base["placement_terminal_load_reacquisition_yaw_authority_enabled"] == 1.0)
    check("weak-guide terminal yaw authority disabled", weak["placement_terminal_load_reacquisition_yaw_authority_enabled"] == 0.0)
    check("F1 anchor remains enabled", weak["placement_carried_visual_yaw_anchor_enabled"] == 1.0)

    # Prove F2 config changed no historical tuning knobs besides the new flag.
    f2_cmp = copy.deepcopy(f2)
    f2_cmp["autonomy"].pop("placement_terminal_load_reacquisition_yaw_authority_enabled", None)
    f2_cmp["perception"]["terminal_autonomy_overrides"]["weak_guide"].pop(
        "placement_terminal_load_reacquisition_yaw_authority_enabled", None
    )
    check("F2 config has no collateral tuning drift", f2_cmp == f1)

    # Frozen release/safety contract.
    check("strict position remains 9.5cm", math.isclose(float(weak["placement_strict_release_position_limit_m"]), 0.095, abs_tol=1e-12))
    check("strict yaw remains 4.6deg", math.isclose(float(weak["placement_strict_release_yaw_limit_rad"]), math.radians(4.6), abs_tol=1e-12))
    check("observer 1deg yaw floor unchanged", math.isclose(float(weak["placement_carried_observer_minimum_yaw_sigma_rad"]), math.radians(1.0), abs_tol=1e-12))
    check("yaw sigma gain unchanged", math.isclose(float(weak["placement_strict_release_yaw_sigma_gain"]), 0.22, abs_tol=1e-12))
    check("execution yaw reserve unchanged", math.isclose(float(weak["placement_strict_release_execution_yaw_reserve_rad"]), math.radians(0.4), abs_tol=1e-12))
    check("target yaw floor unchanged", math.isclose(float(weak["placement_strict_release_target_yaw_margin_floor_rad"]), math.radians(0.35), abs_tol=1e-12))
    check("consensus release authority remains off", float(weak["placement_certified_basin_consensus_release_authority"]) == 0.0)
    check("terminal budget remains 90s", math.isclose(float(weak["placement_terminal_budget_seconds"]), 90.0, abs_tol=1e-12))

    reacq = f2["terminal_load_reacquisition"]["profiles"]["weak_guide"]
    check("D2 reacq remains enabled", bool(reacq["enabled"]))
    check("D2 position sigma unchanged", math.isclose(float(reacq["measurement_position_sigma_m"]), 0.018, abs_tol=1e-12))
    check("D2 yaw measurement calibration unchanged", math.isclose(float(reacq["measurement_yaw_sigma_deg"]), 0.9, abs_tol=1e-12))
    check("D2 position innovation gate unchanged", math.isclose(float(reacq["maximum_position_innovation_m"]), 0.06, abs_tol=1e-12))

    observer_source = (ROOT / "control" / "carried_load_observer.py").read_text(encoding="utf-8")
    position_only_body = observer_source.split("def update_position_only(", 1)[1].split("@property", 1)[0]
    check("observer exposes true position-only path", "def update_position_only(" in observer_source)
    check("position-only path preserves yaw variance", "self._yaw_var" not in position_only_body)
    check("position-only path preserves pose yaw", "float(pose.yaw)" in position_only_body)
    check("position-only path uses only position gate", "yaw_innovation_gate" not in position_only_body)

    source = (ROOT / "task" / "pickup_state_machine.py").read_text(encoding="utf-8")
    check("state machine calls position-only observer", "observer.update_position_only(" in source)
    check("position-only path does not reset full belief", "if yaw_authority and self._load_belief_enabled()" in source)
    check("F2 telemetry distinguishes translation-only provenance", "terminal_rgb_reacquisition_position_only" in source)
    print("V9.3.12-R4-F2 static audit: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
