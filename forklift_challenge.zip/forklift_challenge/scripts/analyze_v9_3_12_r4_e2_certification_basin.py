"""Analyze V9.3.12-R4-E2 certification-basin closure from a trace JSONL."""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from statistics import mean


def _time(row: dict) -> float:
    return float(row.get("estimated_observation", {}).get("sim_time", row.get("ground_truth_observation", {}).get("sim_time", 0.0)))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("trace", type=Path)
    parser.add_argument("--output-json", type=Path)
    parser.add_argument("--output-md", type=Path)
    args = parser.parse_args()

    rows = [json.loads(line) for line in args.trace.read_text(encoding="utf-8").splitlines() if line.strip()]
    decisions = [(row, row.get("decision", {})) for row in rows]

    selected = [(row, d) for row, d in decisions if "R4-E2 certification-basin closure selected" in str(d.get("status", ""))]
    e2_motion = [(row, d) for row, d in decisions if "R4-E2 certification-basin LEG" in str(d.get("status", ""))]
    e2_feedback = [(row, d) for row, d in decisions if "R4-E2 certification-basin feedback" in str(d.get("status", ""))]
    gray_holds = [(row, d) for row, d in decisions if "R4-E2 post-closure gray-zone hold" in str(d.get("status", ""))]
    supervisor_settle = [(row, d) for row, d in decisions if d.get("placement_precision_phase") == "RELEASE_SETTLE"]
    release_events = [(row, d) for row, d in decisions if "RELEASE_INTENT executed" in str(d.get("status", ""))]

    last_d = decisions[-1][1] if decisions else {}
    cert_pos = [float(d["strict_release_certification_position_error_m"]) for _, d in decisions if d.get("strict_release_certification_position_error_m") is not None]
    cert_yaw = [abs(float(d["strict_release_certification_yaw_error_deg"])) for _, d in decisions if d.get("strict_release_certification_yaw_error_deg") is not None]
    filtered_pos = [float(d["placement_precision_filtered_position_error_m"]) for _, d in decisions if d.get("placement_precision_filtered_position_error_m") is not None]
    filtered_yaw = [abs(float(d["placement_precision_filtered_yaw_error_deg"])) for _, d in decisions if d.get("placement_precision_filtered_yaw_error_deg") is not None]

    truth_inside = []
    for row, d in decisions:
        gt = row.get("ground_truth_observation", {})
        # Trace does not always contain final error directly; the result summary
        # remains the authoritative pass/fail. Keep truth use diagnosis-only.
        if gt and d.get("placement_error", {}).get("distance") is not None:
            truth_inside.append(False)  # intentionally not inferred from controller-space placement_error

    result = {
        "trace": str(args.trace),
        "samples": len(rows),
        "certification_basin_selected_count": len(selected),
        "certification_basin_motion_frame_count": len(e2_motion),
        "certification_basin_feedback_count": len(e2_feedback),
        "gray_zone_hold_frame_count": len(gray_holds),
        "release_supervisor_settle_frame_count": len(supervisor_settle),
        "release_execute_count": len(release_events),
        "first_e2_selection_time_s": None if not selected else _time(selected[0][0]),
        "first_e2_feedback_time_s": None if not e2_feedback else _time(e2_feedback[0][0]),
        "first_release_time_s": None if not release_events else _time(release_events[0][0]),
        "minimum_certification_position_error_m": None if not cert_pos else min(cert_pos),
        "minimum_certification_abs_yaw_error_deg": None if not cert_yaw else min(cert_yaw),
        "minimum_filtered_position_error_m": None if not filtered_pos else min(filtered_pos),
        "minimum_filtered_abs_yaw_error_deg": None if not filtered_yaw else min(filtered_yaw),
        "final_e2_search_count": int(last_d.get("placement_certification_basin_closure_search_count", 0)),
        "final_e2_activation_count": int(last_d.get("placement_certification_basin_closure_activation_count", 0)),
        "final_e2_total_candidate_count": int(last_d.get("placement_certification_basin_closure_total_candidate_count", 0)),
        "final_e2_feedback_reject_count": int(last_d.get("placement_certification_basin_closure_feedback_reject_count", 0)),
        "final_e2_predicted_deficit_improvement": float(last_d.get("placement_certification_basin_closure_last_predicted_deficit_improvement", 0.0)),
        "final_e2_measured_deficit_improvement": float(last_d.get("placement_certification_basin_closure_last_measured_deficit_improvement", 0.0)),
        "final_e2_current_deficit": float(last_d.get("placement_certification_basin_closure_last_current_deficit", 0.0)),
        "final_e2_predicted_deficit": float(last_d.get("placement_certification_basin_closure_last_predicted_deficit", 0.0)),
        "final_e2_post_motion_rgb_updates": int(last_d.get("placement_certification_basin_closure_post_motion_rgb_updates", 0)),
        "final_e2_supervisor_retry_suppressed_count": int(last_d.get("placement_certification_basin_closure_supervisor_retry_suppressed_count", 0)),
        "final_post_closure_gray_zone_hold_count": int(last_d.get("placement_post_closure_gray_zone_hold_count", 0)),
        "final_release_commit_count": int(last_d.get("placement_release_commit_count", 0)),
        "final_strict_certified": bool(last_d.get("strict_release_certified", False)),
        "final_strict_blocker": str(last_d.get("strict_release_certification_blocker", "NONE")),
    }

    print("V9.3.12-R4-E2 certification-basin analysis")
    for key, value in result.items():
        print(f"  {key}: {value}")

    if args.output_json:
        args.output_json.parent.mkdir(parents=True, exist_ok=True)
        args.output_json.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    if args.output_md:
        args.output_md.parent.mkdir(parents=True, exist_ok=True)
        lines = ["# V9.3.12-R4-E2 Certification-Basin Analysis", ""]
        lines.extend(f"- **{key}**: {value}" for key, value in result.items())
        args.output_md.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
