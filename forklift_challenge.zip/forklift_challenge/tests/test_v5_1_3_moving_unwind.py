"""Tests for V5.1.3 moving steering unwind recovery."""

from __future__ import annotations

from control.docking_controller import DockingController
from interfaces.observation import ForkliftObservation, Pose3D
from task.pickup_state_machine import (
    PickupParameters,
    PickupState,
    PickupStateMachine,
)


def pose(x=0.0, y=0.0, yaw=0.0):
    return Pose3D(x=x, y=y, z=0.0, roll=0.0, pitch=0.0, yaw=yaw)


def observation(
    sim_time,
    *,
    vehicle_x=0.0,
    steering_left=-0.30,
    steering_right=-0.22,
):
    return ForkliftObservation(
        sim_time=sim_time,
        vehicle_pose_world=pose(vehicle_x),
        vehicle_linear_velocity=(0.0, 0.0, 0.0),
        vehicle_angular_velocity=(0.0, 0.0, 0.0),
        steering_left=steering_left,
        steering_right=steering_right,
        front_wheel_speed_left=0.0,
        front_wheel_speed_right=0.0,
        lift_position=0.04,
        lift_velocity=0.0,
        pallet_pose_world=pose(3.2),
        pallet_pose_in_base=pose(4.0, 0.3),
        placement_pose_in_base=pose(5.0, -1.0),
        fork_contact_count=0,
        load_state="GROUND",
    )


def parameters():
    return PickupParameters(
        insertion_lift_target=0.04,
        transport_lift_target=0.30,
        pre_approach_distance=2.85,
        insertion_distance=1.60,
        approach_max_speed=0.32,
        align_max_speed=0.13,
        insertion_max_speed=0.09,
        retreat_speed=-0.18,
        retreat_distance=0.75,
        approach_capture_distance=0.42,
        pre_position_tolerance=0.085,
        pre_lateral_tolerance=0.060,
        pre_yaw_tolerance=0.075,
        insertion_position_tolerance=0.055,
        insertion_lateral_tolerance=0.045,
        insertion_yaw_tolerance=0.060,
        lift_position_tolerance=0.055,
        lift_velocity_tolerance=0.015,
        lifted_minimum_fork_height=0.12,
        verify_lift_seconds=0.60,
        maximum_load_tilt=0.175,
        lower_timeout=4.0,
        approach_timeout=35.0,
        align_timeout=20.0,
        insert_timeout=18.0,
        lift_timeout=8.0,
        retreat_timeout=10.0,
        align_minimum_speed=0.075,
        alignment_hold_seconds=0.35,
        progress_timeout=1.0,
        progress_improvement=0.018,
        recovery_speed=-0.24,
        recovery_distance=0.40,
        recovery_timeout=12.0,
        maximum_recoveries=2,
        overshoot_longitudinal_tolerance=0.14,
        recovery_steering_tolerance=0.14,
        recovery_center_hold_seconds=0.12,
        recovery_center_timeout=6.0,
        recovery_unwind_speed=-0.08,
        recovery_unwind_distance=0.18,
    )


def machine():
    return PickupStateMachine(
        parameters=parameters(),
        docking_controller=DockingController(
            distance_gain=0.78,
            heading_gain=1.45,
            yaw_gain=0.72,
            lateral_gain=0.82,
            lookahead_distance=0.95,
            maximum_steering=0.36,
            minimum_creep_speed=0.055,
            heading_slowdown_angle=0.75,
            yaw_slowdown_angle=0.52,
            minimum_alignment_scale=0.32,
        ),
    )


def enter_recovery(sm):
    sm.reset(0.0)
    assert sm.step(observation(0.30)).state == PickupState.APPROACH
    sm.step(observation(0.40))
    result = sm.step(observation(1.41))
    assert result.state == PickupState.RECOVER_REVERSE
    return result


def test_recovery_moves_slowly_instead_of_waiting_at_standstill():
    result = enter_recovery(machine())
    assert result.action.speed_target == -0.08
    assert result.action.steering_command == 0.0
    assert "unwind steering" in result.status


def test_unwind_does_not_fail_when_steering_remains_large():
    sm = machine()
    enter_recovery(sm)
    result = sm.step(
        observation(
            7.50,
            vehicle_x=-0.10,
            steering_left=-0.28,
            steering_right=-0.20,
        )
    )
    assert result.state == PickupState.RECOVER_REVERSE
    assert result.failure_reason is None
    assert result.action.speed_target == -0.24


def test_unwind_switches_to_main_reverse_after_distance_limit():
    sm = machine()
    enter_recovery(sm)
    result = sm.step(
        observation(
            3.00,
            vehicle_x=-0.19,
            steering_left=-0.20,
            steering_right=-0.15,
        )
    )
    assert result.state == PickupState.RECOVER_REVERSE
    assert result.action.speed_target == -0.24


def test_total_recovery_distance_returns_to_approach():
    sm = machine()
    enter_recovery(sm)
    result = sm.step(
        observation(
            5.0,
            vehicle_x=-0.41,
            steering_left=-0.05,
            steering_right=-0.04,
        )
    )
    assert result.state == PickupState.APPROACH
    assert result.action.speed_target == 0.0
