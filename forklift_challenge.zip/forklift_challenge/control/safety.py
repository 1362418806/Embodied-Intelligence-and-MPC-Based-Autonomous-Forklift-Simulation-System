"""Safety interlocks shared by teleoperation and autonomous control."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class DriveInterlockResult:
    """Resolved drive command after applying lift/drive safety rules."""

    requested_speed: float
    applied_speed: float
    lift_motion_active: bool
    reason: str


class LiftDriveInterlock:
    """Block driving only while the lift is physically moving or settling.

    A position servo can retain a non-zero steady-state target error under load.
    Therefore this interlock intentionally does *not* compare lift target and
    lift position. It watches lift velocity and target changes instead. This
    prevents the old failure mode where an elevated fork could never drive.
    """

    def __init__(
        self,
        *,
        enabled: bool,
        velocity_threshold: float,
        settle_time: float,
        target_change_epsilon: float = 1e-6,
    ) -> None:
        if velocity_threshold < 0.0:
            raise ValueError("velocity_threshold must be non-negative")
        if settle_time < 0.0:
            raise ValueError("settle_time must be non-negative")
        if target_change_epsilon < 0.0:
            raise ValueError("target_change_epsilon must be non-negative")

        self.enabled = enabled
        self.velocity_threshold = velocity_threshold
        self.settle_time = settle_time
        self.target_change_epsilon = target_change_epsilon
        self._last_target: float | None = None
        self._last_motion_time = float("-inf")

    def reset(self, *, lift_target: float, sim_time: float) -> None:
        """Reset the interlock without unnecessarily blocking initial driving."""
        self._last_target = float(lift_target)
        self._last_motion_time = float(sim_time) - self.settle_time

    def resolve(
        self,
        *,
        requested_speed: float,
        lift_velocity: float,
        lift_target: float,
        sim_time: float,
    ) -> DriveInterlockResult:
        """Return the drive command permitted by the current lift state."""
        sim_time = float(sim_time)
        target_changed = (
            self._last_target is None
            or abs(float(lift_target) - self._last_target)
            > self.target_change_epsilon
        )
        moving = abs(float(lift_velocity)) > self.velocity_threshold

        if target_changed:
            self._last_target = float(lift_target)
            self._last_motion_time = sim_time

        if moving:
            self._last_motion_time = sim_time

        settling = sim_time - self._last_motion_time < self.settle_time
        active = self.enabled and (target_changed or moving or settling)

        if not self.enabled:
            reason = "disabled"
        elif target_changed:
            reason = "target-change"
        elif moving:
            reason = "moving"
        elif settling:
            reason = "settling"
        else:
            reason = "off"

        return DriveInterlockResult(
            requested_speed=float(requested_speed),
            applied_speed=0.0 if active else float(requested_speed),
            lift_motion_active=active,
            reason=reason,
        )
