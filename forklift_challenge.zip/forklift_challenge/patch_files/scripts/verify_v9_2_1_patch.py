"""Verify the installed V9.2.1 terminal precision patch."""

from __future__ import annotations

from pathlib import Path
import subprocess
import sys


def run(command: list[str], project_root: Path) -> None:
    """Run one verification command and stop immediately on failure."""
    print(">", " ".join(command))
    subprocess.run(command, cwd=project_root, check=True)


def main() -> int:
    """Compile the patch, run unit tests, then run deterministic smoke checks."""
    project_root = Path(__file__).resolve().parents[1]
    python = sys.executable
    run([python, "-m", "compileall", "-q", "forklift_v9_2_1_terminal_precision"], project_root)
    run([python, "-m", "pytest", "-q", "tests/test_v9_2_1_terminal_precision.py"], project_root)
    run([python, "scripts/run_v9_2_1_precision_selftest.py"], project_root)
    print("V9.2.1 patch verification: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
