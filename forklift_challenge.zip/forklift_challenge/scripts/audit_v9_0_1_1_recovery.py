"""Audit old failure traces with the V9.0.1.1 runway-distance formula."""
from __future__ import annotations
import argparse, json, math, re
from pathlib import Path
import yaml

ROOT=Path(__file__).resolve().parents[1]

def main()->int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('trace_dir',type=Path)
    ap.add_argument('--profile',choices=('moderate','finals'),required=True)
    ap.add_argument('--config',type=Path,default=ROOT/'configs'/'vehicle_v9_0_1_1.yaml')
    args=ap.parse_args()
    cfg=yaml.safe_load(args.config.read_text(encoding='utf-8'))
    p=cfg['perception']['terminal_autonomy_overrides'][args.profile]
    rows=[]
    for path in sorted(args.trace_dir.glob('*.jsonl')):
        previous=None
        for line in path.read_text(encoding='utf-8').splitlines():
            obj=json.loads(line); d=obj['decision']; state=d['state']
            if state=='PLACE_RECOVER_REVERSE' and previous is not None and previous['state']!='PLACE_RECOVER_REVERSE':
                source=previous
                dock=source.get('docking_error') or d.get('docking_error')
                perr=source.get('placement_error') or d.get('placement_error')
                if dock is None or perr is None:
                    previous=d; continue
                attempt=int(d.get('placement_recovery_count') or 1)
                legacy=(p['placement_recovery_minimum_distance']+p['placement_recovery_lateral_gain']*abs(perr['lateral'])+p['placement_recovery_yaw_gain']*abs(perr['yaw']))
                overs=max(0.0,-dock['longitudinal'])
                req=(p['placement_recovery_runway_distance']+p['placement_recovery_longitudinal_gain']*overs+p['placement_recovery_lateral_gain']*abs(dock['lateral'])+p['placement_recovery_yaw_gain']*abs(dock['yaw'])+p['placement_recovery_attempt_distance_gain']*max(0,attempt-1))
                req=min(p['placement_recovery_maximum_distance'],max(p['placement_recovery_runway_distance'],req))
                target=max(legacy,req-max(0.0,dock['longitudinal']))
                target=min(p['placement_recovery_maximum_distance'],max(p['placement_recovery_minimum_distance'],target))
                rows.append((path.name,attempt,dock['longitudinal'],dock['lateral'],math.degrees(dock['yaw']),target))
            previous=d
    for row in rows:
        print(f'{row[0]} recovery={row[1]} trigger_long={row[2]:+.3f} lateral={row[3]:+.3f} yaw={row[4]:+.1f}deg new_target={row[5]:.3f}m')
    if rows:
        vals=[r[-1] for r in rows]
        print(f'cycles={len(rows)} target_range={min(vals):.3f}-{max(vals):.3f}m mean={sum(vals)/len(vals):.3f}m')
    return 0
if __name__=='__main__': raise SystemExit(main())
