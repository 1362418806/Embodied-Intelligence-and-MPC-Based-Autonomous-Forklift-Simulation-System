"""Analyze V9.3.12-R4-E8 pre-lift carried-load yaw consensus.

Runtime section uses only controller-visible telemetry. Diagnostic truth is
reported separately and never feeds control.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from statistics import median


def wrap_deg(value: float) -> float:
    return (float(value) + 180.0) % 360.0 - 180.0


def load_rows(path: Path) -> list[dict]:
    rows=[]
    for line in path.read_text(encoding='utf-8').splitlines():
        if line.strip(): rows.append(json.loads(line))
    return rows


def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument('trace')
    ap.add_argument('--output-json')
    ap.add_argument('--output-md')
    args=ap.parse_args()
    path=Path(args.trace)
    rows=load_rows(path)
    if not rows:
        raise ValueError('empty trace')

    use_jump_time=None
    prev_use=0
    last_dec={}
    strict_gaps=[]
    truth_ready=0
    for row in rows:
        d=row.get('decision') or {}
        last_dec=d
        use=int(d.get('carried_load_prelift_yaw_consensus_use_count') or 0)
        if use>prev_use and use_jump_time is None:
            use_jump_time=float((row.get('ground_truth_observation') or {}).get('sim_time', 0.0))
        prev_use=use
        cy=d.get('strict_release_certification_yaw_error_deg')
        ym=d.get('strict_release_yaw_margin_deg')
        if cy is not None and ym is not None:
            strict_gaps.append(abs(float(cy))+float(ym)-4.6)
        gt=row.get('ground_truth_observation') or {}
        pallet=gt.get('pallet_pose_in_base') or {}
        target=gt.get('placement_pose_in_base') or {}
        if pallet and target:
            pos=math.hypot(float(target['x'])-float(pallet['x']), float(target['y'])-float(pallet['y']))
            yaw=abs(wrap_deg(math.degrees(float(target['yaw'])-float(pallet['yaw']))))
            if pos<0.10 and yaw<5.0:
                truth_ready+=1

    sample_count=int(last_dec.get('carried_load_prelift_yaw_consensus_sample_count') or 0)
    consensus_yaw=last_dec.get('carried_load_prelift_yaw_consensus_world_yaw_deg')
    spread=last_dec.get('carried_load_prelift_yaw_consensus_spread_deg')
    age=last_dec.get('carried_load_prelift_yaw_consensus_age_seconds')
    delta=last_dec.get('carried_load_prelift_yaw_consensus_delta_from_legacy_deg')
    use_count=int(last_dec.get('carried_load_prelift_yaw_consensus_use_count') or 0)
    fallback=int(last_dec.get('carried_load_prelift_yaw_consensus_fallback_count') or 0)
    legacy_yaw=None
    if consensus_yaw is not None and delta is not None:
        legacy_yaw=wrap_deg(float(consensus_yaw)-float(delta))

    gt_seed_world_yaw=None
    legacy_err=None
    consensus_err=None
    if use_jump_time is not None:
        row=min(rows, key=lambda r: abs(float((r.get('ground_truth_observation') or {}).get('sim_time', 1e9))-use_jump_time))
        gt_pose=(row.get('ground_truth_observation') or {}).get('pallet_pose_world') or {}
        if gt_pose.get('yaw') is not None:
            gt_seed_world_yaw=math.degrees(float(gt_pose['yaw']))
            if legacy_yaw is not None: legacy_err=abs(wrap_deg(legacy_yaw-gt_seed_world_yaw))
            if consensus_yaw is not None: consensus_err=abs(wrap_deg(float(consensus_yaw)-gt_seed_world_yaw))

    result={
        'trace': str(path),
        'samples': len(rows),
        'consensus_use_count': use_count,
        'consensus_fallback_count': fallback,
        'consensus_sample_count_final': sample_count,
        'consensus_world_yaw_deg_final': consensus_yaw,
        'consensus_spread_deg_final': spread,
        'consensus_age_seconds_final': age,
        'consensus_delta_from_legacy_deg': delta,
        'first_consensus_use_time_s': use_jump_time,
        'minimum_strict_effective_yaw_gap_deg': min(strict_gaps) if strict_gaps else None,
        'truth_ready_frame_count_diagnostic': truth_ready,
        'strict_certified_final': bool(last_dec.get('strict_release_certified', False)),
        'strict_blocker_final': last_dec.get('strict_release_certification_blocker'),
        'release_commit_count_final': int(last_dec.get('placement_release_commit_count') or 0),
        'diagnostic_gt_seed_world_yaw_deg': gt_seed_world_yaw,
        'diagnostic_legacy_seed_abs_yaw_error_deg': legacy_err,
        'diagnostic_consensus_seed_abs_yaw_error_deg': consensus_err,
        'diagnostic_seed_abs_yaw_error_improvement_deg': (
            None if legacy_err is None or consensus_err is None else legacy_err-consensus_err
        ),
    }
    print('V9.3.12-R4-E8 pre-lift yaw consensus analysis')
    for k,v in result.items(): print(f'  {k}: {v}')
    if args.output_json:
        Path(args.output_json).write_text(json.dumps(result, indent=2),encoding='utf-8')
    if args.output_md:
        lines=['# V9.3.12-R4-E8 pre-lift yaw consensus analysis','']
        lines += [f'- **{k}**: {v}' for k,v in result.items()]
        Path(args.output_md).write_text('\n'.join(lines)+'\n',encoding='utf-8')
    return 0

if __name__=='__main__':
    raise SystemExit(main())
