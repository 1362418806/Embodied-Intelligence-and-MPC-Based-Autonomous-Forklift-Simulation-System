"""State-machine tests for V5.2 centreline gates."""

from __future__ import annotations

from pathlib import Path

import yaml

from control.docking_controller import DockingController
from interfaces.observation import ForkliftObservation, Pose3D
from task.pickup_state_machine import (
    PickupParameters,
    PickupState,
    PickupStateMachine,
)


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def pose(x=0.0, y=0.0, yaw=0.0) -> Pose3D:
    return Pose3D(x=x, y=y, z=0.0, roll=0.0, pitch=0.0, yaw=yaw)


def observation(
    sim_time: float,
    *,
    pallet_x: float,
    pallet_y: float = 0.0,
    pallet_yaw: float = 0.0,
) -> ForkliftObservation:
    return ForkliftObservation(
        sim_time=sim_time,
        vehicle_pose_world=pose(),
        vehicle_linear_velocity=(0.0, 0.0, 0.0),
        vehicle_angular_velocity=(0.0, 0.0, 0.0),
        steering_left=0.0,
        steering_right=0.0,
        front_wheel_speed_left=0.0,
        front_wheel_speed_right=0.0,
        lift_position=0.04,
        lift_velocity=0.0,
        pallet_pose_world=pose(3.2),
        pallet_pose_in_base=pose(
            pallet_x,
            pallet_y,
            pallet_yaw,
        ),
        placement_pose_in_base=pose(5.0, -1.0),
        fork_contact_count=0,
        load_state="GROUND",
    )


def load_machine() -> PickupStateMachine:
    config_path = PROJECT_ROOT / "configs" / "vehicle_v5_2.yaml"
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    values = config["controller"]
    controller = DockingController(
        distance_gain=float(values["distance_gain"]),
        heading_gain=float(values["heading_gain"]),
        yaw_gain=float(values["yaw_gain"]),
        lateral_gain=float(values["lateral_gain"]),
        lookahead_distance=float(values["lookahead_distance"]),
        maximum_steering=float(values["maximum_steering"]),
        minimum_creep_speed=float(values["minimum_creep_speed"]),
        heading_slowdown_angle=float(values["heading_slowdown_angle"]),
        yaw_slowdown_angle=float(values["yaw_slowdown_angle"]),
        minimum_alignment_scale=float(values["minimum_alignment_scale"]),
    )
    return PickupStateMachine(
        parameters=PickupParameters.from_mapping(config["autonomy"]),
        docking_controller=controller,
    )


def enter_approach(machine: PickupStateMachine) -> None:
    machine.reset(0.0)
    decision = machine.step(observation(0.30, pallet_x=4.0))
    assert decision.state == PickupState.APPROACH


def test_approach_uses_longitudinal_gate_not_exact_standoff_point() -> None:
    machine = load_machine()
    enter_approach(machine)
    decision = machine.step(
        observation(
            0.40,
            pallet_x=3.24,
            pallet_y=0.08,
            pallet_yaw=0.02,
        )
    )
    assert decision.state == PickupState.ALIGN
    assert decision.action.speed_target == 0.0


def test_alignment_hands_off_after_centreline_gate_is_held() -> None:
    machine = load_machine()
    enter_approach(machine)
    machine.step(observation(0.40, pallet_x=3.20))
    first = machine.step(
        observation(
            0.50,
            pallet_x=2.75,
            pallet_y=0.05,
            pallet_yaw=0.02,
        )
    )
    assert first.state == PickupState.ALIGN
    assert first.action.speed_target == 0.0
    second = machine.step(
        observation(
            0.70,
            pallet_x=2.75,
            pallet_y=0.05,
            pallet_yaw=0.02,
        )
    )
    assert second.state == PickupState.INSERT


def test_insert_completion_depends_on_longitudinal_and_line_errors() -> None:
    machine = load_machine()
    machine.state = PickupState.INSERT
    machine._state_enter_time = 0.0
    decision = machine.step(
        observation(
            1.0,
            pallet_x=1.64,
            pallet_y=0.02,
            pallet_yaw=0.01,
        )
    )
    assert decision.state == PickupState.LIFT


def test_insert_recovers_when_corridor_is_lost() -> None:
    machine = load_machine()
    machine.state = PickupState.INSERT
    machine._state_enter_time = 0.0
    decision = machine.step(
        observation(
            1.0,
            pallet_x=2.20,
            pallet_y=0.25,
            pallet_yaw=0.15,
        )
    )
    assert decision.state == PickupState.RECOVER_REVERSE
