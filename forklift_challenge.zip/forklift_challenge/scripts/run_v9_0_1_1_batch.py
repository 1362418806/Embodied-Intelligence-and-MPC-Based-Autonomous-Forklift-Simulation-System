"""Batch evaluation for V9.0.1.1 dual-colour pocket pickup and placement missions."""

from __future__ import annotations

import argparse
from datetime import datetime
from pathlib import Path
import sys
from typing import Any

import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from evaluation.dual_vision_metrics import write_dual_vision_results
from scenarios.randomization import ScenarioSampler
from simulator.dual_vision_mission_episode import run_vision_mission_episode


DEFAULT_CONFIG = PROJECT_ROOT / "configs" / "vehicle_v9_0_1_1.yaml"


def load_config(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise FileNotFoundError(f"configuration file does not exist: {path}")
    with path.open("r", encoding="utf-8") as stream:
        config = yaml.safe_load(stream)
    if not isinstance(config, dict):
        raise ValueError("configuration root must be a mapping")
    if "perception" not in config:
        raise KeyError("perception")
    return config


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--episodes", type=int, default=20)
    parser.add_argument("--seed", type=int)
    parser.add_argument("--difficulty", choices=ScenarioSampler.difficulties())
    parser.add_argument("--profile", choices=("clean", "moderate", "finals"))
    parser.add_argument(
        "--appearance-profile",
        choices=("clean", "moderate", "finals", "combined"),
    )
    parser.add_argument("--output", type=Path)
    parser.add_argument("--max-time", type=float)
    parser.add_argument("--trace-failures", action="store_true")
    parser.add_argument("--trace-all", action="store_true")
    parser.add_argument("--require-success-rate", type=float, default=0.0)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    config = load_config(args.config.resolve())
    seed = int(
        args.seed
        if args.seed is not None
        else config["randomization"]["default_seed"]
    )
    difficulty = str(
        args.difficulty
        if args.difficulty is not None
        else config["randomization"]["default_difficulty"]
    )
    profile = str(
        args.profile
        if args.profile is not None
        else config["perception"]["default_profile"]
    )
    appearance_profile = str(
        args.appearance_profile
        if args.appearance_profile is not None
        else config["appearance_stress"]["default_profile"]
    )
    sampler = ScenarioSampler(seed=seed, difficulty=difficulty)
    scenarios = [sampler.sample() for _ in range(args.episodes)]
    output = (
        args.output.resolve()
        if args.output
        else (
            PROJECT_ROOT
            / config["batch"]["output_root"]
            / (
                f"batch_{datetime.now().strftime('%Y%m%d_%H%M%S')}_"
                f"{profile}_{appearance_profile}"
            )
        ).resolve()
    )
    output.mkdir(parents=True, exist_ok=True)
    results = []
    print(
        f"Running {len(scenarios)} V9.0.1.1 dual-vision missions | seed={seed} | "
        f"difficulty={difficulty} | profile={profile} | "
        f"appearance={appearance_profile} | output={output}"
    )
    for index, scenario in enumerate(scenarios, 1):
        trace = (
            output / "traces" / f"{scenario.scenario_id}.jsonl"
            if args.trace_all
            else None
        )
        result = run_vision_mission_episode(
            config,
            scenario,
            profile_name=profile,
            appearance_profile_name=appearance_profile,
            max_episode_seconds=args.max_time,
            trace_path=trace,
        )
        results.append(result)
        verdict = "PASS" if result.success else "FAIL"
        reason = "" if result.success else f" | {result.failure_reason}"
        print(
            f"[{index:02d}/{len(scenarios):02d}] {verdict} "
            f"{scenario.scenario_id:<16} t={result.duration_seconds:5.1f}s "
            f"place={result.final_placement_error_m:.3f}m "
            f"vision={result.vision_detection_rate:.0%} "
            f"vision_rmse="
            f"{result.vision_position_rmse_m if result.vision_position_rmse_m is not None else float('nan'):.3f}m "
            f"pose_rmse={result.pallet_position_rmse_m:.3f}/"
            f"{result.placement_position_rmse_m:.3f}m{reason}"
        )
        if args.trace_failures and not result.success and trace is None:
            run_vision_mission_episode(
                config,
                scenario,
                profile_name=profile,
                appearance_profile_name=appearance_profile,
                max_episode_seconds=args.max_time,
                trace_path=output
                / "failure_traces"
                / f"{scenario.scenario_id}.jsonl",
            )

    summary = write_dual_vision_results(output, results)
    print("\nV9.0.1.1 appearance-stress mission summary")
    print(f"  success: {summary['success_count']}/{summary['episode_count']}")
    print(f"  success_rate: {summary['success_rate']:.1%}")
    print(
        "  avg_success_placement_error: "
        f"{summary['average_success_placement_error_m']}"
    )
    print(
        "  estimate_rmse pallet/placement: "
        f"{summary['average_pallet_position_rmse_m']:.3f}/"
        f"{summary['average_placement_position_rmse_m']:.3f}m"
    )
    print(
        "  pallet-pocket overall/opportunity/use: "
        f"{summary['average_pickup_vision_detection_rate']:.1%}/"
        f"{summary['average_pickup_vision_opportunity_detection_rate']:.1%}/"
        f"{summary['pickup_vision_use_rate']:.1%}"
    )
    print(
        "  pallet-pocket raw/fused RMSE: "
        f"{summary['average_pickup_vision_position_rmse_m']}/"
        f"{summary['average_pickup_vision_fused_position_rmse_m']}m"
    )
    print(
        "  pallet-pocket APPROACH/ALIGN/INSERT: "
        f"{summary['average_pickup_vision_detection_rate_approach']:.1%}/"
        f"{summary['average_pickup_vision_detection_rate_align']:.1%}/"
        f"{summary['average_pickup_vision_detection_rate_insert']:.1%}"
    )
    print(
        "  pickup acquisition/preinsert ready/first preinsert: "
        f"{summary['pickup_vision_acquisition_rate']:.1%}/"
        f"{summary['pickup_vision_preinsert_ready_rate']:.1%}/"
        f"{summary['pickup_vision_first_detection_preinsert_rate']:.1%}"
    )
    print(
        "  pickup measurement raw/rejected/control exceedances: "
        f"{summary['total_pickup_vision_raw_outlier_count']}/"
        f"{summary['total_pickup_vision_innovation_rejected_count']}/"
        f"{summary['total_pickup_vision_control_accepted_outlier_count']}"
    )
    print(
        "  pickup guide/innovation rejections: "
        f"{summary['total_pickup_vision_measurement_guide_rejected_count']}/"
        f"{summary['total_pickup_vision_innovation_rejected_count']}"
    )
    print(
        "  pickup accepted measurements/severe outliers: "
        f"{summary['total_pickup_vision_control_accepted_measurement_count']}/"
        f"{summary['total_pickup_vision_control_accepted_severe_outlier_count']}"
    )
    print(
        "  detector-only position/yaw RMSE: "
        f"{summary['average_pickup_detector_raw_position_rmse_m']}/"
        f"{summary['average_pickup_detector_raw_yaw_rmse_deg']}"
    )
    print(
        "  pickup raw/fused yaw RMSE and P95: "
        f"{summary['average_pickup_vision_yaw_rmse_deg']}/"
        f"{summary['average_pickup_vision_fused_yaw_rmse_deg']} deg | "
        f"{summary['average_pickup_vision_raw_yaw_p95_deg']}/"
        f"{summary['average_pickup_vision_fused_yaw_p95_deg']} deg"
    )
    print(
        "  RGB marker detection/rmse/use: "
        f"{summary['average_vision_detection_rate']:.1%}/"
        f"{summary['average_vision_position_rmse_m']}/"
        f"{summary['vision_terminal_use_rate']:.1%}"
    )
    print(
        "  render retries/failures/context warnings: "
        f"{summary['render_retry_count']}/"
        f"{summary['render_failure_count']}/"
        f"{summary['render_context_warning_count']}"
    )
    print(
        "  appearance frames/dropout/blur/occlusion: "
        f"{summary['appearance_frame_count']}/"
        f"{summary['appearance_dropout_count']}/"
        f"{summary['appearance_blur_count']}/"
        f"{summary['appearance_occlusion_count']}"
    )
    print(
        "  pickup arbitration high/medium/reject: "
        f"{summary['pickup_vision_high_confidence_count']}/"
        f"{summary['pickup_vision_medium_confidence_count']}/"
        f"{summary['pickup_vision_confidence_rejection_count']}"
    )
    print(
        "  placement arbitration high/medium/reject/guide: "
        f"{summary['vision_high_confidence_count']}/"
        f"{summary['vision_medium_confidence_count']}/"
        f"{summary['vision_confidence_rejection_count']}/"
        f"{summary['vision_guide_rejection_count']}"
    )
    print(f"  results: {output}")
    return 2 if summary["success_rate"] < args.require_success_rate else 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (FileNotFoundError, KeyError, RuntimeError, ValueError, yaml.YAMLError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
