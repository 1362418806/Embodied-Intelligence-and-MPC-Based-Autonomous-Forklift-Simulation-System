"""Static/invariant audit for V9.3.12-R4-E7 target-yaw witness."""
from __future__ import annotations

import math
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[1]


def check(name: str, ok: bool) -> None:
    print(f"{'PASS' if ok else 'FAIL'} {name}")
    if not ok:
        raise AssertionError(name)


def main() -> int:
    py_files = [
        ROOT / "perception" / "color_marker_detector.py",
        ROOT / "perception" / "vision_placement.py",
        ROOT / "task" / "pickup_state_machine.py",
        ROOT / "control" / "terminal_micro_primitives.py",
        ROOT / "control" / "terminal_mpc.py",
        ROOT / "evaluation" / "dual_vision_metrics.py",
        ROOT / "simulator" / "dual_vision_mission_episode.py",
        ROOT / "scripts" / "run_v9_3_12_r4_e7_batch.py",
        ROOT / "scripts" / "analyze_v9_3_12_r4_e7_target_yaw_witness.py",
        ROOT / "scripts" / "evaluate_v9_3_12_r4_e7_precision_closure.py",
    ]
    for path in py_files:
        compile(path.read_text(encoding="utf-8"), str(path), "exec")
    check("Python syntax", True)

    cfg = yaml.safe_load(
        (ROOT / "configs" / "vehicle_v9_3_12_r4_e7.yaml").read_text(encoding="utf-8")
    )
    weak = cfg["vision"]["profiles"]["weak_guide"]
    base = cfg["autonomy"]
    tauto = cfg["perception"]["terminal_autonomy_overrides"]["weak_guide"]
    detector = (ROOT / "perception" / "color_marker_detector.py").read_text(encoding="utf-8")
    vision = (ROOT / "perception" / "vision_placement.py").read_text(encoding="utf-8")
    state = (ROOT / "task" / "pickup_state_machine.py").read_text(encoding="utf-8")

    check("E7 centre yaw witness enabled", bool(weak["center_yaw_witness_enabled"]))
    check("full centre yaw weight", math.isclose(float(weak["center_yaw_witness_weight"]), 1.0))
    check("short online witness window", int(weak["center_yaw_witness_window"]) == 5)
    check("requires >=3 consistent witness frames", int(weak["center_yaw_witness_minimum_consistent_samples"]) >= 3)
    check("witness spread gate <=0.5deg", float(weak["center_yaw_witness_max_delta_spread_deg"]) <= 0.5)
    check("witness yaw disagreement bounded <=3deg", float(weak["center_yaw_witness_max_yaw_disagreement_deg"]) <= 3.0)
    check("witness position disagreement bounded <=6cm", float(weak["center_yaw_witness_max_position_disagreement_m"]) <= 0.06)

    # Other vision profiles must not be implicitly enabled by defaults.
    for name in ("clean", "moderate", "finals"):
        profile = cfg["vision"]["profiles"][name]
        check(
            f"{name} witness not enabled",
            not bool(profile.get("center_yaw_witness_enabled", False)),
        )

    check("legacy 16-corner primary PnP retained", "object_rows.append" in detector and "image_rows.append" in detector)
    check("centre PnP is a second passive solve", "center_solved = self._solve_pose" in detector)
    check("primary acceptance independent of centre witness", "accepted = (" in detector and "center_target_pose" not in detector[detector.index("accepted = ("):detector.index("if accepted:", detector.index("accepted = ("))])
    check("legacy x/y retained by witness", "x=float(legacy.x)" in vision and "y=float(legacy.y)" in vision)
    check("online temporal consensus used", "center_yaw_witness_delta_history_rad" in vision and "median(self.center_yaw_witness_delta_history_rad)" in vision)
    check("no fixed historical yaw offset", "-1.3" not in vision and "-1.37" not in vision and "historical_offset" not in vision)
    check("terminal RGB pipeline unchanged active", tauto.get("terminal_load_reacquisition_enabled", 1.0) != 0.0)
    check("internal position contract unchanged", tauto["placement_strict_release_position_limit_m"] == 0.095)
    check("internal yaw contract unchanged", math.isclose(tauto["placement_strict_release_yaw_limit_rad"], math.radians(4.6), rel_tol=1e-9))
    check("terminal budget unchanged", tauto["placement_terminal_budget_seconds"] == 90.0)
    check("consensus release authority OFF", tauto["placement_certified_basin_consensus_release_authority"] == 0.0)
    check("release chain not bypassed", "ReleaseDecisionSupervisor" in state and "RELEASE_INTENT executed" in state)
    check("no GT in runtime witness", "ground_truth" not in vision.lower() and "ground_truth" not in detector.lower())

    print("\nV9.3.12-R4-E7 audit PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
