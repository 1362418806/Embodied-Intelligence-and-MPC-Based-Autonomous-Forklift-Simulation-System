"""Static/invariant audit for V9.3.12-R4-F3 axis-separated yaw evidence."""
from __future__ import annotations

import copy
import math
from pathlib import Path
import py_compile
import sys

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def check(name: str, ok: bool) -> None:
    print(f"{'PASS' if ok else 'FAIL'} {name}")
    if not ok:
        raise AssertionError(name)


def main() -> int:
    compile_files = (
        "control/carried_load_observer.py",
        "control/carried_load_yaw_anchor.py",
        "task/pickup_state_machine.py",
        "evaluation/dual_vision_metrics.py",
        "simulator/dual_vision_mission_episode.py",
        "scripts/analyze_v9_3_12_r4_f3_axis_yaw_evidence.py",
        "scripts/run_v9_3_12_r4_f3_batch.py",
        "scripts/evaluate_v9_3_12_r4_f3_precision_closure.py",
    )
    for rel in compile_files:
        py_compile.compile(str(ROOT / rel), doraise=True)
        check(f"compile:{rel}", True)

    f2 = yaml.safe_load((ROOT / "configs" / "vehicle_v9_3_12_r4_f2.yaml").read_text(encoding="utf-8"))
    f3 = yaml.safe_load((ROOT / "configs" / "vehicle_v9_3_12_r4_f3.yaml").read_text(encoding="utf-8"))
    base = f3["autonomy"]
    weak = f3["perception"]["terminal_autonomy_overrides"]["weak_guide"]

    check("legacy/base F3 axis split remains disabled", base["placement_carried_yaw_axis_evidence_enabled"] == 0.0)
    check("weak-guide F3 axis split enabled", weak["placement_carried_yaw_axis_evidence_enabled"] == 1.0)
    check("F2 terminal yaw authority remains disabled", weak["placement_terminal_load_reacquisition_yaw_authority_enabled"] == 0.0)
    check("F1 late-insert anchor remains enabled", weak["placement_carried_visual_yaw_anchor_enabled"] == 1.0)

    # Prove F3 config changes no historical tuning knobs besides the new F3 flag.
    f3_cmp = copy.deepcopy(f3)
    f3_cmp["autonomy"].pop("placement_carried_yaw_axis_evidence_enabled", None)
    f3_cmp["perception"]["terminal_autonomy_overrides"]["weak_guide"].pop(
        "placement_carried_yaw_axis_evidence_enabled", None
    )
    check("F3 config has no collateral tuning drift", f3_cmp == f2)

    # Frozen release/safety contract.
    check("strict position remains 9.5cm", math.isclose(float(weak["placement_strict_release_position_limit_m"]), 0.095, abs_tol=1e-12))
    check("strict yaw remains 4.6deg", math.isclose(float(weak["placement_strict_release_yaw_limit_rad"]), math.radians(4.6), abs_tol=1e-12))
    check("observer 1deg yaw floor unchanged", math.isclose(float(weak["placement_carried_observer_minimum_yaw_sigma_rad"]), math.radians(1.0), abs_tol=1e-12))
    check("legacy observer initial yaw sigma remains 2deg", math.isclose(float(weak["placement_carried_observer_initial_yaw_sigma_rad"]), math.radians(2.0), abs_tol=1e-12))
    check("motion gate threshold remains historical 1.25deg", math.isclose(float(weak["placement_fresh_rgb_yaw_closure_maximum_observer_yaw_sigma_rad"]), math.radians(1.25), abs_tol=1e-12))
    check("yaw sigma gain unchanged", math.isclose(float(weak["placement_strict_release_yaw_sigma_gain"]), 0.22, abs_tol=1e-12))
    check("execution yaw reserve unchanged", math.isclose(float(weak["placement_strict_release_execution_yaw_reserve_rad"]), math.radians(0.4), abs_tol=1e-12))
    check("target yaw floor unchanged", math.isclose(float(weak["placement_strict_release_target_yaw_margin_floor_rad"]), math.radians(0.35), abs_tol=1e-12))
    check("consensus release authority remains off", float(weak["placement_certified_basin_consensus_release_authority"]) == 0.0)
    check("terminal budget remains 90s", math.isclose(float(weak["placement_terminal_budget_seconds"]), 90.0, abs_tol=1e-12))

    observer_source = (ROOT / "control" / "carried_load_observer.py").read_text(encoding="utf-8")
    check("observer accepts qualified initial yaw sigma", "initial_yaw_sigma_override_rad" in observer_source)
    check("anchor covariance cannot bypass minimum floor", "self.config.minimum_yaw_sigma_rad" in observer_source.split("def initialize(", 1)[1].split("def _update_fast", 1)[0])
    pos_only = observer_source.split("def update_position_only(", 1)[1].split("@property", 1)[0]
    check("F2 position-only observer path retained", "def update_position_only(" in observer_source)
    check("position-only path still preserves yaw variance", "self._yaw_var" not in pos_only)

    source = (ROOT / "task" / "pickup_state_machine.py").read_text(encoding="utf-8")
    check("axis-specific yaw stale helper exists", "def _carried_yaw_stale_for_release(" in source)
    check("motion/release yaw sigma split exists", "def _motion_carried_load_yaw_sigma_rad(" in source)
    check("F1 anchor seeds conservative yaw covariance", "initial_yaw_sigma_override_rad=yaw_sigma_override" in source)
    check("terminal position-only RGB resets translation debt only", "self._reset_translation_load_belief_reference(observation)" in source)
    check("terminal position-only RGB cannot refresh yaw evidence", "yaw_authority\n                and self.parameters.placement_carried_yaw_axis_evidence_enabled > 0.5" in source)
    check("three bounded E-series motion gates use motion sigma", source.count("self._motion_carried_load_yaw_sigma_rad()") >= 4)

    strict = source.split("def _strict_release_certified", 1)[1]
    check(
        "strict release still uses full release yaw risk",
        "p.placement_strict_release_yaw_sigma_gain\n            * self._effective_carried_load_yaw_sigma_rad()" in strict,
    )
    check(
        "consensus quality still uses full release yaw risk",
        "self._effective_carried_load_yaw_sigma_rad()\n                <= p.placement_certified_basin_consensus_max_load_yaw_sigma_rad" in strict,
    )
    check("no runtime truth use introduced by F3", "ground_truth" not in source)
    print("V9.3.12-R4-F3 static audit: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
