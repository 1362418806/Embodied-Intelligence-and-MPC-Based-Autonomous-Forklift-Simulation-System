"""Render raw/stressed fork RGB and verify V8.2 appearance pipeline."""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

import cv2
import mujoco
import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from perception.appearance_stress import AppearanceStressPipeline
from perception.pallet_pocket_detector import PalletPocketDetector
from scenarios.randomization import ScenarioSampler, apply_scenario
from simulator.camera_renderer import MultiCameraRenderer
from simulator.observation_builder import ObservationBuilder

DEFAULT_CONFIG = PROJECT_ROOT / "configs" / "vehicle_v9_1_2.yaml"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--seed", type=int, default=20260803)
    parser.add_argument(
        "--difficulty",
        choices=ScenarioSampler.difficulties(),
        default="easy",
    )
    parser.add_argument(
        "--appearance-profile",
        choices=("clean", "moderate", "finals", "combined"),
        default="moderate",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=PROJECT_ROOT / "outputs" / "v9_1_2_vision_smoke",
    )
    args = parser.parse_args()

    config = yaml.safe_load(args.config.read_text(encoding="utf-8"))
    model = mujoco.MjModel.from_xml_path(
        str((PROJECT_ROOT / config["model"]["xml_path"]).resolve())
    )
    data = mujoco.MjData(model)
    mujoco.mj_resetData(model, data)

    scenario = ScenarioSampler(
        seed=args.seed,
        difficulty=args.difficulty,
    ).sample()
    apply_scenario(model, data, scenario)

    stress = AppearanceStressPipeline.from_config(
        config["appearance_stress"],
        profile_name=args.appearance_profile,
        seed=scenario.seed,
        image_width=int(config["camera"]["width"]),
        image_height=int(config["camera"]["height"]),
    )
    stress.apply_camera_extrinsics(
        model,
        mujoco,
        (
            str(config["pickup_vision"]["camera_name"]),
            str(config["vision"]["camera_name"]),
        ),
    )

    lift_id = mujoco.mj_name2id(
        model,
        mujoco.mjtObj.mjOBJ_ACTUATOR,
        "lift_position",
    )
    data.ctrl[lift_id] = float(
        config["autonomy"]["insertion_lift_target"]
    )
    for _ in range(int(round(0.8 / model.opt.timestep))):
        mujoco.mj_step(model, data)

    renderer = MultiCameraRenderer(
        model,
        width=int(config["camera"]["width"]),
        height=int(config["camera"]["height"]),
    )
    raw = None
    stressed = None
    try:
        for _ in range(5):
            raw = renderer.render(
                data,
                str(config["pickup_vision"]["camera_name"]),
            )
            stressed = stress.apply(
                raw,
                channel="pickup",
            ).image
            if stressed is not None:
                break
    finally:
        renderer.close()
    if raw is None or stressed is None:
        print("appearance stress dropped all smoke attempts")
        print(stress.metrics())
        return 3

    detector = PalletPocketDetector.from_config(
        config["pickup_vision"],
        image_width=int(config["camera"]["width"]),
        image_height=int(config["camera"]["height"]),
    )
    truth = ObservationBuilder(model).build(
        data,
        fork_contact_count=0,
        load_state="GROUND",
    )
    detection = detector.detect(
        stressed,
        prior_pose_in_base=truth.pallet_pose_in_base,
    )
    annotated = detector.annotate(stressed, detection)
    masks = detector.debug_masks(stressed)

    args.output.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(
        str(args.output / "fork_rgb_raw.png"),
        cv2.cvtColor(raw, cv2.COLOR_RGB2BGR),
    )
    cv2.imwrite(
        str(args.output / "fork_rgb_stressed.png"),
        cv2.cvtColor(stressed, cv2.COLOR_RGB2BGR),
    )
    cv2.imwrite(
        str(args.output / "fork_rgb_stressed_pockets.png"),
        cv2.cvtColor(annotated, cv2.COLOR_RGB2BGR),
    )
    cv2.imwrite(str(args.output / "fork_rgb_left_mask.png"), masks["left"])
    cv2.imwrite(str(args.output / "fork_rgb_right_mask.png"), masks["right"])

    print(f"scenario: {scenario.scenario_id}")
    print(f"appearance_profile: {args.appearance_profile}")
    print(f"pocket_status: {detection.status}")
    print(f"confidence: {detection.confidence:.3f}")
    print(f"reprojection_error_px: {detection.reprojection_error_px}")
    print(f"stress: {stress.metrics()}")
    print(f"images: {args.output.resolve()}")
    return 0 if detection.success else 2


if __name__ == "__main__":
    raise SystemExit(main())
