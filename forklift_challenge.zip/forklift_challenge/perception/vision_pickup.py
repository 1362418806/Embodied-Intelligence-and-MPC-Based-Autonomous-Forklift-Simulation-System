"""State-aware RGB pallet-pose fusion for pickup alignment."""
from __future__ import annotations
from dataclasses import asdict, dataclass, replace
import math
from typing import Any, Mapping
import numpy as np
from interfaces.observation import ForkliftObservation, Pose3D
from perception.pallet_pocket_detector import PalletPocketDetection, PalletPocketDetector, wrap_angle
from perception.pose_pipeline import PerceptionFrame


def _state(value): return None if value is None else str(getattr(value,'value',value))
def _base_to_world(vehicle,pose):
    c=math.cos(vehicle.yaw); s=math.sin(vehicle.yaw)
    return Pose3D(x=vehicle.x+c*pose.x-s*pose.y,y=vehicle.y+s*pose.x+c*pose.y,z=vehicle.z+pose.z,roll=pose.roll,pitch=pose.pitch,yaw=wrap_angle(vehicle.yaw+pose.yaw))
def _world_to_base(vehicle,pose):
    dx=pose.x-vehicle.x; dy=pose.y-vehicle.y; c=math.cos(vehicle.yaw); s=math.sin(vehicle.yaw)
    return Pose3D(x=c*dx+s*dy,y=-s*dx+c*dy,z=pose.z-vehicle.z,roll=pose.roll,pitch=pose.pitch,yaw=wrap_angle(pose.yaw-vehicle.yaw))

@dataclass(frozen=True)
class VisionPickupProfile:
    enabled:bool; update_hz:float; active_states:frozenset[str]
    maximum_activation_distance_m:float; filter_alpha:float
    maximum_position_innovation_m:float; maximum_yaw_innovation_rad:float
    maximum_stale_seconds:float; require_detection_for_success:bool
    minimum_detections_for_success:int
    minimum_detections_before_insert:int=0
    preinsert_states:frozenset[str]=frozenset(
        {"APPROACH","ALIGN"}
    )
    measurement_position_visual_weight:float=1.0
    measurement_yaw_visual_weight:float=1.0
    maximum_measurement_guide_position_difference_m:float=float("inf")
    maximum_measurement_guide_yaw_difference_rad:float=float("inf")
    minimum_control_confidence:float=0.0
    high_confidence_threshold:float=0.0
    high_confidence_maximum_reprojection_error_px:float=float("inf")
    maximum_control_reprojection_error_px:float=float("inf")
    medium_position_visual_scale:float=1.0
    medium_yaw_visual_scale:float=1.0
    maximum_preinsert_ready_stale_seconds:float=float("inf")
    coarse_guide_prior:bool=False
    high_confidence_takeover_position_m:float=float("inf")
    high_confidence_takeover_yaw_rad:float=float("inf")
    visual_authority_latch_enabled:bool=False
    visual_authority_acquire_high_count:int=2
    visual_authority_release_stale_seconds:float=float("inf")
    @classmethod
    def from_mapping(cls,v:Mapping[str,Any]):
        r=cls(
            bool(v.get('enabled',True)),
            float(v.get('update_hz',10)),
            frozenset(
                str(x) for x in v.get(
                    'active_states',
                    ('APPROACH','ALIGN','INSERT','RECOVER_REVERSE'),
                )
            ),
            float(v.get('maximum_activation_distance_m',4.0)),
            float(v.get('filter_alpha',.62)),
            float(v.get('maximum_position_innovation_m',.75)),
            math.radians(
                float(v.get('maximum_yaw_innovation_deg',34))
            ),
            float(v.get('maximum_stale_seconds',3.8)),
            bool(v.get('require_detection_for_success',True)),
            int(v.get('minimum_detections_for_success',5)),
            int(v.get('minimum_detections_before_insert',0)),
            frozenset(
                str(x) for x in v.get(
                    'preinsert_states',
                    ('APPROACH','ALIGN'),
                )
            ),
            float(
                v.get(
                    'measurement_position_visual_weight',
                    1.0,
                )
            ),
            float(
                v.get(
                    'measurement_yaw_visual_weight',
                    1.0,
                )
            ),
            float(
                v.get(
                    'maximum_measurement_guide_position_difference_m',
                    float('inf'),
                )
            ),
            math.radians(
                float(
                    v.get(
                        'maximum_measurement_guide_yaw_difference_deg',
                        float('inf'),
                    )
                )
            ),
            float(v.get('minimum_control_confidence', 0.0)),
            float(v.get('high_confidence_threshold', 0.0)),
            float(
                v.get(
                    'high_confidence_maximum_reprojection_error_px',
                    float('inf'),
                )
            ),
            float(
                v.get(
                    'maximum_control_reprojection_error_px',
                    float('inf'),
                )
            ),
            float(v.get('medium_position_visual_scale', 1.0)),
            float(v.get('medium_yaw_visual_scale', 1.0)),
            float(
                v.get(
                    'maximum_preinsert_ready_stale_seconds',
                    float('inf'),
                )
            ),
            bool(v.get('coarse_guide_prior', False)),
            float(v.get('high_confidence_takeover_position_m', float('inf'))),
            math.radians(float(v.get('high_confidence_takeover_yaw_deg', float('inf')))),
            bool(v.get('visual_authority_latch_enabled', False)),
            int(v.get('visual_authority_acquire_high_count', 2)),
            float(v.get('visual_authority_release_stale_seconds', float('inf'))),
        )
        if (
            r.update_hz<=0
            or not r.active_states
            or r.maximum_activation_distance_m<=0
            or not 0<r.filter_alpha<=1
            or r.maximum_position_innovation_m<=0
            or r.maximum_yaw_innovation_rad<=0
            or r.maximum_stale_seconds<=0
            or r.minimum_detections_for_success<0
            or r.minimum_detections_before_insert<0
            or not r.preinsert_states
            or not 0.0 <= r.measurement_position_visual_weight <= 1.0
            or not 0.0 <= r.measurement_yaw_visual_weight <= 1.0
            or r.maximum_measurement_guide_position_difference_m <= 0.0
            or r.maximum_measurement_guide_yaw_difference_rad <= 0.0
            or not 0.0 <= r.minimum_control_confidence <= 1.0
            or not 0.0 <= r.high_confidence_threshold <= 1.0
            or r.high_confidence_threshold < r.minimum_control_confidence
            or r.high_confidence_maximum_reprojection_error_px <= 0.0
            or r.maximum_control_reprojection_error_px <= 0.0
            or r.high_confidence_maximum_reprojection_error_px
                > r.maximum_control_reprojection_error_px
            or not 0.0 < r.medium_position_visual_scale <= 1.0
            or not 0.0 < r.medium_yaw_visual_scale <= 1.0
            or r.maximum_preinsert_ready_stale_seconds <= 0.0
            or (r.coarse_guide_prior and (
                r.high_confidence_takeover_position_m
                <= r.maximum_measurement_guide_position_difference_m
                or r.high_confidence_takeover_yaw_rad
                <= r.maximum_measurement_guide_yaw_difference_rad
            ))
            or (r.visual_authority_latch_enabled and (
                not r.coarse_guide_prior
                or r.visual_authority_acquire_high_count <= 0
                or r.visual_authority_release_stale_seconds <= 0.0
            ))
        ):
            raise ValueError('invalid pickup vision profile')
        return r

@dataclass(frozen=True)
class VisionPickupDiagnostics:
    enabled:bool; active:bool; controller_state:str|None; status:str; pose_source:str
    sample_count:int; detection_count:int; rejection_count:int; detection_rate:float
    stale_seconds:float; confidence:float|None; reprojection_error_px:float|None
    pallet_distance_m:float|None; vision_used_for_pickup:bool; detector_status:str|None
    raw_detection_count:int; innovation_rejection_count:int
    detection_count_before_insert:int; minimum_detections_before_insert:int
    ready_for_insert:bool; first_detection_state:str|None
    solver_mode:str|None=None; solver_candidate_count:int=0
    prior_position_difference_m:float|None=None
    prior_yaw_difference_deg:float|None=None
    measurement_regularized:bool=False
    measurement_position_visual_weight:float=1.0
    measurement_yaw_visual_weight:float=1.0
    measurement_guide_rejection_count:int=0
    measurement_guide_position_difference_m:float|None=None
    measurement_guide_yaw_difference_deg:float|None=None
    confidence_class:str|None=None
    high_confidence_count:int=0
    medium_confidence_count:int=0
    confidence_rejection_count:int=0
    reacquire_required:bool=False
    preinsert_measurement_fresh:bool=False
    preinsert_ready_achieved:bool=False
    visual_authority:str='GLOBAL_POSE'
    visual_authority_lock_count:int=0
    visual_authority_unlock_count:int=0
    last_accepted_confidence:float|None=None
    last_accepted_reprojection_error_px:float|None=None
    last_accepted_detection_time:float|None=None
    def to_dict(self): return asdict(self)

@dataclass(frozen=True)
class VisionPickupFrame:
    observation:ForkliftObservation; diagnostics:VisionPickupDiagnostics
    detection_pose_in_base:Pose3D|None; detection:PalletPocketDetection|None
    detector_pose_in_base:Pose3D|None=None

class VisionPickupPipeline:
    def __init__(self, *, profile_name:str, profile:VisionPickupProfile, camera_name:str, detector:PalletPocketDetector):
        self.profile_name=profile_name; self.profile=profile; self.camera_name=camera_name; self.detector=detector; self.reset()
    @classmethod
    def from_config(cls, config:Mapping[str,Any], *, profile_name:str,image_width:int,image_height:int,detector=None):
        if profile_name not in config.get('profiles',{}): raise KeyError(f'pickup_vision.profiles.{profile_name}')
        return cls(profile_name=profile_name,profile=VisionPickupProfile.from_mapping(config['profiles'][profile_name]),camera_name=str(config.get('camera_name','fork_rgb')),detector=detector or PalletPocketDetector.from_config(config,image_width=image_width,image_height=image_height))
    def reset(self):
        self.next_sample_time=None
        self.last_time=None
        self.last_detection_time=None
        self.filtered_pallet_world=None
        self.sample_count=0
        self.raw_detection_count=0
        self.detection_count=0
        self.rejection_count=0
        self.innovation_rejection_count=0
        self.measurement_guide_rejection_count=0
        self.visual_takeover_count=0
        self.visual_authority_locked=False
        self.visual_authority_high_streak=0
        self.visual_authority_lock_count=0
        self.visual_authority_unlock_count=0
        self.high_confidence_count=0
        self.medium_confidence_count=0
        self.confidence_rejection_count=0
        self.reacquire_required=False
        self.last_confidence_class=None
        self.detection_count_before_insert=0
        self.preinsert_ready_achieved=False
        self.first_detection_state=None
        self.last_detection=None
        self.last_accepted_confidence=None
        self.last_accepted_reprojection_error_px=None
        self.last_accepted_detection_time=None
        self.last_status=(
            'disabled' if not self.profile.enabled else 'waiting'
        )
        self.ever_applied=False
        self.maximum_stale_seconds_observed=0.0
        self.detector.reset()
    def _active(self,observation,state):
        if not self.profile.enabled or state not in self.profile.active_states: return False
        p=observation.pallet_pose_in_base
        return math.hypot(float(p.x),float(p.y))<=self.profile.maximum_activation_distance_m
    def wants_image(self, *, sim_time:float,controller_state:Any|None,observation:ForkliftObservation)->bool:
        state=_state(controller_state)
        if not self._active(observation,state): return False
        now=float(sim_time)
        if self.last_time is not None and now+1e-9<self.last_time: return True
        return self.next_sample_time is None or now+1e-12>=self.next_sample_time
    def _schedule(self,now):
        period=1.0/self.profile.update_hz
        if self.next_sample_time is None: self.next_sample_time=now+period
        else:
            while self.next_sample_time<=now+1e-12: self.next_sample_time+=period
    def _regularize_measurement(
        self,
        *,
        visual_pose: Pose3D,
        prior_pose: Pose3D,
        position_scale: float = 1.0,
        yaw_scale: float = 1.0,
    ) -> Pose3D:
        position_weight = (
            self.profile.measurement_position_visual_weight
            * float(position_scale)
        )
        yaw_weight = (
            self.profile.measurement_yaw_visual_weight
            * float(yaw_scale)
        )
        return Pose3D(
            x=prior_pose.x
            + position_weight * (visual_pose.x - prior_pose.x),
            y=prior_pose.y
            + position_weight * (visual_pose.y - prior_pose.y),
            z=visual_pose.z,
            roll=0.0,
            pitch=0.0,
            yaw=wrap_angle(
                prior_pose.yaw
                + yaw_weight
                * wrap_angle(visual_pose.yaw - prior_pose.yaw)
            ),
        )

    def _measurement_matches_guide(
        self,
        *,
        measurement: Pose3D,
        guide: Pose3D,
    ) -> tuple[bool, float, float]:
        position_difference = math.hypot(
            measurement.x - guide.x,
            measurement.y - guide.y,
        )
        yaw_difference = abs(
            wrap_angle(measurement.yaw - guide.yaw)
        )
        return (
            position_difference
            <= self.profile.maximum_measurement_guide_position_difference_m
            and yaw_difference
            <= self.profile.maximum_measurement_guide_yaw_difference_rad,
            position_difference,
            yaw_difference,
        )

    def _confidence_class(
        self,
        detection: PalletPocketDetection,
    ) -> str:
        confidence = float(detection.confidence)
        reprojection = (
            float('inf')
            if detection.reprojection_error_px is None
            else float(detection.reprojection_error_px)
        )
        if (
            confidence < self.profile.minimum_control_confidence
            or reprojection
            > self.profile.maximum_control_reprojection_error_px
        ):
            return 'reject'
        if (
            confidence >= self.profile.high_confidence_threshold
            and reprojection
            <= self.profile.high_confidence_maximum_reprojection_error_px
        ):
            return 'high'
        return 'medium'

    def _preinsert_measurement_fresh(self) -> bool:
        if self.last_detection_time is None or self.last_time is None:
            return False
        return (
            max(0.0, self.last_time - self.last_detection_time)
            <= self.profile.maximum_preinsert_ready_stale_seconds
        )

    def _filter(self,m):
        if self.filtered_pallet_world is None: self.filtered_pallet_world=m; return True
        old=self.filtered_pallet_world; pos=math.hypot(m.x-old.x,m.y-old.y); yaw=abs(wrap_angle(m.yaw-old.yaw))
        if pos>self.profile.maximum_position_innovation_m or yaw>self.profile.maximum_yaw_innovation_rad: return False
        a=self.profile.filter_alpha
        self.filtered_pallet_world=Pose3D(x=old.x+a*(m.x-old.x),y=old.y+a*(m.y-old.y),z=old.z+a*(m.z-old.z),roll=0,pitch=0,yaw=wrap_angle(old.yaw+a*wrap_angle(m.yaw-old.yaw)))
        return True
    def ready_for_insert(self)->bool:
        count_ready = (
            self.profile.minimum_detections_before_insert <= 0
            or self.detection_count_before_insert
            >= self.profile.minimum_detections_before_insert
        )
        if not count_ready:
            return False
        if self.profile.minimum_detections_before_insert <= 0:
            return True
        return (
            not self.reacquire_required
            and self._preinsert_measurement_fresh()
        )

    def _update_preinsert_ready_latch(
        self,
        *,
        state: str,
    ) -> None:
        if state not in self.profile.preinsert_states:
            return
        if (
            self.detection_count_before_insert
            < self.profile.minimum_detections_before_insert
        ):
            return
        if self.reacquire_required:
            return
        if not self._preinsert_measurement_fresh():
            return
        self.preinsert_ready_achieved=True

    def meets_success_requirement(self):
        return (
            not self.profile.require_detection_for_success
            or (
                self.detection_count
                >= self.profile.minimum_detections_for_success
                and (
                    self.profile.minimum_detections_before_insert <= 0
                    or self.preinsert_ready_achieved
                )
                and self.ever_applied
            )
        )
    def step(self, *, frame:PerceptionFrame,rgb:np.ndarray|None,controller_state:Any|None=None)->VisionPickupFrame:
        estimated=frame.observation; now=float(estimated.sim_time)
        if self.last_time is not None and now+1e-9<self.last_time: self.reset()
        self.last_time=now
        state=_state(controller_state)
        active=self._active(estimated,state)
        detection=None
        detection_pose=None
        detector_pose=None
        guide_position_difference=None
        guide_yaw_difference=None
        accepted=False
        due=active and (self.next_sample_time is None or now+1e-12>=self.next_sample_time)
        if due:
            self._schedule(now); self.sample_count+=1
            if rgb is None: self.rejection_count+=1; self.last_status='render_missing'
            else:
                try:
                    detection=self.detector.detect(
                        rgb,
                        prior_pose_in_base=estimated.pallet_pose_in_base,
                    )
                except TypeError as exc:
                    if "prior_pose_in_base" not in str(exc):
                        raise
                    detection=self.detector.detect(rgb)
                self.last_detection=detection
                if detection.success and detection.pallet_pose_in_base is not None:
                    self.raw_detection_count+=1
                    detector_pose=detection.pallet_pose_in_base
                    confidence_class=self._confidence_class(detection)
                    self.last_confidence_class=confidence_class
                    if confidence_class == 'reject':
                        self.rejection_count+=1
                        self.confidence_rejection_count+=1
                        if state in self.profile.preinsert_states:
                            self.reacquire_required=True
                        self.last_status='confidence_rejected'
                        detection_pose=None
                    else:
                        if confidence_class == 'high':
                            self.high_confidence_count+=1
                            position_scale=1.0
                            yaw_scale=1.0
                        else:
                            self.medium_confidence_count+=1
                            position_scale=(
                                self.profile.medium_position_visual_scale
                            )
                            yaw_scale=(
                                self.profile.medium_yaw_visual_scale
                            )
                        if (
                            self.profile.coarse_guide_prior
                            and self.visual_authority_locked
                        ):
                            detection_pose=detector_pose
                        else:
                            detection_pose=self._regularize_measurement(
                                visual_pose=detector_pose,
                                prior_pose=estimated.pallet_pose_in_base,
                                position_scale=position_scale,
                                yaw_scale=yaw_scale,
                            )
                    if detection_pose is not None:
                        (
                            guide_ok,
                            guide_position_difference,
                            guide_yaw_difference,
                        ) = self._measurement_matches_guide(
                            measurement=detection_pose,
                            guide=estimated.pallet_pose_in_base,
                        )
                        if (
                            self.profile.coarse_guide_prior
                            and self.visual_authority_locked
                        ):
                            guide_ok=True
                        world=_base_to_world(
                            estimated.vehicle_pose_world,
                            detection_pose,
                        )
                    else:
                        guide_ok=False
                        world=None
                    takeover=False
                    if (
                        detection_pose is not None
                        and not guide_ok
                        and self.profile.coarse_guide_prior
                        and confidence_class == 'high'
                        and detector_pose is not None
                    ):
                        raw_position_difference=math.hypot(
                            detector_pose.x-estimated.pallet_pose_in_base.x,
                            detector_pose.y-estimated.pallet_pose_in_base.y,
                        )
                        raw_yaw_difference=abs(wrap_angle(
                            detector_pose.yaw-estimated.pallet_pose_in_base.yaw
                        ))
                        takeover=(
                            raw_position_difference
                            <= self.profile.high_confidence_takeover_position_m
                            and raw_yaw_difference
                            <= self.profile.high_confidence_takeover_yaw_rad
                        )
                    if detection_pose is None:
                        pass
                    elif not guide_ok and not takeover:
                        self.rejection_count+=1
                        self.measurement_guide_rejection_count+=1
                        if state in self.profile.preinsert_states:
                            self.reacquire_required=True
                        self.last_status='measurement_guide_rejected'
                    elif self._filter(world):
                        if takeover:
                            self.visual_takeover_count+=1
                        self.detection_count+=1
                        if state in self.profile.preinsert_states:
                            self.detection_count_before_insert+=1
                        if self.first_detection_state is None:
                            self.first_detection_state=state
                        self.last_detection_time=now
                        self.last_accepted_confidence=float(detection.confidence)
                        self.last_accepted_reprojection_error_px=(
                            None if detection.reprojection_error_px is None
                            else float(detection.reprojection_error_px)
                        )
                        self.last_accepted_detection_time=now
                        self.reacquire_required=False
                        self.last_status='vision_accepted'
                        accepted=True
                        if self.profile.visual_authority_latch_enabled:
                            if confidence_class == 'high':
                                self.visual_authority_high_streak+=1
                            else:
                                self.visual_authority_high_streak=max(0,self.visual_authority_high_streak-1)
                            if (
                                not self.visual_authority_locked
                                and self.visual_authority_high_streak
                                >= self.profile.visual_authority_acquire_high_count
                            ):
                                self.visual_authority_locked=True
                                self.visual_authority_lock_count+=1
                        self._update_preinsert_ready_latch(
                            state=state,
                        )
                    else:
                        self.rejection_count+=1
                        self.innovation_rejection_count+=1
                        if state in self.profile.preinsert_states:
                            self.reacquire_required=True
                        self.last_status='innovation_rejected'
                else: self.rejection_count+=1; self.last_status=f'pockets_{detection.status}' if detection else 'pockets_failed'
        stale=math.inf if self.last_detection_time is None else max(0.0,now-self.last_detection_time)
        if math.isfinite(stale): self.maximum_stale_seconds_observed=max(self.maximum_stale_seconds_observed,stale)
        if (
            self.profile.visual_authority_latch_enabled
            and self.visual_authority_locked
            and stale > self.profile.visual_authority_release_stale_seconds
        ):
            self.visual_authority_locked=False
            self.visual_authority_high_streak=0
            self.visual_authority_unlock_count+=1
        source='global_pose'
        if active and self.filtered_pallet_world is not None and stale<=self.profile.maximum_stale_seconds:
            estimated=replace(estimated,pallet_pose_in_base=_world_to_base(estimated.vehicle_pose_world,self.filtered_pallet_world)); source='rgb_pockets' if accepted else 'rgb_pocket_world_hold'; self.ever_applied=True
        elif active and self.filtered_pallet_world is not None: self.last_status='vision_stale_fallback'
        last=detection or self.last_detection
        return VisionPickupFrame(
            estimated,
            VisionPickupDiagnostics(
                self.profile.enabled,
                active,
                state,
                self.last_status,
                source,
                self.sample_count,
                self.detection_count,
                self.rejection_count,
                self.detection_count/max(1,self.sample_count),
                stale if math.isfinite(stale) else -1.0,
                None if last is None else last.confidence,
                None if last is None else last.reprojection_error_px,
                None if last is None else last.pallet_distance_m,
                self.ever_applied,
                None if last is None else last.status,
                self.raw_detection_count,
                self.innovation_rejection_count,
                self.detection_count_before_insert,
                self.profile.minimum_detections_before_insert,
                self.ready_for_insert(),
                self.first_detection_state,
                None if last is None else last.solver_mode,
                (
                    0
                    if last is None
                    else last.solver_candidate_count
                ),
                (
                    None
                    if last is None
                    else last.prior_position_difference_m
                ),
                (
                    None
                    if last is None
                    else last.prior_yaw_difference_deg
                ),
                bool(
                    detector_pose is not None
                    and (
                        self.profile.measurement_position_visual_weight
                        < 1.0
                        or self.profile.measurement_yaw_visual_weight
                        < 1.0
                    )
                ),
                self.profile.measurement_position_visual_weight,
                self.profile.measurement_yaw_visual_weight,
                self.measurement_guide_rejection_count,
                guide_position_difference,
                (
                    None
                    if guide_yaw_difference is None
                    else math.degrees(guide_yaw_difference)
                ),
                self.last_confidence_class,
                self.high_confidence_count,
                self.medium_confidence_count,
                self.confidence_rejection_count,
                self.reacquire_required,
                self._preinsert_measurement_fresh(),
                self.preinsert_ready_achieved,
                (
                    'VISUAL_LOCK' if self.visual_authority_locked
                    else 'VISUAL_TRACK' if self.filtered_pallet_world is not None
                    and stale<=self.profile.maximum_stale_seconds
                    else 'COARSE_GUIDE' if self.profile.coarse_guide_prior
                    else 'GLOBAL_POSE'
                ),
                self.visual_authority_lock_count,
                self.visual_authority_unlock_count,
                self.last_accepted_confidence,
                self.last_accepted_reprojection_error_px,
                self.last_accepted_detection_time,
            ),
            detection_pose,
            detection,
            detector_pose,
        )
