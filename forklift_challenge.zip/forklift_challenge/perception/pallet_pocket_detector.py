"""Detect two colour-coded fork-pocket interiors from fork RGB.

V8.1 used a single dark threshold.  In the real rendered scene that threshold
also selected tyres, forks and deep shadows.  Moreover, the original minimum
pair separation was wider than the true pocket projection at the far end of
the pickup approach.

V8.1.3.3 keeps the measurement image-based and uses two colours that do
not overlap the load appearance: magenta on the left and yellow on the right.
A noisy global pallet pose may be used only to rank colour components near the
expected image location.  The returned pose is always solved from RGB pixels.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
import math
from typing import Any, Mapping, Sequence

import cv2
import numpy as np

from interfaces.observation import Pose3D


def wrap_angle(angle: float) -> float:
    return (float(angle) + math.pi) % (2.0 * math.pi) - math.pi


def _vector(values: Sequence[float], name: str) -> np.ndarray:
    array = np.asarray(values, dtype=float)
    if array.shape != (3,):
        raise ValueError(f"{name} must contain three values")
    return array


def _rotation(values: Sequence[Sequence[float]], name: str) -> np.ndarray:
    array = np.asarray(values, dtype=float)
    if array.shape != (3, 3):
        raise ValueError(f"{name} must be 3x3")
    if not np.allclose(array.T @ array, np.eye(3), atol=1e-6):
        raise ValueError(f"{name} must be orthonormal")
    if np.linalg.det(array) < 0.999:
        raise ValueError(f"{name} must be right-handed")
    return array


@dataclass(frozen=True)
class HSVRange:
    lower: tuple[int, int, int]
    upper: tuple[int, int, int]

    @classmethod
    def from_mapping(cls, values: Mapping[str, Any]) -> "HSVRange":
        lower = tuple(int(value) for value in values["lower"])
        upper = tuple(int(value) for value in values["upper"])
        if len(lower) != 3 or len(upper) != 3:
            raise ValueError("HSV limits must contain three values")
        for lo, hi, maximum in zip(lower, upper, (179, 255, 255)):
            if not 0 <= lo <= hi <= maximum:
                raise ValueError("invalid HSV range")
        return cls(lower=lower, upper=upper)


@dataclass(frozen=True)
class PalletPocketGeometry:
    plane_x_m: float
    center_y_m: float
    center_z_m: float
    half_width_m: float
    half_height_m: float

    @classmethod
    def from_mapping(cls, values: Mapping[str, Any]) -> "PalletPocketGeometry":
        result = cls(
            plane_x_m=float(values["plane_x_m"]),
            center_y_m=float(values["center_y_m"]),
            center_z_m=float(values["center_z_m"]),
            half_width_m=float(values["half_width_m"]),
            half_height_m=float(values["half_height_m"]),
        )
        if (
            result.center_y_m <= 0.0
            or result.center_z_m <= 0.0
            or result.half_width_m <= 0.0
            or result.half_height_m <= 0.0
        ):
            raise ValueError("invalid pallet pocket geometry")
        return result

    @property
    def object_points(self) -> np.ndarray:
        rows: list[tuple[float, float, float]] = []
        # Left image marker is pallet +y.  Image-left inside either marker is
        # also pallet +y for a forward-looking camera.
        for center_y in (self.center_y_m, -self.center_y_m):
            rows.extend(
                [
                    (
                        self.plane_x_m,
                        center_y + self.half_width_m,
                        self.center_z_m + self.half_height_m,
                    ),
                    (
                        self.plane_x_m,
                        center_y - self.half_width_m,
                        self.center_z_m + self.half_height_m,
                    ),
                    (
                        self.plane_x_m,
                        center_y - self.half_width_m,
                        self.center_z_m - self.half_height_m,
                    ),
                    (
                        self.plane_x_m,
                        center_y + self.half_width_m,
                        self.center_z_m - self.half_height_m,
                    ),
                ]
            )
        return np.asarray(rows, dtype=np.float64)

    @property
    def center_object_points(self) -> np.ndarray:
        return np.asarray(
            [
                (self.plane_x_m, self.center_y_m, self.center_z_m),
                (self.plane_x_m, -self.center_y_m, self.center_z_m),
            ],
            dtype=np.float64,
        )


@dataclass(frozen=True)
class PalletPocketDetectorParameters:
    image_width: int
    image_height: int
    fovy_degrees: float
    maximum_dark_value: int
    minimum_blob_area_px: int
    maximum_blob_area_fraction: float
    morphology_kernel_px: int
    roi_top_fraction: float
    roi_bottom_fraction: float
    minimum_aspect_ratio: float
    maximum_aspect_ratio: float
    minimum_pair_separation_fraction: float
    maximum_pair_separation_fraction: float
    maximum_vertical_misalignment_fraction: float
    minimum_pair_area_ratio: float
    enforce_pair_area_gate: bool
    enforce_pair_vertical_gate: bool
    maximum_reprojection_error_px: float
    minimum_confidence: float
    minimum_distance_m: float
    maximum_distance_m: float
    expected_pallet_origin_height_in_base_m: float
    maximum_pallet_height_error_m: float
    minimum_upright_cosine: float
    prior_search_radius_px: float
    maximum_prior_position_difference_m: float
    maximum_prior_yaw_difference_rad: float
    solver_use_ippe: bool
    solver_use_unseeded_iterative: bool
    solver_use_previous_pose: bool
    solver_use_prior_seed_fallback: bool
    solver_maximum_candidates: int
    contour_quad_epsilon_fraction: float
    minimum_contour_quad_area_ratio: float
    ground_plane_refine_enabled: bool
    ground_plane_refine_iterations: int
    ground_plane_refine_damping: float
    ground_plane_refine_position_step_m: float
    ground_plane_refine_yaw_step_rad: float
    ground_plane_refine_max_position_step_m: float
    ground_plane_refine_max_yaw_step_rad: float
    ground_plane_refine_maximum_center_error_px: float
    ground_plane_refine_minimum_improvement_px: float
    ground_plane_refine_use_blob_centres: bool
    minimum_expected_width_ratio: float
    maximum_expected_width_ratio: float
    minimum_expected_height_ratio: float
    maximum_expected_height_ratio: float
    expected_size_score_weight: float
    expected_distance_score_weight: float
    candidate_area_reward_weight: float
    prefer_ground_plane_candidate: bool
    camera_position_in_base: tuple[float, float, float]
    camera_rotation_base_from_cv: tuple[tuple[float, float, float], ...]

    @classmethod
    def from_mapping(
        cls,
        values: Mapping[str, Any],
        *,
        image_width: int,
        image_height: int,
    ) -> "PalletPocketDetectorParameters":
        result = cls(
            image_width=int(image_width),
            image_height=int(image_height),
            fovy_degrees=float(values["fovy_degrees"]),
            maximum_dark_value=int(values.get("maximum_dark_value", 72)),
            minimum_blob_area_px=int(values.get("minimum_blob_area_px", 10)),
            maximum_blob_area_fraction=float(
                values.get("maximum_blob_area_fraction", 0.06)
            ),
            morphology_kernel_px=int(values.get("morphology_kernel_px", 3)),
            roi_top_fraction=float(values.get("roi_top_fraction", 0.28)),
            roi_bottom_fraction=float(values.get("roi_bottom_fraction", 0.90)),
            minimum_aspect_ratio=float(values.get("minimum_aspect_ratio", 0.65)),
            maximum_aspect_ratio=float(values.get("maximum_aspect_ratio", 4.8)),
            minimum_pair_separation_fraction=float(
                values.get("minimum_pair_separation_fraction", 0.025)
            ),
            maximum_pair_separation_fraction=float(
                values.get("maximum_pair_separation_fraction", 0.55)
            ),
            maximum_vertical_misalignment_fraction=float(
                values.get("maximum_vertical_misalignment_fraction", 0.14)
            ),
            minimum_pair_area_ratio=float(
                values.get("minimum_pair_area_ratio", 0.35)
            ),
            enforce_pair_area_gate=bool(
                values.get("enforce_pair_area_gate", True)
            ),
            enforce_pair_vertical_gate=bool(
                values.get("enforce_pair_vertical_gate", True)
            ),
            maximum_reprojection_error_px=float(
                values.get("maximum_reprojection_error_px", 5.0)
            ),
            minimum_confidence=float(values.get("minimum_confidence", 0.18)),
            minimum_distance_m=float(values.get("minimum_distance_m", 0.35)),
            maximum_distance_m=float(values.get("maximum_distance_m", 4.8)),
            expected_pallet_origin_height_in_base_m=float(
                values.get("expected_pallet_origin_height_in_base_m", -0.58)
            ),
            maximum_pallet_height_error_m=float(
                values.get("maximum_pallet_height_error_m", 0.34)
            ),
            minimum_upright_cosine=float(
                values.get("minimum_upright_cosine", 0.55)
            ),
            prior_search_radius_px=float(
                values.get("prior_search_radius_px", 115.0)
            ),
            maximum_prior_position_difference_m=float(
                values.get(
                    "maximum_prior_position_difference_m",
                    1.25,
                )
            ),
            maximum_prior_yaw_difference_rad=math.radians(
                float(
                    values.get(
                        "maximum_prior_yaw_difference_deg",
                        45.0,
                    )
                )
            ),
            solver_use_ippe=bool(
                values.get("solver_use_ippe", True)
            ),
            solver_use_unseeded_iterative=bool(
                values.get("solver_use_unseeded_iterative", True)
            ),
            solver_use_previous_pose=bool(
                values.get("solver_use_previous_pose", True)
            ),
            solver_use_prior_seed_fallback=bool(
                values.get("solver_use_prior_seed_fallback", True)
            ),
            solver_maximum_candidates=int(
                values.get("solver_maximum_candidates", 8)
            ),
            contour_quad_epsilon_fraction=float(
                values.get("contour_quad_epsilon_fraction", 0.025)
            ),
            minimum_contour_quad_area_ratio=float(
                values.get("minimum_contour_quad_area_ratio", 0.72)
            ),
            ground_plane_refine_enabled=bool(
                values.get("ground_plane_refine_enabled", True)
            ),
            ground_plane_refine_iterations=int(
                values.get("ground_plane_refine_iterations", 10)
            ),
            ground_plane_refine_damping=float(
                values.get("ground_plane_refine_damping", 0.20)
            ),
            ground_plane_refine_position_step_m=float(
                values.get("ground_plane_refine_position_step_m", 0.01)
            ),
            ground_plane_refine_yaw_step_rad=math.radians(
                float(values.get("ground_plane_refine_yaw_step_deg", 0.35))
            ),
            ground_plane_refine_max_position_step_m=float(
                values.get("ground_plane_refine_max_position_step_m", 0.20)
            ),
            ground_plane_refine_max_yaw_step_rad=math.radians(
                float(values.get("ground_plane_refine_max_yaw_step_deg", 7.0))
            ),
            ground_plane_refine_maximum_center_error_px=float(
                values.get("ground_plane_refine_maximum_center_error_px", 4.0)
            ),
            ground_plane_refine_minimum_improvement_px=float(
                values.get("ground_plane_refine_minimum_improvement_px", 0.05)
            ),
            ground_plane_refine_use_blob_centres=bool(
                values.get("ground_plane_refine_use_blob_centres", True)
            ),
            minimum_expected_width_ratio=float(
                values.get("minimum_expected_width_ratio", 0.20)
            ),
            maximum_expected_width_ratio=float(
                values.get("maximum_expected_width_ratio", 3.00)
            ),
            minimum_expected_height_ratio=float(
                values.get("minimum_expected_height_ratio", 0.20)
            ),
            maximum_expected_height_ratio=float(
                values.get("maximum_expected_height_ratio", 3.00)
            ),
            expected_size_score_weight=float(
                values.get("expected_size_score_weight", 1.20)
            ),
            expected_distance_score_weight=float(
                values.get("expected_distance_score_weight", 2.00)
            ),
            candidate_area_reward_weight=float(
                values.get("candidate_area_reward_weight", 0.03)
            ),
            prefer_ground_plane_candidate=bool(
                values.get("prefer_ground_plane_candidate", True)
            ),
            camera_position_in_base=tuple(
                float(value) for value in values["camera_position_in_base"]
            ),
            camera_rotation_base_from_cv=tuple(
                tuple(float(value) for value in row)
                for row in values["camera_rotation_base_from_cv"]
            ),
        )
        if result.image_width <= 0 or result.image_height <= 0:
            raise ValueError("image dimensions must be positive")
        if not 1.0 < result.fovy_degrees < 179.0:
            raise ValueError("invalid fovy_degrees")
        if not 0 <= result.maximum_dark_value <= 255:
            raise ValueError("maximum_dark_value must be in [0, 255]")
        if result.minimum_blob_area_px <= 0:
            raise ValueError("minimum_blob_area_px must be positive")
        if not 0.0 < result.maximum_blob_area_fraction < 1.0:
            raise ValueError("invalid maximum_blob_area_fraction")
        if not 0.0 <= result.roi_top_fraction < result.roi_bottom_fraction <= 1.0:
            raise ValueError("invalid ROI")
        if not 0.0 < result.minimum_pair_separation_fraction:
            raise ValueError("minimum pair separation must be positive")
        if (
            result.maximum_pair_separation_fraction
            <= result.minimum_pair_separation_fraction
        ):
            raise ValueError("invalid pair separation limits")
        if not 0.0 < result.minimum_pair_area_ratio <= 1.0:
            raise ValueError("invalid pair area ratio")
        if not 0.0 < result.minimum_distance_m < result.maximum_distance_m:
            raise ValueError("invalid distance limits")
        if result.prior_search_radius_px <= 0.0:
            raise ValueError("prior_search_radius_px must be positive")
        if result.maximum_prior_position_difference_m <= 0.0:
            raise ValueError(
                "maximum prior position difference must be positive"
            )
        if result.maximum_prior_yaw_difference_rad <= 0.0:
            raise ValueError(
                "maximum prior yaw difference must be positive"
            )
        if result.solver_maximum_candidates <= 0:
            raise ValueError(
                "solver_maximum_candidates must be positive"
            )
        if not 0.0 < result.contour_quad_epsilon_fraction < 0.25:
            raise ValueError(
                "invalid contour_quad_epsilon_fraction"
            )
        if not 0.0 < result.minimum_contour_quad_area_ratio <= 1.0:
            raise ValueError(
                "invalid minimum_contour_quad_area_ratio"
            )
        if result.ground_plane_refine_iterations <= 0:
            raise ValueError("ground-plane iterations must be positive")
        for value in (
            result.ground_plane_refine_damping,
            result.ground_plane_refine_position_step_m,
            result.ground_plane_refine_yaw_step_rad,
            result.ground_plane_refine_max_position_step_m,
            result.ground_plane_refine_max_yaw_step_rad,
            result.ground_plane_refine_maximum_center_error_px,
        ):
            if value <= 0.0:
                raise ValueError("invalid ground-plane refine parameter")
        if result.ground_plane_refine_minimum_improvement_px < 0.0:
            raise ValueError("invalid minimum improvement")
        if not (
            0.0 < result.minimum_expected_width_ratio
            <= result.maximum_expected_width_ratio
        ):
            raise ValueError("invalid expected width ratios")
        if not (
            0.0 < result.minimum_expected_height_ratio
            <= result.maximum_expected_height_ratio
        ):
            raise ValueError("invalid expected height ratios")
        if (
            result.expected_size_score_weight < 0.0
            or result.expected_distance_score_weight < 0.0
            or result.candidate_area_reward_weight < 0.0
        ):
            raise ValueError("candidate score weights must be non-negative")
        _vector(result.camera_position_in_base, "camera_position_in_base")
        _rotation(
            result.camera_rotation_base_from_cv,
            "camera_rotation_base_from_cv",
        )
        return result


@dataclass(frozen=True)
class PocketBlob:
    center_x: float
    center_y: float
    area_px: int
    aspect_ratio: float
    corners: tuple[tuple[float, float], ...]

    @property
    def width_px(self) -> float:
        points = np.asarray(self.corners, dtype=np.float64)
        return float(points[:, 0].max() - points[:, 0].min())

    @property
    def height_px(self) -> float:
        points = np.asarray(self.corners, dtype=np.float64)
        return float(points[:, 1].max() - points[:, 1].min())

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["width_px"] = self.width_px
        result["height_px"] = self.height_px
        return result


@dataclass(frozen=True)
class PalletPocketDetection:
    success: bool
    status: str
    pallet_pose_in_base: Pose3D | None
    confidence: float
    reprojection_error_px: float | None
    pallet_distance_m: float | None
    blobs: tuple[PocketBlob, ...]
    pair_separation_fraction: float | None = None
    pair_vertical_fraction: float | None = None
    pair_area_ratio: float | None = None
    prior_position_difference_m: float | None = None
    prior_yaw_difference_deg: float | None = None
    solver_mode: str | None = None
    solver_candidate_count: int = 0

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        if self.pallet_pose_in_base is not None:
            result["pallet_pose_in_base"] = asdict(self.pallet_pose_in_base)
        return result


@dataclass(frozen=True)
class PalletPocketVisibility:
    visible: bool
    distance_m: float
    minimum_marker_width_px: float
    minimum_marker_height_px: float
    marker_centres_in_frame: bool
    corner_fraction_in_frame: float

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class _PnPCandidate:
    rvec: np.ndarray
    tvec: np.ndarray
    reprojection_error_px: float
    mode: str
    pose_in_base: Pose3D
    distance_m: float
    geometry_ok: bool
    prior_position_difference_m: float | None
    prior_yaw_difference_rad: float | None
    prior_ok: bool


class PalletPocketDetector:
    MARKER_ORDER = ("left", "right")

    def __init__(
        self,
        *,
        parameters: PalletPocketDetectorParameters,
        geometry: PalletPocketGeometry,
        marker_ranges: Mapping[str, Sequence[HSVRange]] | None,
        segmentation_mode: str,
    ) -> None:
        self.parameters = parameters
        self.geometry = geometry
        self.segmentation_mode = str(segmentation_mode)
        self.marker_ranges = (
            {
                name: tuple(marker_ranges[name])
                for name in self.MARKER_ORDER
            }
            if marker_ranges is not None
            else {}
        )
        if self.segmentation_mode == "dual_hsv":
            if any(
                not self.marker_ranges.get(name)
                for name in self.MARKER_ORDER
            ):
                raise ValueError(
                    "left and right marker ranges are required"
                )
        elif self.segmentation_mode != "legacy_dark":
            raise ValueError(
                f"unsupported segmentation mode: {self.segmentation_mode}"
            )

        fovy = math.radians(parameters.fovy_degrees)
        focal = 0.5 * parameters.image_height / math.tan(0.5 * fovy)
        self.camera_matrix = np.asarray(
            [
                [focal, 0.0, 0.5 * (parameters.image_width - 1)],
                [0.0, focal, 0.5 * (parameters.image_height - 1)],
                [0.0, 0.0, 1.0],
            ],
            dtype=np.float64,
        )
        self.distortion = np.zeros((5, 1), dtype=np.float64)
        self.camera_position = _vector(
            parameters.camera_position_in_base, "camera_position_in_base"
        )
        self.rotation_base_from_cv = _rotation(
            parameters.camera_rotation_base_from_cv,
            "camera_rotation_base_from_cv",
        )
        self.rotation_cv_from_base = self.rotation_base_from_cv.T
        self._previous_rvec: np.ndarray | None = None
        self._previous_tvec: np.ndarray | None = None

    @classmethod
    def from_config(
        cls,
        config: Mapping[str, Any],
        *,
        image_width: int,
        image_height: int,
    ) -> "PalletPocketDetector":
        detector_values = config["detector"]
        hsv = detector_values.get("hsv_ranges")
        if isinstance(hsv, Mapping):
            ranges = {
                name: tuple(
                    HSVRange.from_mapping(item) for item in hsv[name]
                )
                for name in cls.MARKER_ORDER
            }
            mode = str(
                detector_values.get("segmentation_mode", "dual_hsv")
            )
        else:
            # Backward compatibility for V8.1 configs and tests.
            ranges = None
            mode = "legacy_dark"
        return cls(
            parameters=PalletPocketDetectorParameters.from_mapping(
                detector_values,
                image_width=image_width,
                image_height=image_height,
            ),
            geometry=PalletPocketGeometry.from_mapping(config["pockets"]),
            marker_ranges=ranges,
            segmentation_mode=mode,
        )

    def reset(self) -> None:
        self._previous_rvec = None
        self._previous_tvec = None

    @staticmethod
    def _order_quad(points: np.ndarray) -> np.ndarray:
        points = np.asarray(points, dtype=np.float64).reshape(4, 2)
        ordered = np.empty((4, 2), dtype=np.float64)
        sums = points.sum(axis=1)
        differences = points[:, 0] - points[:, 1]
        ordered[0] = points[np.argmin(sums)]
        ordered[2] = points[np.argmax(sums)]
        ordered[1] = points[np.argmax(differences)]
        ordered[3] = points[np.argmin(differences)]
        return ordered

    def _mask(self, hsv: np.ndarray, ranges: Sequence[HSVRange]) -> np.ndarray:
        result = np.zeros(hsv.shape[:2], dtype=np.uint8)
        for item in ranges:
            result = cv2.bitwise_or(
                result,
                cv2.inRange(
                    hsv,
                    np.asarray(item.lower, dtype=np.uint8),
                    np.asarray(item.upper, dtype=np.uint8),
                ),
            )
        top = int(round(self.parameters.roi_top_fraction * result.shape[0]))
        bottom = int(round(self.parameters.roi_bottom_fraction * result.shape[0]))
        result[:top, :] = 0
        result[bottom:, :] = 0
        size = self.parameters.morphology_kernel_px
        if size > 1:
            kernel = np.ones((size, size), dtype=np.uint8)
            result = cv2.morphologyEx(result, cv2.MORPH_OPEN, kernel)
            result = cv2.morphologyEx(result, cv2.MORPH_CLOSE, kernel)
        return result

    def _legacy_mask(self, rgb: np.ndarray) -> np.ndarray:
        gray = cv2.cvtColor(
            np.asarray(rgb, dtype=np.uint8),
            cv2.COLOR_RGB2GRAY,
        )
        result = np.where(
            gray <= self.parameters.maximum_dark_value,
            255,
            0,
        ).astype(np.uint8)
        top = int(
            round(
                self.parameters.roi_top_fraction
                * result.shape[0]
            )
        )
        bottom = int(
            round(
                self.parameters.roi_bottom_fraction
                * result.shape[0]
            )
        )
        result[:top, :] = 0
        result[bottom:, :] = 0
        size = self.parameters.morphology_kernel_px
        if size > 1:
            kernel = np.ones((size, size), dtype=np.uint8)
            result = cv2.morphologyEx(
                result, cv2.MORPH_OPEN, kernel
            )
            result = cv2.morphologyEx(
                result, cv2.MORPH_CLOSE, kernel
            )
        return result

    def _legacy_pair(
        self,
        blobs: list[PocketBlob],
    ) -> tuple[PocketBlob, PocketBlob] | None:
        best = None
        best_score = -1e18
        width = self.parameters.image_width
        height = self.parameters.image_height
        for first_index in range(len(blobs)):
            for second_index in range(first_index + 1, len(blobs)):
                left, right = sorted(
                    (blobs[first_index], blobs[second_index]),
                    key=lambda item: item.center_x,
                )
                separation = (
                    right.center_x - left.center_x
                ) / width
                vertical = abs(
                    right.center_y - left.center_y
                ) / height
                ratio = min(
                    left.area_px, right.area_px
                ) / max(left.area_px, right.area_px)
                if not (
                    self.parameters.minimum_pair_separation_fraction
                    <= separation
                    <= self.parameters.maximum_pair_separation_fraction
                ):
                    continue
                if (
                    vertical
                    > self.parameters.maximum_vertical_misalignment_fraction
                    or ratio
                    < self.parameters.minimum_pair_area_ratio
                ):
                    continue
                score = (
                    ratio
                    - 2.0 * vertical
                    + 0.001 * (left.area_px + right.area_px)
                )
                if score > best_score:
                    best = (left, right)
                    best_score = score
        return best

    def debug_masks(self, rgb: np.ndarray) -> dict[str, np.ndarray]:
        if self.segmentation_mode == "legacy_dark":
            mask = self._legacy_mask(rgb)
            return {"left": mask, "right": mask}
        hsv = cv2.cvtColor(
            np.asarray(rgb, dtype=np.uint8),
            cv2.COLOR_RGB2HSV,
        )
        return {
            name: self._mask(hsv, self.marker_ranges[name])
            for name in self.MARKER_ORDER
        }

    def _components(self, mask: np.ndarray) -> list[PocketBlob]:
        contours, _ = cv2.findContours(
            mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )
        maximum_area = (
            self.parameters.maximum_blob_area_fraction
            * mask.shape[0]
            * mask.shape[1]
        )
        result: list[PocketBlob] = []
        for contour in contours:
            area = float(cv2.contourArea(contour))
            if area < self.parameters.minimum_blob_area_px or area > maximum_area:
                continue
            rect = cv2.minAreaRect(contour)
            width, height = rect[1]
            if min(width, height) <= 1e-6:
                continue
            aspect = max(width, height) / min(width, height)
            if not (
                self.parameters.minimum_aspect_ratio
                <= aspect
                <= self.parameters.maximum_aspect_ratio
            ):
                continue

            perimeter = float(cv2.arcLength(contour, True))
            approximation = cv2.approxPolyDP(
                contour,
                self.parameters.contour_quad_epsilon_fraction
                * perimeter,
                True,
            )
            use_contour_quad = False
            if (
                len(approximation) == 4
                and cv2.isContourConvex(approximation)
            ):
                candidate_quad = approximation.reshape(4, 2)
                candidate_area = abs(
                    float(cv2.contourArea(candidate_quad))
                )
                if (
                    candidate_area
                    >= self.parameters.minimum_contour_quad_area_ratio
                    * area
                ):
                    quad = self._order_quad(candidate_quad)
                    use_contour_quad = True
            if not use_contour_quad:
                quad = self._order_quad(cv2.boxPoints(rect))
            center = quad.mean(axis=0)
            result.append(
                PocketBlob(
                    center_x=float(center[0]),
                    center_y=float(center[1]),
                    area_px=int(round(area)),
                    aspect_ratio=float(aspect),
                    corners=tuple(
                        (float(point[0]), float(point[1])) for point in quad
                    ),
                )
            )
        return result


    def _pose_to_cv(
        self,
        pose: Pose3D,
    ) -> tuple[np.ndarray, np.ndarray]:
        cosine = math.cos(float(pose.yaw))
        sine = math.sin(float(pose.yaw))
        rotation_base_from_object = np.asarray(
            [
                [cosine, -sine, 0.0],
                [sine, cosine, 0.0],
                [0.0, 0.0, 1.0],
            ],
            dtype=np.float64,
        )
        translation_base = np.asarray(
            [float(pose.x), float(pose.y), float(pose.z)],
            dtype=np.float64,
        )
        rotation_cv_from_object = (
            self.rotation_cv_from_base @ rotation_base_from_object
        )
        translation_cv = self.rotation_cv_from_base @ (
            translation_base - self.camera_position
        )
        rvec, _ = cv2.Rodrigues(rotation_cv_from_object)
        return rvec, translation_cv.reshape(3, 1)

    def project_pocket_points(
        self,
        pose_in_base: Pose3D,
    ) -> np.ndarray | None:
        rvec, tvec = self._pose_to_cv(pose_in_base)
        if float(tvec[2, 0]) <= 0.05:
            return None
        projected, _ = cv2.projectPoints(
            self.geometry.object_points,
            rvec,
            tvec,
            self.camera_matrix,
            self.distortion,
        )
        return projected.reshape(2, 4, 2)

    def visibility_opportunity(
        self,
        pose_in_base: Pose3D,
        *,
        minimum_marker_width_px: float,
        minimum_marker_height_px: float,
        image_margin_px: float,
        maximum_distance_m: float,
    ) -> PalletPocketVisibility:
        distance = math.sqrt(
            float(pose_in_base.x) ** 2
            + float(pose_in_base.y) ** 2
            + float(pose_in_base.z) ** 2
        )
        points = self.project_pocket_points(pose_in_base)
        if points is None:
            return PalletPocketVisibility(
                False, distance, 0.0, 0.0, False, 0.0
            )

        widths = [
            float(marker[:, 0].max() - marker[:, 0].min())
            for marker in points
        ]
        heights = [
            float(marker[:, 1].max() - marker[:, 1].min())
            for marker in points
        ]
        centres = points.mean(axis=1)
        margin = float(image_margin_px)
        centre_flags = (
            (centres[:, 0] >= margin)
            & (
                centres[:, 0]
                <= self.parameters.image_width - 1 - margin
            )
            & (centres[:, 1] >= margin)
            & (
                centres[:, 1]
                <= self.parameters.image_height - 1 - margin
            )
        )
        flat = points.reshape(-1, 2)
        corner_flags = (
            (flat[:, 0] >= 0.0)
            & (flat[:, 0] <= self.parameters.image_width - 1)
            & (flat[:, 1] >= 0.0)
            & (flat[:, 1] <= self.parameters.image_height - 1)
        )
        minimum_width = min(widths)
        minimum_height = min(heights)
        centres_in_frame = bool(np.all(centre_flags))
        corner_fraction = float(np.mean(corner_flags))
        visible = (
            distance <= float(maximum_distance_m)
            and centres_in_frame
            and corner_fraction >= 0.75
            and minimum_width >= float(minimum_marker_width_px)
            and minimum_height >= float(minimum_marker_height_px)
        )
        return PalletPocketVisibility(
            visible=visible,
            distance_m=distance,
            minimum_marker_width_px=minimum_width,
            minimum_marker_height_px=minimum_height,
            marker_centres_in_frame=centres_in_frame,
            corner_fraction_in_frame=corner_fraction,
        )

    def _project_prior_markers(
        self,
        pose: Pose3D | None,
    ) -> tuple[np.ndarray, np.ndarray] | None:
        if pose is None:
            return None
        return self.project_pocket_points(pose)

    def _project_prior_centres(
        self,
        pose: Pose3D | None,
    ) -> tuple[np.ndarray, np.ndarray] | None:
        markers = self._project_prior_markers(pose)
        if markers is None:
            return None
        return markers[0].mean(axis=0), markers[1].mean(axis=0)

    def _choose(
        self,
        blobs: list[PocketBlob],
        expected_marker: np.ndarray | None,
    ) -> PocketBlob | None:
        if not blobs:
            return None
        if expected_marker is None:
            return max(blobs, key=lambda item: item.area_px)

        expected_marker = np.asarray(
            expected_marker, dtype=np.float64
        ).reshape(4, 2)
        expected_center = expected_marker.mean(axis=0)
        expected_width = float(
            expected_marker[:, 0].max() - expected_marker[:, 0].min()
        )
        expected_height = float(
            expected_marker[:, 1].max() - expected_marker[:, 1].min()
        )
        if expected_width <= 1e-6 or expected_height <= 1e-6:
            return None

        radius = self.parameters.prior_search_radius_px
        eligible: list[tuple[PocketBlob, float, float, float]] = []
        for blob in blobs:
            distance = math.hypot(
                blob.center_x - float(expected_center[0]),
                blob.center_y - float(expected_center[1]),
            )
            if distance > radius:
                continue
            width_ratio = blob.width_px / expected_width
            height_ratio = blob.height_px / expected_height
            if not (
                self.parameters.minimum_expected_width_ratio
                <= width_ratio
                <= self.parameters.maximum_expected_width_ratio
            ):
                continue
            if not (
                self.parameters.minimum_expected_height_ratio
                <= height_ratio
                <= self.parameters.maximum_expected_height_ratio
            ):
                continue
            eligible.append((blob, distance, width_ratio, height_ratio))

        if not eligible:
            return None

        def score(item: tuple[PocketBlob, float, float, float]) -> float:
            blob, distance, width_ratio, height_ratio = item
            size_penalty = (
                abs(math.log(max(width_ratio, 1e-9)))
                + abs(math.log(max(height_ratio, 1e-9)))
            )
            return (
                -self.parameters.expected_distance_score_weight
                * distance / radius
                -self.parameters.expected_size_score_weight
                * size_penalty
                +self.parameters.candidate_area_reward_weight
                * math.log1p(blob.area_px)
            )

        return max(eligible, key=score)[0]

    def _pair(
        self,
        rgb: np.ndarray,
        prior_pose_in_base: Pose3D | None,
    ) -> tuple[PocketBlob, PocketBlob] | str:
        masks = self.debug_masks(rgb)
        if self.segmentation_mode == "legacy_dark":
            pair = self._legacy_pair(
                self._components(masks["left"])
            )
            return "pocket_pair_missing" if pair is None else pair
        prior = self._project_prior_markers(prior_pose_in_base)
        left_expected = None if prior is None else prior[0]
        right_expected = None if prior is None else prior[1]
        left = self._choose(self._components(masks["left"]), left_expected)
        right = self._choose(self._components(masks["right"]), right_expected)
        if left is None:
            return "left_marker_missing"
        if right is None:
            return "right_marker_missing"
        if left.center_x >= right.center_x:
            return "marker_order_rejected"

        separation = (right.center_x - left.center_x) / self.parameters.image_width
        vertical = (
            abs(right.center_y - left.center_y)
            / self.parameters.image_height
        )
        ratio = min(left.area_px, right.area_px) / max(
            left.area_px, right.area_px
        )
        if not (
            self.parameters.minimum_pair_separation_fraction
            <= separation
            <= self.parameters.maximum_pair_separation_fraction
        ):
            return "pair_separation_rejected"
        if (
            self.parameters.enforce_pair_vertical_gate
            and vertical
            > self.parameters.maximum_vertical_misalignment_fraction
        ):
            return "pair_vertical_rejected"
        if (
            self.parameters.enforce_pair_area_gate
            and ratio < self.parameters.minimum_pair_area_ratio
        ):
            return "pair_area_rejected"
        return left, right

    def _project_center_points_from_parameters(
        self,
        parameters: np.ndarray,
    ) -> np.ndarray | None:
        pose = Pose3D(
            x=float(parameters[0]),
            y=float(parameters[1]),
            z=self.parameters.expected_pallet_origin_height_in_base_m,
            roll=0.0,
            pitch=0.0,
            yaw=wrap_angle(float(parameters[2])),
        )
        rvec, tvec = self._pose_to_cv(pose)
        if float(tvec[2, 0]) <= 0.05:
            return None
        projected, _ = cv2.projectPoints(
            self.geometry.center_object_points,
            rvec,
            tvec,
            self.camera_matrix,
            self.distortion,
        )
        return projected.reshape(2, 2)

    @staticmethod
    def _center_error(
        projected: np.ndarray,
        observed: np.ndarray,
    ) -> float:
        residual = projected - observed
        return float(
            np.sqrt(np.mean(np.sum(residual * residual, axis=1)))
        )

    def _ground_plane_candidate(
        self,
        *,
        image_points: np.ndarray,
        pair: tuple[PocketBlob, PocketBlob],
        prior_pose_in_base: Pose3D | None,
    ) -> _PnPCandidate | None:
        if (
            not self.parameters.ground_plane_refine_enabled
            or prior_pose_in_base is None
        ):
            return None

        observed = np.asarray(
            [
                [pair[0].center_x, pair[0].center_y],
                [pair[1].center_x, pair[1].center_y],
            ],
            dtype=np.float64,
        )
        parameters = np.asarray(
            [
                float(prior_pose_in_base.x),
                float(prior_pose_in_base.y),
                float(prior_pose_in_base.yaw),
            ],
            dtype=np.float64,
        )
        initial_parameters = parameters.copy()
        projected = self._project_center_points_from_parameters(parameters)
        if projected is None:
            return None
        initial_error = self._center_error(projected, observed)
        best_parameters = parameters.copy()
        best_error = initial_error

        steps = np.asarray(
            [
                self.parameters.ground_plane_refine_position_step_m,
                self.parameters.ground_plane_refine_position_step_m,
                self.parameters.ground_plane_refine_yaw_step_rad,
            ],
            dtype=np.float64,
        )

        for _ in range(self.parameters.ground_plane_refine_iterations):
            projected = self._project_center_points_from_parameters(parameters)
            if projected is None:
                break
            residual = (projected - observed).reshape(-1)
            jacobian = np.empty((4, 3), dtype=np.float64)
            valid = True
            for column, step in enumerate(steps):
                plus = parameters.copy()
                minus = parameters.copy()
                plus[column] += step
                minus[column] -= step
                plus[2] = wrap_angle(plus[2])
                minus[2] = wrap_angle(minus[2])
                projected_plus = self._project_center_points_from_parameters(plus)
                projected_minus = self._project_center_points_from_parameters(minus)
                if projected_plus is None or projected_minus is None:
                    valid = False
                    break
                jacobian[:, column] = (
                    projected_plus.reshape(-1)
                    - projected_minus.reshape(-1)
                ) / (2.0 * step)
            if not valid:
                break

            normal = jacobian.T @ jacobian
            normal += self.parameters.ground_plane_refine_damping * np.eye(3)
            gradient = jacobian.T @ residual
            try:
                delta = -np.linalg.solve(normal, gradient)
            except np.linalg.LinAlgError:
                delta = -np.linalg.lstsq(normal, gradient, rcond=None)[0]

            delta[:2] = np.clip(
                delta[:2],
                -self.parameters.ground_plane_refine_max_position_step_m,
                self.parameters.ground_plane_refine_max_position_step_m,
            )
            delta[2] = float(
                np.clip(
                    delta[2],
                    -self.parameters.ground_plane_refine_max_yaw_step_rad,
                    self.parameters.ground_plane_refine_max_yaw_step_rad,
                )
            )

            trial = parameters + delta
            trial[2] = wrap_angle(trial[2])
            offset = trial[:2] - initial_parameters[:2]
            offset_norm = float(np.linalg.norm(offset))
            if offset_norm > self.parameters.maximum_prior_position_difference_m:
                trial[:2] = initial_parameters[:2] + offset * (
                    self.parameters.maximum_prior_position_difference_m
                    / offset_norm
                )
            yaw_offset = wrap_angle(trial[2] - initial_parameters[2])
            yaw_offset = float(
                np.clip(
                    yaw_offset,
                    -self.parameters.maximum_prior_yaw_difference_rad,
                    self.parameters.maximum_prior_yaw_difference_rad,
                )
            )
            trial[2] = wrap_angle(initial_parameters[2] + yaw_offset)

            trial_projected = self._project_center_points_from_parameters(trial)
            if trial_projected is None:
                break
            trial_error = self._center_error(trial_projected, observed)
            if trial_error <= best_error:
                parameters = trial
                best_parameters = trial.copy()
                best_error = trial_error
                if float(np.linalg.norm(delta)) < 1e-5:
                    break
            else:
                # The local model is already close; increase damping by taking
                # a conservative half step instead of jumping to a planar
                # ambiguity.
                half = parameters + 0.5 * delta
                half[2] = wrap_angle(half[2])
                half_projected = self._project_center_points_from_parameters(half)
                if half_projected is None:
                    break
                half_error = self._center_error(half_projected, observed)
                if half_error < best_error:
                    parameters = half
                    best_parameters = half.copy()
                    best_error = half_error
                else:
                    break

        improvement = initial_error - best_error
        if (
            best_error > self.parameters.ground_plane_refine_maximum_center_error_px
            or improvement
            < self.parameters.ground_plane_refine_minimum_improvement_px
        ):
            return None

        pose = Pose3D(
            x=float(best_parameters[0]),
            y=float(best_parameters[1]),
            z=self.parameters.expected_pallet_origin_height_in_base_m,
            roll=0.0,
            pitch=0.0,
            yaw=wrap_angle(float(best_parameters[2])),
        )
        rvec, tvec = self._pose_to_cv(pose)
        distance = float(np.linalg.norm(tvec.reshape(3)))
        prior_position_difference = math.hypot(
            pose.x - prior_pose_in_base.x,
            pose.y - prior_pose_in_base.y,
        )
        prior_yaw_difference = abs(
            wrap_angle(pose.yaw - prior_pose_in_base.yaw)
        )
        prior_ok = (
            prior_position_difference
            <= self.parameters.maximum_prior_position_difference_m
            and prior_yaw_difference
            <= self.parameters.maximum_prior_yaw_difference_rad
        )
        geometry_ok = (
            self.parameters.minimum_distance_m
            <= distance
            <= self.parameters.maximum_distance_m
        )
        full_corner_error = self._reprojection_error(
            image_points,
            rvec,
            tvec,
        )
        return _PnPCandidate(
            rvec=rvec,
            tvec=tvec,
            reprojection_error_px=full_corner_error,
            mode="ground_plane_centres",
            pose_in_base=pose,
            distance_m=distance,
            geometry_ok=geometry_ok,
            prior_position_difference_m=prior_position_difference,
            prior_yaw_difference_rad=prior_yaw_difference,
            prior_ok=prior_ok,
        )

    def _reprojection_error(
        self,
        image_points: np.ndarray,
        rvec: np.ndarray,
        tvec: np.ndarray,
    ) -> float:
        projected, _ = cv2.projectPoints(
            self.geometry.object_points,
            rvec,
            tvec,
            self.camera_matrix,
            self.distortion,
        )
        residual = projected.reshape(-1, 2) - image_points
        return float(
            np.sqrt(np.mean(np.sum(residual * residual, axis=1)))
        )

    def _candidate(
        self,
        *,
        image_points: np.ndarray,
        rvec: np.ndarray,
        tvec: np.ndarray,
        mode: str,
        prior_pose_in_base: Pose3D | None,
    ) -> _PnPCandidate | None:
        rvec = np.asarray(rvec, dtype=np.float64).reshape(3, 1)
        tvec = np.asarray(tvec, dtype=np.float64).reshape(3, 1)
        if (
            not np.isfinite(rvec).all()
            or not np.isfinite(tvec).all()
            or float(tvec[2, 0]) <= 0.05
        ):
            return None

        error = self._reprojection_error(
            image_points, rvec, tvec
        )
        pose, distance, geometry_ok = self._pose(rvec, tvec)

        prior_position_difference = None
        prior_yaw_difference = None
        prior_ok = True
        if prior_pose_in_base is not None:
            prior_position_difference = math.hypot(
                pose.x - prior_pose_in_base.x,
                pose.y - prior_pose_in_base.y,
            )
            prior_yaw_difference = abs(
                wrap_angle(
                    pose.yaw - prior_pose_in_base.yaw
                )
            )
            prior_ok = (
                prior_position_difference
                <= self.parameters.maximum_prior_position_difference_m
                and prior_yaw_difference
                <= self.parameters.maximum_prior_yaw_difference_rad
            )

        return _PnPCandidate(
            rvec=rvec,
            tvec=tvec,
            reprojection_error_px=error,
            mode=mode,
            pose_in_base=pose,
            distance_m=distance,
            geometry_ok=geometry_ok,
            prior_position_difference_m=prior_position_difference,
            prior_yaw_difference_rad=prior_yaw_difference,
            prior_ok=prior_ok,
        )

    def _iterative_candidate(
        self,
        *,
        image_points: np.ndarray,
        mode: str,
        rvec: np.ndarray | None,
        tvec: np.ndarray | None,
        use_guess: bool,
        prior_pose_in_base: Pose3D | None,
    ) -> _PnPCandidate | None:
        try:
            ok, solved_rvec, solved_tvec = cv2.solvePnP(
                self.geometry.object_points,
                image_points,
                self.camera_matrix,
                self.distortion,
                rvec=None if rvec is None else rvec.copy(),
                tvec=None if tvec is None else tvec.copy(),
                useExtrinsicGuess=use_guess,
                flags=cv2.SOLVEPNP_ITERATIVE,
            )
        except cv2.error:
            return None
        if not ok:
            return None
        return self._candidate(
            image_points=image_points,
            rvec=solved_rvec,
            tvec=solved_tvec,
            mode=mode,
            prior_pose_in_base=prior_pose_in_base,
        )

    def _solve(
        self,
        image_points: np.ndarray,
        pair: tuple[PocketBlob, PocketBlob],
        prior_pose_in_base: Pose3D | None,
    ):
        candidates: list[_PnPCandidate] = []

        def append(candidate: _PnPCandidate | None) -> None:
            if candidate is None:
                return
            for existing in candidates:
                if (
                    np.linalg.norm(
                        existing.tvec - candidate.tvec
                    ) < 1e-5
                    and np.linalg.norm(
                        existing.rvec - candidate.rvec
                    ) < 1e-5
                ):
                    return
            candidates.append(candidate)

        append(
            self._ground_plane_candidate(
                image_points=image_points,
                pair=pair,
                prior_pose_in_base=prior_pose_in_base,
            )
        )

        # IPPE explicitly exposes both planar pose hypotheses.  The coarse
        # pose is used only to select a physically consistent solution.
        if (
            self.parameters.solver_use_ippe
            and hasattr(cv2, "SOLVEPNP_IPPE")
        ):
            try:
                result = cv2.solvePnPGeneric(
                    self.geometry.object_points,
                    image_points,
                    self.camera_matrix,
                    self.distortion,
                    flags=cv2.SOLVEPNP_IPPE,
                )
                ok = bool(result[0])
                if ok:
                    rvecs = result[1]
                    tvecs = result[2]
                    for index, (rvec, tvec) in enumerate(
                        zip(rvecs, tvecs)
                    ):
                        append(
                            self._candidate(
                                image_points=image_points,
                                rvec=rvec,
                                tvec=tvec,
                                mode=f"ippe_{index}",
                                prior_pose_in_base=(
                                    prior_pose_in_base
                                ),
                            )
                        )
            except (cv2.error, TypeError, ValueError):
                pass

        # Crucial V8.1.3.1 fix: always retain an unseeded iterative solve.
        # V8.1.3 used the noisy coarse pose as the only initial condition,
        # which converged to a false ~0.9 m planar solution in every episode.
        if self.parameters.solver_use_unseeded_iterative:
            append(
                self._iterative_candidate(
                    image_points=image_points,
                    mode="iterative_unseeded",
                    rvec=None,
                    tvec=None,
                    use_guess=False,
                    prior_pose_in_base=prior_pose_in_base,
                )
            )

        if (
            self.parameters.solver_use_previous_pose
            and self._previous_rvec is not None
            and self._previous_tvec is not None
        ):
            append(
                self._iterative_candidate(
                    image_points=image_points,
                    mode="iterative_previous",
                    rvec=self._previous_rvec,
                    tvec=self._previous_tvec,
                    use_guess=True,
                    prior_pose_in_base=prior_pose_in_base,
                )
            )

        # Kept only as a fallback hypothesis.  It must still compete against
        # unseeded/IPPE solutions and pass the same geometry/prior checks.
        if (
            self.parameters.solver_use_prior_seed_fallback
            and prior_pose_in_base is not None
        ):
            prior_rvec, prior_tvec = self._pose_to_cv(
                prior_pose_in_base
            )
            if float(prior_tvec[2, 0]) > 0.05:
                append(
                    self._iterative_candidate(
                        image_points=image_points,
                        mode="iterative_prior_fallback",
                        rvec=prior_rvec,
                        tvec=prior_tvec,
                        use_guess=True,
                        prior_pose_in_base=prior_pose_in_base,
                    )
                )

        candidates = candidates[
            : self.parameters.solver_maximum_candidates
        ]
        if not candidates:
            return None

        def distance_ok(candidate: _PnPCandidate) -> bool:
            return (
                self.parameters.minimum_distance_m
                <= candidate.distance_m
                <= self.parameters.maximum_distance_m
            )

        # Selection tiers:
        # 1. physically valid + prior-consistent + within reprojection limit;
        # 2. physically valid + prior-consistent;
        # 3. prior-consistent;
        # 4. best diagnostic candidate.
        tiers = (
            [
                item
                for item in candidates
                if (
                    item.geometry_ok
                    and item.prior_ok
                    and distance_ok(item)
                    and item.reprojection_error_px
                    <= self.parameters.maximum_reprojection_error_px
                )
            ],
            [
                item
                for item in candidates
                if (
                    item.geometry_ok
                    and item.prior_ok
                    and distance_ok(item)
                )
            ],
            [item for item in candidates if item.prior_ok],
            candidates,
        )
        selected = next(tier for tier in tiers if tier)
        mode_order = {
            "iterative_previous": 0,
            "iterative_unseeded": 1,
            "ippe_0": 2,
            "ippe_1": 3,
            "ground_plane_centres": 4,
        }

        def candidate_key(item: _PnPCandidate):
            ground_priority = (
                0
                if (
                    self.parameters.prefer_ground_plane_candidate
                    and item.mode == "ground_plane_centres"
                )
                else 1
            )
            return (
                ground_priority,
                item.reprojection_error_px,
                float("inf")
                if item.prior_position_difference_m is None
                else item.prior_position_difference_m,
                mode_order.get(item.mode, 99),
            )

        best = min(selected, key=candidate_key)
        return best, len(candidates)

    def _pose(self, rvec: np.ndarray, tvec: np.ndarray):
        rotation_cv, _ = cv2.Rodrigues(rvec)
        position_cv = tvec.reshape(3)
        distance = float(np.linalg.norm(position_cv))
        position_base = (
            self.camera_position
            + self.rotation_base_from_cv @ position_cv
        )
        rotation_base = self.rotation_base_from_cv @ rotation_cv
        forward = rotation_base[:, 0]
        up = rotation_base[:, 2]
        yaw = math.atan2(float(forward[1]), float(forward[0]))
        upright = float(up[2]) >= self.parameters.minimum_upright_cosine
        facing_camera = float(rotation_cv[2, 0]) > 0.10
        height_ok = (
            abs(
                float(position_base[2])
                - self.parameters.expected_pallet_origin_height_in_base_m
            )
            <= self.parameters.maximum_pallet_height_error_m
        )
        pose = Pose3D(
            x=float(position_base[0]),
            y=float(position_base[1]),
            z=float(position_base[2]),
            roll=0.0,
            pitch=0.0,
            yaw=wrap_angle(yaw),
        )
        return pose, distance, upright and facing_camera and height_ok

    def detect(
        self,
        rgb: np.ndarray,
        *,
        prior_pose_in_base: Pose3D | None = None,
    ) -> PalletPocketDetection:
        if rgb.ndim != 3 or rgb.shape[2] != 3:
            raise ValueError("rgb image must have shape (height,width,3)")
        if rgb.shape[:2] != (
            self.parameters.image_height,
            self.parameters.image_width,
        ):
            raise ValueError("image dimensions do not match configuration")

        pair = self._pair(rgb, prior_pose_in_base)
        if isinstance(pair, str):
            return PalletPocketDetection(
                False, pair, None, 0.0, None, None, ()
            )

        pair_separation = (
            pair[1].center_x - pair[0].center_x
        ) / self.parameters.image_width
        pair_vertical = abs(
            pair[1].center_y - pair[0].center_y
        ) / self.parameters.image_height
        pair_area_ratio = min(
            pair[0].area_px, pair[1].area_px
        ) / max(pair[0].area_px, pair[1].area_px)

        image_points = np.asarray(
            [point for blob in pair for point in blob.corners],
            dtype=np.float64,
        )
        solved = self._solve(
            image_points, pair, prior_pose_in_base
        )
        if solved is None:
            return PalletPocketDetection(
                False, "pnp_failed", None, 0.0, None, None, pair
            )

        candidate, solver_candidate_count = solved
        rvec = candidate.rvec
        tvec = candidate.tvec
        error = candidate.reprojection_error_px
        pose = candidate.pose_in_base
        distance = candidate.distance_m
        geometry_ok = candidate.geometry_ok
        area_score = min(
            1.0,
            min(blob.area_px for blob in pair)
            / float(max(1, 5 * self.parameters.minimum_blob_area_px)),
        )
        reprojection_score = max(
            0.0,
            1.0 - error / self.parameters.maximum_reprojection_error_px,
        )
        vertical_score = max(
            0.0,
            1.0
            - abs(pair[0].center_y - pair[1].center_y)
            / (
                self.parameters.maximum_vertical_misalignment_fraction
                * self.parameters.image_height
                + 1e-9
            ),
        )
        confidence = float(
            0.30 * area_score
            + 0.52 * reprojection_score
            + 0.18 * vertical_score
        )
        distance_ok = (
            self.parameters.minimum_distance_m
            <= distance
            <= self.parameters.maximum_distance_m
        )
        prior_position_difference = (
            candidate.prior_position_difference_m
        )
        prior_yaw_difference = (
            candidate.prior_yaw_difference_rad
        )
        prior_ok = candidate.prior_ok

        accepted = (
            geometry_ok
            and distance_ok
            and prior_ok
            and error <= self.parameters.maximum_reprojection_error_px
            and confidence >= self.parameters.minimum_confidence
        )
        if accepted:
            self._previous_rvec = rvec.copy()
            self._previous_tvec = tvec.copy()
            status = "accepted"
        elif not geometry_ok:
            status = "geometry_rejected"
        elif not distance_ok:
            status = "distance_rejected"
        elif not prior_ok:
            status = "prior_consistency_rejected"
        elif error > self.parameters.maximum_reprojection_error_px:
            status = "reprojection_rejected"
        else:
            status = "confidence_rejected"

        return PalletPocketDetection(
            accepted,
            status,
            pose if accepted else None,
            confidence,
            error,
            distance,
            pair,
            pair_separation,
            pair_vertical,
            pair_area_ratio,
            prior_position_difference,
            (
                None
                if prior_yaw_difference is None
                else math.degrees(prior_yaw_difference)
            ),
            candidate.mode,
            solver_candidate_count,
        )

    def annotate(
        self,
        rgb: np.ndarray,
        detection: PalletPocketDetection,
    ) -> np.ndarray:
        bgr = cv2.cvtColor(
            np.asarray(rgb, dtype=np.uint8), cv2.COLOR_RGB2BGR
        )
        colours = ((255, 0, 255), (0, 255, 255))
        for index, blob in enumerate(detection.blobs):
            polygon = np.asarray(
                blob.corners, dtype=np.int32
            ).reshape(-1, 1, 2)
            cv2.polylines(
                bgr,
                [polygon],
                True,
                colours[min(index, 1)],
                2,
            )
            cv2.putText(
                bgr,
                "L" if index == 0 else "R",
                (int(blob.center_x) + 5, int(blob.center_y) - 5),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.55,
                colours[min(index, 1)],
                2,
                cv2.LINE_AA,
            )
        cv2.putText(
            bgr,
            f"pockets: {detection.status} conf={detection.confidence:.2f}",
            (10, 24),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.58,
            (255, 255, 255),
            2,
            cv2.LINE_AA,
        )
        return cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
