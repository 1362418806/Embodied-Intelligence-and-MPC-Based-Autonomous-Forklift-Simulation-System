"""Metrics for complete missions driven by noisy pose estimates."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
import csv
import json
from pathlib import Path
from statistics import mean
from typing import Any, Iterable


@dataclass(frozen=True)
class PerceptionMissionResult:
    scenario_id: str
    difficulty: str
    seed: int
    perception_profile: str
    success: bool
    final_state: str
    failure_reason: str | None
    duration_seconds: float
    path_length_m: float
    max_abs_steering_deg: float
    max_load_tilt_deg: float
    final_placement_error_m: float
    final_placement_yaw_error_deg: float
    release_pallet_motion_m: float
    steering_exercised: bool
    recovery_count: int
    pallet_position_rmse_m: float
    pallet_yaw_rmse_deg: float
    placement_position_rmse_m: float
    placement_yaw_rmse_deg: float
    maximum_stale_seconds: float
    measurement_dropout_rate: float
    measurement_rejection_rate: float
    state_durations: dict[str, float] = field(default_factory=dict)
    scenario: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def summarize_perception_missions(
    results: Iterable[PerceptionMissionResult],
) -> dict[str, Any]:
    items = list(results)
    successes = [item for item in items if item.success]
    failures: dict[str, int] = {}
    by_difficulty: dict[str, dict[str, Any]] = {}
    by_profile: dict[str, dict[str, Any]] = {}

    for item in items:
        if not item.success:
            key = item.failure_reason or item.final_state or "unknown"
            failures[key] = failures.get(key, 0) + 1
        difficulty = by_difficulty.setdefault(
            item.difficulty, {"episodes": 0, "successes": 0}
        )
        difficulty["episodes"] += 1
        difficulty["successes"] += int(item.success)
        profile = by_profile.setdefault(
            item.perception_profile, {"episodes": 0, "successes": 0}
        )
        profile["episodes"] += 1
        profile["successes"] += int(item.success)

    for collection in (by_difficulty, by_profile):
        for bucket in collection.values():
            bucket["success_rate"] = bucket["successes"] / bucket["episodes"]

    if not items:
        return {
            "episode_count": 0,
            "success_count": 0,
            "success_rate": 0.0,
            "failure_reasons": {},
            "by_difficulty": {},
            "by_profile": {},
        }

    def success_mean(name: str) -> float | None:
        return mean(getattr(item, name) for item in successes) if successes else None

    return {
        "episode_count": len(items),
        "success_count": len(successes),
        "success_rate": len(successes) / len(items),
        "steering_exercised_rate": sum(item.steering_exercised for item in items)
        / len(items),
        "average_duration_seconds": mean(item.duration_seconds for item in items),
        "average_path_length_m": mean(item.path_length_m for item in items),
        "average_success_duration_seconds": success_mean("duration_seconds"),
        "average_success_placement_error_m": success_mean(
            "final_placement_error_m"
        ),
        "maximum_success_placement_error_m": max(
            (item.final_placement_error_m for item in successes), default=None
        ),
        "maximum_load_tilt_deg": max(item.max_load_tilt_deg for item in items),
        "average_pallet_position_rmse_m": mean(
            item.pallet_position_rmse_m for item in items
        ),
        "average_pallet_yaw_rmse_deg": mean(item.pallet_yaw_rmse_deg for item in items),
        "average_placement_position_rmse_m": mean(
            item.placement_position_rmse_m for item in items
        ),
        "average_placement_yaw_rmse_deg": mean(
            item.placement_yaw_rmse_deg for item in items
        ),
        "maximum_stale_seconds": max(item.maximum_stale_seconds for item in items),
        "average_measurement_dropout_rate": mean(
            item.measurement_dropout_rate for item in items
        ),
        "average_measurement_rejection_rate": mean(
            item.measurement_rejection_rate for item in items
        ),
        "failure_reasons": failures,
        "by_difficulty": by_difficulty,
        "by_profile": by_profile,
    }


def write_perception_results(
    output_dir: Path,
    results: Iterable[PerceptionMissionResult],
) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    items = list(results)
    summary = summarize_perception_missions(items)

    with (output_dir / "episodes.jsonl").open("w", encoding="utf-8") as stream:
        for item in items:
            stream.write(json.dumps(item.to_dict(), ensure_ascii=False) + "\n")

    fields = [
        "scenario_id",
        "difficulty",
        "seed",
        "perception_profile",
        "success",
        "final_state",
        "failure_reason",
        "duration_seconds",
        "path_length_m",
        "max_abs_steering_deg",
        "max_load_tilt_deg",
        "final_placement_error_m",
        "final_placement_yaw_error_deg",
        "release_pallet_motion_m",
        "steering_exercised",
        "recovery_count",
        "pallet_position_rmse_m",
        "pallet_yaw_rmse_deg",
        "placement_position_rmse_m",
        "placement_yaw_rmse_deg",
        "maximum_stale_seconds",
        "measurement_dropout_rate",
        "measurement_rejection_rate",
    ]
    with (output_dir / "episodes.csv").open(
        "w", newline="", encoding="utf-8-sig"
    ) as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for item in items:
            row = item.to_dict()
            writer.writerow({name: row[name] for name in fields})

    (output_dir / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return summary
