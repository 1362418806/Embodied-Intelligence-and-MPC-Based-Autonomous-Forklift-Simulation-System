"""V5.2.2 fork-segment corridor regression tests."""

from __future__ import annotations

import math
from pathlib import Path

import pytest
import yaml

from control.docking_controller import (
    DockingController,
    object_axis_corridor_error,
)
from interfaces.observation import ForkliftObservation, Pose3D
from task.pickup_state_machine import (
    PickupParameters,
    PickupState,
    PickupStateMachine,
)


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def pose(
    x: float = 0.0,
    y: float = 0.0,
    yaw: float = 0.0,
) -> Pose3D:
    return Pose3D(
        x=x,
        y=y,
        z=0.0,
        roll=0.0,
        pitch=0.0,
        yaw=yaw,
    )


def pose_from_axis(
    *,
    x: float,
    lateral: float,
    yaw: float,
) -> Pose3D:
    """Construct an object pose with a requested object-axis lateral error."""
    cosine = math.cos(yaw)
    sine = math.sin(yaw)
    y = (lateral + x * sine) / cosine
    return pose(x=x, y=y, yaw=yaw)


def observation(
    *,
    sim_time: float,
    pallet_pose: Pose3D,
    fork_contact_count: int = 0,
) -> ForkliftObservation:
    return ForkliftObservation(
        sim_time=sim_time,
        vehicle_pose_world=pose(),
        vehicle_linear_velocity=(0.0, 0.0, 0.0),
        vehicle_angular_velocity=(0.0, 0.0, 0.0),
        steering_left=0.0,
        steering_right=0.0,
        front_wheel_speed_left=0.0,
        front_wheel_speed_right=0.0,
        lift_position=0.04,
        lift_velocity=0.0,
        pallet_pose_world=pose(3.2),
        pallet_pose_in_base=pallet_pose,
        placement_pose_in_base=pose(5.0, -1.0),
        fork_contact_count=fork_contact_count,
        load_state="GROUND",
    )


def load_machine() -> PickupStateMachine:
    config = yaml.safe_load(
        (PROJECT_ROOT / "configs" / "vehicle_v5_2_2.yaml").read_text(
            encoding="utf-8"
        )
    )
    values = config["controller"]
    controller = DockingController(
        distance_gain=float(values["distance_gain"]),
        heading_gain=float(values["heading_gain"]),
        yaw_gain=float(values["yaw_gain"]),
        lateral_gain=float(values["lateral_gain"]),
        lookahead_distance=float(values["lookahead_distance"]),
        maximum_steering=float(values["maximum_steering"]),
        minimum_creep_speed=float(values["minimum_creep_speed"]),
        heading_slowdown_angle=float(values["heading_slowdown_angle"]),
        yaw_slowdown_angle=float(values["yaw_slowdown_angle"]),
        minimum_alignment_scale=float(values["minimum_alignment_scale"]),
    )
    return PickupStateMachine(
        parameters=PickupParameters.from_mapping(config["autonomy"]),
        docking_controller=controller,
    )


def enter_state(
    machine: PickupStateMachine,
    state: PickupState,
    *,
    sim_time: float = 0.0,
) -> None:
    machine.state = state
    machine._state_enter_time = sim_time
    machine._alignment_condition_since = None
    machine._reset_progress(sim_time)


def test_corridor_samples_actual_fork_overlap() -> None:
    pallet = pose_from_axis(
        x=1.451,
        lateral=0.136,
        yaw=math.radians(-4.16),
    )
    error = object_axis_corridor_error(
        pallet,
        fork_root_distance=0.82,
        fork_tip_distance=1.98,
        object_half_length=0.50,
        object_center_distance=pallet.x,
    )
    assert error.near_reference == pytest.approx(0.951, abs=1e-6)
    assert error.far_reference == pytest.approx(1.951, abs=1e-6)
    # Origin lateral error is 13.6 cm, but yaw makes the fork segment fit.
    assert error.maximum_abs_lateral < 0.07


def test_alignment_uses_projected_fork_corridor_not_origin_lateral() -> None:
    machine = load_machine()
    enter_state(machine, PickupState.ALIGN)

    # Representative difficult trace geometry: origin lateral error exceeds
    # the legacy 0.12 m threshold, while the projected insertion corridor fits.
    pallet = pose_from_axis(
        x=2.46,
        lateral=-0.130,
        yaw=math.radians(1.58),
    )
    first = machine.step(observation(sim_time=0.0, pallet_pose=pallet))
    assert first.state == PickupState.ALIGN
    assert first.action.speed_target == 0.0
    assert first.corridor_error is not None
    assert first.corridor_error.maximum_abs_lateral <= 0.16

    second = machine.step(observation(sim_time=0.20, pallet_pose=pallet))
    assert second.state == PickupState.INSERT
    assert second.corridor_error is not None


def test_insertion_accepts_safe_fork_geometry_at_early_lift_depth() -> None:
    machine = load_machine()
    enter_state(machine, PickupState.INSERT)

    pallet = pose_from_axis(
        x=1.719,
        lateral=0.092,
        yaw=math.radians(-1.78),
    )
    decision = machine.step(observation(sim_time=1.0, pallet_pose=pallet))
    assert decision.state == PickupState.LIFT
    assert decision.corridor_error is not None
    assert decision.corridor_error.maximum_abs_lateral < 0.10


def test_insertion_accepts_yaw_lateral_cancellation_from_trace() -> None:
    machine = load_machine()
    enter_state(machine, PickupState.INSERT)

    pallet = pose_from_axis(
        x=1.451,
        lateral=0.136,
        yaw=math.radians(-4.16),
    )
    decision = machine.step(observation(sim_time=1.0, pallet_pose=pallet))
    assert decision.state == PickupState.LIFT
    serialized = decision.to_dict()
    assert serialized["fork_corridor_error"]["maximum_abs_lateral"] < 0.10


def test_unsafe_fork_corridor_does_not_lift() -> None:
    machine = load_machine()
    enter_state(machine, PickupState.INSERT)

    pallet = pose_from_axis(
        x=1.70,
        lateral=0.20,
        yaw=0.0,
    )
    decision = machine.step(observation(sim_time=1.0, pallet_pose=pallet))
    assert decision.state == PickupState.RECOVER_REVERSE
    assert decision.action.speed_target < 0.0
