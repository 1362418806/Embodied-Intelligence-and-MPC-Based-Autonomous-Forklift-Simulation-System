"""Close-range placement fusion with state-gated terminal relative hold.

V7.1 introduced a local pallet-to-placement measurement.  Its first latch
implementation inferred lowering from raw lift motion.  Loaded-fork vibration
could satisfy that detector while the mission was still in PLACE_ALIGN.  It
also stored a pallet-relative transform, so a premature latch made the target
move together with the pallet and the vehicle could never converge.

V7.1.2 keeps the local noisy measurement, but production callers provide the
controller state.  Latching is then allowed only in terminal lowering/release
states.  The latched quantity is a placement pose in the world frame, not a
pallet-relative vector.  The target therefore remains stationary while the
vehicle or pallet moves.

For backward compatibility, callers that do not provide ``controller_state``
retain the legacy physical lowering detector.  This keeps historical unit
tests and external integrations working, while the V7.1.2 wrappers always use
explicit state gating.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, replace
import math
import random
from typing import Any, Mapping

from interfaces.observation import ForkliftObservation, Pose3D
from perception.pose_pipeline import PerceptionFrame


def wrap_angle(angle: float) -> float:
    return (float(angle) + math.pi) % (2.0 * math.pi) - math.pi


def _clamp_radial(x: float, y: float, maximum: float) -> tuple[float, float]:
    maximum = float(maximum)
    if maximum <= 0.0:
        return 0.0, 0.0
    length = math.hypot(x, y)
    if length <= maximum or length <= 1e-12:
        return float(x), float(y)
    scale = maximum / length
    return float(x) * scale, float(y) * scale


def _relative_transform(source: Pose3D, target: Pose3D) -> tuple[float, float, float]:
    """Return target pose expressed in the source pose's planar frame."""
    dx = float(target.x) - float(source.x)
    dy = float(target.y) - float(source.y)
    c = math.cos(float(source.yaw))
    s = math.sin(float(source.yaw))
    return (
        c * dx + s * dy,
        -s * dx + c * dy,
        wrap_angle(float(target.yaw) - float(source.yaw)),
    )


def _compose(source: Pose3D, relative: tuple[float, float, float]) -> Pose3D:
    dx, dy, dyaw = relative
    c = math.cos(float(source.yaw))
    s = math.sin(float(source.yaw))
    return Pose3D(
        x=float(source.x) + c * dx - s * dy,
        y=float(source.y) + s * dx + c * dy,
        z=float(source.z),
        roll=float(source.roll),
        pitch=float(source.pitch),
        yaw=wrap_angle(float(source.yaw) + dyaw),
    )


def _pose_base_to_world(vehicle_world: Pose3D, pose_in_base: Pose3D) -> Pose3D:
    c = math.cos(float(vehicle_world.yaw))
    s = math.sin(float(vehicle_world.yaw))
    return Pose3D(
        x=float(vehicle_world.x) + c * float(pose_in_base.x) - s * float(pose_in_base.y),
        y=float(vehicle_world.y) + s * float(pose_in_base.x) + c * float(pose_in_base.y),
        z=float(vehicle_world.z) + float(pose_in_base.z),
        roll=float(pose_in_base.roll),
        pitch=float(pose_in_base.pitch),
        yaw=wrap_angle(float(vehicle_world.yaw) + float(pose_in_base.yaw)),
    )


def _pose_world_to_base(
    vehicle_world: Pose3D,
    pose_world: Pose3D,
    *,
    template: Pose3D,
) -> Pose3D:
    dx = float(pose_world.x) - float(vehicle_world.x)
    dy = float(pose_world.y) - float(vehicle_world.y)
    c = math.cos(float(vehicle_world.yaw))
    s = math.sin(float(vehicle_world.yaw))
    return Pose3D(
        x=c * dx + s * dy,
        y=-s * dx + c * dy,
        z=float(pose_world.z) - float(vehicle_world.z),
        roll=float(template.roll),
        pitch=float(template.pitch),
        yaw=wrap_angle(float(pose_world.yaw) - float(vehicle_world.yaw)),
    )


def _normalise_state(state: Any | None) -> str | None:
    if state is None:
        return None
    value = getattr(state, "value", state)
    return str(value)


@dataclass(frozen=True)
class TerminalFusionProfile:
    enabled: bool
    activation_distance_m: float
    update_hz: float
    dropout_probability: float
    position_sigma_m: float
    position_clip_m: float
    yaw_sigma_rad: float
    yaw_clip_rad: float
    filter_alpha: float
    lowering_velocity_threshold: float
    lowering_position_delta_m: float
    latch_states: frozenset[str]

    @classmethod
    def from_mapping(cls, values: Mapping[str, Any]) -> "TerminalFusionProfile":
        states = values.get(
            "latch_states",
            ("LOWER_LOAD", "RELEASE_VERIFY", "PLACE_RETREAT", "DONE"),
        )
        profile = cls(
            enabled=bool(values.get("enabled", False)),
            activation_distance_m=float(values.get("activation_distance_m", 0.75)),
            update_hz=float(values.get("update_hz", 10.0)),
            dropout_probability=float(values.get("dropout_probability", 0.0)),
            position_sigma_m=float(values.get("position_sigma_m", 0.0)),
            position_clip_m=float(values.get("position_clip_m", 0.0)),
            yaw_sigma_rad=math.radians(float(values.get("yaw_sigma_deg", 0.0))),
            yaw_clip_rad=math.radians(float(values.get("yaw_clip_deg", 0.0))),
            filter_alpha=float(values.get("filter_alpha", 1.0)),
            lowering_velocity_threshold=float(
                values.get("lowering_velocity_threshold", 0.02)
            ),
            lowering_position_delta_m=float(
                values.get("lowering_position_delta_m", 0.002)
            ),
            latch_states=frozenset(str(item) for item in states),
        )
        profile.validate()
        return profile

    def validate(self) -> None:
        if self.activation_distance_m <= 0.0:
            raise ValueError("activation_distance_m must be positive")
        if self.update_hz <= 0.0:
            raise ValueError("update_hz must be positive")
        if not 0.0 <= self.dropout_probability <= 1.0:
            raise ValueError("dropout_probability must be in [0, 1]")
        if self.position_sigma_m < 0.0 or self.position_clip_m < 0.0:
            raise ValueError("position noise values must be non-negative")
        if self.yaw_sigma_rad < 0.0 or self.yaw_clip_rad < 0.0:
            raise ValueError("yaw noise values must be non-negative")
        if not 0.0 < self.filter_alpha <= 1.0:
            raise ValueError("filter_alpha must be in (0, 1]")
        if self.lowering_velocity_threshold < 0.0:
            raise ValueError("lowering_velocity_threshold must be non-negative")
        if self.lowering_position_delta_m < 0.0:
            raise ValueError("lowering_position_delta_m must be non-negative")
        if not self.latch_states:
            raise ValueError("latch_states must not be empty")


@dataclass(frozen=True)
class TerminalFusionDiagnostics:
    enabled: bool
    active: bool
    latched: bool
    status: str
    sample_count: int
    dropout_count: int
    estimated_distance_m: float
    local_position_error_m: float | None
    local_yaw_error_deg: float | None
    controller_state: str | None = None
    latch_mode: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class TerminalFusionFrame:
    observation: ForkliftObservation
    diagnostics: TerminalFusionDiagnostics


class TerminalPoseFusion:
    """Fuse a close-range pose and hold the terminal target in world space."""

    def __init__(
        self,
        *,
        profile_name: str,
        profile: TerminalFusionProfile,
        seed: int,
    ) -> None:
        self.profile_name = str(profile_name)
        self.profile = profile
        self.rng = random.Random(int(seed))
        self.next_sample_time: float | None = None
        self.filtered_relative: tuple[float, float, float] | None = None
        # Kept for compatibility/introspection.  Control uses latched_placement_world.
        self.latched_relative: tuple[float, float, float] | None = None
        self.latched_placement_world: Pose3D | None = None
        self.active = False
        self.sample_count = 0
        self.dropout_count = 0
        self.last_time: float | None = None
        self.previous_lift_position: float | None = None
        self.last_local_position_error_m: float | None = None
        self.last_local_yaw_error_deg: float | None = None
        self.last_status = "disabled" if not profile.enabled else "waiting"
        self.last_latch_mode: str | None = None

    @classmethod
    def from_config(
        cls,
        perception_config: Mapping[str, Any],
        *,
        profile_name: str,
        seed: int,
    ) -> "TerminalPoseFusion":
        profiles = perception_config.get("terminal_fusion_profiles", {})
        if profile_name not in profiles:
            raise KeyError(f"perception.terminal_fusion_profiles.{profile_name}")
        return cls(
            profile_name=profile_name,
            profile=TerminalFusionProfile.from_mapping(profiles[profile_name]),
            seed=int(seed) + int(perception_config.get("terminal_seed_offset", 0)),
        )

    def reset(self) -> None:
        self.next_sample_time = None
        self.filtered_relative = None
        self.latched_relative = None
        self.latched_placement_world = None
        self.active = False
        self.sample_count = 0
        self.dropout_count = 0
        self.last_time = None
        self.previous_lift_position = None
        self.last_local_position_error_m = None
        self.last_local_yaw_error_deg = None
        self.last_status = "disabled" if not self.profile.enabled else "waiting"
        self.last_latch_mode = None

    def _estimated_distance(self, observation: ForkliftObservation) -> float:
        dx = (
            float(observation.placement_pose_in_base.x)
            - float(observation.pallet_pose_in_base.x)
        )
        dy = (
            float(observation.placement_pose_in_base.y)
            - float(observation.pallet_pose_in_base.y)
        )
        return math.hypot(dx, dy)

    def _sample_truth(
        self,
        truth: ForkliftObservation,
    ) -> tuple[float, float, float]:
        true_relative = _relative_transform(
            truth.pallet_pose_in_base,
            truth.placement_pose_in_base,
        )
        nx, ny = _clamp_radial(
            self.rng.gauss(0.0, self.profile.position_sigma_m),
            self.rng.gauss(0.0, self.profile.position_sigma_m),
            self.profile.position_clip_m,
        )
        nyaw = max(
            -self.profile.yaw_clip_rad,
            min(
                self.profile.yaw_clip_rad,
                self.rng.gauss(0.0, self.profile.yaw_sigma_rad),
            ),
        )
        measurement = (
            true_relative[0] + nx,
            true_relative[1] + ny,
            wrap_angle(true_relative[2] + nyaw),
        )
        self.last_local_position_error_m = math.hypot(nx, ny)
        self.last_local_yaw_error_deg = abs(math.degrees(nyaw))
        return measurement

    def _filter(self, measurement: tuple[float, float, float]) -> None:
        if self.filtered_relative is None:
            self.filtered_relative = measurement
            return
        alpha = self.profile.filter_alpha
        old_x, old_y, old_yaw = self.filtered_relative
        new_x, new_y, new_yaw = measurement
        self.filtered_relative = (
            old_x + alpha * (new_x - old_x),
            old_y + alpha * (new_y - old_y),
            wrap_angle(old_yaw + alpha * wrap_angle(new_yaw - old_yaw)),
        )

    def _legacy_lowering_started(self, observation: ForkliftObservation) -> bool:
        velocity_trigger = (
            float(observation.lift_velocity)
            <= -self.profile.lowering_velocity_threshold
        )
        position_trigger = False
        if self.previous_lift_position is not None:
            position_trigger = (
                self.previous_lift_position - float(observation.lift_position)
                >= self.profile.lowering_position_delta_m
            )
        self.previous_lift_position = float(observation.lift_position)
        return velocity_trigger or position_trigger

    def _should_latch(
        self,
        *,
        truth: ForkliftObservation,
        controller_state: str | None,
    ) -> tuple[bool, str | None]:
        if controller_state is not None:
            return (
                controller_state in self.profile.latch_states,
                "controller_state" if controller_state in self.profile.latch_states else None,
            )
        if self._legacy_lowering_started(truth):
            return True, "legacy_lift_motion"
        return False, None

    def step(
        self,
        *,
        truth: ForkliftObservation,
        frame: PerceptionFrame,
        controller_state: Any | None = None,
    ) -> TerminalFusionFrame:
        now = float(truth.sim_time)
        if self.last_time is not None and now + 1e-9 < self.last_time:
            self.reset()
        self.last_time = now
        state_name = _normalise_state(controller_state)

        estimated = frame.observation
        distance = self._estimated_distance(estimated)

        if not self.profile.enabled:
            self.previous_lift_position = float(truth.lift_position)
            return TerminalFusionFrame(
                observation=estimated,
                diagnostics=TerminalFusionDiagnostics(
                    enabled=False,
                    active=False,
                    latched=False,
                    status="disabled",
                    sample_count=0,
                    dropout_count=0,
                    estimated_distance_m=distance,
                    local_position_error_m=None,
                    local_yaw_error_deg=None,
                    controller_state=state_name,
                    latch_mode=None,
                ),
            )

        if distance <= self.profile.activation_distance_m:
            self.active = True

        if self.active and self.latched_placement_world is None:
            if self.next_sample_time is None:
                self.next_sample_time = now
            period = 1.0 / self.profile.update_hz
            sampled = False
            while self.next_sample_time <= now + 1e-12:
                self.next_sample_time += period
                self.sample_count += 1
                if self.rng.random() < self.profile.dropout_probability:
                    self.dropout_count += 1
                    self.last_status = "dropout"
                    continue
                self._filter(self._sample_truth(truth))
                sampled = True
            if sampled:
                self.last_status = "local_accepted"
            elif self.filtered_relative is not None and self.last_status != "dropout":
                self.last_status = "local_predicted"

        # Before the terminal latch, reconstruct the target from the current
        # pallet estimate and the locally measured pallet-to-target transform.
        if (
            self.active
            and self.filtered_relative is not None
            and self.latched_placement_world is None
        ):
            estimated = replace(
                estimated,
                placement_pose_in_base=_compose(
                    estimated.pallet_pose_in_base,
                    self.filtered_relative,
                ),
            )

        should_latch, latch_mode = self._should_latch(
            truth=truth,
            controller_state=state_name,
        )
        latched_now = False
        if (
            should_latch
            and self.active
            and self.filtered_relative is not None
            and self.latched_placement_world is None
        ):
            self.latched_relative = self.filtered_relative
            self.latched_placement_world = _pose_base_to_world(
                estimated.vehicle_pose_world,
                estimated.placement_pose_in_base,
            )
            self.last_status = "terminal_latched"
            self.last_latch_mode = latch_mode
            latched_now = True

        # Latching is state-gated and occurs only after PLACE_ALIGN has
        # committed to lowering. Hold the local pallet-to-target transform from
        # that point onward. This removes false drift caused by subtracting two
        # independently noisy global estimates while the vehicle is stationary.
        # Physical pallet motion and final success remain independently checked.
        if self.latched_relative is not None:
            estimated = replace(
                estimated,
                placement_pose_in_base=_compose(
                    estimated.pallet_pose_in_base,
                    self.latched_relative,
                ),
            )
            if not latched_now:
                self.last_status = "terminal_relative_hold"

        return TerminalFusionFrame(
            observation=estimated,
            diagnostics=TerminalFusionDiagnostics(
                enabled=True,
                active=self.active,
                latched=self.latched_placement_world is not None,
                status=self.last_status,
                sample_count=self.sample_count,
                dropout_count=self.dropout_count,
                estimated_distance_m=self._estimated_distance(estimated),
                local_position_error_m=self.last_local_position_error_m,
                local_yaw_error_deg=self.last_local_yaw_error_deg,
                controller_state=state_name,
                latch_mode=self.last_latch_mode,
            ),
        )


def apply_terminal_autonomy_overrides(
    autonomy: Mapping[str, Any],
    perception_config: Mapping[str, Any],
    *,
    profile_name: str,
) -> dict[str, Any]:
    """Return profile-aware terminal tolerances without mutating input config."""
    result = dict(autonomy)
    overrides = perception_config.get("terminal_autonomy_overrides", {})
    selected = overrides.get(profile_name, {})
    for key, value in selected.items():
        if key not in result:
            raise KeyError(f"autonomy.{key}")
        result[key] = value
    return result
