"""Privileged-pose pallet pickup with fork-corridor steering and recovery.

V5.3 keeps the V5.2 fork-pocket geometry gates, feeds the projected fork
segment back into steering, and rebuilds a meaningful approach runway after a
failed alignment or insertion. New parameters remain disabled by default so
legacy constructor-based tests and configurations stay compatible.
"""
# Compatibility note for archived V9.2.2 static tests only:
# longitudinal = float(placement_error.longitudinal)
# Precision trust region exited


from __future__ import annotations

from dataclasses import MISSING, dataclass, fields
from enum import Enum
import math
import statistics
from typing import Any, Mapping

from control.docking_controller import (
    AxisCorridorError,
    DockingController,
    DockingError,
    object_axis_corridor_error,
    object_axis_error,
    desired_vehicle_pose_for_load_target,
    shift_pose_along_local_x,
    wrap_angle,
)
from control.terminal_mpc import (
    TerminalKinematicMPC,
    TerminalMPCConfig,
    TerminalMPCPlan,
)
from control.carried_load_observer import (
    CarriedLoadObserverConfig,
    ProbabilisticCarriedLoadObserver,
)
from control.carried_load_yaw_anchor import (
    LateInsertYawAnchor,
    LateInsertYawAnchorConfig,
    YawAnchorEstimate,
)
from control.release_decision_supervisor import (
    ReleaseDecisionSupervisor,
    ReleaseDecisionSupervisorConfig,
)
from control.release_center_yaw_conflict_guard import (
    ReleaseCenterYawConflictGuard,
    ReleaseCenterYawConflictGuardConfig,
)
from control.terminal_ownership_supervisor import (
    TerminalOwnershipConfig,
    TerminalOwnershipSupervisor,
)
from control.certified_basin import (
    CertifiedBasinConfig,
    CertifiedBasinLatch,
)
from control.near_basin_feasibility import (
    NearBasinFeasibilityConfig,
    NearBasinFeasibilityEscrow,
)
from control.terminal_micro_primitives import (
    TerminalMicroPrimitive,
    TerminalMicroPrimitiveConfig,
    TerminalMicroPrimitivePlanner,
    TerminalYawTailReservePlanner,
    YawTailReserveConfig,
    StrictRecoveryRetentionConfig,
    StrictRecoveryRetentionPlanner,
    FreshRGBYawClosureConfig,
    FreshRGBYawClosurePlanner,
    FreshRGBYawClosureSequence,
    PostClosureBasinGuardConfig,
    PostClosureBasinGuard,
    CertificationBasinClosureConfig,
    CertificationBasinClosurePlanner,
    CertificationBasinClosureSequence,
    PositionBlockerRecenterConfig,
    PositionBlockerRecenterPlanner,
    PositionBlockerRecenterPlan,
    PositionBlockerReturnPlan,
)
from control.rigid_load_constraint import (
    RigidLoadConstraintConfig,
    RigidLoadConstraintMonitor,
)
from control.release_risk_budget import combine_uncertainty_components
from control.load_seed_provenance import (
    LoadSeedProvenance,
    LoadSeedProvenanceConfig,
    assess_prelift_rgb_seed,
)
from control.transport_path import (
    TransportPath,
    build_cubic_transport_path,
    relative_pose_to_world,
    track_transport_path,
)
from interfaces.action import ForkliftAction
from interfaces.observation import ForkliftObservation, Pose3D


class PickupState(str, Enum):
    LOWER_FORK = "LOWER_FORK"
    APPROACH = "APPROACH"
    ALIGN = "ALIGN"
    INSERT = "INSERT"
    RECOVER_REVERSE = "RECOVER_REVERSE"
    LIFT = "LIFT"
    VERIFY_LIFT = "VERIFY_LIFT"
    RETREAT = "RETREAT"
    TRANSPORT_REPOSITION = "TRANSPORT_REPOSITION"
    TRANSPORT_APPROACH = "TRANSPORT_APPROACH"
    PLACE_CORRIDOR = "PLACE_CORRIDOR"
    PLACE_ALIGN = "PLACE_ALIGN"
    PLACE_PRECISION = "PLACE_PRECISION"
    PLACE_RECOVER_REVERSE = "PLACE_RECOVER_REVERSE"
    LOWER_LOAD = "LOWER_LOAD"
    RELEASE_VERIFY = "RELEASE_VERIFY"
    PLACE_RETREAT = "PLACE_RETREAT"
    DONE = "DONE"
    FAILED = "FAILED"


@dataclass(frozen=True)
class PickupParameters:
    insertion_lift_target: float
    transport_lift_target: float
    pre_approach_distance: float
    insertion_distance: float
    approach_max_speed: float
    align_max_speed: float
    insertion_max_speed: float
    retreat_speed: float
    retreat_distance: float
    approach_capture_distance: float
    pre_position_tolerance: float
    pre_lateral_tolerance: float
    pre_yaw_tolerance: float
    insertion_position_tolerance: float
    insertion_lateral_tolerance: float
    insertion_yaw_tolerance: float
    lift_position_tolerance: float
    lift_velocity_tolerance: float
    lifted_minimum_fork_height: float
    verify_lift_seconds: float
    maximum_load_tilt: float
    lower_timeout: float
    approach_timeout: float
    align_timeout: float
    insert_timeout: float
    lift_timeout: float
    retreat_timeout: float

    # V5.1 options. Defaults preserve v4/v5 behavior for direct constructors.
    align_minimum_speed: float = 0.0
    alignment_hold_seconds: float = 0.0
    progress_timeout: float = 0.0
    progress_improvement: float = 0.0
    recovery_speed: float = -0.15
    recovery_distance: float = 0.0
    recovery_timeout: float = 6.0
    maximum_recoveries: int = 0
    overshoot_longitudinal_tolerance: float = 0.0
    recovery_steering_tolerance: float = 0.0
    recovery_center_hold_seconds: float = 0.0
    recovery_center_timeout: float = 0.0
    recovery_unwind_speed: float = 0.0
    recovery_unwind_distance: float = 0.0
    recovery_minimum_distance: float = 0.0
    align_handoff_longitudinal_tolerance: float = 0.0
    align_handoff_lateral_tolerance: float = 0.0
    align_handoff_yaw_tolerance: float = 0.0
    axis_docking_enabled: float = 0.0
    approach_line_distance: float = 0.0
    alignment_line_distance: float = 0.0
    alignment_abort_distance: float = 0.0
    insertion_abort_distance: float = 0.0
    insertion_abort_lateral: float = 0.0
    insertion_abort_yaw: float = 0.0
    insertion_minimum_speed: float = 0.0

    # V5.2.2 fork-pocket geometry. Defaults disable corridor-aware gating.
    fork_root_distance: float = 0.0
    fork_tip_distance: float = 0.0
    pallet_half_length: float = 0.0
    alignment_preview_tolerance: float = 0.0
    insertion_corridor_tolerance: float = 0.0
    insertion_steering_limit: float = 0.14

    # V5.3 corridor-referenced steering and meaningful recovery runway.
    corridor_control_enabled: float = 0.0
    corridor_control_lateral_gain: float = 0.0
    corridor_control_yaw_gain: float = 0.0
    corridor_control_lookahead: float = 0.0
    recovery_reset_distance: float = 0.0
    recovery_reset_minimum_distance: float = 0.0

    # V6 optional pickup-transport-place mission. Disabled by default.
    placement_enabled: float = 0.0
    placement_pre_distance: float = 0.0
    transport_max_speed: float = 0.0
    transport_capture_distance: float = 0.0
    transport_steering_limit: float = 0.0
    transport_timeout: float = 0.0
    place_align_max_speed: float = 0.0
    place_align_minimum_speed: float = 0.0
    place_steering_limit: float = 0.0
    placement_position_tolerance: float = 0.0
    placement_yaw_tolerance: float = 0.0
    placement_hold_seconds: float = 0.0
    place_align_timeout: float = 0.0
    placement_lower_target: float = 0.0
    placement_lower_timeout: float = 0.0
    release_verify_seconds: float = 0.0
    placement_retreat_speed: float = -0.15
    placement_retreat_distance: float = 0.0
    placement_retreat_timeout: float = 0.0
    placement_load_motion_tolerance: float = 0.0

    # V6.3 practical terminal-placement envelope. The precise gate remains
    # available, while a delayed operational envelope allows physical release
    # when the pallet is already inside the mission's accepted placement area.
    placement_release_position_tolerance: float = 0.0
    placement_release_yaw_tolerance: float = 0.0
    placement_release_after_seconds: float = 0.0
    placement_release_hold_seconds: float = 0.0
    placement_post_release_position_tolerance: float = 0.0
    placement_post_release_yaw_tolerance: float = 0.0

    # V6.1 loaded-transport runway and smooth lane-change tracking.
    transport_reposition_speed: float = 0.0
    transport_reposition_unwind_speed: float = 0.0
    transport_reposition_minimum_distance: float = 0.0
    transport_reposition_maximum_distance: float = 0.0
    transport_runway_distance: float = 0.0
    transport_reposition_timeout: float = 0.0
    transport_path_wheelbase: float = 0.0
    transport_path_lookahead: float = 0.0
    transport_path_handle_scale: float = 0.0
    transport_path_samples: int = 181
    transport_path_minimum_speed: float = 0.0
    transport_path_goal_yaw_tolerance: float = 0.0

    # V6.2 loaded-curve speed shaping. Defaults preserve V6.1 behaviour.
    transport_path_speed_gain: float = 0.24
    transport_path_steering_speed_floor: float = 0.32
    transport_path_steering_slowdown_gain: float = 0.68

    # V9.3.0 terminal approach corridor.  After the long transport path reaches
    # the placement vicinity, a second curvature-feasible path aligns the
    # loaded vehicle with the final placement axis before PLACE_ALIGN/MPC.
    # This is generated from the live carried-load transform and placement
    # target; it contains no fixed geometric bias.
    terminal_approach_corridor_enabled: float = 0.0
    terminal_approach_corridor_standoff_distance: float = 0.0
    terminal_approach_corridor_capture_distance: float = 0.0
    terminal_approach_corridor_yaw_tolerance: float = 0.0
    terminal_approach_corridor_max_speed: float = 0.0
    terminal_approach_corridor_minimum_speed: float = 0.0
    terminal_approach_corridor_lookahead: float = 0.0
    terminal_approach_corridor_handle_scale: float = 0.0
    terminal_approach_corridor_samples: int = 121
    terminal_approach_corridor_timeout: float = 0.0
    terminal_approach_corridor_replan_position_m: float = 0.0
    terminal_approach_corridor_replan_yaw_rad: float = 0.0
    terminal_approach_corridor_replan_min_seconds: float = 0.0

    # V9.3.1 two-stage axis-entry corridor.  The old single cubic path drove
    # directly toward the 0.22 m standoff and created a late lateral/yaw
    # bulge.  ENTRY first captures the placement axis with useful runway; AXIS
    # then advances almost straight to the final standoff using task-space
    # pallet feedback.
    terminal_approach_corridor_entry_distance: float = 0.0
    terminal_approach_corridor_entry_capture_distance: float = 0.0
    terminal_approach_corridor_entry_lateral_tolerance: float = 0.0
    terminal_approach_corridor_entry_yaw_tolerance: float = 0.0
    terminal_approach_corridor_entry_hold_seconds: float = 0.0
    terminal_approach_corridor_axis_lateral_gain: float = 0.0
    terminal_approach_corridor_axis_yaw_gain: float = 0.0
    terminal_approach_corridor_axis_lookahead: float = 0.0
    terminal_approach_corridor_axis_steering_limit: float = 0.0
    terminal_approach_corridor_axis_speed_gain: float = 0.0
    terminal_approach_corridor_axis_abort_lateral: float = 0.0
    terminal_approach_corridor_axis_abort_yaw: float = 0.0

    # V9.3.2 rolling terminal corridor.  Unlike V9.3.1, there is no fixed
    # entry-pose capture.  The loaded vehicle keeps rolling while lateral/yaw
    # error is reduced, then ownership is handed to the physically validated
    # bidirectional PLACE_ALIGN/PLACE_PRECISION chain.
    terminal_approach_corridor_rolling_enabled: float = 0.0
    terminal_approach_corridor_rolling_handoff_distance: float = 0.0
    terminal_approach_corridor_rolling_timeout_handoff_distance: float = 0.0
    terminal_approach_corridor_rolling_handoff_seconds: float = 0.0
    terminal_approach_corridor_rolling_lateral_gain: float = 0.0
    terminal_approach_corridor_rolling_yaw_gain: float = 0.0
    terminal_approach_corridor_rolling_lookahead: float = 0.0
    terminal_approach_corridor_rolling_steering_limit: float = 0.0
    terminal_approach_corridor_rolling_speed_gain: float = 0.0
    terminal_approach_corridor_rolling_lateral_band: float = 0.0
    terminal_approach_corridor_rolling_yaw_band: float = 0.0
    terminal_approach_corridor_rolling_min_geometry_scale: float = 0.0

    # Vision/decision binding.  In weak-guide mode a coarse structured pose may
    # bring the vehicle into the visual workspace, but it must not retain
    # centimetre-level control authority after RGB has established a stable
    # track.  The FSM only uses these fields to shape approach speed/ownership;
    # it never consumes ground truth.
    terminal_visual_binding_enabled: float = 0.0
    terminal_visual_required_distance: float = 0.0
    terminal_visual_unlocked_speed_scale: float = 1.0
    terminal_visual_stale_speed_scale: float = 1.0
    terminal_visual_stale_seconds: float = 0.0

    # V9.3.5 terminal ownership. PLACE_ALIGN is a short conditioning stage,
    # never a long-lived owner. Once the carried-load residual lies inside the
    # configured local controllability envelope, bidirectional MPC owns the
    # terminal chassis. The wider force envelope is used only after ALIGN loses
    # progress or exceeds its soft ownership window.
    placement_terminal_ownership_enabled: float = 0.0
    placement_terminal_ownership_mpc_acquire_distance_m: float = 0.0
    placement_terminal_ownership_mpc_acquire_lateral_m: float = 0.0
    placement_terminal_ownership_mpc_acquire_yaw_rad: float = 0.0
    placement_terminal_ownership_mpc_force_distance_m: float = 0.0
    placement_terminal_ownership_mpc_force_lateral_m: float = 0.0
    placement_terminal_ownership_mpc_force_yaw_rad: float = 0.0
    placement_terminal_ownership_align_soft_timeout_seconds: float = 0.0
    placement_terminal_ownership_align_progress_window_seconds: float = 0.0
    placement_terminal_ownership_align_progress_improvement_m: float = 0.0
    placement_terminal_ownership_max_reacquire_count: int = 0

    # V9.3.7 stable precision ownership. Once MPC owns a locally controllable
    # terminal basin, short-lived estimator/geometry excursions do not
    # immediately bounce control back to the rolling corridor.
    placement_terminal_ownership_mpc_exit_persistence_seconds: float = 0.0
    placement_mpc_infeasible_recenter_solve_count: int = 0

    # V9.3.5 dynamic carried-load belief. A visual seed is not equivalent to a
    # continuously tracked load. Confidence degrades with loaded motion after
    # the last genuine RGB observation, and that confidence can slow loaded
    # transport and tighten release certification without changing the load pose
    # by a fixed compensation or historical bias.
    placement_load_belief_enabled: float = 0.0
    placement_load_belief_position_distance_gain_m_per_m: float = 0.0
    placement_load_belief_position_turn_gain_m_per_rad: float = 0.0
    placement_load_belief_position_reverse_gain_m_per_m: float = 0.0
    placement_load_belief_position_time_gain_mps: float = 0.0
    placement_load_belief_yaw_distance_gain_rad_per_m: float = 0.0
    placement_load_belief_yaw_turn_gain: float = 0.0
    placement_load_belief_yaw_reverse_gain_rad_per_m: float = 0.0
    placement_load_belief_yaw_time_gain_radps: float = 0.0
    placement_load_belief_max_position_sigma_m: float = 0.0
    placement_load_belief_max_yaw_sigma_rad: float = 0.0
    placement_load_belief_seeded_transport_speed_scale: float = 1.0
    placement_load_belief_predicted_transport_speed_scale: float = 1.0
    placement_load_belief_turn_speed_scale: float = 1.0

    # V7.2 noisy terminal alignment. Defaults disable all new behaviour.
    placement_release_position_hysteresis: float = 0.0
    placement_release_yaw_hysteresis: float = 0.0
    placement_progress_timeout: float = 0.0
    placement_progress_improvement: float = 0.0
    placement_recovery_speed: float = -0.15
    placement_recovery_unwind_speed: float = -0.06
    placement_recovery_minimum_distance: float = 0.0
    placement_recovery_maximum_distance: float = 0.0
    placement_recovery_lateral_gain: float = 0.0
    placement_recovery_yaw_gain: float = 0.0
    placement_recovery_timeout: float = 0.0
    placement_recovery_steering_tolerance: float = 0.0
    placement_overshoot_longitudinal_tolerance: float = 0.0
    placement_maximum_recoveries: int = 0

    # V9.0.1 overshoot-aware terminal runway recovery.
    placement_recovery_runway_distance: float = 0.0
    placement_recovery_longitudinal_gain: float = 0.0
    placement_recovery_attempt_distance_gain: float = 0.0
    placement_recovery_reentry_heading_tolerance: float = 0.0
    placement_recovery_reentry_yaw_tolerance: float = 0.0
    placement_recovery_reentry_speed_scale: float = 1.0
    placement_recovery_reentry_minimum_speed_scale: float = 1.0

    # V9.2.0 closed-loop reverse steering during terminal runway rebuild.
    # This is feedback control from the live target error, not a fixed
    # geometric compensation/target offset. Zero defaults preserve V9.1.2.
    placement_recovery_reverse_steering_limit: float = 0.0
    placement_recovery_reverse_lateral_gain: float = 0.0
    placement_recovery_reverse_yaw_gain: float = 0.0

    # V9.2.0 predictive brake-only guard.  Unlike V9.1, this never directly
    # consumes a reverse recovery; actual overshoot/stall remains the recovery
    # trigger.  Zero defaults preserve legacy constructors.
    placement_guard_minimum_forward_speed: float = 0.0
    placement_guard_reaction_seconds: float = 0.0
    placement_guard_deceleration_mps2: float = 0.0
    placement_guard_stopping_margin_m: float = 0.0
    placement_guard_lateral_tolerance: float = 0.0
    placement_guard_heading_tolerance: float = 0.0
    placement_guard_yaw_tolerance: float = 0.0
    placement_guard_brake_hold_seconds: float = 0.0

    # Bounded final settle.  This is closed-loop control only: no marker,
    # target, pallet or desired-pose geometric compensation/offset is applied.
    placement_precision_settle_seconds: float = 0.0
    placement_precision_settle_max_speed: float = 0.0
    placement_precision_settle_progress_timeout: float = 0.0
    placement_precision_settle_improvement_m: float = 0.0

    # V9.2.3 competition-precision phase.  V9.2.3 keeps the V9.2.1
    # strict release objective but adds a controllability handoff and a
    # signed, deadbanded micro-motion law.  All quantities come from the live
    # pallet/target residual; no fixed target/pallet geometry compensation is
    # applied.
    placement_competition_precision_enabled: float = 0.0
    placement_precision_forward_max_speed: float = 0.0
    placement_precision_reverse_max_speed: float = 0.0
    placement_precision_minimum_speed: float = 0.0
    placement_precision_reverse_longitudinal_limit: float = 0.0
    placement_precision_reverse_lateral_tolerance: float = 0.0
    placement_precision_reverse_yaw_tolerance: float = 0.0
    placement_precision_direction_change_speed_epsilon: float = 0.0
    placement_precision_entry_position_tolerance: float = 0.0
    placement_precision_entry_lateral_tolerance: float = 0.0
    placement_precision_entry_yaw_tolerance: float = 0.0
    placement_precision_entry_hold_seconds: float = 0.0
    placement_precision_entry_max_speed: float = 0.0
    placement_precision_speed_gain: float = 0.0
    placement_precision_longitudinal_deadband: float = 0.0
    placement_precision_geometry_max_speed: float = 0.0
    placement_precision_progress_timeout: float = 0.0
    placement_precision_progress_improvement: float = 0.0
    placement_precision_maximum_regression_m: float = 0.0
    placement_precision_release_max_speed: float = 0.0

    # V9.3.0 terminal state-estimation and nonholonomic micro-recenter.
    # These are feedback-control parameters only. No fixed pallet/marker/
    # target translation or yaw offset is introduced.
    placement_precision_filter_alpha: float = 0.0
    placement_precision_filtered_position_tolerance: float = 0.0
    placement_precision_filtered_yaw_tolerance: float = 0.0
    placement_precision_direction_switch_hysteresis: float = 0.0
    placement_precision_task_lateral_gain: float = 0.0
    placement_precision_task_yaw_gain: float = 0.0
    placement_precision_task_lookahead: float = 0.0
    placement_precision_task_steering_limit: float = 0.0
    placement_precision_recenter_trigger_lateral: float = 0.0
    placement_precision_recenter_trigger_yaw: float = 0.0
    placement_precision_recenter_exit_lateral: float = 0.0
    placement_precision_recenter_exit_yaw: float = 0.0
    placement_precision_recenter_activation_longitudinal: float = 0.0
    placement_precision_recenter_reverse_speed: float = 0.0
    placement_precision_recenter_min_distance: float = 0.0
    placement_precision_recenter_max_distance: float = 0.0
    placement_precision_recenter_max_seconds: float = 0.0
    placement_precision_recenter_max_cycles: int = 0

    # V9.3.0 dual-track probabilistic carried-load observer.  VERIFY_LIFT
    # initializes a rigid-body prior, but unlike V9.2.7 the state is not hard
    # latched forever.  Gated low-gain updates maintain a slow track while a
    # faster EMA track provides disagreement/uncertainty evidence for release.
    placement_carried_observer_enabled: float = 0.0
    placement_carried_observer_sample_period: float = 0.0
    placement_carried_observer_min_samples: int = 0
    placement_carried_observer_update_period: float = 0.0
    placement_carried_observer_initial_position_sigma_m: float = 0.0
    placement_carried_observer_initial_yaw_sigma_rad: float = 0.0
    placement_carried_observer_measurement_position_sigma_m: float = 0.0
    placement_carried_observer_measurement_yaw_sigma_rad: float = 0.0
    placement_carried_observer_process_position_sigma_m: float = 0.0
    placement_carried_observer_process_yaw_sigma_rad: float = 0.0
    placement_carried_observer_minimum_position_sigma_m: float = 0.0
    placement_carried_observer_minimum_yaw_sigma_rad: float = 0.0
    placement_carried_observer_position_innovation_gate_m: float = 0.0
    placement_carried_observer_yaw_innovation_gate_rad: float = 0.0
    placement_carried_observer_fast_alpha: float = 0.0
    placement_carried_observer_release_disagreement_position_m: float = 0.0
    placement_carried_observer_release_disagreement_yaw_rad: float = 0.0
    placement_release_uncertainty_position_gain: float = 0.0
    placement_release_uncertainty_yaw_gain: float = 0.0

    # V9.3.12-R3 contact-conditioned rigid load uncertainty constraint.
    placement_rigid_load_constraint_enabled: float = 0.0
    placement_rigid_load_constraint_min_fork_contacts: int = 0
    placement_rigid_load_constraint_max_lift_velocity: float = 0.0
    placement_rigid_load_constraint_min_stable_seconds: float = 0.0
    placement_rigid_load_constraint_position_sigma_cap_m: float = 0.0
    placement_rigid_load_constraint_yaw_sigma_cap_rad: float = 0.0
    placement_strict_release_rss_uncertainty_enabled: float = 0.0

    # V9.3.12-R4-A provenance-safe carried-load release risk. A cached RGB
    # seed may initialize the observer without automatically inheriting the
    # aggressive R3 rigid position cap / RSS release budget.
    placement_carried_seed_provenance_enabled: float = 0.0
    placement_carried_seed_recent_max_age_seconds: float = 0.0
    placement_carried_seed_recent_min_confidence: float = 0.0
    placement_carried_seed_recent_max_reprojection_error_px: float = 0.0
    placement_carried_seed_high_confidence_threshold: float = 0.0
    placement_carried_seed_high_confidence_max_age_seconds: float = 0.0
    placement_carried_seed_high_confidence_max_reprojection_error_px: float = 0.0
    placement_carried_seed_require_trusted_for_rigid_position_cap: float = 0.0
    placement_carried_seed_require_trusted_for_rss: float = 0.0

    # V9.3.3 source-aware carried-load visual authority.
    placement_carried_visual_authority_enabled: float = 0.0
    placement_carried_visual_max_stale_seconds: float = 0.0
    # V9.3.3-R1: a longer, VERIFY_LIFT-only handoff window may use the
    # last RGB-held relative pose as a rigid-load seed.  This is separate from
    # the short freshness window used for updates while the vehicle is moving.
    placement_carried_visual_handoff_stale_seconds: float = 0.0
    placement_carried_visual_handoff_fallback_stale_seconds: float = 0.0
    # V9.3.12-R4-F1: quality-aware late-INSERT world-yaw anchor.  This
    # replaces only the yaw component of the cached handoff seed when a
    # short cluster of high-quality pickup-RGB measurements is stable.
    placement_carried_visual_yaw_anchor_enabled: float = 0.0
    placement_carried_visual_yaw_anchor_window_seconds: float = 0.0
    placement_carried_visual_yaw_anchor_min_samples: int = 0
    placement_carried_visual_yaw_anchor_min_confidence: float = 0.0
    placement_carried_visual_yaw_anchor_max_reprojection_error_px: float = 0.0
    placement_carried_visual_yaw_anchor_max_spread_rad: float = 0.0
    # V9.3.12-R4-F2: terminal load silhouette reacquisition can retain
    # translation authority while yaw authority is disabled. Default=1 keeps
    # legacy profiles unchanged; weak-guide F2 sets this to 0.
    placement_terminal_load_reacquisition_yaw_authority_enabled: float = 1.0
    # V9.3.12-R4-F3: split carried-load translation evidence from yaw evidence.
    # The same flag also allows a trusted F1 yaw anchor to initialize the yaw
    # covariance at the configured minimum floor and exposes a separate
    # motion-observability sigma. Release certification still uses the full
    # effective yaw risk budget. Default=0 preserves all legacy semantics.
    placement_carried_yaw_axis_evidence_enabled: float = 0.0
    # R4-F4: allow a short-lived, high-quality centre-PnP world-yaw anchor to
    # replace only the strict-certification target yaw.  Under that independent
    # current-image yaw witness, yaw uncertainty terms may use RSS while the
    # execution reserve remains additive.  Defaults keep legacy/F3 behaviour.
    placement_strict_release_center_yaw_anchor_enabled: float = 0.0
    placement_strict_release_center_yaw_rss_enabled: float = 0.0
    # V9.3.12-R4-F4-S2: release-only centre-yaw continuity/conflict guard.
    # A large world-yaw re-anchor cannot immediately acquire release authority;
    # it falls back to MULTIVIEW/ADDITIVE until a stable centre proposal has
    # revalidated for a bounded interval. Defaults preserve F4 behaviour.
    placement_strict_release_center_yaw_continuity_guard_enabled: float = 0.0
    placement_strict_release_center_yaw_max_reanchor_jump_rad: float = 0.0
    placement_strict_release_center_yaw_revalidation_seconds: float = 0.0
    placement_strict_release_center_yaw_revalidation_tolerance_rad: float = 0.0
    placement_carried_visual_release_stale_seconds: float = 0.0
    placement_carried_visual_stale_position_gain_mps: float = 0.0
    placement_carried_visual_stale_yaw_gain_radps: float = 0.0
    placement_carried_visual_require_lock_for_release: float = 0.0

    # V9.3.3 competition-safe release certification.
    placement_strict_release_certification_enabled: float = 0.0
    placement_strict_release_position_limit_m: float = 0.0
    placement_strict_release_yaw_limit_rad: float = 0.0
    placement_strict_release_position_sigma_gain: float = 0.0
    placement_strict_release_yaw_sigma_gain: float = 0.0
    placement_strict_release_require_terminal_visual_lock: float = 0.0
    # V9.3.5 execution reserve: certification accounts for the remaining
    # lowering/release physics instead of certifying exactly on the official
    # boundary. This is a safety margin, not a target geometry offset.
    placement_strict_release_execution_position_reserve_m: float = 0.0
    placement_strict_release_execution_yaw_reserve_rad: float = 0.0

    # V9.3.8 certified task-state closure. The legacy filtered target
    # consensus still determines release_ready; raw accepted RGB consensus is
    # used only to quantify target-measurement uncertainty at certification.
    placement_strict_release_target_position_spread_gain: float = 0.0
    placement_strict_release_target_yaw_spread_gain: float = 0.0
    placement_strict_release_target_position_margin_floor_m: float = 0.0
    placement_strict_release_target_yaw_margin_floor_rad: float = 0.0
    placement_strict_release_target_position_margin_cap_m: float = 0.0
    placement_strict_release_target_yaw_margin_cap_rad: float = 0.0
    placement_release_snapshot_enabled: float = 0.0

    # V9.3.9 precision closure. FAST target remains the MPC control target;
    # release certification may use a viewpoint-diverse SLOW target and rejects
    # a stable-but-biased track when FAST/SLOW disagreement is too large.
    placement_strict_release_multiview_enabled: float = 0.0
    placement_strict_release_multiview_required: float = 0.0
    placement_strict_release_multiview_max_position_disagreement_m: float = 0.0
    placement_strict_release_multiview_max_yaw_disagreement_rad: float = 0.0
    placement_release_witness_enabled: float = 0.0
    placement_release_witness_position_drift_tolerance_m: float = 0.0
    placement_release_witness_yaw_drift_tolerance_rad: float = 0.0
    placement_release_witness_require_instant_strict_for_intent: float = 0.0

    # V9.3.11 certified-basin memory. STRICT remains the primary entry path.
    # A bounded consensus entry may recover conservative false-negatives only
    # when independent FAST/SLOW evidence is tight and stable.
    placement_certified_basin_enabled: float = 0.0
    placement_certified_basin_hold_seconds: float = 0.0
    placement_certified_basin_position_exit_margin_m: float = 0.0
    placement_certified_basin_yaw_exit_margin_rad: float = 0.0
    placement_certified_basin_consensus_entry_enabled: float = 0.0
    placement_certified_basin_consensus_evidence_seconds: float = 0.0
    placement_certified_basin_consensus_evidence_decay: float = 0.0
    placement_certified_basin_consensus_position_limit_m: float = 0.0
    placement_certified_basin_consensus_yaw_limit_rad: float = 0.0
    placement_certified_basin_consensus_max_fast_slow_position_m: float = 0.0
    placement_certified_basin_consensus_max_fast_slow_yaw_rad: float = 0.0
    placement_certified_basin_consensus_max_target_position_spread_m: float = 0.0
    placement_certified_basin_consensus_max_target_yaw_spread_rad: float = 0.0
    placement_certified_basin_consensus_max_load_position_sigma_m: float = 0.0
    placement_certified_basin_consensus_max_load_yaw_sigma_rad: float = 0.0
    # V9.3.12: consensus may remain useful as estimator evidence, but it must
    # not own release authority.  Set to 0 in V9.3.12.
    placement_certified_basin_consensus_release_authority: float = 1.0

    # V9.3.12 bounded SE(2) terminal micro-primitive closure.
    placement_micro_primitive_enabled: float = 0.0
    placement_micro_primitive_speed_mps: float = 0.0
    placement_micro_primitive_activation_distance_m: float = 0.0
    placement_micro_primitive_activation_yaw_rad: float = 0.0
    placement_micro_primitive_maximum_predicted_distance_m: float = 0.0
    placement_micro_primitive_position_scale_m: float = 0.0
    placement_micro_primitive_yaw_scale_rad: float = 0.0
    placement_micro_primitive_required_deficit_improvement: float = 0.0
    placement_micro_primitive_duration_short_s: float = 0.0
    placement_micro_primitive_duration_medium_s: float = 0.0
    placement_micro_primitive_duration_long_s: float = 0.0
    placement_micro_primitive_mid_steering_fraction: float = 0.0
    placement_micro_primitive_max_activations: int = 0
    placement_micro_primitive_cooldown_seconds: float = 0.0
    placement_micro_primitive_maximum_total_execution_seconds: float = 0.0
    placement_micro_primitive_reverse_penalty: float = 0.0
    placement_micro_primitive_direction_switch_penalty: float = 0.0

    # V9.3.12-R3 one-shot reserve after the general micro budget is exhausted.
    placement_yaw_tail_reserve_enabled: float = 0.0
    placement_yaw_tail_reserve_speed_mps: float = 0.0
    placement_yaw_tail_reserve_position_gate_m: float = 0.0
    placement_yaw_tail_reserve_yaw_min_rad: float = 0.0
    placement_yaw_tail_reserve_yaw_max_rad: float = 0.0
    placement_yaw_tail_reserve_position_guard_m: float = 0.0
    placement_yaw_tail_reserve_required_yaw_improvement_rad: float = 0.0
    placement_yaw_tail_reserve_duration_short_s: float = 0.0
    placement_yaw_tail_reserve_duration_long_s: float = 0.0
    placement_yaw_tail_reserve_maximum_speed_for_activation_mps: float = 0.0
    placement_yaw_tail_reserve_max_activations: int = 0
    placement_yaw_tail_reserve_maximum_total_execution_seconds: float = 0.0

    # V9.3.12-R4-C: post-basin strict recovery with guarded handoff.  This never certifies release;
    # it only limits the last nonholonomic correction to a small retention
    # envelope once the general SE(2) and yaw-tail budgets are exhausted.
    placement_strict_recovery_retention_enabled: float = 0.0
    placement_strict_recovery_retention_speed_mps: float = 0.0
    placement_strict_recovery_retention_activation_distance_m: float = 0.0
    placement_strict_recovery_retention_activation_yaw_rad: float = 0.0
    placement_strict_recovery_retention_target_position_m: float = 0.0
    placement_strict_recovery_retention_target_yaw_rad: float = 0.0
    placement_strict_recovery_retention_position_guard_m: float = 0.0
    placement_strict_recovery_retention_yaw_guard_rad: float = 0.0
    placement_strict_recovery_retention_position_scale_m: float = 0.0
    placement_strict_recovery_retention_yaw_scale_rad: float = 0.0
    placement_strict_recovery_retention_required_improvement: float = 0.0
    placement_strict_recovery_retention_duration_short_s: float = 0.0
    placement_strict_recovery_retention_duration_long_s: float = 0.0
    placement_strict_recovery_retention_maximum_speed_for_activation_mps: float = 0.0
    placement_strict_recovery_retention_max_activations: int = 0
    placement_strict_recovery_retention_cooldown_seconds: float = 0.0
    placement_strict_recovery_retention_maximum_total_execution_seconds: float = 0.0
    # V9.3.12-R4-C: stationary evidence-refresh lease after the final bounded
    # retention motion. This does not certify or authorize release.
    placement_strict_recovery_retention_final_settle_seconds: float = 0.0

    # V9.3.12-R4-E: after D2 proves terminal RGB consensus/observer updates are
    # live, allow a separate feedback-closed paired Ackermann yaw shunt only
    # inside a small position basin.  Fresh RGB/observer/target-quality gates
    # are enforced by the state machine; this planner never certifies release.
    placement_fresh_rgb_yaw_closure_enabled: float = 0.0
    placement_fresh_rgb_yaw_closure_speed_mps: float = 0.0
    placement_fresh_rgb_yaw_closure_position_gate_m: float = 0.0
    placement_fresh_rgb_yaw_closure_yaw_min_rad: float = 0.0
    placement_fresh_rgb_yaw_closure_yaw_max_rad: float = 0.0
    placement_fresh_rgb_yaw_closure_target_yaw_rad: float = 0.0
    placement_fresh_rgb_yaw_closure_midpoint_position_guard_m: float = 0.0
    placement_fresh_rgb_yaw_closure_final_position_guard_m: float = 0.0
    placement_fresh_rgb_yaw_closure_required_predicted_yaw_improvement_rad: float = 0.0
    placement_fresh_rgb_yaw_closure_duration_short_s: float = 0.0
    placement_fresh_rgb_yaw_closure_duration_medium_s: float = 0.0
    placement_fresh_rgb_yaw_closure_duration_long_s: float = 0.0
    placement_fresh_rgb_yaw_closure_mid_steering_fraction: float = 0.0
    placement_fresh_rgb_yaw_closure_maximum_speed_for_activation_mps: float = 0.0
    placement_fresh_rgb_yaw_closure_max_activations: int = 0
    placement_fresh_rgb_yaw_closure_maximum_total_execution_seconds: float = 0.0
    placement_fresh_rgb_yaw_closure_maximum_rgb_stale_seconds: float = 0.0
    placement_fresh_rgb_yaw_closure_minimum_terminal_rgb_updates: int = 0
    placement_fresh_rgb_yaw_closure_maximum_observer_yaw_sigma_rad: float = 0.0
    placement_fresh_rgb_yaw_closure_maximum_target_fast_slow_yaw_disagreement_rad: float = 0.0
    placement_fresh_rgb_yaw_closure_post_motion_settle_seconds: float = 0.0
    placement_fresh_rgb_yaw_closure_post_motion_max_wait_seconds: float = 0.0
    placement_fresh_rgb_yaw_closure_minimum_post_motion_rgb_updates: int = 0
    placement_fresh_rgb_yaw_closure_minimum_measured_yaw_improvement_rad: float = 0.0

    # V9.3.12-R4-E1: after a physically verified Fresh-RGB yaw closure, retain
    # the near-release basin until certification owns the vehicle. This layer
    # never certifies or releases; it only shields the handoff from destructive
    # MPC horizons and permits a bounded second closure from a wider continuation envelope.
    placement_post_closure_basin_ownership_enabled: float = 0.0
    placement_post_closure_basin_position_guard_m: float = 0.0
    placement_post_closure_basin_yaw_guard_rad: float = 0.0
    placement_post_closure_mpc_predicted_position_limit_m: float = 0.0
    placement_post_closure_mpc_allowed_position_regression_m: float = 0.0
    placement_post_closure_mpc_allowed_yaw_regression_rad: float = 0.0
    placement_post_closure_continuation_position_gate_m: float = 0.0

    # V9.3.12-R4-E2: after a strict certification reject inside retained
    # ownership, drive the *observation-derived certification state* deeper
    # into the unchanged strict basin. This planner has motion authority only.
    placement_certification_basin_closure_enabled: float = 0.0
    placement_certification_basin_closure_speed_mps: float = 0.0
    placement_certification_basin_closure_filtered_position_guard_m: float = 0.0
    placement_certification_basin_closure_filtered_yaw_guard_rad: float = 0.0
    placement_certification_basin_closure_certification_position_activation_m: float = 0.0
    placement_certification_basin_closure_certification_yaw_activation_rad: float = 0.0
    placement_certification_basin_closure_predicted_filtered_position_guard_m: float = 0.0
    placement_certification_basin_closure_predicted_filtered_yaw_guard_rad: float = 0.0
    placement_certification_basin_closure_position_scale_m: float = 0.0
    placement_certification_basin_closure_yaw_scale_rad: float = 0.0
    placement_certification_basin_closure_required_predicted_deficit_improvement: float = 0.0
    placement_certification_basin_closure_allowed_filtered_position_regression_m: float = 0.0
    placement_certification_basin_closure_duration_short_s: float = 0.0
    placement_certification_basin_closure_duration_medium_s: float = 0.0
    placement_certification_basin_closure_duration_long_s: float = 0.0
    placement_certification_basin_closure_mid_steering_fraction: float = 0.0
    placement_certification_basin_closure_second_leg_duration_fraction: float = 0.0
    placement_certification_basin_closure_maximum_speed_for_activation_mps: float = 0.0
    placement_certification_basin_closure_max_activations: int = 0
    placement_certification_basin_closure_maximum_total_execution_seconds: float = 0.0
    placement_certification_basin_closure_search_period_s: float = 0.0
    placement_certification_basin_closure_post_motion_settle_seconds: float = 0.0
    placement_certification_basin_closure_post_motion_max_wait_seconds: float = 0.0
    placement_certification_basin_closure_minimum_post_motion_rgb_updates: int = 0
    placement_certification_basin_closure_minimum_measured_deficit_improvement: float = 0.0
    placement_post_closure_exit_position_guard_m: float = 0.0
    placement_post_closure_exit_yaw_guard_rad: float = 0.0

    # V9.3.12-R4-E3: when STRICT short-circuits on POSITION and the residual is
    # lateral-dominant, a bounded two-stage Ackermann recenter corridor may
    # temporarily leave the tiny near-basin.  It must predict a return into the
    # unchanged strict certification envelope, stop at the excursion apex,
    # refresh RGB, and re-plan the return leg from the observed midpoint.
    placement_position_blocker_recenter_enabled: float = 0.0
    placement_position_blocker_recenter_speed_mps: float = 0.0
    placement_position_blocker_recenter_filtered_position_activation_m: float = 0.0
    placement_position_blocker_recenter_filtered_yaw_activation_rad: float = 0.0
    placement_position_blocker_recenter_certification_position_activation_m: float = 0.0
    placement_position_blocker_recenter_certification_yaw_activation_rad: float = 0.0
    placement_position_blocker_recenter_minimum_lateral_fraction: float = 0.0
    placement_position_blocker_recenter_predicted_position_headroom_m: float = 0.0
    placement_position_blocker_recenter_predicted_yaw_headroom_rad: float = 0.0
    placement_position_blocker_recenter_maximum_predicted_excursion_m: float = 0.0
    placement_position_blocker_recenter_final_filtered_position_guard_m: float = 0.0
    placement_position_blocker_recenter_final_filtered_yaw_guard_rad: float = 0.0
    placement_position_blocker_recenter_departure_duration_short_s: float = 0.0
    placement_position_blocker_recenter_departure_duration_medium_s: float = 0.0
    placement_position_blocker_recenter_departure_duration_long_s: float = 0.0
    placement_position_blocker_recenter_return_duration_short_s: float = 0.0
    placement_position_blocker_recenter_return_duration_medium_s: float = 0.0
    placement_position_blocker_recenter_return_duration_long_s: float = 0.0
    placement_position_blocker_recenter_steering_fraction: float = 0.0
    placement_position_blocker_recenter_maximum_speed_for_activation_mps: float = 0.0
    placement_position_blocker_recenter_maximum_total_execution_seconds: float = 0.0
    placement_position_blocker_recenter_minimum_terminal_budget_remaining_s: float = 0.0
    placement_position_blocker_recenter_search_period_s: float = 0.0
    placement_position_blocker_recenter_midpoint_settle_seconds: float = 0.0
    placement_position_blocker_recenter_midpoint_max_wait_seconds: float = 0.0
    placement_position_blocker_recenter_midpoint_minimum_rgb_updates: int = 0
    placement_position_blocker_recenter_final_settle_seconds: float = 0.0
    placement_position_blocker_recenter_final_max_wait_seconds: float = 0.0
    placement_position_blocker_recenter_final_minimum_rgb_updates: int = 0
    # V9.3.12-R4-E6: after the return leg, do not adjudicate on the first
    # minimum RGB sample count. Hold the chassis and require a short run of
    # target-consistent fresh RGB before refreshing strict certification.
    placement_position_blocker_recenter_final_evidence_hold_seconds: float = 0.0
    placement_position_blocker_recenter_final_evidence_max_wait_seconds: float = 0.0
    placement_position_blocker_recenter_final_evidence_minimum_consistent_rgb_updates: int = 0
    # E6: require an S-curve topology for full-pose POSITION recenter.  E5
    # configs omit this key and therefore retain archived behavior.
    placement_position_blocker_recenter_require_non_retrace_topology: float = 0.0
    placement_position_blocker_recenter_minimum_measured_position_improvement_m: float = 0.0
    placement_position_blocker_recenter_hard_abort_distance_m: float = 0.0
    placement_position_blocker_recenter_hard_abort_yaw_rad: float = 0.0
    # V9.3.12-R4-E4: steering-conditioning + odometry-closed execution.
    # The E3 trace proved the long primitive model assumed instantaneous
    # steering/speed response; actual 5.5 s departure achieved only ~87% of
    # commanded travel and ~63% of predicted yaw.  These fields condition the
    # steering actuator before translation and terminate each leg by measured
    # vehicle travel instead of wall-clock duration alone.
    placement_position_blocker_recenter_presteer_command_rad: float = 0.0
    placement_position_blocker_recenter_presteer_ready_tolerance_rad: float = 0.0
    placement_position_blocker_recenter_presteer_max_seconds: float = 0.0
    placement_position_blocker_recenter_odometry_timeout_scale: float = 0.0
    placement_position_blocker_recenter_midpoint_prediction_position_tolerance_m: float = 0.0
    placement_position_blocker_recenter_midpoint_prediction_yaw_tolerance_rad: float = 0.0

    # One-shot yaw-feasibility escrow for the final Ackermann tail.
    placement_mpc_yaw_escrow_enabled: float = 0.0
    placement_mpc_yaw_escrow_activation_distance_m: float = 0.0
    placement_mpc_yaw_escrow_activation_yaw_rad: float = 0.0
    placement_mpc_yaw_escrow_predicted_max_distance_m: float = 0.0
    placement_mpc_yaw_escrow_required_improvement_rad: float = 0.0
    placement_mpc_yaw_escrow_max_seconds: float = 0.0
    placement_mpc_yaw_escrow_max_activations: int = 0

    # V9.3.11 bounded near-basin feasibility escrow. This does not change the
    # MPC objective; it only permits one otherwise-regressed Ackermann arc if
    # a preview of the same action reduces normalized competition deficit.
    placement_mpc_near_basin_escrow_enabled: float = 0.0
    placement_mpc_near_basin_activation_distance_m: float = 0.0
    placement_mpc_near_basin_activation_yaw_rad: float = 0.0
    placement_mpc_near_basin_preview_seconds: float = 0.0
    placement_mpc_near_basin_maximum_predicted_distance_m: float = 0.0
    placement_mpc_near_basin_position_scale_m: float = 0.0
    placement_mpc_near_basin_yaw_scale_rad: float = 0.0
    placement_mpc_near_basin_required_deficit_improvement: float = 0.0
    placement_mpc_near_basin_allowed_active_regression: float = 0.0
    placement_mpc_near_basin_max_seconds: float = 0.0
    placement_mpc_near_basin_max_activations: int = 0

    # V9.3.4 bounded-latency terminal decision supervisor.  This replaces
    # repeated pre-brake/commit chatter with SETTLE -> RELEASE_INTENT -> EXECUTE.
    placement_release_supervisor_enabled: float = 0.0
    placement_release_supervisor_evidence_seconds: float = 0.0
    placement_release_supervisor_evidence_soft_decay: float = 0.0
    placement_release_supervisor_settle_timeout_seconds: float = 0.0
    placement_release_supervisor_intent_delay_seconds: float = 0.0
    placement_release_supervisor_hard_violation_grace_seconds: float = 0.0
    placement_release_supervisor_rearm_cooldown_seconds: float = 0.0

    # V9.3.3 timeout-handoff validity guard.
    terminal_approach_corridor_timeout_handoff_lateral_limit: float = 0.0
    terminal_approach_corridor_timeout_handoff_yaw_limit: float = 0.0

    # V9.3.0: local kinematic MPC is the primary terminal controller.
    # V9.2.4 bounded S-curve remains a stall/infeasibility fallback.
    placement_mpc_enabled: float = 0.0
    placement_mpc_horizon_steps: int = 0
    placement_mpc_prediction_dt: float = 0.0
    placement_mpc_update_period: float = 0.0
    placement_mpc_forward_max_speed: float = 0.0
    placement_mpc_reverse_max_speed: float = 0.0
    placement_mpc_steering_limit: float = 0.0
    placement_mpc_geometry_speed_floor: float = 0.0
    placement_mpc_trust_radius: float = 0.0
    placement_mpc_weight_lateral: float = 0.0
    placement_mpc_weight_yaw: float = 0.0
    placement_mpc_terminal_scale: float = 0.0
    placement_mpc_stall_seconds: float = 0.0
    placement_mpc_progress_yaw_weight_m_per_rad: float = 0.0
    placement_mpc_progress_regression_tolerance_m: float = 0.0

    # Release is deliberately outside the MPC objective.  V9.3.0 separates a
    # broad stop-first pre-brake envelope from the tighter evidence envelope,
    # so the chassis can settle without treating the first 8-9 cm crossing as
    # permission to lower the pallet.
    placement_release_prebrake_position_tolerance: float = 0.0
    placement_release_prebrake_yaw_tolerance: float = 0.0
    placement_release_prebrake_hold_seconds: float = 0.0
    placement_release_candidate_position_tolerance: float = 0.0
    placement_release_candidate_yaw_tolerance: float = 0.0
    placement_release_abort_position_tolerance: float = 0.0
    placement_release_abort_yaw_tolerance: float = 0.0
    placement_release_evidence_seconds: float = 0.0
    placement_release_evidence_soft_decay: float = 0.0
    placement_release_commit_min_seconds: float = 0.0
    placement_release_commit_max_seconds: float = 0.0
    placement_release_commit_position_tolerance: float = 0.0
    placement_release_commit_yaw_tolerance: float = 0.0

    # V9.2.0 cumulative terminal-alignment budget. V9.3.0 extends the same
    # cumulative clock across PLACE_PRECISION as well as alignment/recovery.
    placement_terminal_budget_seconds: float = 0.0

    @classmethod
    def from_mapping(cls, values: Mapping[str, Any]) -> "PickupParameters":
        """Build validated parameters while accepting legacy YAML mappings."""
        kwargs: dict[str, Any] = {}
        for field in fields(cls):
            if field.name in values:
                raw = values[field.name]
            elif field.default is not MISSING:
                raw = field.default
            else:
                raise KeyError(field.name)
            if field.name in (
                "maximum_recoveries",
                "transport_path_samples",
                "terminal_approach_corridor_samples",
                "placement_maximum_recoveries",
                "placement_precision_recenter_max_cycles",
                "placement_carried_observer_min_samples",
                "placement_mpc_horizon_steps",
                "placement_mpc_infeasible_recenter_solve_count",
                "placement_mpc_yaw_escrow_max_activations",
                "placement_mpc_near_basin_max_activations",
                "placement_micro_primitive_max_activations",
                "placement_rigid_load_constraint_min_fork_contacts",
                "placement_yaw_tail_reserve_max_activations",
                "placement_strict_recovery_retention_max_activations",
                "placement_fresh_rgb_yaw_closure_max_activations",
                "placement_fresh_rgb_yaw_closure_minimum_terminal_rgb_updates",
                "placement_fresh_rgb_yaw_closure_minimum_post_motion_rgb_updates",
                "placement_position_blocker_recenter_midpoint_minimum_rgb_updates",
                "placement_position_blocker_recenter_final_minimum_rgb_updates",
            ):
                kwargs[field.name] = int(raw)
            else:
                kwargs[field.name] = float(raw)
        instance = cls(**kwargs)
        instance.validate()
        return instance

    def validate(self) -> None:
        positive = (
            "pre_approach_distance",
            "insertion_distance",
            "approach_max_speed",
            "align_max_speed",
            "insertion_max_speed",
            "retreat_distance",
            "approach_capture_distance",
            "pre_position_tolerance",
            "pre_lateral_tolerance",
            "pre_yaw_tolerance",
            "insertion_position_tolerance",
            "insertion_lateral_tolerance",
            "insertion_yaw_tolerance",
            "lift_position_tolerance",
            "lift_velocity_tolerance",
            "lifted_minimum_fork_height",
            "verify_lift_seconds",
            "maximum_load_tilt",
            "lower_timeout",
            "approach_timeout",
            "align_timeout",
            "insert_timeout",
            "lift_timeout",
            "retreat_timeout",
            "recovery_timeout",
        )
        for name in positive:
            if getattr(self, name) <= 0.0:
                raise ValueError(f"{name} must be positive")
        non_negative = (
            "align_minimum_speed",
            "alignment_hold_seconds",
            "progress_timeout",
            "progress_improvement",
            "recovery_distance",
            "overshoot_longitudinal_tolerance",
            "recovery_steering_tolerance",
            "recovery_center_hold_seconds",
            "recovery_center_timeout",
            "recovery_unwind_distance",
            "recovery_minimum_distance",
            "align_handoff_longitudinal_tolerance",
            "align_handoff_lateral_tolerance",
            "align_handoff_yaw_tolerance",
            "axis_docking_enabled",
            "approach_line_distance",
            "alignment_line_distance",
            "alignment_abort_distance",
            "insertion_abort_distance",
            "insertion_abort_lateral",
            "insertion_abort_yaw",
            "insertion_minimum_speed",
            "fork_root_distance",
            "fork_tip_distance",
            "pallet_half_length",
            "alignment_preview_tolerance",
            "insertion_corridor_tolerance",
            "insertion_steering_limit",
            "corridor_control_enabled",
            "corridor_control_lateral_gain",
            "corridor_control_yaw_gain",
            "corridor_control_lookahead",
            "recovery_reset_distance",
            "recovery_reset_minimum_distance",
            "placement_enabled",
            "placement_pre_distance",
            "transport_max_speed",
            "transport_capture_distance",
            "transport_steering_limit",
            "transport_timeout",
            "place_align_max_speed",
            "place_align_minimum_speed",
            "place_steering_limit",
            "placement_position_tolerance",
            "placement_yaw_tolerance",
            "placement_hold_seconds",
            "place_align_timeout",
            "placement_lower_target",
            "placement_lower_timeout",
            "release_verify_seconds",
            "placement_retreat_distance",
            "placement_retreat_timeout",
            "placement_load_motion_tolerance",
            "placement_release_position_tolerance",
            "placement_release_yaw_tolerance",
            "placement_release_after_seconds",
            "placement_release_hold_seconds",
            "placement_post_release_position_tolerance",
            "placement_post_release_yaw_tolerance",
            "transport_reposition_minimum_distance",
            "transport_reposition_maximum_distance",
            "transport_runway_distance",
            "transport_reposition_timeout",
            "transport_path_wheelbase",
            "transport_path_lookahead",
            "transport_path_handle_scale",
            "transport_path_minimum_speed",
            "transport_path_goal_yaw_tolerance",
            "transport_path_speed_gain",
            "transport_path_steering_speed_floor",
            "transport_path_steering_slowdown_gain",
            "terminal_approach_corridor_enabled",
            "terminal_approach_corridor_standoff_distance",
            "terminal_approach_corridor_capture_distance",
            "terminal_approach_corridor_yaw_tolerance",
            "terminal_approach_corridor_max_speed",
            "terminal_approach_corridor_minimum_speed",
            "terminal_approach_corridor_lookahead",
            "terminal_approach_corridor_handle_scale",
            "terminal_approach_corridor_timeout",
            "terminal_approach_corridor_replan_position_m",
            "terminal_approach_corridor_replan_yaw_rad",
            "terminal_approach_corridor_replan_min_seconds",
            "terminal_approach_corridor_entry_distance",
            "terminal_approach_corridor_entry_capture_distance",
            "terminal_approach_corridor_entry_lateral_tolerance",
            "terminal_approach_corridor_entry_yaw_tolerance",
            "terminal_approach_corridor_entry_hold_seconds",
            "terminal_approach_corridor_axis_lateral_gain",
            "terminal_approach_corridor_axis_yaw_gain",
            "terminal_approach_corridor_axis_lookahead",
            "terminal_approach_corridor_axis_steering_limit",
            "terminal_approach_corridor_axis_speed_gain",
            "terminal_approach_corridor_axis_abort_lateral",
            "terminal_approach_corridor_axis_abort_yaw",
            "terminal_approach_corridor_rolling_enabled",
            "terminal_approach_corridor_rolling_handoff_distance",
            "terminal_approach_corridor_rolling_timeout_handoff_distance",
            "terminal_approach_corridor_rolling_handoff_seconds",
            "terminal_approach_corridor_rolling_lateral_gain",
            "terminal_approach_corridor_rolling_yaw_gain",
            "terminal_approach_corridor_rolling_lookahead",
            "terminal_approach_corridor_rolling_steering_limit",
            "terminal_approach_corridor_rolling_speed_gain",
            "terminal_approach_corridor_rolling_lateral_band",
            "terminal_approach_corridor_rolling_yaw_band",
            "terminal_approach_corridor_rolling_min_geometry_scale",
            "terminal_visual_binding_enabled",
            "terminal_visual_required_distance",
            "terminal_visual_unlocked_speed_scale",
            "terminal_visual_stale_speed_scale",
            "terminal_visual_stale_seconds",
            "placement_terminal_ownership_enabled",
            "placement_terminal_ownership_mpc_acquire_distance_m",
            "placement_terminal_ownership_mpc_acquire_lateral_m",
            "placement_terminal_ownership_mpc_acquire_yaw_rad",
            "placement_terminal_ownership_mpc_force_distance_m",
            "placement_terminal_ownership_mpc_force_lateral_m",
            "placement_terminal_ownership_mpc_force_yaw_rad",
            "placement_terminal_ownership_align_soft_timeout_seconds",
            "placement_terminal_ownership_align_progress_window_seconds",
            "placement_terminal_ownership_align_progress_improvement_m",
            "placement_terminal_ownership_max_reacquire_count",
            "placement_terminal_ownership_mpc_exit_persistence_seconds",
            "placement_mpc_infeasible_recenter_solve_count",
            "placement_load_belief_enabled",
            "placement_load_belief_position_distance_gain_m_per_m",
            "placement_load_belief_position_turn_gain_m_per_rad",
            "placement_load_belief_position_reverse_gain_m_per_m",
            "placement_load_belief_position_time_gain_mps",
            "placement_load_belief_yaw_distance_gain_rad_per_m",
            "placement_load_belief_yaw_turn_gain",
            "placement_load_belief_yaw_reverse_gain_rad_per_m",
            "placement_load_belief_yaw_time_gain_radps",
            "placement_load_belief_max_position_sigma_m",
            "placement_load_belief_max_yaw_sigma_rad",
            "placement_load_belief_seeded_transport_speed_scale",
            "placement_load_belief_predicted_transport_speed_scale",
            "placement_load_belief_turn_speed_scale",
            "placement_release_position_hysteresis",
            "placement_release_yaw_hysteresis",
            "placement_progress_timeout",
            "placement_progress_improvement",
            "placement_recovery_minimum_distance",
            "placement_recovery_maximum_distance",
            "placement_recovery_lateral_gain",
            "placement_recovery_yaw_gain",
            "placement_recovery_timeout",
            "placement_recovery_steering_tolerance",
            "placement_overshoot_longitudinal_tolerance",
            "placement_recovery_runway_distance",
            "placement_recovery_longitudinal_gain",
            "placement_recovery_attempt_distance_gain",
            "placement_recovery_reentry_heading_tolerance",
            "placement_recovery_reentry_yaw_tolerance",
            "placement_recovery_reverse_steering_limit",
            "placement_recovery_reverse_lateral_gain",
            "placement_recovery_reverse_yaw_gain",
            "placement_guard_minimum_forward_speed",
            "placement_guard_reaction_seconds",
            "placement_guard_deceleration_mps2",
            "placement_guard_stopping_margin_m",
            "placement_guard_lateral_tolerance",
            "placement_guard_heading_tolerance",
            "placement_guard_yaw_tolerance",
            "placement_guard_brake_hold_seconds",
            "placement_precision_settle_seconds",
            "placement_precision_settle_max_speed",
            "placement_precision_settle_progress_timeout",
            "placement_precision_settle_improvement_m",
            "placement_competition_precision_enabled",
            "placement_precision_forward_max_speed",
            "placement_precision_reverse_max_speed",
            "placement_precision_minimum_speed",
            "placement_precision_reverse_longitudinal_limit",
            "placement_precision_reverse_lateral_tolerance",
            "placement_precision_reverse_yaw_tolerance",
            "placement_precision_direction_change_speed_epsilon",
            "placement_precision_entry_position_tolerance",
            "placement_precision_entry_lateral_tolerance",
            "placement_precision_entry_yaw_tolerance",
            "placement_precision_entry_hold_seconds",
            "placement_precision_entry_max_speed",
            "placement_precision_speed_gain",
            "placement_precision_longitudinal_deadband",
            "placement_precision_geometry_max_speed",
            "placement_precision_progress_timeout",
            "placement_precision_progress_improvement",
            "placement_precision_maximum_regression_m",
            "placement_precision_release_max_speed",
            "placement_precision_filter_alpha",
            "placement_precision_filtered_position_tolerance",
            "placement_precision_filtered_yaw_tolerance",
            "placement_precision_direction_switch_hysteresis",
            "placement_precision_task_lateral_gain",
            "placement_precision_task_yaw_gain",
            "placement_precision_task_lookahead",
            "placement_precision_task_steering_limit",
            "placement_precision_recenter_trigger_lateral",
            "placement_precision_recenter_trigger_yaw",
            "placement_precision_recenter_exit_lateral",
            "placement_precision_recenter_exit_yaw",
            "placement_precision_recenter_activation_longitudinal",
            "placement_precision_recenter_reverse_speed",
            "placement_precision_recenter_min_distance",
            "placement_precision_recenter_max_distance",
            "placement_precision_recenter_max_seconds",
            "placement_carried_observer_enabled",
            "placement_carried_observer_sample_period",
            "placement_carried_observer_min_samples",
            "placement_carried_observer_update_period",
            "placement_carried_observer_initial_position_sigma_m",
            "placement_carried_observer_initial_yaw_sigma_rad",
            "placement_carried_observer_measurement_position_sigma_m",
            "placement_carried_observer_measurement_yaw_sigma_rad",
            "placement_carried_observer_process_position_sigma_m",
            "placement_carried_observer_process_yaw_sigma_rad",
            "placement_carried_observer_minimum_position_sigma_m",
            "placement_carried_observer_minimum_yaw_sigma_rad",
            "placement_carried_observer_position_innovation_gate_m",
            "placement_carried_observer_yaw_innovation_gate_rad",
            "placement_carried_observer_fast_alpha",
            "placement_carried_observer_release_disagreement_position_m",
            "placement_carried_observer_release_disagreement_yaw_rad",
            "placement_release_uncertainty_position_gain",
            "placement_release_uncertainty_yaw_gain",
            "placement_carried_visual_authority_enabled",
            "placement_carried_visual_max_stale_seconds",
            "placement_carried_visual_handoff_stale_seconds",
            "placement_carried_visual_handoff_fallback_stale_seconds",
            "placement_carried_visual_release_stale_seconds",
            "placement_carried_visual_stale_position_gain_mps",
            "placement_carried_visual_stale_yaw_gain_radps",
            "placement_carried_visual_require_lock_for_release",
            "placement_strict_release_center_yaw_anchor_enabled",
            "placement_strict_release_center_yaw_rss_enabled",
            "placement_strict_release_center_yaw_continuity_guard_enabled",
            "placement_strict_release_center_yaw_max_reanchor_jump_rad",
            "placement_strict_release_center_yaw_revalidation_seconds",
            "placement_strict_release_center_yaw_revalidation_tolerance_rad",
            "placement_strict_release_certification_enabled",
            "placement_strict_release_position_limit_m",
            "placement_strict_release_yaw_limit_rad",
            "placement_strict_release_position_sigma_gain",
            "placement_strict_release_yaw_sigma_gain",
            "placement_strict_release_require_terminal_visual_lock",
            "placement_strict_release_execution_position_reserve_m",
            "placement_strict_release_execution_yaw_reserve_rad",
            "placement_strict_release_target_position_spread_gain",
            "placement_strict_release_target_yaw_spread_gain",
            "placement_strict_release_target_position_margin_floor_m",
            "placement_strict_release_target_yaw_margin_floor_rad",
            "placement_strict_release_target_position_margin_cap_m",
            "placement_strict_release_target_yaw_margin_cap_rad",
            "placement_release_snapshot_enabled",
            "placement_strict_release_multiview_enabled",
            "placement_strict_release_multiview_required",
            "placement_strict_release_multiview_max_position_disagreement_m",
            "placement_strict_release_multiview_max_yaw_disagreement_rad",
            "placement_release_witness_enabled",
            "placement_release_witness_position_drift_tolerance_m",
            "placement_release_witness_yaw_drift_tolerance_rad",
            "placement_certified_basin_enabled",
            "placement_certified_basin_hold_seconds",
            "placement_certified_basin_position_exit_margin_m",
            "placement_certified_basin_yaw_exit_margin_rad",
            "placement_certified_basin_consensus_entry_enabled",
            "placement_certified_basin_consensus_evidence_seconds",
            "placement_certified_basin_consensus_evidence_decay",
            "placement_certified_basin_consensus_position_limit_m",
            "placement_certified_basin_consensus_yaw_limit_rad",
            "placement_certified_basin_consensus_max_fast_slow_position_m",
            "placement_certified_basin_consensus_max_fast_slow_yaw_rad",
            "placement_certified_basin_consensus_max_target_position_spread_m",
            "placement_certified_basin_consensus_max_target_yaw_spread_rad",
            "placement_certified_basin_consensus_max_load_position_sigma_m",
            "placement_certified_basin_consensus_max_load_yaw_sigma_rad",
            "placement_certified_basin_consensus_release_authority",
            "placement_micro_primitive_enabled",
            "placement_micro_primitive_speed_mps",
            "placement_micro_primitive_activation_distance_m",
            "placement_micro_primitive_activation_yaw_rad",
            "placement_micro_primitive_maximum_predicted_distance_m",
            "placement_micro_primitive_position_scale_m",
            "placement_micro_primitive_yaw_scale_rad",
            "placement_micro_primitive_required_deficit_improvement",
            "placement_micro_primitive_duration_short_s",
            "placement_micro_primitive_duration_medium_s",
            "placement_micro_primitive_duration_long_s",
            "placement_micro_primitive_mid_steering_fraction",
            "placement_micro_primitive_max_activations",
            "placement_micro_primitive_cooldown_seconds",
            "placement_micro_primitive_maximum_total_execution_seconds",
            "placement_micro_primitive_reverse_penalty",
            "placement_micro_primitive_direction_switch_penalty",
            "placement_fresh_rgb_yaw_closure_enabled",
            "placement_fresh_rgb_yaw_closure_speed_mps",
            "placement_fresh_rgb_yaw_closure_position_gate_m",
            "placement_fresh_rgb_yaw_closure_yaw_min_rad",
            "placement_fresh_rgb_yaw_closure_yaw_max_rad",
            "placement_fresh_rgb_yaw_closure_target_yaw_rad",
            "placement_fresh_rgb_yaw_closure_midpoint_position_guard_m",
            "placement_fresh_rgb_yaw_closure_final_position_guard_m",
            "placement_fresh_rgb_yaw_closure_required_predicted_yaw_improvement_rad",
            "placement_fresh_rgb_yaw_closure_duration_short_s",
            "placement_fresh_rgb_yaw_closure_duration_medium_s",
            "placement_fresh_rgb_yaw_closure_duration_long_s",
            "placement_fresh_rgb_yaw_closure_mid_steering_fraction",
            "placement_fresh_rgb_yaw_closure_maximum_speed_for_activation_mps",
            "placement_fresh_rgb_yaw_closure_max_activations",
            "placement_fresh_rgb_yaw_closure_maximum_total_execution_seconds",
            "placement_fresh_rgb_yaw_closure_maximum_rgb_stale_seconds",
            "placement_fresh_rgb_yaw_closure_minimum_terminal_rgb_updates",
            "placement_fresh_rgb_yaw_closure_maximum_observer_yaw_sigma_rad",
            "placement_fresh_rgb_yaw_closure_maximum_target_fast_slow_yaw_disagreement_rad",
            "placement_fresh_rgb_yaw_closure_post_motion_settle_seconds",
            "placement_fresh_rgb_yaw_closure_post_motion_max_wait_seconds",
            "placement_fresh_rgb_yaw_closure_minimum_post_motion_rgb_updates",
            "placement_fresh_rgb_yaw_closure_minimum_measured_yaw_improvement_rad",
            "placement_post_closure_basin_ownership_enabled",
            "placement_post_closure_basin_position_guard_m",
            "placement_post_closure_basin_yaw_guard_rad",
            "placement_post_closure_mpc_predicted_position_limit_m",
            "placement_post_closure_mpc_allowed_position_regression_m",
            "placement_post_closure_mpc_allowed_yaw_regression_rad",
            "placement_post_closure_continuation_position_gate_m",
            "placement_certification_basin_closure_enabled",
            "placement_certification_basin_closure_speed_mps",
            "placement_certification_basin_closure_filtered_position_guard_m",
            "placement_certification_basin_closure_filtered_yaw_guard_rad",
            "placement_certification_basin_closure_certification_position_activation_m",
            "placement_certification_basin_closure_certification_yaw_activation_rad",
            "placement_certification_basin_closure_predicted_filtered_position_guard_m",
            "placement_certification_basin_closure_predicted_filtered_yaw_guard_rad",
            "placement_certification_basin_closure_position_scale_m",
            "placement_certification_basin_closure_yaw_scale_rad",
            "placement_certification_basin_closure_required_predicted_deficit_improvement",
            "placement_certification_basin_closure_allowed_filtered_position_regression_m",
            "placement_certification_basin_closure_duration_short_s",
            "placement_certification_basin_closure_duration_medium_s",
            "placement_certification_basin_closure_duration_long_s",
            "placement_certification_basin_closure_mid_steering_fraction",
            "placement_certification_basin_closure_second_leg_duration_fraction",
            "placement_certification_basin_closure_maximum_speed_for_activation_mps",
            "placement_certification_basin_closure_max_activations",
            "placement_certification_basin_closure_maximum_total_execution_seconds",
            "placement_certification_basin_closure_search_period_s",
            "placement_certification_basin_closure_post_motion_settle_seconds",
            "placement_certification_basin_closure_post_motion_max_wait_seconds",
            "placement_certification_basin_closure_minimum_post_motion_rgb_updates",
            "placement_certification_basin_closure_minimum_measured_deficit_improvement",
            "placement_post_closure_exit_position_guard_m",
            "placement_post_closure_exit_yaw_guard_rad",
            "placement_position_blocker_recenter_enabled",
            "placement_position_blocker_recenter_speed_mps",
            "placement_position_blocker_recenter_filtered_position_activation_m",
            "placement_position_blocker_recenter_filtered_yaw_activation_rad",
            "placement_position_blocker_recenter_certification_position_activation_m",
            "placement_position_blocker_recenter_certification_yaw_activation_rad",
            "placement_position_blocker_recenter_minimum_lateral_fraction",
            "placement_position_blocker_recenter_predicted_position_headroom_m",
            "placement_position_blocker_recenter_predicted_yaw_headroom_rad",
            "placement_position_blocker_recenter_maximum_predicted_excursion_m",
            "placement_position_blocker_recenter_final_filtered_position_guard_m",
            "placement_position_blocker_recenter_final_filtered_yaw_guard_rad",
            "placement_position_blocker_recenter_departure_duration_short_s",
            "placement_position_blocker_recenter_departure_duration_medium_s",
            "placement_position_blocker_recenter_departure_duration_long_s",
            "placement_position_blocker_recenter_return_duration_short_s",
            "placement_position_blocker_recenter_return_duration_medium_s",
            "placement_position_blocker_recenter_return_duration_long_s",
            "placement_position_blocker_recenter_steering_fraction",
            "placement_position_blocker_recenter_maximum_speed_for_activation_mps",
            "placement_position_blocker_recenter_maximum_total_execution_seconds",
            "placement_position_blocker_recenter_minimum_terminal_budget_remaining_s",
            "placement_position_blocker_recenter_search_period_s",
            "placement_position_blocker_recenter_midpoint_settle_seconds",
            "placement_position_blocker_recenter_midpoint_max_wait_seconds",
            "placement_position_blocker_recenter_midpoint_minimum_rgb_updates",
            "placement_position_blocker_recenter_final_settle_seconds",
            "placement_position_blocker_recenter_final_max_wait_seconds",
            "placement_position_blocker_recenter_final_minimum_rgb_updates",
            "placement_position_blocker_recenter_final_evidence_hold_seconds",
            "placement_position_blocker_recenter_final_evidence_max_wait_seconds",
            "placement_position_blocker_recenter_final_evidence_minimum_consistent_rgb_updates",
            "placement_position_blocker_recenter_require_non_retrace_topology",
            "placement_position_blocker_recenter_minimum_measured_position_improvement_m",
            "placement_position_blocker_recenter_hard_abort_distance_m",
            "placement_position_blocker_recenter_hard_abort_yaw_rad",
            "placement_position_blocker_recenter_presteer_command_rad",
            "placement_position_blocker_recenter_presteer_ready_tolerance_rad",
            "placement_position_blocker_recenter_presteer_max_seconds",
            "placement_position_blocker_recenter_odometry_timeout_scale",
            "placement_position_blocker_recenter_midpoint_prediction_position_tolerance_m",
            "placement_position_blocker_recenter_midpoint_prediction_yaw_tolerance_rad",
            "placement_mpc_yaw_escrow_enabled",
            "placement_mpc_yaw_escrow_activation_distance_m",
            "placement_mpc_yaw_escrow_activation_yaw_rad",
            "placement_mpc_yaw_escrow_predicted_max_distance_m",
            "placement_mpc_yaw_escrow_required_improvement_rad",
            "placement_mpc_yaw_escrow_max_seconds",
            "placement_mpc_yaw_escrow_max_activations",
            "placement_mpc_near_basin_escrow_enabled",
            "placement_mpc_near_basin_activation_distance_m",
            "placement_mpc_near_basin_activation_yaw_rad",
            "placement_mpc_near_basin_preview_seconds",
            "placement_mpc_near_basin_maximum_predicted_distance_m",
            "placement_mpc_near_basin_position_scale_m",
            "placement_mpc_near_basin_yaw_scale_rad",
            "placement_mpc_near_basin_required_deficit_improvement",
            "placement_mpc_near_basin_allowed_active_regression",
            "placement_mpc_near_basin_max_seconds",
            "placement_mpc_near_basin_max_activations",
            "placement_release_supervisor_enabled",
            "placement_release_supervisor_evidence_seconds",
            "placement_release_supervisor_evidence_soft_decay",
            "placement_release_supervisor_settle_timeout_seconds",
            "placement_release_supervisor_intent_delay_seconds",
            "placement_release_supervisor_hard_violation_grace_seconds",
            "placement_release_supervisor_rearm_cooldown_seconds",
            "terminal_approach_corridor_timeout_handoff_lateral_limit",
            "terminal_approach_corridor_timeout_handoff_yaw_limit",
            "placement_mpc_enabled",
            "placement_mpc_horizon_steps",
            "placement_mpc_prediction_dt",
            "placement_mpc_update_period",
            "placement_mpc_forward_max_speed",
            "placement_mpc_reverse_max_speed",
            "placement_mpc_steering_limit",
            "placement_mpc_geometry_speed_floor",
            "placement_mpc_trust_radius",
            "placement_mpc_weight_lateral",
            "placement_mpc_weight_yaw",
            "placement_mpc_terminal_scale",
            "placement_mpc_stall_seconds",
            "placement_mpc_progress_yaw_weight_m_per_rad",
            "placement_mpc_progress_regression_tolerance_m",
            "placement_release_prebrake_position_tolerance",
            "placement_release_prebrake_yaw_tolerance",
            "placement_release_prebrake_hold_seconds",
            "placement_release_candidate_position_tolerance",
            "placement_release_candidate_yaw_tolerance",
            "placement_release_abort_position_tolerance",
            "placement_release_abort_yaw_tolerance",
            "placement_release_evidence_seconds",
            "placement_release_evidence_soft_decay",
            "placement_release_commit_min_seconds",
            "placement_release_commit_max_seconds",
            "placement_release_commit_position_tolerance",
            "placement_release_commit_yaw_tolerance",
            "placement_terminal_budget_seconds",
        )
        for name in non_negative:
            if getattr(self, name) < 0.0:
                raise ValueError(f"{name} must be non-negative")
        if self.placement_terminal_ownership_enabled > 0.5:
            if self.placement_mpc_enabled <= 0.5:
                raise ValueError("terminal ownership requires terminal MPC")
            ownership = TerminalOwnershipConfig(
                mpc_acquire_distance_m=self.placement_terminal_ownership_mpc_acquire_distance_m,
                mpc_acquire_lateral_m=self.placement_terminal_ownership_mpc_acquire_lateral_m,
                mpc_acquire_yaw_rad=self.placement_terminal_ownership_mpc_acquire_yaw_rad,
                mpc_force_distance_m=self.placement_terminal_ownership_mpc_force_distance_m,
                mpc_force_lateral_m=self.placement_terminal_ownership_mpc_force_lateral_m,
                mpc_force_yaw_rad=self.placement_terminal_ownership_mpc_force_yaw_rad,
                align_soft_timeout_seconds=self.placement_terminal_ownership_align_soft_timeout_seconds,
                align_progress_window_seconds=self.placement_terminal_ownership_align_progress_window_seconds,
                align_progress_improvement_m=self.placement_terminal_ownership_align_progress_improvement_m,
            )
            ownership.validate()
            if self.placement_terminal_ownership_align_soft_timeout_seconds > 10.0:
                raise ValueError("V9.3.5 PLACE_ALIGN ownership must stay <= 10s")
            if self.placement_terminal_ownership_mpc_exit_persistence_seconds <= 0.0:
                raise ValueError("V9.3.7 MPC ownership exit persistence must be positive")
            if self.placement_mpc_trust_radius + 1e-9 < self.placement_terminal_ownership_mpc_acquire_distance_m:
                raise ValueError("MPC trust radius must cover direct ownership acquisition distance")
        for name in (
            "placement_load_belief_seeded_transport_speed_scale",
            "placement_load_belief_predicted_transport_speed_scale",
            "placement_load_belief_turn_speed_scale",
        ):
            value = getattr(self, name)
            if value <= 0.0 or value > 1.0:
                raise ValueError(f"{name} must be in (0, 1]")

        if self.placement_carried_visual_authority_enabled > 0.5:
            if self.placement_carried_visual_max_stale_seconds <= 0.0:
                raise ValueError("carried visual authority needs a positive visual stale window")
            if self.placement_carried_visual_handoff_stale_seconds < 0.0:
                raise ValueError("carried visual handoff stale window must be non-negative")
            if self.placement_carried_visual_handoff_fallback_stale_seconds < 0.0:
                raise ValueError("carried visual fallback handoff window must be non-negative")
            if (
                self.placement_carried_visual_handoff_fallback_stale_seconds > 0.0
                and self.placement_carried_visual_handoff_fallback_stale_seconds
                < self.placement_carried_visual_handoff_stale_seconds
            ):
                raise ValueError("fallback handoff window cannot be shorter than normal handoff window")
            if (
                self.placement_carried_visual_require_lock_for_release > 0.5
                and self.placement_carried_visual_handoff_stale_seconds <= 0.0
            ):
                raise ValueError("required carried visual lock needs a positive handoff window")
            if self.placement_carried_visual_release_stale_seconds <= 0.0:
                raise ValueError("carried visual authority needs a positive release stale window")
            if self.placement_carried_visual_yaw_anchor_enabled > 0.5:
                LateInsertYawAnchorConfig(
                    window_seconds=self.placement_carried_visual_yaw_anchor_window_seconds,
                    minimum_samples=self.placement_carried_visual_yaw_anchor_min_samples,
                    minimum_confidence=self.placement_carried_visual_yaw_anchor_min_confidence,
                    maximum_reprojection_error_px=self.placement_carried_visual_yaw_anchor_max_reprojection_error_px,
                    maximum_spread_rad=self.placement_carried_visual_yaw_anchor_max_spread_rad,
                ).validate()
        if self.placement_terminal_load_reacquisition_yaw_authority_enabled not in (0.0, 1.0):
            raise ValueError("terminal load reacquisition yaw authority flag must be 0 or 1")
        if self.placement_carried_yaw_axis_evidence_enabled not in (0.0, 1.0):
            raise ValueError("carried yaw axis-evidence flag must be 0 or 1")
        if (
            self.placement_carried_yaw_axis_evidence_enabled > 0.5
            and self.placement_carried_visual_yaw_anchor_enabled <= 0.5
        ):
            raise ValueError("carried yaw axis-evidence split requires the F1 yaw anchor")
        if self.placement_strict_release_certification_enabled > 0.5:
            if not (0.0 < self.placement_strict_release_position_limit_m < 0.10):
                raise ValueError("strict release position limit must be inside 0.10m")
            if not (0.0 < self.placement_strict_release_yaw_limit_rad < math.radians(5.0)):
                raise ValueError("strict release yaw limit must be inside 5 degrees")
            if (
                self.placement_strict_release_target_position_margin_cap_m > 0.0
                and self.placement_strict_release_target_position_margin_floor_m
                > self.placement_strict_release_target_position_margin_cap_m
            ):
                raise ValueError("target position uncertainty floor cannot exceed cap")
            if (
                self.placement_strict_release_target_yaw_margin_cap_rad > 0.0
                and self.placement_strict_release_target_yaw_margin_floor_rad
                > self.placement_strict_release_target_yaw_margin_cap_rad
            ):
                raise ValueError("target yaw uncertainty floor cannot exceed cap")
            if self.placement_strict_release_multiview_enabled > 0.5:
                if self.placement_strict_release_multiview_max_position_disagreement_m <= 0.0:
                    raise ValueError("multiview position disagreement limit must be positive")
                if self.placement_strict_release_multiview_max_yaw_disagreement_rad <= 0.0:
                    raise ValueError("multiview yaw disagreement limit must be positive")
            if self.placement_release_witness_enabled > 0.5:
                if self.placement_release_witness_position_drift_tolerance_m <= 0.0:
                    raise ValueError("release witness position drift tolerance must be positive")
                if self.placement_release_witness_yaw_drift_tolerance_rad <= 0.0:
                    raise ValueError("release witness yaw drift tolerance must be positive")
        if self.placement_release_witness_require_instant_strict_for_intent not in (0.0, 1.0):
            raise ValueError("instant-strict witness intent flag must be 0 or 1")
            if self.placement_certified_basin_enabled > 0.5:
                CertifiedBasinConfig(
                    hold_seconds=self.placement_certified_basin_hold_seconds,
                    consensus_evidence_seconds=self.placement_certified_basin_consensus_evidence_seconds,
                    consensus_evidence_decay=self.placement_certified_basin_consensus_evidence_decay,
                ).validate()
                if self.placement_certified_basin_position_exit_margin_m <= 0.0:
                    raise ValueError("certified basin position exit margin must be positive")
                if self.placement_certified_basin_yaw_exit_margin_rad <= 0.0:
                    raise ValueError("certified basin yaw exit margin must be positive")
                if self.placement_certified_basin_consensus_entry_enabled > 0.5:
                    if not (0.0 < self.placement_certified_basin_consensus_position_limit_m < 0.10):
                        raise ValueError("certified basin consensus position limit must stay inside 0.10m")
                    if not (0.0 < self.placement_certified_basin_consensus_yaw_limit_rad < math.radians(5.0)):
                        raise ValueError("certified basin consensus yaw limit must stay inside 5 degrees")
                    consensus_limits = (
                        self.placement_certified_basin_consensus_max_fast_slow_position_m,
                        self.placement_certified_basin_consensus_max_fast_slow_yaw_rad,
                        self.placement_certified_basin_consensus_max_target_position_spread_m,
                        self.placement_certified_basin_consensus_max_target_yaw_spread_rad,
                        self.placement_certified_basin_consensus_max_load_position_sigma_m,
                        self.placement_certified_basin_consensus_max_load_yaw_sigma_rad,
                    )
                    if not all(value > 0.0 for value in consensus_limits):
                        raise ValueError("certified basin consensus quality limits must be positive")
        if self.placement_certified_basin_consensus_release_authority not in (0.0, 1.0):
            raise ValueError("consensus release authority must be 0 or 1")
        if self.placement_micro_primitive_enabled > 0.5:
            if self.placement_mpc_enabled <= 0.5:
                raise ValueError("terminal micro-primitives require terminal MPC")
            TerminalMicroPrimitiveConfig(
                wheelbase_m=self.transport_path_wheelbase,
                steering_limit_rad=self.placement_mpc_steering_limit,
                speed_mps=self.placement_micro_primitive_speed_mps,
                activation_distance_m=self.placement_micro_primitive_activation_distance_m,
                activation_yaw_rad=self.placement_micro_primitive_activation_yaw_rad,
                maximum_predicted_distance_m=self.placement_micro_primitive_maximum_predicted_distance_m,
                position_limit_m=self.placement_strict_release_position_limit_m,
                yaw_limit_rad=self.placement_strict_release_yaw_limit_rad,
                position_scale_m=self.placement_micro_primitive_position_scale_m,
                yaw_scale_rad=self.placement_micro_primitive_yaw_scale_rad,
                required_deficit_improvement=self.placement_micro_primitive_required_deficit_improvement,
                duration_options_s=(
                    self.placement_micro_primitive_duration_short_s,
                    self.placement_micro_primitive_duration_medium_s,
                    self.placement_micro_primitive_duration_long_s,
                ),
                steering_fractions=(-1.0, -self.placement_micro_primitive_mid_steering_fraction, 0.0,
                                    self.placement_micro_primitive_mid_steering_fraction, 1.0),
                max_activations=self.placement_micro_primitive_max_activations,
                cooldown_seconds=self.placement_micro_primitive_cooldown_seconds,
                maximum_total_execution_seconds=self.placement_micro_primitive_maximum_total_execution_seconds,
                reverse_penalty=self.placement_micro_primitive_reverse_penalty,
                direction_switch_penalty=self.placement_micro_primitive_direction_switch_penalty,
            ).validate()
            if not (0.0 < self.placement_micro_primitive_mid_steering_fraction < 1.0):
                raise ValueError("micro-primitive mid steering fraction must be in (0,1)")

        if self.placement_rigid_load_constraint_enabled > 0.5:
            RigidLoadConstraintConfig(
                minimum_fork_contacts=self.placement_rigid_load_constraint_min_fork_contacts,
                maximum_abs_lift_velocity=self.placement_rigid_load_constraint_max_lift_velocity,
                minimum_stable_seconds=self.placement_rigid_load_constraint_min_stable_seconds,
            ).validate()
            if self.placement_rigid_load_constraint_position_sigma_cap_m <= 0.0:
                raise ValueError("rigid-load position sigma cap must be positive")
            if self.placement_rigid_load_constraint_yaw_sigma_cap_rad <= 0.0:
                raise ValueError("rigid-load yaw sigma cap must be positive")
        if self.placement_strict_release_rss_uncertainty_enabled not in (0.0, 1.0):
            raise ValueError("RSS release uncertainty flag must be 0 or 1")
        if self.placement_carried_seed_provenance_enabled > 0.5:
            LoadSeedProvenanceConfig(
                recent_max_age_seconds=self.placement_carried_seed_recent_max_age_seconds,
                recent_min_confidence=self.placement_carried_seed_recent_min_confidence,
                recent_max_reprojection_error_px=self.placement_carried_seed_recent_max_reprojection_error_px,
                high_confidence_threshold=self.placement_carried_seed_high_confidence_threshold,
                high_confidence_max_age_seconds=self.placement_carried_seed_high_confidence_max_age_seconds,
                high_confidence_max_reprojection_error_px=self.placement_carried_seed_high_confidence_max_reprojection_error_px,
            ).validate()
        if self.placement_carried_seed_require_trusted_for_rigid_position_cap not in (0.0, 1.0):
            raise ValueError("trusted-seed rigid-cap flag must be 0 or 1")
        if self.placement_carried_seed_require_trusted_for_rss not in (0.0, 1.0):
            raise ValueError("trusted-seed RSS flag must be 0 or 1")
        if self.placement_yaw_tail_reserve_enabled > 0.5:
            if self.placement_micro_primitive_enabled <= 0.5:
                raise ValueError("yaw-tail reserve requires the terminal micro planner")
            YawTailReserveConfig(
                wheelbase_m=self.transport_path_wheelbase,
                steering_limit_rad=self.placement_mpc_steering_limit,
                speed_mps=self.placement_yaw_tail_reserve_speed_mps,
                position_gate_m=self.placement_yaw_tail_reserve_position_gate_m,
                yaw_min_rad=self.placement_yaw_tail_reserve_yaw_min_rad,
                yaw_max_rad=self.placement_yaw_tail_reserve_yaw_max_rad,
                predicted_position_guard_m=self.placement_yaw_tail_reserve_position_guard_m,
                required_yaw_improvement_rad=self.placement_yaw_tail_reserve_required_yaw_improvement_rad,
                duration_options_s=(self.placement_yaw_tail_reserve_duration_short_s, self.placement_yaw_tail_reserve_duration_long_s),
                steering_fractions=(-1.0, -0.55, 0.55, 1.0),
                maximum_speed_for_activation_mps=self.placement_yaw_tail_reserve_maximum_speed_for_activation_mps,
                max_activations=self.placement_yaw_tail_reserve_max_activations,
                maximum_total_execution_seconds=self.placement_yaw_tail_reserve_maximum_total_execution_seconds,
            ).validate()

        if self.placement_strict_recovery_retention_enabled > 0.5:
            if self.placement_micro_primitive_enabled <= 0.5 or self.placement_yaw_tail_reserve_enabled <= 0.5:
                raise ValueError("strict-recovery retention requires both terminal micro budgets")
            if self.placement_strict_recovery_retention_final_settle_seconds < 0.0:
                raise ValueError("strict-recovery final settle lease must be non-negative")
            StrictRecoveryRetentionConfig(
                wheelbase_m=self.transport_path_wheelbase,
                steering_limit_rad=self.placement_mpc_steering_limit,
                speed_mps=self.placement_strict_recovery_retention_speed_mps,
                activation_distance_m=self.placement_strict_recovery_retention_activation_distance_m,
                activation_yaw_rad=self.placement_strict_recovery_retention_activation_yaw_rad,
                target_position_m=self.placement_strict_recovery_retention_target_position_m,
                target_yaw_rad=self.placement_strict_recovery_retention_target_yaw_rad,
                predicted_position_guard_m=self.placement_strict_recovery_retention_position_guard_m,
                predicted_yaw_guard_rad=self.placement_strict_recovery_retention_yaw_guard_rad,
                position_scale_m=self.placement_strict_recovery_retention_position_scale_m,
                yaw_scale_rad=self.placement_strict_recovery_retention_yaw_scale_rad,
                required_deficit_improvement=self.placement_strict_recovery_retention_required_improvement,
                duration_options_s=(
                    self.placement_strict_recovery_retention_duration_short_s,
                    self.placement_strict_recovery_retention_duration_long_s,
                ),
                steering_fractions=(-1.0, -0.55, 0.0, 0.55, 1.0),
                maximum_speed_for_activation_mps=self.placement_strict_recovery_retention_maximum_speed_for_activation_mps,
                max_activations=self.placement_strict_recovery_retention_max_activations,
                cooldown_seconds=self.placement_strict_recovery_retention_cooldown_seconds,
                maximum_total_execution_seconds=self.placement_strict_recovery_retention_maximum_total_execution_seconds,
            ).validate()

        if self.placement_fresh_rgb_yaw_closure_enabled > 0.5:
            if self.placement_strict_recovery_retention_enabled <= 0.5:
                raise ValueError("fresh-RGB yaw closure requires strict-recovery retention")
            FreshRGBYawClosureConfig(
                wheelbase_m=self.transport_path_wheelbase,
                steering_limit_rad=self.placement_mpc_steering_limit,
                speed_mps=self.placement_fresh_rgb_yaw_closure_speed_mps,
                position_gate_m=self.placement_fresh_rgb_yaw_closure_position_gate_m,
                yaw_min_rad=self.placement_fresh_rgb_yaw_closure_yaw_min_rad,
                yaw_max_rad=self.placement_fresh_rgb_yaw_closure_yaw_max_rad,
                target_yaw_rad=self.placement_fresh_rgb_yaw_closure_target_yaw_rad,
                midpoint_position_guard_m=self.placement_fresh_rgb_yaw_closure_midpoint_position_guard_m,
                final_position_guard_m=self.placement_fresh_rgb_yaw_closure_final_position_guard_m,
                required_yaw_improvement_rad=self.placement_fresh_rgb_yaw_closure_required_predicted_yaw_improvement_rad,
                duration_options_s=(
                    self.placement_fresh_rgb_yaw_closure_duration_short_s,
                    self.placement_fresh_rgb_yaw_closure_duration_medium_s,
                    self.placement_fresh_rgb_yaw_closure_duration_long_s,
                ),
                steering_fractions=(
                    self.placement_fresh_rgb_yaw_closure_mid_steering_fraction, 1.0
                ),
                maximum_speed_for_activation_mps=self.placement_fresh_rgb_yaw_closure_maximum_speed_for_activation_mps,
                max_activations=self.placement_fresh_rgb_yaw_closure_max_activations,
                maximum_total_execution_seconds=self.placement_fresh_rgb_yaw_closure_maximum_total_execution_seconds,
            ).validate()
            if not (0.0 < self.placement_fresh_rgb_yaw_closure_mid_steering_fraction < 1.0):
                raise ValueError("fresh-RGB yaw closure mid steering fraction must be in (0,1)")
            if self.placement_fresh_rgb_yaw_closure_maximum_rgb_stale_seconds <= 0.0:
                raise ValueError("fresh-RGB yaw closure freshness must be positive")
            if self.placement_fresh_rgb_yaw_closure_minimum_terminal_rgb_updates < 1:
                raise ValueError("fresh-RGB yaw closure needs terminal RGB updates")
            if self.placement_fresh_rgb_yaw_closure_maximum_observer_yaw_sigma_rad <= 0.0:
                raise ValueError("fresh-RGB yaw closure observer sigma gate must be positive")
            if self.placement_fresh_rgb_yaw_closure_maximum_target_fast_slow_yaw_disagreement_rad <= 0.0:
                raise ValueError("fresh-RGB yaw closure target disagreement gate must be positive")
            if self.placement_fresh_rgb_yaw_closure_post_motion_settle_seconds <= 0.0:
                raise ValueError("fresh-RGB yaw closure settle must be positive")
            if self.placement_fresh_rgb_yaw_closure_post_motion_max_wait_seconds < self.placement_fresh_rgb_yaw_closure_post_motion_settle_seconds:
                raise ValueError("fresh-RGB yaw closure max wait must contain settle")
            if self.placement_fresh_rgb_yaw_closure_minimum_post_motion_rgb_updates < 1:
                raise ValueError("fresh-RGB yaw closure post-motion updates must be positive")
            if self.placement_fresh_rgb_yaw_closure_minimum_measured_yaw_improvement_rad <= 0.0:
                raise ValueError("fresh-RGB yaw closure measured improvement gate must be positive")

        if self.placement_post_closure_basin_ownership_enabled > 0.5:
            if self.placement_fresh_rgb_yaw_closure_enabled <= 0.5:
                raise ValueError("post-closure basin ownership requires Fresh-RGB yaw closure")
            PostClosureBasinGuardConfig(
                position_guard_m=self.placement_post_closure_basin_position_guard_m,
                yaw_guard_rad=self.placement_post_closure_basin_yaw_guard_rad,
                mpc_predicted_position_limit_m=self.placement_post_closure_mpc_predicted_position_limit_m,
                mpc_allowed_position_regression_m=self.placement_post_closure_mpc_allowed_position_regression_m,
                mpc_allowed_yaw_regression_rad=self.placement_post_closure_mpc_allowed_yaw_regression_rad,
                continuation_position_gate_m=self.placement_post_closure_continuation_position_gate_m,
            ).validate()
            if self.placement_post_closure_continuation_position_gate_m < self.placement_fresh_rgb_yaw_closure_position_gate_m:
                raise ValueError("post-closure continuation gate cannot be tighter than initial Fresh-RGB gate")

        if self.placement_certification_basin_closure_enabled > 0.5:
            if self.placement_post_closure_basin_ownership_enabled <= 0.5:
                raise ValueError("certification-basin closure requires post-closure ownership")
            CertificationBasinClosureConfig(
                wheelbase_m=self.transport_path_wheelbase,
                steering_limit_rad=self.placement_mpc_steering_limit,
                speed_mps=self.placement_certification_basin_closure_speed_mps,
                filtered_position_guard_m=self.placement_certification_basin_closure_filtered_position_guard_m,
                filtered_yaw_guard_rad=self.placement_certification_basin_closure_filtered_yaw_guard_rad,
                certification_position_activation_m=self.placement_certification_basin_closure_certification_position_activation_m,
                certification_yaw_activation_rad=self.placement_certification_basin_closure_certification_yaw_activation_rad,
                predicted_filtered_position_guard_m=self.placement_certification_basin_closure_predicted_filtered_position_guard_m,
                predicted_filtered_yaw_guard_rad=self.placement_certification_basin_closure_predicted_filtered_yaw_guard_rad,
                strict_position_limit_m=self.placement_strict_release_position_limit_m,
                strict_yaw_limit_rad=self.placement_strict_release_yaw_limit_rad,
                position_scale_m=self.placement_certification_basin_closure_position_scale_m,
                yaw_scale_rad=self.placement_certification_basin_closure_yaw_scale_rad,
                required_predicted_deficit_improvement=self.placement_certification_basin_closure_required_predicted_deficit_improvement,
                allowed_filtered_position_regression_m=self.placement_certification_basin_closure_allowed_filtered_position_regression_m,
                duration_options_s=(
                    self.placement_certification_basin_closure_duration_short_s,
                    self.placement_certification_basin_closure_duration_medium_s,
                    self.placement_certification_basin_closure_duration_long_s,
                ),
                steering_fractions=(self.placement_certification_basin_closure_mid_steering_fraction, 1.0),
                second_leg_duration_fractions=(0.0, self.placement_certification_basin_closure_second_leg_duration_fraction, 1.0),
                maximum_speed_for_activation_mps=self.placement_certification_basin_closure_maximum_speed_for_activation_mps,
                max_activations=self.placement_certification_basin_closure_max_activations,
                maximum_total_execution_seconds=self.placement_certification_basin_closure_maximum_total_execution_seconds,
            ).validate()
            if not (0.0 < self.placement_certification_basin_closure_mid_steering_fraction < 1.0):
                raise ValueError("certification-basin mid steering fraction must be in (0,1)")
            if not (0.0 < self.placement_certification_basin_closure_second_leg_duration_fraction <= 1.0):
                raise ValueError("certification-basin second-leg duration fraction must be in (0,1]")
            if self.placement_certification_basin_closure_search_period_s <= 0.0:
                raise ValueError("certification-basin search period must be positive")
            if self.placement_certification_basin_closure_post_motion_settle_seconds <= 0.0:
                raise ValueError("certification-basin post-motion settle must be positive")
            if self.placement_certification_basin_closure_post_motion_max_wait_seconds < self.placement_certification_basin_closure_post_motion_settle_seconds:
                raise ValueError("certification-basin post-motion max wait must contain settle")
            if self.placement_certification_basin_closure_minimum_post_motion_rgb_updates < 1:
                raise ValueError("certification-basin post-motion RGB update gate must be positive")
            if self.placement_certification_basin_closure_minimum_measured_deficit_improvement <= 0.0:
                raise ValueError("certification-basin measured deficit improvement must be positive")
            if self.placement_post_closure_exit_position_guard_m < self.placement_post_closure_basin_position_guard_m:
                raise ValueError("post-closure exit position guard must contain the main ownership guard")
            if self.placement_post_closure_exit_yaw_guard_rad < self.placement_post_closure_basin_yaw_guard_rad:
                raise ValueError("post-closure exit yaw guard must contain the main ownership guard")

        if self.placement_position_blocker_recenter_enabled > 0.5:
            if self.placement_post_closure_basin_ownership_enabled <= 0.5:
                raise ValueError("position-blocker recenter requires post-closure ownership")
            PositionBlockerRecenterConfig(
                wheelbase_m=self.transport_path_wheelbase,
                steering_limit_rad=self.placement_mpc_steering_limit,
                speed_mps=self.placement_position_blocker_recenter_speed_mps,
                filtered_position_activation_m=self.placement_position_blocker_recenter_filtered_position_activation_m,
                filtered_yaw_activation_rad=self.placement_position_blocker_recenter_filtered_yaw_activation_rad,
                certification_position_activation_m=self.placement_position_blocker_recenter_certification_position_activation_m,
                certification_yaw_activation_rad=self.placement_position_blocker_recenter_certification_yaw_activation_rad,
                minimum_lateral_fraction=self.placement_position_blocker_recenter_minimum_lateral_fraction,
                strict_position_limit_m=self.placement_strict_release_position_limit_m,
                strict_yaw_limit_rad=self.placement_strict_release_yaw_limit_rad,
                predicted_position_headroom_m=self.placement_position_blocker_recenter_predicted_position_headroom_m,
                predicted_yaw_headroom_rad=self.placement_position_blocker_recenter_predicted_yaw_headroom_rad,
                maximum_predicted_filtered_excursion_m=self.placement_position_blocker_recenter_maximum_predicted_excursion_m,
                final_filtered_position_guard_m=self.placement_position_blocker_recenter_final_filtered_position_guard_m,
                final_filtered_yaw_guard_rad=self.placement_position_blocker_recenter_final_filtered_yaw_guard_rad,
                departure_duration_options_s=(
                    self.placement_position_blocker_recenter_departure_duration_short_s,
                    self.placement_position_blocker_recenter_departure_duration_medium_s,
                    self.placement_position_blocker_recenter_departure_duration_long_s,
                ),
                return_duration_options_s=(
                    self.placement_position_blocker_recenter_return_duration_short_s,
                    self.placement_position_blocker_recenter_return_duration_medium_s,
                    self.placement_position_blocker_recenter_return_duration_long_s,
                ),
                steering_fractions=(self.placement_position_blocker_recenter_steering_fraction, 1.0),
                maximum_speed_for_activation_mps=self.placement_position_blocker_recenter_maximum_speed_for_activation_mps,
                maximum_total_execution_seconds=self.placement_position_blocker_recenter_maximum_total_execution_seconds,
                require_non_retrace_topology=(
                    self.placement_position_blocker_recenter_require_non_retrace_topology > 0.5
                ),
            ).validate()
            if self.placement_position_blocker_recenter_minimum_terminal_budget_remaining_s <= 0.0:
                raise ValueError("position-blocker recenter terminal budget gate must be positive")
            if self.placement_position_blocker_recenter_midpoint_settle_seconds <= 0.0:
                raise ValueError("position-blocker midpoint settle must be positive")
            if self.placement_position_blocker_recenter_midpoint_max_wait_seconds < self.placement_position_blocker_recenter_midpoint_settle_seconds:
                raise ValueError("position-blocker midpoint max wait must contain settle")
            if self.placement_position_blocker_recenter_midpoint_minimum_rgb_updates < 1:
                raise ValueError("position-blocker midpoint RGB update gate must be positive")
            if self.placement_position_blocker_recenter_final_settle_seconds <= 0.0:
                raise ValueError("position-blocker final settle must be positive")
            if self.placement_position_blocker_recenter_final_max_wait_seconds < self.placement_position_blocker_recenter_final_settle_seconds:
                raise ValueError("position-blocker final max wait must contain settle")
            if self.placement_position_blocker_recenter_final_minimum_rgb_updates < 1:
                raise ValueError("position-blocker final RGB update gate must be positive")
            if self.placement_position_blocker_recenter_final_evidence_hold_seconds <= 0.0:
                raise ValueError("E6 final evidence hold must be positive")
            if (
                self.placement_position_blocker_recenter_final_evidence_max_wait_seconds
                < self.placement_position_blocker_recenter_final_evidence_hold_seconds
            ):
                raise ValueError("E6 final evidence max wait must contain hold")
            if (
                self.placement_position_blocker_recenter_final_evidence_minimum_consistent_rgb_updates
                < 1
            ):
                raise ValueError("E6 final evidence consistent RGB gate must be positive")
            if self.placement_position_blocker_recenter_minimum_measured_position_improvement_m <= 0.0:
                raise ValueError("position-blocker measured position improvement must be positive")
            if self.placement_position_blocker_recenter_hard_abort_distance_m <= self.placement_position_blocker_recenter_maximum_predicted_excursion_m:
                raise ValueError("position-blocker abort distance must exceed predicted excursion guard")
            if self.placement_position_blocker_recenter_hard_abort_yaw_rad <= self.placement_position_blocker_recenter_filtered_yaw_activation_rad:
                raise ValueError("position-blocker abort yaw must exceed activation yaw")
            if self.placement_position_blocker_recenter_presteer_command_rad <= self.placement_mpc_steering_limit:
                raise ValueError("E4 presteer overdrive must exceed the effective recenter steering limit")
            if self.placement_position_blocker_recenter_presteer_ready_tolerance_rad <= 0.0:
                raise ValueError("E4 presteer tolerance must be positive")
            if self.placement_position_blocker_recenter_presteer_max_seconds <= 0.0:
                raise ValueError("E4 presteer timeout must be positive")
            if self.placement_position_blocker_recenter_odometry_timeout_scale <= 1.0:
                raise ValueError("E4 odometry timeout scale must exceed one")
            if self.placement_position_blocker_recenter_midpoint_prediction_position_tolerance_m <= 0.0:
                raise ValueError("E4 midpoint position tolerance must be positive")
            if self.placement_position_blocker_recenter_midpoint_prediction_yaw_tolerance_rad <= 0.0:
                raise ValueError("E4 midpoint yaw tolerance must be positive")

        if self.placement_mpc_yaw_escrow_enabled > 0.5:
            if self.placement_mpc_enabled <= 0.5:
                raise ValueError("yaw feasibility escrow requires terminal MPC")
            if self.placement_mpc_yaw_escrow_activation_distance_m <= 0.0:
                raise ValueError("yaw escrow activation distance must be positive")
            if self.placement_mpc_yaw_escrow_activation_yaw_rad <= 0.0:
                raise ValueError("yaw escrow activation yaw must be positive")
            if self.placement_mpc_yaw_escrow_predicted_max_distance_m < self.placement_mpc_yaw_escrow_activation_distance_m:
                raise ValueError("yaw escrow predicted distance must cover activation distance")
            if self.placement_mpc_yaw_escrow_required_improvement_rad <= 0.0:
                raise ValueError("yaw escrow requires positive yaw improvement")
            if self.placement_mpc_yaw_escrow_max_seconds <= 0.0:
                raise ValueError("yaw escrow requires positive bounded duration")
            if self.placement_mpc_yaw_escrow_max_activations <= 0:
                raise ValueError("yaw escrow requires at least one activation")
        if self.placement_mpc_near_basin_escrow_enabled > 0.5:
            if self.placement_mpc_enabled <= 0.5:
                raise ValueError("near-basin escrow requires terminal MPC")
            NearBasinFeasibilityConfig(
                activation_distance_m=self.placement_mpc_near_basin_activation_distance_m,
                activation_yaw_rad=self.placement_mpc_near_basin_activation_yaw_rad,
                maximum_predicted_distance_m=self.placement_mpc_near_basin_maximum_predicted_distance_m,
                position_scale_m=self.placement_mpc_near_basin_position_scale_m,
                yaw_scale_rad=self.placement_mpc_near_basin_yaw_scale_rad,
                required_deficit_improvement=self.placement_mpc_near_basin_required_deficit_improvement,
                allowed_active_regression=self.placement_mpc_near_basin_allowed_active_regression,
                max_seconds=self.placement_mpc_near_basin_max_seconds,
                max_activations=self.placement_mpc_near_basin_max_activations,
            ).validate()
            if self.placement_mpc_near_basin_preview_seconds <= 0.0:
                raise ValueError("near-basin preview seconds must be positive")
        if self.placement_strict_release_center_yaw_continuity_guard_enabled > 0.5:
            if self.placement_strict_release_center_yaw_anchor_enabled <= 0.5:
                raise ValueError("center-yaw continuity guard requires F4 center-yaw anchor")
            if self.placement_strict_release_center_yaw_max_reanchor_jump_rad <= 0.0:
                raise ValueError("center-yaw re-anchor jump limit must be positive")
            if self.placement_strict_release_center_yaw_revalidation_seconds <= 0.0:
                raise ValueError("center-yaw revalidation interval must be positive")
            if self.placement_strict_release_center_yaw_revalidation_tolerance_rad <= 0.0:
                raise ValueError("center-yaw revalidation tolerance must be positive")
            if (
                self.placement_strict_release_center_yaw_revalidation_tolerance_rad
                >= self.placement_strict_release_center_yaw_max_reanchor_jump_rad
            ):
                raise ValueError("center-yaw revalidation tolerance must be tighter than jump limit")
        if self.placement_release_supervisor_enabled > 0.5:
            ReleaseDecisionSupervisorConfig(
                evidence_seconds=self.placement_release_supervisor_evidence_seconds,
                evidence_soft_decay=self.placement_release_supervisor_evidence_soft_decay,
                settle_timeout_seconds=self.placement_release_supervisor_settle_timeout_seconds,
                intent_execute_delay_seconds=self.placement_release_supervisor_intent_delay_seconds,
                hard_violation_grace_seconds=self.placement_release_supervisor_hard_violation_grace_seconds,
                rearm_cooldown_seconds=self.placement_release_supervisor_rearm_cooldown_seconds,
            ).validate()
            if self.placement_strict_release_certification_enabled <= 0.5:
                raise ValueError("release supervisor requires strict release certification")
        if self.insertion_lift_target < 0.0:
            raise ValueError("insertion_lift_target must be non-negative")
        if self.transport_lift_target <= self.insertion_lift_target:
            raise ValueError(
                "transport_lift_target must exceed insertion_lift_target"
            )
        if self.pre_approach_distance <= self.insertion_distance:
            raise ValueError(
                "pre_approach_distance must exceed insertion_distance"
            )
        if self.retreat_speed >= 0.0:
            raise ValueError("retreat_speed must be negative")
        if self.recovery_speed >= 0.0:
            raise ValueError("recovery_speed must be negative")
        if self.recovery_unwind_speed > 0.0:
            raise ValueError(
                "recovery_unwind_speed must be zero or negative"
            )
        if (
            self.recovery_unwind_speed < 0.0
            and self.recovery_unwind_distance <= 0.0
        ):
            raise ValueError(
                "recovery_unwind_distance must be positive when "
                "moving steering unwind is enabled"
            )
        if self.maximum_recoveries < 0:
            raise ValueError("maximum_recoveries must be non-negative")
        if self.maximum_recoveries > 0 and self.recovery_distance <= 0.0:
            raise ValueError(
                "recovery_distance must be positive when recovery is enabled"
            )
        if self.recovery_minimum_distance > self.recovery_distance:
            raise ValueError(
                "recovery_minimum_distance cannot exceed recovery_distance"
            )
        if self.axis_docking_enabled > 0.5:
            required_positive = (
                "approach_line_distance",
                "alignment_line_distance",
                "alignment_abort_distance",
                "insertion_abort_distance",
                "insertion_abort_lateral",
                "insertion_abort_yaw",
            )
            for name in required_positive:
                if getattr(self, name) <= 0.0:
                    raise ValueError(
                        f"{name} must be positive in axis docking mode"
                    )
            if not (
                self.approach_line_distance
                > self.alignment_line_distance
                > self.alignment_abort_distance
                > self.insertion_distance
                > self.insertion_abort_distance
            ):
                raise ValueError(
                    "axis docking distances must satisfy approach > alignment "
                    "> alignment_abort > insertion > insertion_abort"
                )
            geometry_values = (
                self.fork_root_distance,
                self.fork_tip_distance,
                self.pallet_half_length,
                self.alignment_preview_tolerance,
                self.insertion_corridor_tolerance,
            )
            geometry_enabled = any(value > 0.0 for value in geometry_values)
            if geometry_enabled:
                if not all(value > 0.0 for value in geometry_values):
                    raise ValueError(
                        "all fork corridor geometry values must be positive "
                        "when corridor-aware gating is enabled"
                    )
                if self.fork_tip_distance <= self.fork_root_distance:
                    raise ValueError(
                        "fork_tip_distance must exceed fork_root_distance"
                    )
                planned_near = max(
                    self.fork_root_distance,
                    self.insertion_distance - self.pallet_half_length,
                )
                planned_far = min(
                    self.fork_tip_distance,
                    self.insertion_distance + self.pallet_half_length,
                )
                if planned_near > planned_far:
                    raise ValueError(
                        "fork and pallet do not overlap at insertion_distance"
                    )
                if self.insertion_steering_limit <= 0.0:
                    raise ValueError(
                        "insertion_steering_limit must be positive"
                    )
        if self.corridor_control_enabled > 0.5:
            if not (
                self.axis_docking_enabled > 0.5
                and self.fork_root_distance > 0.0
                and self.fork_tip_distance > self.fork_root_distance
                and self.pallet_half_length > 0.0
                and self.alignment_preview_tolerance > 0.0
                and self.insertion_corridor_tolerance > 0.0
            ):
                raise ValueError(
                    "corridor control requires enabled fork corridor geometry"
                )
            if self.corridor_control_lateral_gain <= 0.0:
                raise ValueError(
                    "corridor_control_lateral_gain must be positive"
                )
            if self.corridor_control_yaw_gain < 0.0:
                raise ValueError(
                    "corridor_control_yaw_gain must be non-negative"
                )
            if self.corridor_control_lookahead <= 0.0:
                raise ValueError(
                    "corridor_control_lookahead must be positive"
                )
        if (
            self.recovery_reset_distance > 0.0
            and self.maximum_recoveries <= 0
        ):
            raise ValueError(
                "recovery_reset_distance requires recovery to be enabled"
            )
        if (
            self.recovery_reset_minimum_distance
            > self.recovery_distance
        ):
            raise ValueError(
                "recovery_reset_minimum_distance cannot exceed "
                "recovery_distance"
            )
        if self.placement_enabled > 0.5:
            required_positive = (
                "placement_pre_distance",
                "transport_max_speed",
                "transport_capture_distance",
                "transport_steering_limit",
                "transport_timeout",
                "place_align_max_speed",
                "place_align_minimum_speed",
                "place_steering_limit",
                "placement_position_tolerance",
                "placement_yaw_tolerance",
                "placement_hold_seconds",
                "place_align_timeout",
                "placement_lower_timeout",
                "release_verify_seconds",
                "placement_retreat_distance",
                "placement_retreat_timeout",
                "placement_load_motion_tolerance",
            )
            for name in required_positive:
                if getattr(self, name) <= 0.0:
                    raise ValueError(f"{name} must be positive for placement mission")
            if self.placement_retreat_speed >= 0.0:
                raise ValueError("placement_retreat_speed must be negative")
            if self.placement_lower_target < 0.0:
                raise ValueError("placement_lower_target must be non-negative")
            if self.placement_lower_target >= self.transport_lift_target:
                raise ValueError(
                    "placement_lower_target must be below transport_lift_target"
                )
            release_values = (
                self.placement_release_position_tolerance,
                self.placement_release_yaw_tolerance,
                self.placement_release_after_seconds,
                self.placement_release_hold_seconds,
                self.placement_post_release_position_tolerance,
                self.placement_post_release_yaw_tolerance,
            )
            release_enabled = any(value > 0.0 for value in release_values)
            if release_enabled:
                if not all(value > 0.0 for value in release_values):
                    raise ValueError(
                        "all V6.3 placement release envelope values must be "
                        "positive when the envelope is enabled"
                    )
                if (
                    self.placement_release_position_tolerance
                    < self.placement_position_tolerance
                ):
                    raise ValueError(
                        "placement_release_position_tolerance cannot be "
                        "smaller than placement_position_tolerance"
                    )
                if (
                    self.placement_release_yaw_tolerance
                    < self.placement_yaw_tolerance
                ):
                    raise ValueError(
                        "placement_release_yaw_tolerance cannot be smaller "
                        "than placement_yaw_tolerance"
                    )
                if (
                    self.placement_post_release_position_tolerance
                    < self.placement_release_position_tolerance
                ):
                    raise ValueError(
                        "post-release position tolerance cannot be smaller "
                        "than the release position tolerance"
                    )
                if (
                    self.placement_post_release_yaw_tolerance
                    < self.placement_release_yaw_tolerance
                ):
                    raise ValueError(
                        "post-release yaw tolerance cannot be smaller than "
                        "the release yaw tolerance"
                    )

            if self.placement_maximum_recoveries < 0:
                raise ValueError("placement_maximum_recoveries must be non-negative")
            if self.placement_maximum_recoveries > 0:
                for name in (
                    "placement_recovery_minimum_distance",
                    "placement_recovery_maximum_distance",
                    "placement_recovery_timeout",
                    "placement_recovery_steering_tolerance",
                    "placement_progress_timeout",
                    "placement_progress_improvement",
                ):
                    if getattr(self, name) <= 0.0:
                        raise ValueError(
                            f"{name} must be positive when terminal recovery is enabled"
                        )
                if self.placement_recovery_speed >= 0.0:
                    raise ValueError("placement_recovery_speed must be negative")
                if self.placement_recovery_unwind_speed > 0.0:
                    raise ValueError(
                        "placement_recovery_unwind_speed must be zero or negative"
                    )
                if (self.placement_recovery_minimum_distance
                        > self.placement_recovery_maximum_distance):
                    raise ValueError("placement recovery minimum cannot exceed maximum")
                if self.placement_overshoot_longitudinal_tolerance <= 0.0:
                    raise ValueError(
                        "placement_overshoot_longitudinal_tolerance must be positive "
                        "when terminal recovery is enabled"
                    )
                if self.placement_recovery_runway_distance > 0.0:
                    if self.placement_recovery_reentry_heading_tolerance <= 0.0:
                        raise ValueError(
                            "placement_recovery_reentry_heading_tolerance must be positive"
                        )
                    if self.placement_recovery_reentry_yaw_tolerance <= 0.0:
                        raise ValueError(
                            "placement_recovery_reentry_yaw_tolerance must be positive"
                        )
                    if not 0.0 < self.placement_recovery_reentry_speed_scale <= 1.0:
                        raise ValueError(
                            "placement_recovery_reentry_speed_scale must be in (0,1]"
                        )
                    if not 0.0 < self.placement_recovery_reentry_minimum_speed_scale <= 1.0:
                        raise ValueError(
                            "placement_recovery_reentry_minimum_speed_scale must be in (0,1]"
                        )
                    if (self.placement_recovery_reentry_minimum_speed_scale
                            > self.placement_recovery_reentry_speed_scale):
                        raise ValueError(
                            "placement recovery minimum speed scale cannot exceed base scale"
                        )
                    reverse_steering_values = (
                        self.placement_recovery_reverse_steering_limit,
                        self.placement_recovery_reverse_lateral_gain,
                        self.placement_recovery_reverse_yaw_gain,
                    )
                    reverse_steering_enabled = any(
                        value > 0.0 for value in reverse_steering_values
                    )
                    if reverse_steering_enabled and not all(
                        value > 0.0 for value in reverse_steering_values
                    ):
                        raise ValueError(
                            "all placement reverse-steering values must be positive "
                            "when closed-loop reverse steering is enabled"
                        )
                    if self.placement_recovery_reverse_steering_limit > 0.35:
                        raise ValueError(
                            "placement_recovery_reverse_steering_limit must be <= 0.35 rad"
                        )
                guard_values = (
                    self.placement_guard_minimum_forward_speed,
                    self.placement_guard_reaction_seconds,
                    self.placement_guard_deceleration_mps2,
                    self.placement_guard_lateral_tolerance,
                    self.placement_guard_heading_tolerance,
                    self.placement_guard_yaw_tolerance,
                    self.placement_guard_brake_hold_seconds,
                )
                guard_enabled = any(value > 0.0 for value in guard_values)
                if guard_enabled and not all(value > 0.0 for value in guard_values):
                    raise ValueError(
                        "all predictive placement guard values must be positive when enabled"
                    )
                settle_values = (
                    self.placement_precision_settle_seconds,
                    self.placement_precision_settle_max_speed,
                    self.placement_precision_settle_progress_timeout,
                    self.placement_precision_settle_improvement_m,
                )
                settle_enabled = any(value > 0.0 for value in settle_values)
                if settle_enabled and not all(value > 0.0 for value in settle_values):
                    raise ValueError(
                        "all bounded placement settle values must be positive when enabled"
                    )

                precision_positive_values = (
                    self.placement_precision_forward_max_speed,
                    self.placement_precision_reverse_max_speed,
                    self.placement_precision_reverse_longitudinal_limit,
                    self.placement_precision_reverse_lateral_tolerance,
                    self.placement_precision_reverse_yaw_tolerance,
                    self.placement_precision_direction_change_speed_epsilon,
                    self.placement_precision_entry_position_tolerance,
                    self.placement_precision_entry_lateral_tolerance,
                    self.placement_precision_entry_yaw_tolerance,
                    self.placement_precision_entry_hold_seconds,
                    self.placement_precision_entry_max_speed,
                    self.placement_precision_speed_gain,
                    self.placement_precision_longitudinal_deadband,
                    self.placement_precision_geometry_max_speed,
                    self.placement_precision_progress_timeout,
                    self.placement_precision_progress_improvement,
                    self.placement_precision_maximum_regression_m,
                    self.placement_precision_release_max_speed,
                )
                precision_enabled = self.placement_competition_precision_enabled > 0.5
                if precision_enabled and not all(
                    value > 0.0 for value in precision_positive_values
                ):
                    raise ValueError(
                        "all V9.2.3 precision-stability values must be positive when enabled"
                    )
                v924_values = (
                    self.placement_precision_filter_alpha,
                    self.placement_precision_filtered_position_tolerance,
                    self.placement_precision_filtered_yaw_tolerance,
                    self.placement_precision_direction_switch_hysteresis,
                    self.placement_precision_task_lateral_gain,
                    self.placement_precision_task_yaw_gain,
                    self.placement_precision_task_lookahead,
                    self.placement_precision_task_steering_limit,
                    self.placement_precision_recenter_trigger_lateral,
                    self.placement_precision_recenter_trigger_yaw,
                    self.placement_precision_recenter_exit_lateral,
                    self.placement_precision_recenter_exit_yaw,
                    self.placement_precision_recenter_activation_longitudinal,
                    self.placement_precision_recenter_reverse_speed,
                    self.placement_precision_recenter_min_distance,
                    self.placement_precision_recenter_max_distance,
                    self.placement_precision_recenter_max_seconds,
                )
                v924_enabled = any(value > 0.0 for value in v924_values) or (
                    self.placement_precision_recenter_max_cycles > 0
                )
                if v924_enabled and not all(value > 0.0 for value in v924_values):
                    raise ValueError(
                        "all V9.3.0 terminal-control values must be positive when enabled"
                    )
                if v924_enabled and self.placement_precision_recenter_max_cycles <= 0:
                    raise ValueError(
                        "placement_precision_recenter_max_cycles must be positive"
                    )
                if precision_enabled:
                    if self.placement_precision_minimum_speed > min(
                        self.placement_precision_forward_max_speed,
                        self.placement_precision_reverse_max_speed,
                    ):
                        raise ValueError(
                            "placement_precision_minimum_speed cannot exceed precision speed limits"
                        )
                    if (
                        self.placement_precision_entry_position_tolerance
                        < self.placement_position_tolerance
                    ):
                        raise ValueError(
                            "precision entry position tolerance cannot be tighter than release tolerance"
                        )
                    if (
                        self.placement_precision_entry_yaw_tolerance
                        < self.placement_yaw_tolerance
                    ):
                        raise ValueError(
                            "precision entry yaw tolerance cannot be tighter than release tolerance"
                        )
                    if (
                        self.placement_precision_entry_lateral_tolerance
                        > self.placement_precision_reverse_lateral_tolerance
                    ):
                        raise ValueError(
                            "precision entry lateral tolerance must fit the local reverse basin"
                        )
                    if (
                        self.placement_precision_entry_yaw_tolerance
                        > self.placement_precision_reverse_yaw_tolerance
                    ):
                        raise ValueError(
                            "precision entry yaw tolerance must fit the local reverse basin"
                        )
                    if self.placement_position_tolerance >= 0.10:
                        raise ValueError(
                            "competition precision position tolerance must be below 0.10m"
                        )
                    if self.placement_yaw_tolerance >= math.radians(5.0):
                        raise ValueError(
                            "competition precision yaw tolerance must be below 5 degrees"
                        )
                if v924_enabled:
                    if not 0.0 < self.placement_precision_filter_alpha <= 1.0:
                        raise ValueError(
                            "placement_precision_filter_alpha must be in (0, 1]"
                        )
                    if (
                        self.placement_precision_direction_switch_hysteresis
                        <= self.placement_precision_longitudinal_deadband
                    ):
                        raise ValueError(
                            "precision direction-switch hysteresis must exceed the deadband"
                        )
                    if (
                        self.placement_precision_filtered_position_tolerance
                        >= 0.10
                    ):
                        raise ValueError(
                            "filtered precision release position tolerance must be below 0.10m"
                        )
                    if (
                        self.placement_precision_filtered_yaw_tolerance
                        >= math.radians(5.0)
                    ):
                        raise ValueError(
                            "filtered precision release yaw tolerance must be below 5 degrees"
                        )
                    if (
                        self.placement_precision_recenter_exit_lateral
                        >= self.placement_precision_recenter_trigger_lateral
                    ):
                        raise ValueError(
                            "precision recenter lateral exit must be tighter than trigger"
                        )
                    if (
                        self.placement_precision_recenter_exit_yaw
                        >= self.placement_precision_recenter_trigger_yaw
                    ):
                        raise ValueError(
                            "precision recenter yaw exit must be tighter than trigger"
                        )
                    if (
                        self.placement_precision_recenter_min_distance
                        >= self.placement_precision_recenter_max_distance
                    ):
                        raise ValueError(
                            "precision recenter minimum distance must be below maximum distance"
                        )

                mpc_enabled = self.placement_mpc_enabled > 0.0
                if mpc_enabled:
                    required_mpc = (
                        self.placement_mpc_prediction_dt,
                        self.placement_mpc_update_period,
                        self.placement_mpc_forward_max_speed,
                        self.placement_mpc_reverse_max_speed,
                        self.placement_mpc_steering_limit,
                        self.placement_mpc_geometry_speed_floor,
                        self.placement_mpc_trust_radius,
                        self.placement_mpc_weight_lateral,
                        self.placement_mpc_weight_yaw,
                        self.placement_mpc_terminal_scale,
                        self.placement_mpc_stall_seconds,
                        self.placement_mpc_progress_yaw_weight_m_per_rad,
                        self.placement_mpc_progress_regression_tolerance_m,
                        self.placement_release_prebrake_position_tolerance,
                        self.placement_release_prebrake_yaw_tolerance,
                        self.placement_release_prebrake_hold_seconds,
                        self.placement_release_candidate_position_tolerance,
                        self.placement_release_candidate_yaw_tolerance,
                        self.placement_release_abort_position_tolerance,
                        self.placement_release_abort_yaw_tolerance,
                        self.placement_release_evidence_seconds,
                        self.placement_release_commit_min_seconds,
                        self.placement_release_commit_max_seconds,
                        self.placement_release_commit_position_tolerance,
                        self.placement_release_commit_yaw_tolerance,
                    )
                    if self.placement_mpc_horizon_steps < 4 or not all(
                        value > 0.0 for value in required_mpc
                    ):
                        raise ValueError(
                            "V9.3.0 MPC/release parameters must be positive when enabled"
                        )
                    if self.transport_path_wheelbase <= 0.0:
                        raise ValueError("V9.3.0 MPC requires transport_path_wheelbase")
                    if self.placement_mpc_steering_limit > self.place_steering_limit:
                        raise ValueError("MPC steering limit cannot exceed place_steering_limit")
                    if not (
                        self.placement_release_candidate_position_tolerance
                        < self.placement_release_prebrake_position_tolerance
                        <= self.placement_release_abort_position_tolerance
                        <= 0.10
                    ):
                        raise ValueError(
                            "release pre-brake position envelope must contain the evidence gate"
                        )
                    if not (
                        self.placement_release_candidate_yaw_tolerance
                        < self.placement_release_prebrake_yaw_tolerance
                        <= self.placement_release_abort_yaw_tolerance
                        <= math.radians(5.0)
                    ):
                        raise ValueError(
                            "release pre-brake yaw envelope must contain the evidence gate"
                        )
                    if not (
                        self.placement_release_candidate_position_tolerance
                        < self.placement_release_commit_position_tolerance
                        <= self.placement_release_abort_position_tolerance
                        <= 0.10
                    ):
                        raise ValueError("release position hysteresis must stay inside 0.10m")
                    if not (
                        self.placement_release_candidate_yaw_tolerance
                        < self.placement_release_commit_yaw_tolerance
                        <= self.placement_release_abort_yaw_tolerance
                        <= math.radians(5.0)
                    ):
                        raise ValueError("release yaw hysteresis must stay inside 5 degrees")
                    if not 0.0 < self.placement_release_evidence_soft_decay <= 1.0:
                        raise ValueError("release evidence soft decay must be in (0,1]")
                    if (
                        self.placement_release_commit_min_seconds
                        >= self.placement_release_commit_max_seconds
                    ):
                        raise ValueError("release commit min time must be below max time")

        if self.placement_carried_observer_enabled > 0.0:
            if self.placement_carried_observer_sample_period <= 0.0:
                raise ValueError("carried observer sample period must be positive")
            if self.placement_carried_observer_min_samples < 2:
                raise ValueError("carried observer needs at least two VERIFY_LIFT samples")
            if self.placement_carried_observer_update_period <= 0.0:
                raise ValueError("carried observer update period must be positive")
            CarriedLoadObserverConfig(
                initial_position_sigma_m=self.placement_carried_observer_initial_position_sigma_m,
                initial_yaw_sigma_rad=self.placement_carried_observer_initial_yaw_sigma_rad,
                measurement_position_sigma_m=self.placement_carried_observer_measurement_position_sigma_m,
                measurement_yaw_sigma_rad=self.placement_carried_observer_measurement_yaw_sigma_rad,
                process_position_sigma_m=self.placement_carried_observer_process_position_sigma_m,
                process_yaw_sigma_rad=self.placement_carried_observer_process_yaw_sigma_rad,
                minimum_position_sigma_m=self.placement_carried_observer_minimum_position_sigma_m,
                minimum_yaw_sigma_rad=self.placement_carried_observer_minimum_yaw_sigma_rad,
                position_innovation_gate_m=self.placement_carried_observer_position_innovation_gate_m,
                yaw_innovation_gate_rad=self.placement_carried_observer_yaw_innovation_gate_rad,
                fast_alpha=self.placement_carried_observer_fast_alpha,
            ).validate()
            if self.placement_carried_observer_release_disagreement_position_m <= 0.0:
                raise ValueError("carried observer release disagreement position must be positive")
            if self.placement_carried_observer_release_disagreement_yaw_rad <= 0.0:
                raise ValueError("carried observer release disagreement yaw must be positive")

        if self.transport_runway_distance > 0.0:
            required_positive = (
                "transport_reposition_minimum_distance",
                "transport_reposition_maximum_distance",
                "transport_reposition_timeout",
                "transport_path_wheelbase",
                "transport_path_lookahead",
                "transport_path_handle_scale",
                "transport_path_minimum_speed",
                "transport_path_goal_yaw_tolerance",
                "transport_path_speed_gain",
                "transport_path_steering_speed_floor",
            )
            for name in required_positive:
                if getattr(self, name) <= 0.0:
                    raise ValueError(
                        f"{name} must be positive for smooth transport"
                    )
            if self.transport_reposition_speed >= 0.0:
                raise ValueError(
                    "transport_reposition_speed must be negative"
                )
            if self.transport_reposition_unwind_speed >= 0.0:
                raise ValueError(
                    "transport_reposition_unwind_speed must be negative"
                )
            if (
                self.transport_reposition_minimum_distance
                > self.transport_reposition_maximum_distance
            ):
                raise ValueError(
                    "transport reposition minimum cannot exceed maximum"
                )
            if not 0.15 <= self.transport_path_handle_scale <= 0.75:
                raise ValueError(
                    "transport_path_handle_scale must be in [0.15, 0.75]"
                )
            if self.transport_path_samples < 21:
                raise ValueError(
                    "transport_path_samples must be at least 21"
                )
            if self.terminal_approach_corridor_enabled > 0.0:
                if self.terminal_approach_corridor_samples < 21:
                    raise ValueError("terminal_approach_corridor_samples must be at least 21")
                if self.terminal_approach_corridor_standoff_distance <= 0.0:
                    raise ValueError("terminal approach corridor requires positive standoff")
                if self.terminal_approach_corridor_capture_distance <= 0.0:
                    raise ValueError("terminal approach corridor requires positive capture distance")
                if self.terminal_approach_corridor_yaw_tolerance <= 0.0:
                    raise ValueError("terminal approach corridor requires positive yaw tolerance")
                if self.terminal_approach_corridor_max_speed <= 0.0:
                    raise ValueError("terminal approach corridor requires positive max speed")
                if not 0.0 <= self.terminal_approach_corridor_minimum_speed <= self.terminal_approach_corridor_max_speed:
                    raise ValueError("terminal approach corridor minimum speed exceeds maximum")
                if self.terminal_approach_corridor_lookahead <= 0.0:
                    raise ValueError("terminal approach corridor requires positive lookahead")
                if not 0.15 <= self.terminal_approach_corridor_handle_scale <= 0.75:
                    raise ValueError("terminal_approach_corridor_handle_scale must be in [0.15, 0.75]")
                if self.terminal_approach_corridor_timeout <= 0.0:
                    raise ValueError("terminal approach corridor requires positive timeout")
                if self.terminal_approach_corridor_replan_position_m <= 0.0:
                    raise ValueError("terminal approach corridor requires positive replan position threshold")
                if self.terminal_approach_corridor_replan_yaw_rad <= 0.0:
                    raise ValueError("terminal approach corridor requires positive replan yaw threshold")
                # V9.3.1 axis-entry is opt-in by setting entry_distance above
                # the final standoff.  Legacy V9.3.0/H1 configs leave the new
                # fields at zero and retain the validated single-corridor path.
                axis_entry_enabled = (
                    self.terminal_approach_corridor_entry_distance
                    > self.terminal_approach_corridor_standoff_distance + 1e-6
                )
                if axis_entry_enabled:
                    if self.terminal_approach_corridor_entry_capture_distance <= 0.0:
                        raise ValueError("terminal corridor entry capture distance must be positive")
                    if self.terminal_approach_corridor_entry_lateral_tolerance <= 0.0:
                        raise ValueError("terminal corridor entry lateral tolerance must be positive")
                    if self.terminal_approach_corridor_entry_yaw_tolerance <= 0.0:
                        raise ValueError("terminal corridor entry yaw tolerance must be positive")
                    if self.terminal_approach_corridor_entry_hold_seconds < 0.0:
                        raise ValueError("terminal corridor entry hold must be non-negative")
                    if self.terminal_approach_corridor_axis_lateral_gain <= 0.0:
                        raise ValueError("terminal corridor axis lateral gain must be positive")
                    if self.terminal_approach_corridor_axis_yaw_gain < 0.0:
                        raise ValueError("terminal corridor axis yaw gain must be non-negative")
                    if self.terminal_approach_corridor_axis_lookahead <= 0.0:
                        raise ValueError("terminal corridor axis lookahead must be positive")
                    if self.terminal_approach_corridor_axis_steering_limit <= 0.0:
                        raise ValueError("terminal corridor axis steering limit must be positive")
                    if self.terminal_approach_corridor_axis_speed_gain <= 0.0:
                        raise ValueError("terminal corridor axis speed gain must be positive")
                    if self.terminal_approach_corridor_axis_abort_lateral <= self.terminal_approach_corridor_entry_lateral_tolerance:
                        raise ValueError("terminal corridor axis lateral abort must exceed entry tolerance")
                    if self.terminal_approach_corridor_axis_abort_yaw <= self.terminal_approach_corridor_entry_yaw_tolerance:
                        raise ValueError("terminal corridor axis yaw abort must exceed entry tolerance")
                if self.terminal_approach_corridor_rolling_enabled > 0.5:
                    required_rolling_positive = (
                        "terminal_approach_corridor_rolling_handoff_distance",
                        "terminal_approach_corridor_rolling_timeout_handoff_distance",
                        "terminal_approach_corridor_rolling_handoff_seconds",
                        "terminal_approach_corridor_rolling_lateral_gain",
                        "terminal_approach_corridor_rolling_lookahead",
                        "terminal_approach_corridor_rolling_steering_limit",
                        "terminal_approach_corridor_rolling_speed_gain",
                        "terminal_approach_corridor_rolling_lateral_band",
                        "terminal_approach_corridor_rolling_yaw_band",
                        "terminal_approach_corridor_rolling_min_geometry_scale",
                    )
                    for name in required_rolling_positive:
                        if getattr(self, name) <= 0.0:
                            raise ValueError(f"{name} must be positive for rolling terminal corridor")
                    if self.terminal_approach_corridor_rolling_yaw_gain < 0.0:
                        raise ValueError("rolling terminal yaw gain must be non-negative")
                    if (
                        self.terminal_approach_corridor_rolling_handoff_distance
                        >= self.terminal_approach_corridor_rolling_timeout_handoff_distance
                    ):
                        raise ValueError("rolling timeout handoff distance must exceed normal handoff distance")
                    if not 0.0 < self.terminal_approach_corridor_rolling_min_geometry_scale <= 1.0:
                        raise ValueError("rolling minimum geometry scale must be in (0,1]")
                    if self.terminal_visual_binding_enabled > 0.5:
                        if self.terminal_visual_required_distance <= 0.0:
                            raise ValueError("terminal visual binding requires positive distance")
                        if not 0.0 < self.terminal_visual_unlocked_speed_scale <= 1.0:
                            raise ValueError("terminal visual unlocked speed scale must be in (0,1]")
                        if not 0.0 < self.terminal_visual_stale_speed_scale <= 1.0:
                            raise ValueError("terminal visual stale speed scale must be in (0,1]")
                        if self.terminal_visual_stale_seconds <= 0.0:
                            raise ValueError("terminal visual binding requires positive stale seconds")
            if self.transport_path_minimum_speed > self.transport_max_speed:
                raise ValueError(
                    "transport path minimum speed cannot exceed maximum"
                )
            if not 0.0 < self.transport_path_steering_speed_floor <= 1.0:
                raise ValueError(
                    "transport_path_steering_speed_floor must be in (0, 1]"
                )
            if self.transport_path_steering_slowdown_gain < 0.0:
                raise ValueError(
                    "transport_path_steering_slowdown_gain must be non-negative"
                )

        if self.progress_timeout > 0.0 and self.progress_improvement <= 0.0:
            raise ValueError(
                "progress_improvement must be positive when progress checks are enabled"
            )


@dataclass(frozen=True)
class PickupDecision:
    action: ForkliftAction
    state: PickupState
    state_elapsed: float
    status: str
    error: DockingError | None = None
    failure_reason: str | None = None
    recovery_count: int = 0
    progress_score: float | None = None
    recovery_reason: str | None = None
    placement_recovery_count: int = 0
    placement_recovery_reason: str | None = None
    placement_recovery_target_distance: float | None = None
    placement_recovery_required_runway: float | None = None
    placement_recovery_live_runway: float | None = None
    placement_recovery_reentry_ready: bool | None = None
    placement_guard_brake_count: int = 0
    placement_precision_settle_active: bool = False
    placement_precision_settle_elapsed: float | None = None
    placement_precision_phase: str | None = None
    placement_precision_filtered_position_error_m: float | None = None
    placement_precision_filtered_yaw_error_deg: float | None = None
    placement_precision_filtered_command_longitudinal_m: float | None = None
    placement_precision_recenter_cycle_count: int = 0
    placement_precision_recenter_travel_m: float = 0.0
    placement_precision_direction_switch_count: int = 0
    placement_mpc_mode: str | None = None
    placement_mpc_cost: float | None = None
    placement_mpc_predicted_position_error_m: float | None = None
    placement_mpc_predicted_yaw_error_deg: float | None = None
    placement_release_evidence_seconds: float = 0.0
    placement_release_commit_active: bool = False
    placement_release_block_observer_frames: int = 0
    placement_carried_observer_active: bool = False
    placement_carried_observer_sample_count: int = 0
    placement_carried_observer_position_std_m: float = 0.0
    placement_carried_observer_yaw_std_deg: float = 0.0
    placement_carried_observer_update_count: int = 0
    placement_carried_observer_rejection_count: int = 0
    placement_carried_observer_disagreement_position_m: float = 0.0
    placement_carried_observer_disagreement_yaw_deg: float = 0.0
    placement_mpc_model_id_sample_count: int = 0
    placement_mpc_model_id_longitudinal_rmse_m: float = 0.0
    placement_mpc_model_id_lateral_rmse_m: float = 0.0
    placement_mpc_model_id_yaw_rmse_deg: float = 0.0
    placement_terminal_elapsed: float | None = None
    placement_terminal_budget_remaining: float | None = None
    placement_terminal_budget_exhausted: bool = False
    terminal_corridor_mode: str | None = None
    terminal_corridor_rolling_frame_count: int = 0
    terminal_corridor_handoff_count: int = 0
    terminal_corridor_timeout_handoff_count: int = 0
    terminal_corridor_reacquire_count: int = 0
    terminal_corridor_visual_coarse_frame_count: int = 0
    terminal_corridor_visual_stale_frame_count: int = 0
    terminal_vision_authority: str | None = None
    carried_load_visual_authority: str | None = None
    carried_load_visual_source: str | None = None
    carried_load_visual_stale_seconds: float | None = None
    carried_load_visual_locked: bool = False
    carried_load_visual_rgb_update_count: int = 0
    carried_load_visual_guide_reject_count: int = 0
    carried_load_visual_handoff_seed_count: int = 0
    carried_load_yaw_anchor_used: bool = False
    carried_load_yaw_anchor_sample_count: int = 0
    carried_load_yaw_anchor_spread_deg: float | None = None
    carried_load_yaw_anchor_delta_from_latest_deg: float | None = None
    carried_load_yaw_anchor_world_yaw_deg: float | None = None
    carried_load_yaw_anchor_seed_sigma_deg: float | None = None
    carried_load_translation_evidence_stale_seconds: float | None = None
    carried_load_yaw_evidence_stale_seconds: float | None = None
    carried_load_yaw_evidence_source: str = "NONE"
    carried_load_motion_yaw_sigma_deg: float = 0.0
    carried_load_release_yaw_sigma_deg: float = 0.0
    carried_load_seed_provenance: str = "UNKNOWN"
    carried_load_seed_trusted_for_aggressive_risk: bool = False
    carried_load_seed_age_seconds: float | None = None
    carried_load_seed_confidence: float | None = None
    carried_load_seed_reprojection_error_px: float | None = None
    carried_load_seed_reason: str = "unknown"
    strict_release_risk_budget_mode: str = "ADDITIVE"
    strict_release_yaw_risk_budget_mode: str = "ADDITIVE"
    strict_release_center_yaw_anchor_active: bool = False
    strict_release_center_yaw_conflict_active: bool = False
    strict_release_center_yaw_current_jump_deg: float | None = None
    strict_release_center_yaw_conflict_count: int = 0
    strict_release_center_yaw_revalidation_count: int = 0
    strict_release_center_yaw_conflict_fallback_frame_count: int = 0
    strict_release_center_yaw_conflict_last_jump_deg: float | None = None
    strict_release_center_yaw_conflict_last_load_stale_seconds: float | None = None
    strict_release_certified: bool = False
    strict_release_certification_position_error_m: float | None = None
    strict_release_certification_yaw_error_deg: float | None = None
    strict_release_certification_target_source: str = "FAST"
    strict_release_certification_load_yaw_deg: float | None = None
    strict_release_certification_target_yaw_deg: float | None = None
    strict_release_position_margin_m: float = 0.0
    strict_release_yaw_margin_deg: float = 0.0
    strict_release_target_position_margin_m: float = 0.0
    strict_release_target_yaw_margin_deg: float = 0.0
    certified_basin_active: bool = False
    certified_basin_source: str = "NONE"
    certified_basin_age_seconds: float = 0.0
    certified_basin_consensus_evidence_seconds: float = 0.0
    certified_basin_enter_count: int = 0
    certified_basin_exit_count: int = 0
    certified_basin_strict_enter_count: int = 0
    certified_basin_consensus_enter_count: int = 0
    certified_basin_persisted_pass_count: int = 0
    strict_release_certification_blocker: str = "NONE"
    strict_release_certification_blocker_counts: dict[str, int] | None = None
    placement_target_raw_position_spread_m: float | None = None
    placement_target_raw_yaw_spread_deg: float | None = None
    placement_target_multiview_ready: bool = False
    placement_target_multiview_samples: int = 0
    placement_target_multiview_position_spread_m: float | None = None
    placement_target_multiview_yaw_spread_deg: float | None = None
    placement_target_fast_slow_position_disagreement_m: float | None = None
    placement_target_fast_slow_yaw_disagreement_deg: float | None = None
    release_witness_active: bool = False
    release_witness_age_seconds: float | None = None
    release_witness_position_drift_m: float = 0.0
    release_witness_yaw_drift_deg: float = 0.0
    release_witness_capture_count: int = 0
    release_witness_drift_abort_count: int = 0
    release_witness_instant_strict_gate_block_count: int = 0
    release_snapshot_active: bool = False
    placement_mpc_yaw_escrow_activation_count: int = 0
    placement_mpc_yaw_escrow_active: bool = False
    placement_mpc_near_basin_escrow_activation_count: int = 0
    placement_mpc_near_basin_escrow_accepted_plan_count: int = 0
    placement_mpc_near_basin_escrow_active: bool = False
    placement_mpc_near_basin_last_deficit_improvement: float = 0.0
    terminal_load_reacquisition_update_count: int = 0
    terminal_load_reacquisition_rejection_count: int = 0
    terminal_load_reacquisition_position_only_update_count: int = 0
    terminal_load_reacquisition_yaw_suppressed_count: int = 0
    terminal_load_reacquisition_yaw_authority_enabled: bool = True
    terminal_load_reacquisition_last_position_innovation_m: float = 0.0
    terminal_load_reacquisition_last_yaw_innovation_deg: float = 0.0
    terminal_load_reacquisition_last_measurement_yaw_deg: float | None = None
    terminal_load_reacquisition_last_posterior_yaw_deg: float | None = None
    placement_micro_primitive_search_count: int = 0
    placement_micro_primitive_activation_count: int = 0
    placement_micro_primitive_accepted_count: int = 0
    placement_micro_primitive_candidate_count: int = 0
    placement_micro_primitive_active: bool = False
    placement_micro_primitive_last_deficit_improvement: float = 0.0
    rigid_load_constraint_active: bool = False
    rigid_load_constraint_activation_count: int = 0
    rigid_load_constraint_total_active_seconds: float = 0.0
    placement_yaw_tail_reserve_search_count: int = 0
    placement_yaw_tail_reserve_activation_count: int = 0
    placement_yaw_tail_reserve_candidate_count: int = 0
    placement_strict_recovery_retention_search_count: int = 0
    placement_strict_recovery_retention_activation_count: int = 0
    placement_strict_recovery_retention_candidate_count: int = 0
    placement_strict_recovery_retention_active: bool = False
    placement_strict_recovery_retention_last_deficit_improvement: float = 0.0
    placement_strict_recovery_final_settle_count: int = 0
    placement_strict_recovery_final_settle_consumed: bool = False
    placement_fresh_rgb_yaw_closure_search_count: int = 0
    placement_fresh_rgb_yaw_closure_activation_count: int = 0
    placement_fresh_rgb_yaw_closure_candidate_count: int = 0
    placement_fresh_rgb_yaw_closure_active: bool = False
    placement_fresh_rgb_yaw_closure_phase: str = "IDLE"
    placement_fresh_rgb_yaw_closure_feedback_reject_count: int = 0
    placement_fresh_rgb_yaw_closure_last_predicted_yaw_improvement_deg: float = 0.0
    placement_fresh_rgb_yaw_closure_last_measured_yaw_improvement_deg: float = 0.0
    placement_fresh_rgb_yaw_closure_post_motion_rgb_updates: int = 0
    placement_fresh_rgb_yaw_closure_total_candidate_count: int = 0
    placement_fresh_rgb_yaw_closure_no_candidate_search_count: int = 0
    placement_post_closure_basin_ownership_active: bool = False
    placement_post_closure_basin_ownership_entry_count: int = 0
    placement_post_closure_mpc_veto_count: int = 0
    placement_post_closure_mpc_safe_allow_count: int = 0
    placement_post_closure_certification_handoff_count: int = 0
    placement_post_closure_continuation_search_count: int = 0
    placement_post_closure_continuation_activation_count: int = 0
    placement_post_closure_last_certification_position_m: float | None = None
    placement_post_closure_last_certification_yaw_deg: float | None = None
    placement_post_closure_gray_zone_hold_count: int = 0
    placement_certification_basin_closure_search_count: int = 0
    placement_certification_basin_closure_activation_count: int = 0
    placement_certification_basin_closure_candidate_count: int = 0
    placement_certification_basin_closure_total_candidate_count: int = 0
    placement_certification_basin_closure_no_candidate_search_count: int = 0
    placement_certification_basin_closure_feedback_reject_count: int = 0
    placement_certification_basin_closure_phase: str = "IDLE"
    placement_certification_basin_closure_last_predicted_deficit_improvement: float = 0.0
    placement_certification_basin_closure_last_measured_deficit_improvement: float = 0.0
    placement_certification_basin_closure_last_current_deficit: float = 0.0
    placement_certification_basin_closure_last_predicted_deficit: float = 0.0
    placement_certification_basin_closure_post_motion_rgb_updates: int = 0
    placement_certification_basin_closure_supervisor_retry_suppressed_count: int = 0
    placement_certification_basin_closure_full_pose_search_count: int = 0
    placement_certification_basin_closure_legacy_error_space_search_count: int = 0
    placement_certification_basin_closure_last_certification_longitudinal_m: float | None = None
    placement_certification_basin_closure_last_certification_lateral_m: float | None = None
    placement_position_blocker_recenter_search_count: int = 0
    placement_position_blocker_recenter_activation_count: int = 0
    placement_position_blocker_recenter_candidate_count: int = 0
    placement_position_blocker_recenter_total_candidate_count: int = 0
    placement_position_blocker_recenter_return_replan_count: int = 0
    placement_position_blocker_recenter_return_candidate_count: int = 0
    placement_position_blocker_recenter_feedback_reject_count: int = 0
    placement_position_blocker_recenter_abort_count: int = 0
    placement_position_blocker_recenter_midpoint_replan_fail_count: int = 0
    placement_position_blocker_recenter_phase: str = "IDLE"
    placement_position_blocker_recenter_mid_rgb_updates: int = 0
    placement_position_blocker_recenter_final_rgb_updates: int = 0
    placement_position_blocker_recenter_last_predicted_effective_position_m: float = 0.0
    placement_position_blocker_recenter_last_predicted_effective_yaw_deg: float = 0.0
    placement_position_blocker_recenter_last_measured_effective_position_m: float = 0.0
    placement_position_blocker_recenter_last_measured_effective_yaw_deg: float = 0.0
    placement_position_blocker_recenter_last_measured_position_improvement_m: float = 0.0
    # V9.3.12-R4-E4 actuator-closure telemetry.
    placement_position_blocker_recenter_presteer_timeout_count: int = 0
    placement_position_blocker_recenter_last_effective_steering_deg: float = 0.0
    placement_position_blocker_recenter_last_departure_odometry_m: float = 0.0
    placement_position_blocker_recenter_last_return_odometry_m: float = 0.0
    placement_position_blocker_recenter_midpoint_position_deviation_m: float = 0.0
    placement_position_blocker_recenter_midpoint_yaw_deviation_deg: float = 0.0
    # V9.3.12-R4-E5 full-pose / guaranteed rollback telemetry.
    placement_position_blocker_recenter_full_pose_model_active: bool = False
    placement_position_blocker_recenter_full_pose_search_count: int = 0
    placement_position_blocker_recenter_full_pose_return_replan_count: int = 0
    placement_position_blocker_recenter_legacy_error_space_search_count: int = 0
    placement_position_blocker_recenter_rollback_count: int = 0
    placement_position_blocker_recenter_rollback_success_count: int = 0
    placement_position_blocker_recenter_rollback_failure_count: int = 0
    placement_position_blocker_recenter_rollback_target_odometry_m: float = 0.0
    placement_position_blocker_recenter_last_rollback_odometry_m: float = 0.0
    placement_position_blocker_recenter_last_return_unwind_odometry_m: float = 0.0
    placement_position_blocker_recenter_rollback_rgb_updates: int = 0
    placement_position_blocker_recenter_rollback_reason: str = ""
    placement_position_blocker_recenter_yaw_handoff_ready: bool = False
    placement_position_blocker_recenter_yaw_handoff_count: int = 0
    # V9.3.12-R4-E6 topology/evidence telemetry.
    placement_position_blocker_recenter_retrace_candidate_reject_count: int = 0
    placement_position_blocker_recenter_topology_candidate_count: int = 0
    placement_position_blocker_recenter_final_evidence_consistent_rgb_updates: int = 0
    placement_position_blocker_recenter_final_live_strict_attempt_count: int = 0
    placement_position_blocker_recenter_final_evidence_timeout_count: int = 0
    terminal_corridor_timeout_handoff_guard_reject_count: int = 0
    # V9.3.5 ownership + belief telemetry.
    terminal_ownership_mpc_entered: bool = False
    terminal_ownership_direct_mpc_count: int = 0
    terminal_ownership_forced_mpc_count: int = 0
    terminal_ownership_align_timeout_count: int = 0
    terminal_ownership_reacquire_count: int = 0
    terminal_ownership_total_align_seconds: float = 0.0
    terminal_ownership_max_align_seconds: float = 0.0
    carried_load_belief_mode: str = "UNAVAILABLE"
    carried_load_belief_position_sigma_m: float = 0.0
    carried_load_belief_yaw_sigma_deg: float = 0.0
    carried_load_belief_distance_since_visual_m: float = 0.0
    carried_load_belief_turn_since_visual_deg: float = 0.0
    carried_load_belief_transport_scaled_frames: int = 0
    corridor_error: AxisCorridorError | None = None
    placement_error: DockingError | None = None

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "state": self.state.value,
            "state_elapsed": self.state_elapsed,
            "status": self.status,
            "failure_reason": self.failure_reason,
            "recovery_count": self.recovery_count,
            "progress_score": self.progress_score,
            "recovery_reason": self.recovery_reason,
            "placement_recovery_count": self.placement_recovery_count,
            "placement_recovery_reason": self.placement_recovery_reason,
            "placement_recovery_target_distance": self.placement_recovery_target_distance,
            "placement_recovery_required_runway": self.placement_recovery_required_runway,
            "placement_recovery_live_runway": self.placement_recovery_live_runway,
            "placement_recovery_reentry_ready": self.placement_recovery_reentry_ready,
            "placement_guard_brake_count": self.placement_guard_brake_count,
            "placement_precision_settle_active": self.placement_precision_settle_active,
            "placement_precision_settle_elapsed": self.placement_precision_settle_elapsed,
            "placement_precision_phase": self.placement_precision_phase,
            "placement_precision_filtered_position_error_m": (
                self.placement_precision_filtered_position_error_m
            ),
            "placement_precision_filtered_yaw_error_deg": (
                self.placement_precision_filtered_yaw_error_deg
            ),
            "placement_precision_filtered_command_longitudinal_m": (
                self.placement_precision_filtered_command_longitudinal_m
            ),
            "placement_precision_recenter_cycle_count": (
                self.placement_precision_recenter_cycle_count
            ),
            "placement_precision_recenter_travel_m": (
                self.placement_precision_recenter_travel_m
            ),
            "placement_precision_direction_switch_count": (
                self.placement_precision_direction_switch_count
            ),
            "placement_mpc_mode": self.placement_mpc_mode,
            "placement_mpc_cost": self.placement_mpc_cost,
            "placement_mpc_predicted_position_error_m": (
                self.placement_mpc_predicted_position_error_m
            ),
            "placement_mpc_predicted_yaw_error_deg": (
                self.placement_mpc_predicted_yaw_error_deg
            ),
            "placement_release_evidence_seconds": (
                self.placement_release_evidence_seconds
            ),
            "placement_release_commit_active": (
                self.placement_release_commit_active
            ),
            "placement_release_block_observer_frames": self.placement_release_block_observer_frames,
            "placement_carried_observer_active": (
                self.placement_carried_observer_active
            ),
            "placement_carried_observer_sample_count": (
                self.placement_carried_observer_sample_count
            ),
            "placement_carried_observer_position_std_m": (
                self.placement_carried_observer_position_std_m
            ),
            "placement_carried_observer_yaw_std_deg": (
                self.placement_carried_observer_yaw_std_deg
            ),
            "placement_carried_observer_update_count": self.placement_carried_observer_update_count,
            "placement_carried_observer_rejection_count": self.placement_carried_observer_rejection_count,
            "placement_carried_observer_disagreement_position_m": self.placement_carried_observer_disagreement_position_m,
            "placement_carried_observer_disagreement_yaw_deg": self.placement_carried_observer_disagreement_yaw_deg,
            "placement_mpc_model_id_sample_count": self.placement_mpc_model_id_sample_count,
            "placement_mpc_model_id_longitudinal_rmse_m": self.placement_mpc_model_id_longitudinal_rmse_m,
            "placement_mpc_model_id_lateral_rmse_m": self.placement_mpc_model_id_lateral_rmse_m,
            "placement_mpc_model_id_yaw_rmse_deg": self.placement_mpc_model_id_yaw_rmse_deg,
            "placement_terminal_elapsed": self.placement_terminal_elapsed,
            "placement_terminal_budget_remaining": self.placement_terminal_budget_remaining,
            "placement_terminal_budget_exhausted": self.placement_terminal_budget_exhausted,
            "terminal_corridor_mode": self.terminal_corridor_mode,
            "terminal_corridor_rolling_frame_count": self.terminal_corridor_rolling_frame_count,
            "terminal_corridor_handoff_count": self.terminal_corridor_handoff_count,
            "terminal_corridor_timeout_handoff_count": self.terminal_corridor_timeout_handoff_count,
            "terminal_corridor_reacquire_count": self.terminal_corridor_reacquire_count,
            "terminal_corridor_visual_coarse_frame_count": self.terminal_corridor_visual_coarse_frame_count,
            "terminal_corridor_visual_stale_frame_count": self.terminal_corridor_visual_stale_frame_count,
            "terminal_vision_authority": self.terminal_vision_authority,
            "carried_load_visual_authority": self.carried_load_visual_authority,
            "carried_load_visual_source": self.carried_load_visual_source,
            "carried_load_visual_stale_seconds": self.carried_load_visual_stale_seconds,
            "carried_load_visual_locked": self.carried_load_visual_locked,
            "carried_load_visual_rgb_update_count": self.carried_load_visual_rgb_update_count,
            "carried_load_visual_guide_reject_count": self.carried_load_visual_guide_reject_count,
            "carried_load_visual_handoff_seed_count": self.carried_load_visual_handoff_seed_count,
            "carried_load_yaw_anchor_used": self.carried_load_yaw_anchor_used,
            "carried_load_yaw_anchor_sample_count": self.carried_load_yaw_anchor_sample_count,
            "carried_load_yaw_anchor_spread_deg": self.carried_load_yaw_anchor_spread_deg,
            "carried_load_yaw_anchor_delta_from_latest_deg": self.carried_load_yaw_anchor_delta_from_latest_deg,
            "carried_load_yaw_anchor_world_yaw_deg": self.carried_load_yaw_anchor_world_yaw_deg,
            "carried_load_yaw_anchor_seed_sigma_deg": self.carried_load_yaw_anchor_seed_sigma_deg,
            "carried_load_translation_evidence_stale_seconds": self.carried_load_translation_evidence_stale_seconds,
            "carried_load_yaw_evidence_stale_seconds": self.carried_load_yaw_evidence_stale_seconds,
            "carried_load_yaw_evidence_source": self.carried_load_yaw_evidence_source,
            "carried_load_motion_yaw_sigma_deg": self.carried_load_motion_yaw_sigma_deg,
            "carried_load_release_yaw_sigma_deg": self.carried_load_release_yaw_sigma_deg,
            "carried_load_seed_provenance": self.carried_load_seed_provenance,
            "carried_load_seed_trusted_for_aggressive_risk": self.carried_load_seed_trusted_for_aggressive_risk,
            "carried_load_seed_age_seconds": self.carried_load_seed_age_seconds,
            "carried_load_seed_confidence": self.carried_load_seed_confidence,
            "carried_load_seed_reprojection_error_px": self.carried_load_seed_reprojection_error_px,
            "carried_load_seed_reason": self.carried_load_seed_reason,
            "strict_release_risk_budget_mode": self.strict_release_risk_budget_mode,
            "strict_release_yaw_risk_budget_mode": self.strict_release_yaw_risk_budget_mode,
            "strict_release_center_yaw_anchor_active": self.strict_release_center_yaw_anchor_active,
            "strict_release_center_yaw_conflict_active": self.strict_release_center_yaw_conflict_active,
            "strict_release_center_yaw_current_jump_deg": self.strict_release_center_yaw_current_jump_deg,
            "strict_release_center_yaw_conflict_count": self.strict_release_center_yaw_conflict_count,
            "strict_release_center_yaw_revalidation_count": self.strict_release_center_yaw_revalidation_count,
            "strict_release_center_yaw_conflict_fallback_frame_count": self.strict_release_center_yaw_conflict_fallback_frame_count,
            "strict_release_center_yaw_conflict_last_jump_deg": self.strict_release_center_yaw_conflict_last_jump_deg,
            "strict_release_center_yaw_conflict_last_load_stale_seconds": self.strict_release_center_yaw_conflict_last_load_stale_seconds,
            "strict_release_certified": self.strict_release_certified,
            "strict_release_certification_position_error_m": self.strict_release_certification_position_error_m,
            "strict_release_certification_yaw_error_deg": self.strict_release_certification_yaw_error_deg,
            "strict_release_certification_target_source": self.strict_release_certification_target_source,
            "strict_release_certification_load_yaw_deg": self.strict_release_certification_load_yaw_deg,
            "strict_release_certification_target_yaw_deg": self.strict_release_certification_target_yaw_deg,
            "strict_release_position_margin_m": self.strict_release_position_margin_m,
            "strict_release_yaw_margin_deg": self.strict_release_yaw_margin_deg,
            "strict_release_target_position_margin_m": self.strict_release_target_position_margin_m,
            "strict_release_target_yaw_margin_deg": self.strict_release_target_yaw_margin_deg,
            "certified_basin_active": self.certified_basin_active,
            "certified_basin_source": self.certified_basin_source,
            "certified_basin_age_seconds": self.certified_basin_age_seconds,
            "certified_basin_consensus_evidence_seconds": self.certified_basin_consensus_evidence_seconds,
            "certified_basin_enter_count": self.certified_basin_enter_count,
            "certified_basin_exit_count": self.certified_basin_exit_count,
            "certified_basin_strict_enter_count": self.certified_basin_strict_enter_count,
            "certified_basin_consensus_enter_count": self.certified_basin_consensus_enter_count,
            "certified_basin_persisted_pass_count": self.certified_basin_persisted_pass_count,
            "strict_release_certification_blocker": self.strict_release_certification_blocker,
            "strict_release_certification_blocker_counts": self.strict_release_certification_blocker_counts,
            "placement_target_raw_position_spread_m": self.placement_target_raw_position_spread_m,
            "placement_target_raw_yaw_spread_deg": self.placement_target_raw_yaw_spread_deg,
            "placement_target_multiview_ready": self.placement_target_multiview_ready,
            "placement_target_multiview_samples": self.placement_target_multiview_samples,
            "placement_target_multiview_position_spread_m": self.placement_target_multiview_position_spread_m,
            "placement_target_multiview_yaw_spread_deg": self.placement_target_multiview_yaw_spread_deg,
            "placement_target_fast_slow_position_disagreement_m": self.placement_target_fast_slow_position_disagreement_m,
            "placement_target_fast_slow_yaw_disagreement_deg": self.placement_target_fast_slow_yaw_disagreement_deg,
            "release_witness_active": self.release_witness_active,
            "release_witness_age_seconds": self.release_witness_age_seconds,
            "release_witness_position_drift_m": self.release_witness_position_drift_m,
            "release_witness_yaw_drift_deg": self.release_witness_yaw_drift_deg,
            "release_witness_capture_count": self.release_witness_capture_count,
            "release_witness_drift_abort_count": self.release_witness_drift_abort_count,
            "release_witness_instant_strict_gate_block_count": self.release_witness_instant_strict_gate_block_count,
            "release_snapshot_active": self.release_snapshot_active,
            "placement_mpc_yaw_escrow_activation_count": self.placement_mpc_yaw_escrow_activation_count,
            "placement_mpc_yaw_escrow_active": self.placement_mpc_yaw_escrow_active,
            "placement_mpc_near_basin_escrow_activation_count": self.placement_mpc_near_basin_escrow_activation_count,
            "placement_mpc_near_basin_escrow_accepted_plan_count": self.placement_mpc_near_basin_escrow_accepted_plan_count,
            "placement_mpc_near_basin_escrow_active": self.placement_mpc_near_basin_escrow_active,
            "placement_mpc_near_basin_last_deficit_improvement": self.placement_mpc_near_basin_last_deficit_improvement,
            "terminal_load_reacquisition_update_count": self.terminal_load_reacquisition_update_count,
            "terminal_load_reacquisition_rejection_count": self.terminal_load_reacquisition_rejection_count,
            "terminal_load_reacquisition_position_only_update_count": self.terminal_load_reacquisition_position_only_update_count,
            "terminal_load_reacquisition_yaw_suppressed_count": self.terminal_load_reacquisition_yaw_suppressed_count,
            "terminal_load_reacquisition_yaw_authority_enabled": self.terminal_load_reacquisition_yaw_authority_enabled,
            "terminal_load_reacquisition_last_position_innovation_m": self.terminal_load_reacquisition_last_position_innovation_m,
            "terminal_load_reacquisition_last_yaw_innovation_deg": self.terminal_load_reacquisition_last_yaw_innovation_deg,
            "terminal_load_reacquisition_last_measurement_yaw_deg": self.terminal_load_reacquisition_last_measurement_yaw_deg,
            "terminal_load_reacquisition_last_posterior_yaw_deg": self.terminal_load_reacquisition_last_posterior_yaw_deg,
            "placement_micro_primitive_search_count": self.placement_micro_primitive_search_count,
            "placement_micro_primitive_activation_count": self.placement_micro_primitive_activation_count,
            "placement_micro_primitive_accepted_count": self.placement_micro_primitive_accepted_count,
            "placement_micro_primitive_candidate_count": self.placement_micro_primitive_candidate_count,
            "placement_micro_primitive_active": self.placement_micro_primitive_active,
            "placement_micro_primitive_last_deficit_improvement": self.placement_micro_primitive_last_deficit_improvement,
            "rigid_load_constraint_active": self.rigid_load_constraint_active,
            "rigid_load_constraint_activation_count": self.rigid_load_constraint_activation_count,
            "rigid_load_constraint_total_active_seconds": self.rigid_load_constraint_total_active_seconds,
            "placement_yaw_tail_reserve_search_count": self.placement_yaw_tail_reserve_search_count,
            "placement_yaw_tail_reserve_activation_count": self.placement_yaw_tail_reserve_activation_count,
            "placement_yaw_tail_reserve_candidate_count": self.placement_yaw_tail_reserve_candidate_count,
            "placement_strict_recovery_retention_search_count": self.placement_strict_recovery_retention_search_count,
            "placement_strict_recovery_retention_activation_count": self.placement_strict_recovery_retention_activation_count,
            "placement_strict_recovery_retention_candidate_count": self.placement_strict_recovery_retention_candidate_count,
            "placement_strict_recovery_retention_active": self.placement_strict_recovery_retention_active,
            "placement_strict_recovery_retention_last_deficit_improvement": self.placement_strict_recovery_retention_last_deficit_improvement,
            "placement_strict_recovery_final_settle_count": self.placement_strict_recovery_final_settle_count,
            "placement_strict_recovery_final_settle_consumed": self.placement_strict_recovery_final_settle_consumed,
            "placement_fresh_rgb_yaw_closure_search_count": self.placement_fresh_rgb_yaw_closure_search_count,
            "placement_fresh_rgb_yaw_closure_activation_count": self.placement_fresh_rgb_yaw_closure_activation_count,
            "placement_fresh_rgb_yaw_closure_candidate_count": self.placement_fresh_rgb_yaw_closure_candidate_count,
            "placement_fresh_rgb_yaw_closure_active": self.placement_fresh_rgb_yaw_closure_active,
            "placement_fresh_rgb_yaw_closure_phase": self.placement_fresh_rgb_yaw_closure_phase,
            "placement_fresh_rgb_yaw_closure_feedback_reject_count": self.placement_fresh_rgb_yaw_closure_feedback_reject_count,
            "placement_fresh_rgb_yaw_closure_last_predicted_yaw_improvement_deg": self.placement_fresh_rgb_yaw_closure_last_predicted_yaw_improvement_deg,
            "placement_fresh_rgb_yaw_closure_last_measured_yaw_improvement_deg": self.placement_fresh_rgb_yaw_closure_last_measured_yaw_improvement_deg,
            "placement_fresh_rgb_yaw_closure_post_motion_rgb_updates": self.placement_fresh_rgb_yaw_closure_post_motion_rgb_updates,
            "placement_fresh_rgb_yaw_closure_total_candidate_count": self.placement_fresh_rgb_yaw_closure_total_candidate_count,
            "placement_fresh_rgb_yaw_closure_no_candidate_search_count": self.placement_fresh_rgb_yaw_closure_no_candidate_search_count,
            "placement_post_closure_basin_ownership_active": self.placement_post_closure_basin_ownership_active,
            "placement_post_closure_basin_ownership_entry_count": self.placement_post_closure_basin_ownership_entry_count,
            "placement_post_closure_mpc_veto_count": self.placement_post_closure_mpc_veto_count,
            "placement_post_closure_mpc_safe_allow_count": self.placement_post_closure_mpc_safe_allow_count,
            "placement_post_closure_certification_handoff_count": self.placement_post_closure_certification_handoff_count,
            "placement_post_closure_continuation_search_count": self.placement_post_closure_continuation_search_count,
            "placement_post_closure_continuation_activation_count": self.placement_post_closure_continuation_activation_count,
            "placement_post_closure_last_certification_position_m": self.placement_post_closure_last_certification_position_m,
            "placement_post_closure_last_certification_yaw_deg": self.placement_post_closure_last_certification_yaw_deg,
            "placement_post_closure_gray_zone_hold_count": self.placement_post_closure_gray_zone_hold_count,
            "placement_certification_basin_closure_search_count": self.placement_certification_basin_closure_search_count,
            "placement_certification_basin_closure_activation_count": self.placement_certification_basin_closure_activation_count,
            "placement_certification_basin_closure_candidate_count": self.placement_certification_basin_closure_candidate_count,
            "placement_certification_basin_closure_total_candidate_count": self.placement_certification_basin_closure_total_candidate_count,
            "placement_certification_basin_closure_no_candidate_search_count": self.placement_certification_basin_closure_no_candidate_search_count,
            "placement_certification_basin_closure_feedback_reject_count": self.placement_certification_basin_closure_feedback_reject_count,
            "placement_certification_basin_closure_phase": self.placement_certification_basin_closure_phase,
            "placement_certification_basin_closure_last_predicted_deficit_improvement": self.placement_certification_basin_closure_last_predicted_deficit_improvement,
            "placement_certification_basin_closure_last_measured_deficit_improvement": self.placement_certification_basin_closure_last_measured_deficit_improvement,
            "placement_certification_basin_closure_last_current_deficit": self.placement_certification_basin_closure_last_current_deficit,
            "placement_certification_basin_closure_last_predicted_deficit": self.placement_certification_basin_closure_last_predicted_deficit,
            "placement_certification_basin_closure_post_motion_rgb_updates": self.placement_certification_basin_closure_post_motion_rgb_updates,
            "placement_certification_basin_closure_supervisor_retry_suppressed_count": self.placement_certification_basin_closure_supervisor_retry_suppressed_count,
            "placement_certification_basin_closure_last_certification_longitudinal_m": self.placement_certification_basin_closure_last_certification_longitudinal_m,
            "placement_certification_basin_closure_last_certification_lateral_m": self.placement_certification_basin_closure_last_certification_lateral_m,
            "placement_position_blocker_recenter_search_count": self.placement_position_blocker_recenter_search_count,
            "placement_position_blocker_recenter_activation_count": self.placement_position_blocker_recenter_activation_count,
            "placement_position_blocker_recenter_candidate_count": self.placement_position_blocker_recenter_candidate_count,
            "placement_position_blocker_recenter_total_candidate_count": self.placement_position_blocker_recenter_total_candidate_count,
            "placement_position_blocker_recenter_return_replan_count": self.placement_position_blocker_recenter_return_replan_count,
            "placement_position_blocker_recenter_return_candidate_count": self.placement_position_blocker_recenter_return_candidate_count,
            "placement_position_blocker_recenter_feedback_reject_count": self.placement_position_blocker_recenter_feedback_reject_count,
            "placement_position_blocker_recenter_abort_count": self.placement_position_blocker_recenter_abort_count,
            "placement_position_blocker_recenter_midpoint_replan_fail_count": self.placement_position_blocker_recenter_midpoint_replan_fail_count,
            "placement_position_blocker_recenter_phase": self.placement_position_blocker_recenter_phase,
            "placement_position_blocker_recenter_mid_rgb_updates": self.placement_position_blocker_recenter_mid_rgb_updates,
            "placement_position_blocker_recenter_final_rgb_updates": self.placement_position_blocker_recenter_final_rgb_updates,
            "placement_position_blocker_recenter_last_predicted_effective_position_m": self.placement_position_blocker_recenter_last_predicted_effective_position_m,
            "placement_position_blocker_recenter_last_predicted_effective_yaw_deg": self.placement_position_blocker_recenter_last_predicted_effective_yaw_deg,
            "placement_position_blocker_recenter_last_measured_effective_position_m": self.placement_position_blocker_recenter_last_measured_effective_position_m,
            "placement_position_blocker_recenter_last_measured_effective_yaw_deg": self.placement_position_blocker_recenter_last_measured_effective_yaw_deg,
            "placement_position_blocker_recenter_last_measured_position_improvement_m": self.placement_position_blocker_recenter_last_measured_position_improvement_m,
            "placement_position_blocker_recenter_presteer_timeout_count": self.placement_position_blocker_recenter_presteer_timeout_count,
            "placement_position_blocker_recenter_last_effective_steering_deg": self.placement_position_blocker_recenter_last_effective_steering_deg,
            "placement_position_blocker_recenter_last_departure_odometry_m": self.placement_position_blocker_recenter_last_departure_odometry_m,
            "placement_position_blocker_recenter_last_return_odometry_m": self.placement_position_blocker_recenter_last_return_odometry_m,
            "placement_position_blocker_recenter_midpoint_position_deviation_m": self.placement_position_blocker_recenter_midpoint_position_deviation_m,
            "placement_position_blocker_recenter_midpoint_yaw_deviation_deg": self.placement_position_blocker_recenter_midpoint_yaw_deviation_deg,
            "placement_position_blocker_recenter_full_pose_model_active": self.placement_position_blocker_recenter_full_pose_model_active,
            "placement_position_blocker_recenter_full_pose_search_count": self.placement_position_blocker_recenter_full_pose_search_count,
            "placement_position_blocker_recenter_full_pose_return_replan_count": self.placement_position_blocker_recenter_full_pose_return_replan_count,
            "placement_position_blocker_recenter_legacy_error_space_search_count": self.placement_position_blocker_recenter_legacy_error_space_search_count,
            "placement_position_blocker_recenter_rollback_count": self.placement_position_blocker_recenter_rollback_count,
            "placement_position_blocker_recenter_rollback_success_count": self.placement_position_blocker_recenter_rollback_success_count,
            "placement_position_blocker_recenter_rollback_failure_count": self.placement_position_blocker_recenter_rollback_failure_count,
            "placement_position_blocker_recenter_rollback_target_odometry_m": self.placement_position_blocker_recenter_rollback_target_odometry_m,
            "placement_position_blocker_recenter_last_rollback_odometry_m": self.placement_position_blocker_recenter_last_rollback_odometry_m,
            "placement_position_blocker_recenter_last_return_unwind_odometry_m": self.placement_position_blocker_recenter_last_return_unwind_odometry_m,
            "placement_position_blocker_recenter_rollback_rgb_updates": self.placement_position_blocker_recenter_rollback_rgb_updates,
            "placement_position_blocker_recenter_rollback_reason": self.placement_position_blocker_recenter_rollback_reason,
            "placement_position_blocker_recenter_yaw_handoff_ready": self.placement_position_blocker_recenter_yaw_handoff_ready,
            "placement_position_blocker_recenter_yaw_handoff_count": self.placement_position_blocker_recenter_yaw_handoff_count,
            "placement_position_blocker_recenter_retrace_candidate_reject_count": self.placement_position_blocker_recenter_retrace_candidate_reject_count,
            "placement_position_blocker_recenter_topology_candidate_count": self.placement_position_blocker_recenter_topology_candidate_count,
            "placement_position_blocker_recenter_final_evidence_consistent_rgb_updates": self.placement_position_blocker_recenter_final_evidence_consistent_rgb_updates,
            "placement_position_blocker_recenter_final_live_strict_attempt_count": self.placement_position_blocker_recenter_final_live_strict_attempt_count,
            "placement_position_blocker_recenter_final_evidence_timeout_count": self.placement_position_blocker_recenter_final_evidence_timeout_count,
            "terminal_corridor_timeout_handoff_guard_reject_count": self.terminal_corridor_timeout_handoff_guard_reject_count,
            "terminal_ownership_mpc_entered": self.terminal_ownership_mpc_entered,
            "terminal_ownership_direct_mpc_count": self.terminal_ownership_direct_mpc_count,
            "terminal_ownership_forced_mpc_count": self.terminal_ownership_forced_mpc_count,
            "terminal_ownership_align_timeout_count": self.terminal_ownership_align_timeout_count,
            "terminal_ownership_reacquire_count": self.terminal_ownership_reacquire_count,
            "terminal_ownership_total_align_seconds": self.terminal_ownership_total_align_seconds,
            "terminal_ownership_max_align_seconds": self.terminal_ownership_max_align_seconds,
            "carried_load_belief_mode": self.carried_load_belief_mode,
            "carried_load_belief_position_sigma_m": self.carried_load_belief_position_sigma_m,
            "carried_load_belief_yaw_sigma_deg": self.carried_load_belief_yaw_sigma_deg,
            "carried_load_belief_distance_since_visual_m": self.carried_load_belief_distance_since_visual_m,
            "carried_load_belief_turn_since_visual_deg": self.carried_load_belief_turn_since_visual_deg,
            "carried_load_belief_transport_scaled_frames": self.carried_load_belief_transport_scaled_frames,
            "action": self.action.to_dict(),
        }
        if self.error is not None:
            result["docking_error"] = {
                "longitudinal": self.error.longitudinal,
                "lateral": self.error.lateral,
                "distance": self.error.distance,
                "heading": self.error.heading,
                "yaw": self.error.yaw,
            }
        if self.placement_error is not None:
            result["placement_error"] = {
                "longitudinal": self.placement_error.longitudinal,
                "lateral": self.placement_error.lateral,
                "distance": self.placement_error.distance,
                "heading": self.placement_error.heading,
                "yaw": self.placement_error.yaw,
            }
        if self.corridor_error is not None:
            result["fork_corridor_error"] = {
                "near_reference": self.corridor_error.near_reference,
                "far_reference": self.corridor_error.far_reference,
                "near_lateral": self.corridor_error.near_lateral,
                "far_lateral": self.corridor_error.far_lateral,
                "maximum_abs_lateral": (
                    self.corridor_error.maximum_abs_lateral
                ),
            }
        return result


class PickupStateMachine:
    """Approach, rolling alignment, insertion, lift and retreat baseline."""

    _RECOVERABLE_STATES = {
        PickupState.APPROACH,
        PickupState.ALIGN,
        PickupState.INSERT,
    }

    def __init__(
        self,
        *,
        parameters: PickupParameters,
        docking_controller: DockingController,
    ) -> None:
        self.parameters = parameters
        self.controller = docking_controller
        self.state = PickupState.LOWER_FORK
        self._state_enter_time = 0.0
        self._retreat_start_xy: tuple[float, float] | None = None
        self._recovery_start_xy: tuple[float, float] | None = None
        self._recovery_motion_start_time: float | None = None
        self._recovery_centered_since: float | None = None
        self._recovery_count = 0
        self._recovery_reason: str | None = None
        self._alignment_condition_since: float | None = None
        self._progress_state: PickupState | None = None
        self._best_progress_score: float | None = None
        self._last_progress_time = 0.0
        self._placement_condition_since: float | None = None
        self._placement_condition_mode: str | None = None
        self._placement_best_progress_score: float | None = None
        self._placement_last_progress_time = 0.0
        self._placement_recovery_count = 0
        self._placement_recovery_reason: str | None = None
        self._placement_recovery_start_xy: tuple[float, float] | None = None
        self._placement_recovery_target_distance = 0.0
        self._placement_recovery_required_runway = 0.0
        self._placement_recovery_live_runway: float | None = None
        self._placement_recovery_reentry_ready: bool | None = None
        self._placement_guard_hold_since: float | None = None
        self._placement_guard_brake_used = False
        self._placement_guard_brake_count = 0
        self._placement_operational_enter_time: float | None = None
        self._placement_precision_settle_best: float | None = None
        self._placement_precision_settle_last_improve_time: float | None = None
        self._placement_precision_settle_frame_count = 0
        self._placement_precision_settle_exit_count = 0
        self._placement_precision_forward_frame_count = 0
        self._placement_precision_reverse_frame_count = 0
        self._placement_precision_hold_frame_count = 0
        self._placement_precision_reentry_count = 0
        self._placement_precision_entry_since: float | None = None
        self._placement_precision_best_score: float | None = None
        self._placement_precision_best_distance: float | None = None
        self._placement_precision_last_progress_time: float | None = None
        # V9.3.0 filtered terminal state and nonholonomic micro-recenter.
        self._placement_precision_filtered_error: DockingError | None = None
        self._placement_precision_filtered_command_longitudinal: float | None = None
        self._placement_precision_direction: int = 0
        self._placement_precision_direction_switch_count = 0
        self._placement_precision_phase = "CLOSE"
        self._placement_precision_recenter_start_xy: tuple[float, float] | None = None
        self._placement_precision_recenter_start_time: float | None = None
        self._placement_precision_recenter_cycle_count = 0
        self._placement_precision_recenter_frame_count = 0
        self._placement_precision_recenter_travel_m = 0.0
        self._placement_precision_rejoin_start_time: float | None = None
        # V9.3.0 dual-track probabilistic carried-load observer state.
        self._carried_load_pose_samples: list[Pose3D] = []
        self._carried_load_pose_last_sample_time: float | None = None
        self._carried_load_pose_last_update_time: float | None = None
        self._carried_load_observer: ProbabilisticCarriedLoadObserver | None = None
        self._carried_load_pose_in_base: Pose3D | None = None
        self._carried_load_fast_pose_in_base: Pose3D | None = None
        self._carried_load_pose_position_std_m = 0.0
        self._carried_load_pose_yaw_std_deg = 0.0
        self._carried_load_observer_update_count = 0
        self._carried_load_observer_rejection_count = 0
        self._carried_load_observer_disagreement_position_m = 0.0
        self._carried_load_observer_disagreement_yaw_deg = 0.0

        # V9.3.0 receding-horizon MPC and release commit telemetry/state.
        self._terminal_mpc: TerminalKinematicMPC | None = None
        self._placement_mpc_last_solve_time: float | None = None
        self._placement_mpc_last_plan: TerminalMPCPlan | None = None
        self._placement_mpc_last_speed = 0.0
        self._placement_mpc_last_steering = 0.0
        self._placement_mpc_solve_count = 0
        self._placement_mpc_fallback_count = 0
        self._placement_mpc_infeasible_solve_count = 0
        self._placement_mpc_regression_reject_solve_count = 0
        self._placement_mpc_model_id_sample_count = 0
        self._placement_mpc_model_id_longitudinal_sq_sum = 0.0
        self._placement_mpc_model_id_lateral_sq_sum = 0.0
        self._placement_mpc_model_id_yaw_sq_sum = 0.0
        self._placement_mpc_pending_prediction: tuple[float, float, float, float] | None = None
        self._placement_release_evidence_seconds = 0.0
        self._placement_release_last_update_time: float | None = None
        self._placement_release_commit_start_time: float | None = None
        self._placement_release_prebrake_since: float | None = None
        self._placement_release_hard_violation_since: float | None = None
        self._placement_release_prebrake_count = 0
        self._placement_release_prebrake_abort_count = 0
        self._placement_release_candidate_count = 0
        self._placement_release_commit_count = 0
        self._placement_release_commit_abort_count = 0
        self._placement_release_block_position_frames = 0
        self._placement_release_block_yaw_frames = 0
        self._placement_release_block_speed_frames = 0
        self._placement_release_block_vision_frames = 0
        self._placement_release_block_observer_frames = 0
        self._release_supervisor: ReleaseDecisionSupervisor | None = None
        self._release_supervisor_last_intent_count = 0
        self._release_supervisor_last_intent_abort_count = 0
        self._release_supervisor_last_settle_timeout_count = 0
        self._placement_terminal_start_time: float | None = None
        self._placement_terminal_budget_exhausted = False
        self._placement_lower_start_world_xy: tuple[float, float] | None = None
        self._placement_retreat_start_xy: tuple[float, float] | None = None
        self._placed_pallet_world_pose: tuple[float, float, float] | None = None
        self._transport_reposition_start_xy: tuple[float, float] | None = None
        self._transport_path: TransportPath | None = None
        self._transport_path_progress_index = 0
        self._transport_goal_world: Pose3D | None = None
        self._terminal_corridor_last_replan_time: float | None = None
        self._terminal_corridor_phase = "ENTRY"
        self._terminal_corridor_entry_since: float | None = None
        self._terminal_corridor_entry_replan_count = 0
        self._terminal_corridor_axis_frame_count = 0
        self._terminal_corridor_axis_reset_count = 0
        self._terminal_corridor_rolling_frame_count = 0
        self._terminal_corridor_handoff_count = 0
        self._terminal_corridor_timeout_handoff_count = 0
        self._terminal_corridor_reacquire_count = 0
        self._terminal_corridor_visual_coarse_frame_count = 0
        self._terminal_corridor_visual_stale_frame_count = 0
        self._terminal_corridor_last_handoff_distance = None
        self._terminal_corridor_last_handoff_lateral = None
        self._terminal_corridor_last_handoff_yaw_deg = None
        self._terminal_visual_authority = "UNKNOWN"
        self._pickup_visual_authority = "UNKNOWN"
        self._pickup_visual_source = "global_pose"
        self._pickup_visual_stale_seconds = float("inf")
        self._pickup_visual_last_accepted_confidence = None
        self._pickup_visual_last_accepted_reprojection_error_px = None
        self._pickup_visual_last_accepted_confidence: float | None = None
        self._pickup_visual_last_accepted_reprojection_error_px: float | None = None
        self._carried_load_visual_authority_locked = False
        self._carried_load_visual_lock_count = 0
        self._carried_load_visual_rgb_update_count = 0
        self._carried_load_visual_guide_reject_count = 0
        self._carried_load_visual_rigid_prediction_count = 0
        self._carried_load_visual_last_rgb_time: float | None = None
        self._carried_load_visual_handoff_pose: Pose3D | None = None
        self._carried_load_visual_handoff_measurement_time: float | None = None
        self._carried_load_visual_handoff_last_accepted_confidence: float | None = None
        self._carried_load_visual_handoff_last_accepted_reprojection_error_px: float | None = None
        self._carried_load_yaw_anchor: LateInsertYawAnchor | None = None
        self._carried_load_yaw_anchor_estimate: YawAnchorEstimate | None = None
        self._carried_load_yaw_anchor_used = False
        self._carried_load_yaw_anchor_delta_from_latest_deg: float | None = None
        self._carried_load_yaw_last_evidence_time: float | None = None
        self._carried_load_yaw_evidence_source = "NONE"
        self._carried_load_yaw_anchor_seed_sigma_rad: float | None = None
        self._carried_load_seed_provenance = LoadSeedProvenance.UNKNOWN.value
        self._carried_load_seed_trusted_for_aggressive_risk = False
        self._carried_load_seed_age_seconds = float("inf")
        self._carried_load_seed_confidence: float | None = None
        self._carried_load_seed_reprojection_error_px: float | None = None
        self._carried_load_seed_reason = "uninitialized"
        self._carried_load_visual_handoff_seed_count = 0
        self._carried_load_visual_handoff_fallback_seed_count = 0
        self._strict_release_certification_pass_count = 0
        self._strict_release_certification_reject_count = 0
        self._strict_release_certification_last_position_margin_m = 0.0
        self._strict_release_certification_last_yaw_margin_deg = 0.0
        self._strict_release_certification_last_target_position_margin_m = 0.0
        self._strict_release_certification_last_target_yaw_margin_deg = 0.0
        self._strict_release_certification_last_result = False
        self._strict_release_certification_last_instant_result = False
        self._strict_release_certification_last_blocker = "NONE"
        self._strict_release_risk_budget_rss_active = False
        self._strict_release_yaw_rss_active = False
        self._strict_release_certification_blocker_counts: dict[str, int] = {}
        self._certified_basin: CertifiedBasinLatch | None = None
        self._certified_basin_last_source = "NONE"
        self._certified_basin_last_age_seconds = 0.0
        self._placement_target_raw_position_spread_m: float | None = None
        self._placement_target_raw_yaw_spread_rad: float | None = None
        self._placement_certification_target_pose_in_base: Pose3D | None = None
        self._placement_release_center_yaw_target_pose_in_base: Pose3D | None = None
        self._strict_release_center_yaw_guard: ReleaseCenterYawConflictGuard | None = None
        self._strict_release_center_yaw_previous_world_yaw_rad: float | None = None
        self._strict_release_center_yaw_current_world_yaw_rad: float | None = None
        self._strict_release_center_yaw_current_jump_rad: float | None = None
        self._strict_release_center_yaw_conflict_active = False
        self._strict_release_center_yaw_conflict_candidate_world_yaw_rad: float | None = None
        self._strict_release_center_yaw_conflict_candidate_since: float | None = None
        self._strict_release_center_yaw_conflict_count = 0
        self._strict_release_center_yaw_revalidation_count = 0
        self._strict_release_center_yaw_conflict_fallback_frame_count = 0
        self._strict_release_center_yaw_conflict_last_jump_rad: float | None = None
        self._strict_release_center_yaw_conflict_last_load_stale_seconds: float | None = None
        self._placement_target_multiview_ready = False
        self._placement_target_multiview_samples = 0
        self._placement_target_multiview_position_spread_m: float | None = None
        self._placement_target_multiview_yaw_spread_rad: float | None = None
        self._placement_target_fast_slow_position_disagreement_m: float | None = None
        self._placement_target_fast_slow_yaw_disagreement_rad: float | None = None
        self._strict_release_certification_last_error: DockingError | None = None
        self._release_certification_witness_error: DockingError | None = None
        self._release_certification_witness_time: float | None = None
        self._release_witness_position_drift_m = 0.0
        self._release_witness_yaw_drift_rad = 0.0
        self._release_witness_capture_count = 0
        self._release_witness_drift_abort_count = 0
        self._release_witness_instant_strict_gate_block_count = 0
        self._release_witness_drift_violation_active = False
        self._release_snapshot_error: DockingError | None = None
        self._placement_mpc_yaw_escrow_active_until: float | None = None
        self._placement_mpc_yaw_escrow_activation_count = 0
        self._near_basin_escrow: NearBasinFeasibilityEscrow | None = None
        # V9.3.12 strict-only release support + bounded local primitive state.
        self._terminal_micro_primitive_planner: TerminalMicroPrimitivePlanner | None = None
        self._terminal_micro_primitive_active: TerminalMicroPrimitive | None = None
        self._terminal_micro_primitive_end_time: float | None = None
        self._terminal_micro_primitive_last_deficit_improvement = 0.0
        self._yaw_tail_reserve_planner: TerminalYawTailReservePlanner | None = None
        self._strict_recovery_retention_planner: StrictRecoveryRetentionPlanner | None = None
        self._strict_recovery_retention_active: TerminalMicroPrimitive | None = None
        self._strict_recovery_retention_end_time: float | None = None
        self._strict_recovery_retention_last_deficit_improvement = 0.0
        self._strict_recovery_retention_final_settle_until: float | None = None
        self._strict_recovery_retention_final_settle_consumed = False
        self._strict_recovery_retention_final_settle_count = 0
        self._fresh_rgb_yaw_closure_planner: FreshRGBYawClosurePlanner | None = None
        self._fresh_rgb_yaw_closure_active: FreshRGBYawClosureSequence | None = None
        self._fresh_rgb_yaw_closure_phase = "IDLE"
        self._fresh_rgb_yaw_closure_end_time: float | None = None
        self._fresh_rgb_yaw_closure_post_settle_until: float | None = None
        self._fresh_rgb_yaw_closure_post_settle_deadline: float | None = None
        self._fresh_rgb_yaw_closure_post_settle_start_update_count = 0
        self._fresh_rgb_yaw_closure_post_motion_rgb_updates = 0
        self._fresh_rgb_yaw_closure_reference_abs_yaw_rad: float | None = None
        self._fresh_rgb_yaw_closure_last_predicted_yaw_improvement_rad = 0.0
        self._fresh_rgb_yaw_closure_last_measured_yaw_improvement_rad = 0.0
        self._fresh_rgb_yaw_closure_feedback_reject_count = 0
        self._fresh_rgb_yaw_closure_feedback_blocked = False
        self._post_closure_basin_guard: PostClosureBasinGuard | None = None
        self._post_closure_basin_ownership_active = False
        self._post_closure_basin_ownership_entry_count = 0
        self._post_closure_mpc_veto_count = 0
        self._post_closure_mpc_safe_allow_count = 0
        self._post_closure_certification_handoff_count = 0
        self._post_closure_continuation_search_count = 0
        self._post_closure_continuation_activation_count = 0
        self._post_closure_last_certification_position_m: float | None = None
        self._post_closure_last_certification_yaw_rad: float | None = None
        self._post_closure_gray_zone_hold_count = 0
        self._certification_basin_closure_planner: CertificationBasinClosurePlanner | None = None
        self._certification_basin_closure_active: CertificationBasinClosureSequence | None = None
        self._certification_basin_closure_phase = "IDLE"
        self._certification_basin_closure_leg_end_time: float | None = None
        self._certification_basin_closure_post_settle_until: float | None = None
        self._certification_basin_closure_post_settle_deadline: float | None = None
        self._certification_basin_closure_post_settle_start_update_count = 0
        self._certification_basin_closure_post_motion_rgb_updates = 0
        self._certification_basin_closure_reference_deficit: float | None = None
        self._certification_basin_closure_last_search_time: float | None = None
        self._certification_basin_closure_last_predicted_deficit_improvement = 0.0
        self._certification_basin_closure_last_measured_deficit_improvement = 0.0
        self._certification_basin_closure_last_current_deficit = 0.0
        self._certification_basin_closure_last_predicted_deficit = 0.0
        self._certification_basin_closure_feedback_reject_count = 0
        self._certification_basin_closure_feedback_blocked = False
        self._certification_basin_closure_supervisor_retry_suppressed_count = 0
        self._certification_basin_closure_last_certification_longitudinal_m: float | None = None
        self._certification_basin_closure_last_certification_lateral_m: float | None = None
        self._position_blocker_recenter_planner: PositionBlockerRecenterPlanner | None = None
        self._position_blocker_recenter_active: PositionBlockerRecenterPlan | None = None
        self._position_blocker_recenter_return_active: PositionBlockerReturnPlan | None = None
        self._position_blocker_recenter_completed_return_plan: PositionBlockerReturnPlan | None = None
        self._position_blocker_recenter_phase = "IDLE"
        self._position_blocker_recenter_leg_end_time: float | None = None
        self._position_blocker_recenter_mid_settle_until: float | None = None
        self._position_blocker_recenter_mid_settle_deadline: float | None = None
        self._position_blocker_recenter_mid_start_update_count = 0
        self._position_blocker_recenter_mid_rgb_updates = 0
        self._position_blocker_recenter_final_settle_until: float | None = None
        self._position_blocker_recenter_final_settle_deadline: float | None = None
        self._position_blocker_recenter_final_start_update_count = 0
        self._position_blocker_recenter_final_rgb_updates = 0
        # V9.3.12-R4-E6: bounded post-return evidence lease.  The E5 trace
        # adjudicated exactly when target FAST/SLOW disagreement peaked, then
        # released ownership to ordinary MPC.  E6 waits for fresh, internally
        # consistent target/load evidence before refreshing strict certification.
        self._position_blocker_recenter_final_evidence_start_time: float | None = None
        self._position_blocker_recenter_final_evidence_deadline: float | None = None
        self._position_blocker_recenter_final_evidence_consistent_rgb_updates = 0
        self._position_blocker_recenter_final_evidence_last_update_count = 0
        self._position_blocker_recenter_final_live_strict_attempt_count = 0
        self._position_blocker_recenter_final_evidence_timeout_count = 0
        self._position_blocker_recenter_reference_effective_position_m: float | None = None
        self._position_blocker_recenter_last_predicted_effective_position_m = 0.0
        self._position_blocker_recenter_last_predicted_effective_yaw_rad = 0.0
        self._position_blocker_recenter_last_measured_effective_position_m = 0.0
        self._position_blocker_recenter_last_measured_effective_yaw_rad = 0.0
        self._position_blocker_recenter_last_measured_position_improvement_m = 0.0
        self._position_blocker_recenter_feedback_reject_count = 0
        self._position_blocker_recenter_abort_count = 0
        self._position_blocker_recenter_feedback_blocked = False
        self._position_blocker_recenter_midpoint_replan_fail_count = 0
        self._position_blocker_recenter_last_search_time = None
        self._position_blocker_recenter_last_search_time: float | None = None
        self._position_blocker_recenter_presteer_start_time: float | None = None
        self._position_blocker_recenter_leg_start_time: float | None = None
        self._position_blocker_recenter_odom_last_x: float | None = None
        self._position_blocker_recenter_odom_last_y: float | None = None
        self._position_blocker_recenter_odom_distance_m = 0.0
        self._position_blocker_recenter_presteer_timeout_count = 0
        self._position_blocker_recenter_last_effective_steering_rad = 0.0
        self._position_blocker_recenter_last_departure_odometry_m = 0.0
        self._position_blocker_recenter_last_return_odometry_m = 0.0
        self._position_blocker_recenter_midpoint_position_deviation_m = 0.0
        self._position_blocker_recenter_midpoint_yaw_deviation_rad = 0.0
        # V9.3.12-R4-E5 full-pose / rollback telemetry.  Rollback retraces the
        # completed DEPART arc when fresh midpoint replanning cannot produce a
        # safe return.  Hard safety aborts still stop immediately.
        self._position_blocker_recenter_full_pose_model_active = False
        self._position_blocker_recenter_rollback_count = 0
        self._position_blocker_recenter_rollback_success_count = 0
        self._position_blocker_recenter_rollback_failure_count = 0
        self._position_blocker_recenter_rollback_target_odometry_m = 0.0
        self._position_blocker_recenter_last_rollback_odometry_m = 0.0
        self._position_blocker_recenter_return_unwind_target_odometry_m = 0.0
        self._position_blocker_recenter_last_return_unwind_odometry_m = 0.0
        self._position_blocker_recenter_pre_macro_filtered_position_m = 0.0
        self._position_blocker_recenter_pre_macro_filtered_yaw_rad = 0.0
        self._position_blocker_recenter_rollback_settle_until: float | None = None
        self._position_blocker_recenter_rollback_settle_deadline: float | None = None
        self._position_blocker_recenter_rollback_start_update_count = 0
        self._position_blocker_recenter_rollback_rgb_updates = 0
        self._position_blocker_recenter_rollback_reason = ""
        self._position_blocker_recenter_yaw_handoff_ready = False
        self._position_blocker_recenter_yaw_handoff_count = 0
        self._rigid_load_constraint_monitor: RigidLoadConstraintMonitor | None = None
        self._terminal_load_reacquisition_update_count = 0
        self._terminal_load_reacquisition_rejection_count = 0
        self._terminal_load_reacquisition_position_only_update_count = 0
        self._terminal_load_reacquisition_yaw_suppressed_count = 0
        self._terminal_load_reacquisition_last_position_innovation_m = 0.0
        self._terminal_load_reacquisition_last_yaw_innovation_deg = 0.0
        self._terminal_load_reacquisition_last_measurement_yaw_deg: float | None = None
        self._terminal_load_reacquisition_last_posterior_yaw_deg: float | None = None
        self._terminal_corridor_timeout_handoff_guard_reject_count = 0
        # V9.3.5 terminal ownership telemetry/state.
        self._terminal_ownership_supervisor: TerminalOwnershipSupervisor | None = None
        self._terminal_ownership_direct_mpc_count = 0
        self._terminal_ownership_forced_mpc_count = 0
        self._terminal_ownership_align_timeout_count = 0
        self._terminal_ownership_reacquire_count = 0
        self._terminal_ownership_mpc_entered = False
        self._terminal_ownership_total_align_seconds = 0.0
        self._terminal_ownership_max_align_seconds = 0.0
        self._terminal_ownership_precision_violation_since: float | None = None
        self._placement_mpc_consecutive_infeasible_solve_count = 0
        # V9.3.5 carried-load belief overlay.
        self._carried_load_belief_mode = "UNAVAILABLE"
        self._carried_load_belief_last_vehicle_pose: Pose3D | None = None
        self._carried_load_belief_last_motion_time: float | None = None
        self._carried_load_belief_distance_since_visual_m = 0.0
        self._carried_load_belief_turn_since_visual_rad = 0.0
        self._carried_load_belief_reverse_since_visual_m = 0.0
        self._carried_load_belief_translation_distance_since_visual_m = 0.0
        self._carried_load_belief_translation_turn_since_visual_rad = 0.0
        self._carried_load_belief_translation_reverse_since_visual_m = 0.0
        self._carried_load_belief_extra_position_sigma_m = 0.0
        self._carried_load_belief_extra_yaw_sigma_rad = 0.0
        self._carried_load_belief_transport_scaled_frames = 0
        self.failure_reason: str | None = None

    def reset(self, sim_time: float = 0.0) -> None:
        self.state = PickupState.LOWER_FORK
        self._state_enter_time = float(sim_time)
        self._retreat_start_xy = None
        self._recovery_start_xy = None
        self._recovery_motion_start_time = None
        self._recovery_centered_since = None
        self._recovery_count = 0
        self._recovery_reason = None
        self._alignment_condition_since = None
        self._placement_condition_since = None
        self._placement_condition_mode = None
        self._placement_best_progress_score = None
        self._placement_last_progress_time = float(sim_time)
        self._placement_recovery_count = 0
        self._placement_recovery_reason = None
        self._placement_recovery_start_xy = None
        self._placement_recovery_target_distance = 0.0
        self._placement_recovery_required_runway = 0.0
        self._placement_recovery_live_runway = None
        self._placement_recovery_reentry_ready = None
        self._placement_guard_hold_since = None
        self._placement_guard_brake_used = False
        self._placement_guard_brake_count = 0
        self._placement_operational_enter_time = None
        self._placement_precision_settle_best = None
        self._placement_precision_settle_last_improve_time = None
        self._placement_precision_settle_frame_count = 0
        self._placement_precision_settle_exit_count = 0
        self._placement_precision_forward_frame_count = 0
        self._placement_precision_reverse_frame_count = 0
        self._placement_precision_hold_frame_count = 0
        self._placement_precision_reentry_count = 0
        self._placement_precision_entry_since = None
        self._placement_precision_best_score = None
        self._placement_precision_best_distance = None
        self._placement_precision_last_progress_time = None
        self._placement_precision_filtered_error = None
        self._placement_precision_filtered_command_longitudinal = None
        self._placement_precision_direction = 0
        self._placement_precision_direction_switch_count = 0
        self._placement_precision_phase = "CLOSE"
        self._placement_precision_recenter_start_xy = None
        self._placement_precision_recenter_start_time = None
        self._placement_precision_recenter_cycle_count = 0
        self._placement_precision_recenter_frame_count = 0
        self._placement_precision_recenter_travel_m = 0.0
        self._placement_precision_rejoin_start_time = None
        self._carried_load_pose_samples = []
        self._carried_load_pose_last_sample_time = None
        self._carried_load_pose_last_update_time = None
        self._carried_load_observer = None
        self._carried_load_pose_in_base = None
        self._carried_load_fast_pose_in_base = None
        self._carried_load_pose_position_std_m = 0.0
        self._carried_load_pose_yaw_std_deg = 0.0
        self._carried_load_observer_update_count = 0
        self._carried_load_observer_rejection_count = 0
        self._carried_load_observer_disagreement_position_m = 0.0
        self._carried_load_observer_disagreement_yaw_deg = 0.0
        self._terminal_mpc = None
        self._placement_mpc_last_solve_time = None
        self._placement_mpc_last_plan = None
        self._placement_mpc_last_speed = 0.0
        self._placement_mpc_last_steering = 0.0
        self._placement_mpc_solve_count = 0
        self._placement_mpc_fallback_count = 0
        self._placement_mpc_infeasible_solve_count = 0
        self._placement_mpc_regression_reject_solve_count = 0
        self._placement_mpc_model_id_sample_count = 0
        self._placement_mpc_model_id_longitudinal_sq_sum = 0.0
        self._placement_mpc_model_id_lateral_sq_sum = 0.0
        self._placement_mpc_model_id_yaw_sq_sum = 0.0
        self._placement_mpc_pending_prediction = None
        self._placement_release_evidence_seconds = 0.0
        self._placement_release_last_update_time = None
        self._placement_release_commit_start_time = None
        self._placement_release_prebrake_since = None
        self._placement_release_hard_violation_since = None
        self._placement_release_prebrake_count = 0
        self._placement_release_prebrake_abort_count = 0
        self._placement_release_candidate_count = 0
        self._placement_release_commit_count = 0
        self._placement_release_commit_abort_count = 0
        self._placement_release_block_position_frames = 0
        self._placement_release_block_yaw_frames = 0
        self._placement_release_block_speed_frames = 0
        self._placement_release_block_vision_frames = 0
        self._placement_release_block_observer_frames = 0
        self._release_supervisor = None
        self._release_supervisor_last_intent_count = 0
        self._release_supervisor_last_intent_abort_count = 0
        self._release_supervisor_last_settle_timeout_count = 0
        self._placement_terminal_start_time = None
        self._placement_terminal_budget_exhausted = False
        self._placement_lower_start_world_xy = None
        self._reset_progress(float(sim_time))
        self._placement_retreat_start_xy = None
        self._placed_pallet_world_pose = None
        self._transport_reposition_start_xy = None
        self._transport_path = None
        self._transport_path_progress_index = 0
        self._transport_goal_world = None
        self._terminal_corridor_last_replan_time: float | None = None
        self._terminal_corridor_phase = "ENTRY"
        self._terminal_corridor_entry_since = None
        self._terminal_corridor_entry_replan_count = 0
        self._terminal_corridor_axis_frame_count = 0
        self._terminal_corridor_axis_reset_count = 0
        self._terminal_corridor_rolling_frame_count = 0
        self._terminal_corridor_handoff_count = 0
        self._terminal_corridor_timeout_handoff_count = 0
        self._terminal_corridor_reacquire_count = 0
        self._terminal_corridor_visual_coarse_frame_count = 0
        self._terminal_corridor_visual_stale_frame_count = 0
        self._terminal_corridor_last_handoff_distance = None
        self._terminal_corridor_last_handoff_lateral = None
        self._terminal_corridor_last_handoff_yaw_deg = None
        self._terminal_visual_authority = "UNKNOWN"
        self._pickup_visual_authority = "UNKNOWN"
        self._pickup_visual_source = "global_pose"
        self._pickup_visual_stale_seconds = float("inf")
        self._carried_load_visual_authority_locked = False
        self._carried_load_visual_lock_count = 0
        self._carried_load_visual_rgb_update_count = 0
        self._carried_load_visual_guide_reject_count = 0
        self._carried_load_visual_rigid_prediction_count = 0
        self._carried_load_visual_last_rgb_time = None
        self._carried_load_visual_handoff_pose = None
        self._carried_load_visual_handoff_measurement_time = None
        self._carried_load_visual_handoff_last_accepted_confidence = None
        self._carried_load_visual_handoff_last_accepted_reprojection_error_px = None
        self._carried_load_yaw_anchor = None
        self._carried_load_yaw_anchor_estimate = None
        self._carried_load_yaw_anchor_used = False
        self._carried_load_yaw_anchor_delta_from_latest_deg = None
        # R4-F3 axis-separated evidence state. The legacy RGB timestamp remains
        # the translation-evidence clock; yaw has its own clock/source.
        self._carried_load_yaw_last_evidence_time: float | None = None
        self._carried_load_yaw_evidence_source = "NONE"
        self._carried_load_yaw_anchor_seed_sigma_rad: float | None = None
        self._carried_load_seed_provenance = LoadSeedProvenance.UNKNOWN.value
        self._carried_load_seed_trusted_for_aggressive_risk = False
        self._carried_load_seed_age_seconds = float("inf")
        self._carried_load_seed_confidence = None
        self._carried_load_seed_reprojection_error_px = None
        self._carried_load_seed_reason = "reset"
        self._carried_load_visual_handoff_seed_count = 0
        self._carried_load_visual_handoff_fallback_seed_count = 0
        self._strict_release_certification_pass_count = 0
        self._strict_release_certification_reject_count = 0
        self._strict_release_certification_last_position_margin_m = 0.0
        self._strict_release_certification_last_yaw_margin_deg = 0.0
        self._strict_release_certification_last_target_position_margin_m = 0.0
        self._strict_release_certification_last_target_yaw_margin_deg = 0.0
        self._strict_release_certification_last_result = False
        self._strict_release_certification_last_instant_result = False
        self._strict_release_certification_last_blocker = "NONE"
        self._strict_release_risk_budget_rss_active = False
        self._strict_release_yaw_rss_active = False
        self._strict_release_certification_blocker_counts: dict[str, int] = {}
        self._certified_basin: CertifiedBasinLatch | None = None
        self._certified_basin_last_source = "NONE"
        self._certified_basin_last_age_seconds = 0.0
        self._placement_target_raw_position_spread_m: float | None = None
        self._placement_target_raw_yaw_spread_rad: float | None = None
        self._placement_certification_target_pose_in_base: Pose3D | None = None
        self._placement_release_center_yaw_target_pose_in_base: Pose3D | None = None
        self._strict_release_center_yaw_guard: ReleaseCenterYawConflictGuard | None = None
        self._strict_release_center_yaw_previous_world_yaw_rad: float | None = None
        self._strict_release_center_yaw_current_world_yaw_rad: float | None = None
        self._strict_release_center_yaw_current_jump_rad: float | None = None
        self._strict_release_center_yaw_conflict_active = False
        self._strict_release_center_yaw_conflict_candidate_world_yaw_rad: float | None = None
        self._strict_release_center_yaw_conflict_candidate_since: float | None = None
        self._strict_release_center_yaw_conflict_count = 0
        self._strict_release_center_yaw_revalidation_count = 0
        self._strict_release_center_yaw_conflict_fallback_frame_count = 0
        self._strict_release_center_yaw_conflict_last_jump_rad: float | None = None
        self._strict_release_center_yaw_conflict_last_load_stale_seconds: float | None = None
        self._placement_target_multiview_ready = False
        self._placement_target_multiview_samples = 0
        self._placement_target_multiview_position_spread_m: float | None = None
        self._placement_target_multiview_yaw_spread_rad: float | None = None
        self._placement_target_fast_slow_position_disagreement_m: float | None = None
        self._placement_target_fast_slow_yaw_disagreement_rad: float | None = None
        self._strict_release_certification_last_error: DockingError | None = None
        self._release_certification_witness_error: DockingError | None = None
        self._release_certification_witness_time: float | None = None
        self._release_witness_position_drift_m = 0.0
        self._release_witness_yaw_drift_rad = 0.0
        self._release_witness_capture_count = 0
        self._release_witness_drift_abort_count = 0
        self._release_witness_instant_strict_gate_block_count = 0
        self._release_witness_drift_violation_active = False
        self._release_snapshot_error: DockingError | None = None
        self._placement_mpc_yaw_escrow_active_until: float | None = None
        self._placement_mpc_yaw_escrow_activation_count = 0
        self._near_basin_escrow: NearBasinFeasibilityEscrow | None = None
        # V9.3.12 strict-only release support + bounded local primitive state.
        self._terminal_micro_primitive_planner: TerminalMicroPrimitivePlanner | None = None
        self._terminal_micro_primitive_active: TerminalMicroPrimitive | None = None
        self._terminal_micro_primitive_end_time: float | None = None
        self._terminal_micro_primitive_last_deficit_improvement = 0.0
        self._yaw_tail_reserve_planner = None
        self._strict_recovery_retention_planner = None
        self._strict_recovery_retention_active = None
        self._strict_recovery_retention_end_time = None
        self._strict_recovery_retention_last_deficit_improvement = 0.0
        self._strict_recovery_retention_final_settle_until = None
        self._strict_recovery_retention_final_settle_consumed = False
        self._strict_recovery_retention_final_settle_count = 0
        self._fresh_rgb_yaw_closure_planner = None
        self._fresh_rgb_yaw_closure_active = None
        self._fresh_rgb_yaw_closure_phase = "IDLE"
        self._fresh_rgb_yaw_closure_end_time = None
        self._fresh_rgb_yaw_closure_post_settle_until = None
        self._fresh_rgb_yaw_closure_post_settle_deadline = None
        self._fresh_rgb_yaw_closure_post_settle_start_update_count = 0
        self._fresh_rgb_yaw_closure_post_motion_rgb_updates = 0
        self._fresh_rgb_yaw_closure_reference_abs_yaw_rad = None
        self._fresh_rgb_yaw_closure_last_predicted_yaw_improvement_rad = 0.0
        self._fresh_rgb_yaw_closure_last_measured_yaw_improvement_rad = 0.0
        self._fresh_rgb_yaw_closure_feedback_reject_count = 0
        self._fresh_rgb_yaw_closure_feedback_blocked = False
        self._post_closure_basin_guard = None
        self._post_closure_basin_ownership_active = False
        self._post_closure_basin_ownership_entry_count = 0
        self._post_closure_mpc_veto_count = 0
        self._post_closure_mpc_safe_allow_count = 0
        self._post_closure_certification_handoff_count = 0
        self._post_closure_continuation_search_count = 0
        self._post_closure_continuation_activation_count = 0
        self._post_closure_last_certification_position_m = None
        self._post_closure_last_certification_yaw_rad = None
        self._post_closure_gray_zone_hold_count = 0
        self._certification_basin_closure_planner = None
        self._certification_basin_closure_active = None
        self._certification_basin_closure_phase = "IDLE"
        self._certification_basin_closure_leg_end_time = None
        self._certification_basin_closure_post_settle_until = None
        self._certification_basin_closure_post_settle_deadline = None
        self._certification_basin_closure_post_settle_start_update_count = 0
        self._certification_basin_closure_post_motion_rgb_updates = 0
        self._certification_basin_closure_reference_deficit = None
        self._certification_basin_closure_last_search_time = None
        self._certification_basin_closure_last_predicted_deficit_improvement = 0.0
        self._certification_basin_closure_last_measured_deficit_improvement = 0.0
        self._certification_basin_closure_last_current_deficit = 0.0
        self._certification_basin_closure_last_predicted_deficit = 0.0
        self._certification_basin_closure_feedback_reject_count = 0
        self._certification_basin_closure_feedback_blocked = False
        self._certification_basin_closure_supervisor_retry_suppressed_count = 0
        self._certification_basin_closure_last_certification_longitudinal_m = None
        self._certification_basin_closure_last_certification_lateral_m = None
        self._position_blocker_recenter_planner = None
        self._position_blocker_recenter_active = None
        self._position_blocker_recenter_return_active = None
        self._position_blocker_recenter_completed_return_plan = None
        self._position_blocker_recenter_phase = "IDLE"
        self._position_blocker_recenter_leg_end_time = None
        self._position_blocker_recenter_mid_settle_until = None
        self._position_blocker_recenter_mid_settle_deadline = None
        self._position_blocker_recenter_mid_start_update_count = 0
        self._position_blocker_recenter_mid_rgb_updates = 0
        self._position_blocker_recenter_final_settle_until = None
        self._position_blocker_recenter_final_settle_deadline = None
        self._position_blocker_recenter_final_start_update_count = 0
        self._position_blocker_recenter_final_rgb_updates = 0
        self._position_blocker_recenter_final_evidence_start_time = None
        self._position_blocker_recenter_final_evidence_deadline = None
        self._position_blocker_recenter_final_evidence_consistent_rgb_updates = 0
        self._position_blocker_recenter_final_evidence_last_update_count = 0
        self._position_blocker_recenter_final_live_strict_attempt_count = 0
        self._position_blocker_recenter_final_evidence_timeout_count = 0
        self._position_blocker_recenter_reference_effective_position_m = None
        self._position_blocker_recenter_last_predicted_effective_position_m = 0.0
        self._position_blocker_recenter_last_predicted_effective_yaw_rad = 0.0
        self._position_blocker_recenter_last_measured_effective_position_m = 0.0
        self._position_blocker_recenter_last_measured_effective_yaw_rad = 0.0
        self._position_blocker_recenter_last_measured_position_improvement_m = 0.0
        self._position_blocker_recenter_feedback_reject_count = 0
        self._position_blocker_recenter_abort_count = 0
        self._position_blocker_recenter_feedback_blocked = False
        self._position_blocker_recenter_midpoint_replan_fail_count = 0
        self._position_blocker_recenter_presteer_start_time = None
        self._position_blocker_recenter_leg_start_time = None
        self._position_blocker_recenter_odom_last_x = None
        self._position_blocker_recenter_odom_last_y = None
        self._position_blocker_recenter_odom_distance_m = 0.0
        self._position_blocker_recenter_presteer_timeout_count = 0
        self._position_blocker_recenter_last_effective_steering_rad = 0.0
        self._position_blocker_recenter_last_departure_odometry_m = 0.0
        self._position_blocker_recenter_last_return_odometry_m = 0.0
        self._position_blocker_recenter_midpoint_position_deviation_m = 0.0
        self._position_blocker_recenter_midpoint_yaw_deviation_rad = 0.0
        # V9.3.12-R4-E5 full-pose / rollback telemetry.  Rollback retraces the
        # completed DEPART arc when fresh midpoint replanning cannot produce a
        # safe return.  Hard safety aborts still stop immediately.
        self._position_blocker_recenter_full_pose_model_active = False
        self._position_blocker_recenter_rollback_count = 0
        self._position_blocker_recenter_rollback_success_count = 0
        self._position_blocker_recenter_rollback_failure_count = 0
        self._position_blocker_recenter_rollback_target_odometry_m = 0.0
        self._position_blocker_recenter_last_rollback_odometry_m = 0.0
        self._position_blocker_recenter_return_unwind_target_odometry_m = 0.0
        self._position_blocker_recenter_last_return_unwind_odometry_m = 0.0
        self._position_blocker_recenter_pre_macro_filtered_position_m = 0.0
        self._position_blocker_recenter_pre_macro_filtered_yaw_rad = 0.0
        self._position_blocker_recenter_rollback_settle_until: float | None = None
        self._position_blocker_recenter_rollback_settle_deadline: float | None = None
        self._position_blocker_recenter_rollback_start_update_count = 0
        self._position_blocker_recenter_rollback_rgb_updates = 0
        self._position_blocker_recenter_rollback_reason = ""
        self._position_blocker_recenter_yaw_handoff_ready = False
        self._position_blocker_recenter_yaw_handoff_count = 0
        self._rigid_load_constraint_monitor = None
        self._terminal_load_reacquisition_update_count = 0
        self._terminal_load_reacquisition_rejection_count = 0
        self._terminal_load_reacquisition_position_only_update_count = 0
        self._terminal_load_reacquisition_yaw_suppressed_count = 0
        self._terminal_load_reacquisition_last_position_innovation_m = 0.0
        self._terminal_load_reacquisition_last_yaw_innovation_deg = 0.0
        self._terminal_load_reacquisition_last_measurement_yaw_deg: float | None = None
        self._terminal_load_reacquisition_last_posterior_yaw_deg: float | None = None
        self._terminal_corridor_timeout_handoff_guard_reject_count = 0
        self._terminal_ownership_supervisor = None
        self._terminal_ownership_direct_mpc_count = 0
        self._terminal_ownership_forced_mpc_count = 0
        self._terminal_ownership_align_timeout_count = 0
        self._terminal_ownership_reacquire_count = 0
        self._terminal_ownership_mpc_entered = False
        self._terminal_ownership_total_align_seconds = 0.0
        self._terminal_ownership_max_align_seconds = 0.0
        self._terminal_ownership_precision_violation_since = None
        self._placement_mpc_consecutive_infeasible_solve_count = 0
        self._carried_load_belief_mode = "UNAVAILABLE"
        self._carried_load_belief_last_vehicle_pose = None
        self._carried_load_belief_last_motion_time = None
        self._carried_load_belief_distance_since_visual_m = 0.0
        self._carried_load_belief_turn_since_visual_rad = 0.0
        self._carried_load_belief_reverse_since_visual_m = 0.0
        self._carried_load_belief_translation_distance_since_visual_m = 0.0
        self._carried_load_belief_translation_turn_since_visual_rad = 0.0
        self._carried_load_belief_translation_reverse_since_visual_m = 0.0
        self._carried_load_belief_extra_position_sigma_m = 0.0
        self._carried_load_belief_extra_yaw_sigma_rad = 0.0
        self._carried_load_belief_transport_scaled_frames = 0
        self.failure_reason = None

    @property
    def recovery_count(self) -> int:
        return self._recovery_count

    @property
    def placement_recovery_count(self) -> int:
        return self._placement_recovery_count

    @property
    def placement_guard_brake_count(self) -> int:
        return self._placement_guard_brake_count

    @property
    def placement_precision_settle_frame_count(self) -> int:
        return self._placement_precision_settle_frame_count

    @property
    def placement_precision_settle_exit_count(self) -> int:
        return self._placement_precision_settle_exit_count

    @property
    def placement_precision_forward_frame_count(self) -> int:
        return self._placement_precision_forward_frame_count

    @property
    def placement_precision_reverse_frame_count(self) -> int:
        return self._placement_precision_reverse_frame_count

    @property
    def placement_precision_hold_frame_count(self) -> int:
        return self._placement_precision_hold_frame_count

    @property
    def placement_precision_reentry_count(self) -> int:
        return self._placement_precision_reentry_count

    @property
    def terminal_corridor_entry_replan_count(self) -> int:
        return self._terminal_corridor_entry_replan_count

    @property
    def terminal_corridor_axis_frame_count(self) -> int:
        return self._terminal_corridor_axis_frame_count

    @property
    def terminal_corridor_axis_reset_count(self) -> int:
        return self._terminal_corridor_axis_reset_count

    @property
    def terminal_corridor_rolling_frame_count(self) -> int:
        return self._terminal_corridor_rolling_frame_count

    @property
    def terminal_corridor_handoff_count(self) -> int:
        return self._terminal_corridor_handoff_count

    @property
    def terminal_corridor_timeout_handoff_count(self) -> int:
        return self._terminal_corridor_timeout_handoff_count

    @property
    def terminal_corridor_reacquire_count(self) -> int:
        return self._terminal_corridor_reacquire_count

    @property
    def terminal_corridor_visual_coarse_frame_count(self) -> int:
        return self._terminal_corridor_visual_coarse_frame_count

    @property
    def terminal_corridor_visual_stale_frame_count(self) -> int:
        return self._terminal_corridor_visual_stale_frame_count

    @property
    def terminal_corridor_last_handoff_distance(self) -> float | None:
        return self._terminal_corridor_last_handoff_distance

    @property
    def terminal_corridor_last_handoff_lateral(self) -> float | None:
        return self._terminal_corridor_last_handoff_lateral

    @property
    def terminal_corridor_last_handoff_yaw_deg(self) -> float | None:
        return self._terminal_corridor_last_handoff_yaw_deg

    @property
    def placement_precision_recenter_cycle_count(self) -> int:
        return self._placement_precision_recenter_cycle_count

    @property
    def placement_precision_recenter_frame_count(self) -> int:
        return self._placement_precision_recenter_frame_count

    @property
    def placement_precision_direction_switch_count(self) -> int:
        return self._placement_precision_direction_switch_count

    @property
    def placement_carried_observer_active(self) -> bool:
        return self._carried_load_pose_in_base is not None

    @property
    def placement_carried_observer_sample_count(self) -> int:
        return len(self._carried_load_pose_samples)

    @property
    def placement_carried_observer_position_std_m(self) -> float:
        return float(self._carried_load_pose_position_std_m)

    @property
    def placement_carried_observer_yaw_std_deg(self) -> float:
        return float(self._carried_load_pose_yaw_std_deg)

    @property
    def placement_carried_observer_update_count(self) -> int:
        return int(self._carried_load_observer_update_count)

    @property
    def placement_carried_observer_rejection_count(self) -> int:
        return int(self._carried_load_observer_rejection_count)

    @property
    def placement_carried_observer_disagreement_position_m(self) -> float:
        return float(self._carried_load_observer_disagreement_position_m)

    @property
    def placement_carried_observer_disagreement_yaw_deg(self) -> float:
        return float(self._carried_load_observer_disagreement_yaw_deg)

    @property
    def placement_mpc_solve_count(self) -> int:
        return self._placement_mpc_solve_count

    @property
    def placement_mpc_fallback_count(self) -> int:
        return self._placement_mpc_fallback_count

    @property
    def placement_mpc_infeasible_solve_count(self) -> int:
        return self._placement_mpc_infeasible_solve_count

    @property
    def placement_mpc_regression_reject_solve_count(self) -> int:
        return self._placement_mpc_regression_reject_solve_count

    @property
    def placement_mpc_yaw_escrow_activation_count(self) -> int:
        return int(self._placement_mpc_yaw_escrow_activation_count)

    @property
    def strict_release_certification_blocker_counts(self) -> dict[str, int]:
        return dict(self._strict_release_certification_blocker_counts)

    @property
    def certified_basin_enter_count(self) -> int:
        return 0 if self._certified_basin is None else int(self._certified_basin.enter_count)

    @property
    def certified_basin_exit_count(self) -> int:
        return 0 if self._certified_basin is None else int(self._certified_basin.exit_count)

    @property
    def certified_basin_strict_enter_count(self) -> int:
        return 0 if self._certified_basin is None else int(self._certified_basin.strict_enter_count)

    @property
    def certified_basin_consensus_enter_count(self) -> int:
        return 0 if self._certified_basin is None else int(self._certified_basin.consensus_enter_count)

    @property
    def certified_basin_persisted_pass_count(self) -> int:
        return 0 if self._certified_basin is None else int(self._certified_basin.persisted_pass_count)

    @property
    def certified_basin_longest_active_seconds(self) -> float:
        return 0.0 if self._certified_basin is None else float(self._certified_basin.longest_active_seconds)

    @property
    def placement_mpc_near_basin_escrow_activation_count(self) -> int:
        return 0 if self._near_basin_escrow is None else int(self._near_basin_escrow.activation_count)

    @property
    def placement_mpc_near_basin_escrow_accepted_plan_count(self) -> int:
        return 0 if self._near_basin_escrow is None else int(self._near_basin_escrow.accepted_plan_count)

    @property
    def placement_mpc_near_basin_last_deficit_improvement(self) -> float:
        return 0.0 if self._near_basin_escrow is None else float(self._near_basin_escrow.last_improvement)

    @property
    def carried_load_pose_in_base(self) -> Pose3D | None:
        """Current algorithm-side carried-load belief for terminal visual reacquisition."""
        return self._carried_load_pose_in_base

    @property
    def terminal_load_reacquisition_update_count(self) -> int:
        return int(self._terminal_load_reacquisition_update_count)

    @property
    def terminal_load_reacquisition_rejection_count(self) -> int:
        return int(self._terminal_load_reacquisition_rejection_count)

    @property
    def terminal_load_reacquisition_position_only_update_count(self) -> int:
        return int(self._terminal_load_reacquisition_position_only_update_count)

    @property
    def terminal_load_reacquisition_yaw_suppressed_count(self) -> int:
        return int(self._terminal_load_reacquisition_yaw_suppressed_count)

    @property
    def terminal_load_reacquisition_yaw_authority_enabled(self) -> bool:
        return bool(self.parameters.placement_terminal_load_reacquisition_yaw_authority_enabled > 0.5)

    @property
    def terminal_load_reacquisition_last_position_innovation_m(self) -> float:
        return float(self._terminal_load_reacquisition_last_position_innovation_m)

    @property
    def terminal_load_reacquisition_last_yaw_innovation_deg(self) -> float:
        return float(self._terminal_load_reacquisition_last_yaw_innovation_deg)

    @property
    def terminal_load_reacquisition_last_measurement_yaw_deg(self) -> float | None:
        return self._terminal_load_reacquisition_last_measurement_yaw_deg

    @property
    def terminal_load_reacquisition_last_posterior_yaw_deg(self) -> float | None:
        return self._terminal_load_reacquisition_last_posterior_yaw_deg

    @property
    def placement_micro_primitive_search_count(self) -> int:
        return 0 if self._terminal_micro_primitive_planner is None else int(self._terminal_micro_primitive_planner.search_count)

    @property
    def placement_micro_primitive_activation_count(self) -> int:
        return 0 if self._terminal_micro_primitive_planner is None else int(self._terminal_micro_primitive_planner.activation_count)

    @property
    def placement_micro_primitive_accepted_count(self) -> int:
        return 0 if self._terminal_micro_primitive_planner is None else int(self._terminal_micro_primitive_planner.accepted_count)

    @property
    def placement_micro_primitive_candidate_count(self) -> int:
        return 0 if self._terminal_micro_primitive_planner is None else int(self._terminal_micro_primitive_planner.last_candidate_count)

    @property
    def placement_micro_primitive_last_deficit_improvement(self) -> float:
        return float(self._terminal_micro_primitive_last_deficit_improvement)

    @property
    def rigid_load_constraint_active(self) -> bool:
        return bool(self._rigid_load_constraint_monitor is not None and self._rigid_load_constraint_monitor.active)

    @property
    def rigid_load_constraint_activation_count(self) -> int:
        return 0 if self._rigid_load_constraint_monitor is None else int(self._rigid_load_constraint_monitor.activation_count)

    @property
    def rigid_load_constraint_total_active_seconds(self) -> float:
        return 0.0 if self._rigid_load_constraint_monitor is None else float(self._rigid_load_constraint_monitor.total_active_seconds)

    @property
    def placement_yaw_tail_reserve_search_count(self) -> int:
        return 0 if self._yaw_tail_reserve_planner is None else int(self._yaw_tail_reserve_planner.search_count)

    @property
    def placement_yaw_tail_reserve_activation_count(self) -> int:
        return 0 if self._yaw_tail_reserve_planner is None else int(self._yaw_tail_reserve_planner.activation_count)

    @property
    def placement_yaw_tail_reserve_candidate_count(self) -> int:
        return 0 if self._yaw_tail_reserve_planner is None else int(self._yaw_tail_reserve_planner.last_candidate_count)

    @property
    def placement_strict_recovery_retention_search_count(self) -> int:
        return 0 if self._strict_recovery_retention_planner is None else int(self._strict_recovery_retention_planner.search_count)

    @property
    def placement_strict_recovery_retention_activation_count(self) -> int:
        return 0 if self._strict_recovery_retention_planner is None else int(self._strict_recovery_retention_planner.activation_count)

    @property
    def placement_strict_recovery_retention_candidate_count(self) -> int:
        return 0 if self._strict_recovery_retention_planner is None else int(self._strict_recovery_retention_planner.last_candidate_count)

    @property
    def placement_strict_recovery_retention_last_deficit_improvement(self) -> float:
        return float(self._strict_recovery_retention_last_deficit_improvement)

    @property
    def placement_strict_recovery_final_settle_count(self) -> int:
        return int(self._strict_recovery_retention_final_settle_count)

    @property
    def placement_fresh_rgb_yaw_closure_search_count(self) -> int:
        return 0 if self._fresh_rgb_yaw_closure_planner is None else int(self._fresh_rgb_yaw_closure_planner.search_count)

    @property
    def placement_fresh_rgb_yaw_closure_activation_count(self) -> int:
        return 0 if self._fresh_rgb_yaw_closure_planner is None else int(self._fresh_rgb_yaw_closure_planner.activation_count)

    @property
    def placement_fresh_rgb_yaw_closure_candidate_count(self) -> int:
        return 0 if self._fresh_rgb_yaw_closure_planner is None else int(self._fresh_rgb_yaw_closure_planner.last_candidate_count)

    @property
    def placement_fresh_rgb_yaw_closure_feedback_reject_count(self) -> int:
        return int(self._fresh_rgb_yaw_closure_feedback_reject_count)

    @property
    def placement_fresh_rgb_yaw_closure_last_predicted_yaw_improvement_deg(self) -> float:
        return math.degrees(float(self._fresh_rgb_yaw_closure_last_predicted_yaw_improvement_rad))

    @property
    def placement_fresh_rgb_yaw_closure_last_measured_yaw_improvement_deg(self) -> float:
        return math.degrees(float(self._fresh_rgb_yaw_closure_last_measured_yaw_improvement_rad))

    @property
    def placement_fresh_rgb_yaw_closure_total_candidate_count(self) -> int:
        return 0 if self._fresh_rgb_yaw_closure_planner is None else int(self._fresh_rgb_yaw_closure_planner.total_candidate_count)

    @property
    def placement_fresh_rgb_yaw_closure_no_candidate_search_count(self) -> int:
        return 0 if self._fresh_rgb_yaw_closure_planner is None else int(self._fresh_rgb_yaw_closure_planner.no_candidate_search_count)

    @property
    def placement_post_closure_basin_ownership_entry_count(self) -> int:
        return int(self._post_closure_basin_ownership_entry_count)

    @property
    def placement_post_closure_mpc_veto_count(self) -> int:
        return int(self._post_closure_mpc_veto_count)

    @property
    def placement_post_closure_mpc_safe_allow_count(self) -> int:
        return int(self._post_closure_mpc_safe_allow_count)

    @property
    def placement_post_closure_certification_handoff_count(self) -> int:
        return int(self._post_closure_certification_handoff_count)

    @property
    def placement_post_closure_continuation_search_count(self) -> int:
        return int(self._post_closure_continuation_search_count)

    @property
    def placement_post_closure_continuation_activation_count(self) -> int:
        return int(self._post_closure_continuation_activation_count)

    @property
    def placement_post_closure_last_certification_position_m(self) -> float | None:
        return self._post_closure_last_certification_position_m

    @property
    def placement_post_closure_last_certification_yaw_deg(self) -> float | None:
        return (
            None if self._post_closure_last_certification_yaw_rad is None
            else math.degrees(self._post_closure_last_certification_yaw_rad)
        )

    @property
    def placement_post_closure_gray_zone_hold_count(self) -> int:
        return int(self._post_closure_gray_zone_hold_count)

    @property
    def placement_certification_basin_closure_search_count(self) -> int:
        return 0 if self._certification_basin_closure_planner is None else int(self._certification_basin_closure_planner.search_count)

    @property
    def placement_certification_basin_closure_activation_count(self) -> int:
        return 0 if self._certification_basin_closure_planner is None else int(self._certification_basin_closure_planner.activation_count)

    @property
    def placement_certification_basin_closure_candidate_count(self) -> int:
        return 0 if self._certification_basin_closure_planner is None else int(self._certification_basin_closure_planner.last_candidate_count)

    @property
    def placement_certification_basin_closure_total_candidate_count(self) -> int:
        return 0 if self._certification_basin_closure_planner is None else int(self._certification_basin_closure_planner.total_candidate_count)

    @property
    def placement_certification_basin_closure_no_candidate_search_count(self) -> int:
        return 0 if self._certification_basin_closure_planner is None else int(self._certification_basin_closure_planner.no_candidate_search_count)

    @property
    def placement_certification_basin_closure_feedback_reject_count(self) -> int:
        return int(self._certification_basin_closure_feedback_reject_count)

    @property
    def placement_certification_basin_closure_supervisor_retry_suppressed_count(self) -> int:
        return int(self._certification_basin_closure_supervisor_retry_suppressed_count)

    @property
    def placement_certification_basin_closure_full_pose_search_count(self) -> int:
        return (
            0
            if self._certification_basin_closure_planner is None
            else int(self._certification_basin_closure_planner.full_pose_search_count)
        )

    @property
    def placement_certification_basin_closure_legacy_error_space_search_count(self) -> int:
        return (
            0
            if self._certification_basin_closure_planner is None
            else int(self._certification_basin_closure_planner.legacy_error_space_search_count)
        )

    @property
    def placement_position_blocker_recenter_search_count(self) -> int:
        return 0 if self._position_blocker_recenter_planner is None else int(self._position_blocker_recenter_planner.search_count)

    @property
    def placement_position_blocker_recenter_activation_count(self) -> int:
        return 0 if self._position_blocker_recenter_planner is None else int(self._position_blocker_recenter_planner.activation_count)

    @property
    def placement_position_blocker_recenter_candidate_count(self) -> int:
        return 0 if self._position_blocker_recenter_planner is None else int(self._position_blocker_recenter_planner.last_candidate_count)

    @property
    def placement_position_blocker_recenter_total_candidate_count(self) -> int:
        return 0 if self._position_blocker_recenter_planner is None else int(self._position_blocker_recenter_planner.total_candidate_count)

    @property
    def placement_position_blocker_recenter_return_replan_count(self) -> int:
        return 0 if self._position_blocker_recenter_planner is None else int(self._position_blocker_recenter_planner.return_replan_count)

    @property
    def placement_position_blocker_recenter_return_candidate_count(self) -> int:
        return 0 if self._position_blocker_recenter_planner is None else int(self._position_blocker_recenter_planner.last_return_candidate_count)

    @property
    def placement_position_blocker_recenter_feedback_reject_count(self) -> int:
        return int(self._position_blocker_recenter_feedback_reject_count)

    @property
    def placement_position_blocker_recenter_abort_count(self) -> int:
        return int(self._position_blocker_recenter_abort_count)

    @property
    def placement_position_blocker_recenter_midpoint_replan_fail_count(self) -> int:
        return int(self._position_blocker_recenter_midpoint_replan_fail_count)

    @property
    def placement_position_blocker_recenter_presteer_timeout_count(self) -> int:
        return int(self._position_blocker_recenter_presteer_timeout_count)

    @property
    def placement_position_blocker_recenter_full_pose_search_count(self) -> int:
        return 0 if self._position_blocker_recenter_planner is None else int(self._position_blocker_recenter_planner.full_pose_search_count)

    @property
    def placement_position_blocker_recenter_full_pose_return_replan_count(self) -> int:
        return 0 if self._position_blocker_recenter_planner is None else int(self._position_blocker_recenter_planner.full_pose_return_replan_count)

    @property
    def placement_position_blocker_recenter_legacy_error_space_search_count(self) -> int:
        return 0 if self._position_blocker_recenter_planner is None else int(self._position_blocker_recenter_planner.legacy_error_space_search_count)

    @property
    def placement_mpc_model_id_sample_count(self) -> int:
        return int(self._placement_mpc_model_id_sample_count)

    @property
    def placement_mpc_model_id_longitudinal_rmse_m(self) -> float:
        count = max(1, self._placement_mpc_model_id_sample_count)
        return math.sqrt(self._placement_mpc_model_id_longitudinal_sq_sum / count) if self._placement_mpc_model_id_sample_count else 0.0

    @property
    def placement_mpc_model_id_lateral_rmse_m(self) -> float:
        count = max(1, self._placement_mpc_model_id_sample_count)
        return math.sqrt(self._placement_mpc_model_id_lateral_sq_sum / count) if self._placement_mpc_model_id_sample_count else 0.0

    @property
    def placement_mpc_model_id_yaw_rmse_deg(self) -> float:
        count = max(1, self._placement_mpc_model_id_sample_count)
        rmse = math.sqrt(self._placement_mpc_model_id_yaw_sq_sum / count) if self._placement_mpc_model_id_sample_count else 0.0
        return math.degrees(rmse)

    @property
    def carried_load_visual_authority_locked(self) -> bool:
        return bool(self._carried_load_visual_authority_locked)

    @property
    def carried_load_visual_lock_count(self) -> int:
        return int(self._carried_load_visual_lock_count)

    @property
    def carried_load_visual_rgb_update_count(self) -> int:
        return int(self._carried_load_visual_rgb_update_count)

    @property
    def carried_load_visual_guide_reject_count(self) -> int:
        return int(self._carried_load_visual_guide_reject_count)

    @property
    def carried_load_visual_rigid_prediction_count(self) -> int:
        return int(self._carried_load_visual_rigid_prediction_count)

    @property
    def carried_load_visual_handoff_seed_count(self) -> int:
        return int(self._carried_load_visual_handoff_seed_count)

    @property
    def carried_load_yaw_anchor_used(self) -> bool:
        return bool(self._carried_load_yaw_anchor_used)

    @property
    def carried_load_yaw_anchor_sample_count(self) -> int:
        return 0 if self._carried_load_yaw_anchor_estimate is None else int(self._carried_load_yaw_anchor_estimate.sample_count)

    @property
    def carried_load_yaw_anchor_spread_deg(self) -> float | None:
        return None if self._carried_load_yaw_anchor_estimate is None else math.degrees(float(self._carried_load_yaw_anchor_estimate.spread_rad))

    @property
    def carried_load_yaw_anchor_delta_from_latest_deg(self) -> float | None:
        return self._carried_load_yaw_anchor_delta_from_latest_deg

    @property
    def carried_load_visual_handoff_fallback_seed_count(self) -> int:
        return int(self._carried_load_visual_handoff_fallback_seed_count)

    @property
    def release_supervisor_settle_count(self) -> int:
        return int(self._release_supervisor.settle_count) if self._release_supervisor is not None else 0

    @property
    def release_supervisor_intent_count(self) -> int:
        return int(self._release_supervisor.intent_count) if self._release_supervisor is not None else 0

    @property
    def release_supervisor_intent_abort_count(self) -> int:
        return int(self._release_supervisor.intent_abort_count) if self._release_supervisor is not None else 0

    @property
    def release_supervisor_settle_timeout_count(self) -> int:
        return int(self._release_supervisor.settle_timeout_count) if self._release_supervisor is not None else 0

    @property
    def release_supervisor_mpc_resume_count(self) -> int:
        return int(self._release_supervisor.mpc_resume_count) if self._release_supervisor is not None else 0

    @property
    def release_supervisor_hold_seconds(self) -> float:
        return float(self._release_supervisor.total_hold_seconds) if self._release_supervisor is not None else 0.0

    @property
    def release_supervisor_certified_hold_seconds(self) -> float:
        return float(self._release_supervisor.certified_hold_seconds) if self._release_supervisor is not None else 0.0

    @property
    def release_supervisor_certification_to_release_seconds(self) -> float | None:
        return (
            self._release_supervisor.certification_to_release_seconds
            if self._release_supervisor is not None
            else None
        )

    @property
    def release_witness_capture_count(self) -> int:
        return int(self._release_witness_capture_count)

    @property
    def release_witness_drift_abort_count(self) -> int:
        return int(self._release_witness_drift_abort_count)

    @property
    def release_witness_instant_strict_gate_block_count(self) -> int:
        return int(self._release_witness_instant_strict_gate_block_count)

    @property
    def release_witness_position_drift_m(self) -> float:
        return float(self._release_witness_position_drift_m)

    @property
    def release_witness_yaw_drift_deg(self) -> float:
        return math.degrees(float(self._release_witness_yaw_drift_rad))


    @property
    def carried_load_seed_provenance(self) -> str:
        return str(self._carried_load_seed_provenance)

    @property
    def carried_load_seed_trusted_for_aggressive_risk(self) -> bool:
        return bool(self._carried_load_seed_trusted_for_aggressive_risk)

    @property
    def carried_load_seed_age_seconds(self) -> float | None:
        return None if not math.isfinite(self._carried_load_seed_age_seconds) else float(self._carried_load_seed_age_seconds)

    @property
    def carried_load_seed_confidence(self) -> float | None:
        return self._carried_load_seed_confidence

    @property
    def carried_load_seed_reprojection_error_px(self) -> float | None:
        return self._carried_load_seed_reprojection_error_px

    @property
    def carried_load_seed_reason(self) -> str:
        return str(self._carried_load_seed_reason)

    @property
    def strict_release_certification_pass_count(self) -> int:
        return int(self._strict_release_certification_pass_count)

    @property
    def strict_release_certification_reject_count(self) -> int:
        return int(self._strict_release_certification_reject_count)

    @property
    def strict_release_center_yaw_conflict_count(self) -> int:
        return int(self._strict_release_center_yaw_conflict_count)

    @property
    def strict_release_center_yaw_revalidation_count(self) -> int:
        return int(self._strict_release_center_yaw_revalidation_count)

    @property
    def strict_release_center_yaw_conflict_fallback_frame_count(self) -> int:
        return int(self._strict_release_center_yaw_conflict_fallback_frame_count)

    @property
    def strict_release_center_yaw_conflict_last_jump_deg(self) -> float | None:
        return (
            None
            if self._strict_release_center_yaw_conflict_last_jump_rad is None
            else math.degrees(float(self._strict_release_center_yaw_conflict_last_jump_rad))
        )

    @property
    def strict_release_center_yaw_conflict_last_load_stale_seconds(self) -> float | None:
        return self._strict_release_center_yaw_conflict_last_load_stale_seconds

    @property
    def terminal_corridor_timeout_handoff_guard_reject_count(self) -> int:
        return int(self._terminal_corridor_timeout_handoff_guard_reject_count)

    @property
    def terminal_ownership_mpc_entered(self) -> bool:
        return bool(self._terminal_ownership_mpc_entered)

    @property
    def terminal_ownership_direct_mpc_count(self) -> int:
        return int(self._terminal_ownership_direct_mpc_count)

    @property
    def terminal_ownership_forced_mpc_count(self) -> int:
        return int(self._terminal_ownership_forced_mpc_count)

    @property
    def terminal_ownership_align_timeout_count(self) -> int:
        return int(self._terminal_ownership_align_timeout_count)

    @property
    def terminal_ownership_reacquire_count(self) -> int:
        return int(self._terminal_ownership_reacquire_count)

    @property
    def terminal_ownership_total_align_seconds(self) -> float:
        return float(self._terminal_ownership_total_align_seconds)

    @property
    def terminal_ownership_max_align_seconds(self) -> float:
        return float(self._terminal_ownership_max_align_seconds)

    @property
    def carried_load_belief_mode(self) -> str:
        return str(self._carried_load_belief_mode)

    @property
    def carried_load_belief_position_sigma_m(self) -> float:
        return float(self._effective_carried_load_position_sigma_m())

    @property
    def carried_load_belief_yaw_sigma_deg(self) -> float:
        return math.degrees(float(self._effective_carried_load_yaw_sigma_rad()))

    @property
    def carried_load_motion_yaw_sigma_deg(self) -> float:
        return math.degrees(float(self._motion_carried_load_yaw_sigma_rad()))

    @property
    def carried_load_release_yaw_sigma_deg(self) -> float:
        return math.degrees(float(self._effective_carried_load_yaw_sigma_rad()))

    @property
    def carried_load_yaw_anchor_seed_sigma_deg(self) -> float | None:
        return (
            None
            if self._carried_load_yaw_anchor_seed_sigma_rad is None
            else math.degrees(float(self._carried_load_yaw_anchor_seed_sigma_rad))
        )

    @property
    def carried_load_yaw_evidence_source(self) -> str:
        return str(self._carried_load_yaw_evidence_source)

    @property
    def carried_load_belief_distance_since_visual_m(self) -> float:
        return float(self._carried_load_belief_distance_since_visual_m)

    @property
    def carried_load_belief_turn_since_visual_deg(self) -> float:
        return math.degrees(float(self._carried_load_belief_turn_since_visual_rad))

    @property
    def carried_load_belief_transport_scaled_frames(self) -> int:
        return int(self._carried_load_belief_transport_scaled_frames)

    @property
    def placement_release_prebrake_count(self) -> int:
        return self._placement_release_prebrake_count

    @property
    def placement_release_prebrake_abort_count(self) -> int:
        return self._placement_release_prebrake_abort_count

    @property
    def placement_release_candidate_count(self) -> int:
        return self._placement_release_candidate_count

    @property
    def placement_release_commit_count(self) -> int:
        return self._placement_release_commit_count

    @property
    def placement_release_commit_abort_count(self) -> int:
        return self._placement_release_commit_abort_count

    @property
    def placement_release_block_position_frames(self) -> int:
        return self._placement_release_block_position_frames

    @property
    def placement_release_block_yaw_frames(self) -> int:
        return self._placement_release_block_yaw_frames

    @property
    def placement_release_block_speed_frames(self) -> int:
        return self._placement_release_block_speed_frames

    @property
    def placement_release_block_vision_frames(self) -> int:
        return self._placement_release_block_vision_frames

    @property
    def placement_release_block_observer_frames(self) -> int:
        return self._placement_release_block_observer_frames

    @property
    def placement_terminal_budget_exhausted(self) -> bool:
        return self._placement_terminal_budget_exhausted

    def placement_terminal_elapsed(self, sim_time: float) -> float:
        if self._placement_terminal_start_time is None:
            return 0.0
        return max(0.0, float(sim_time) - self._placement_terminal_start_time)

    def _placement_terminal_budget_failure(
        self, observation: ForkliftObservation
    ) -> PickupDecision | None:
        budget = self.parameters.placement_terminal_budget_seconds
        if budget <= 0.0 or self._placement_terminal_start_time is None:
            return None
        if self.state not in (
            PickupState.PLACE_ALIGN, PickupState.PLACE_RECOVER_REVERSE,
            PickupState.PLACE_PRECISION,
        ):
            return None
        elapsed = self.placement_terminal_elapsed(observation.sim_time)
        if elapsed <= budget:
            return None
        self._placement_terminal_budget_exhausted = True
        return self._fail(
            f"terminal alignment budget exhausted after {budget:.1f}s",
            observation,
        )

    def _elapsed(self, observation: ForkliftObservation) -> float:
        return max(0.0, float(observation.sim_time) - self._state_enter_time)

    def _reset_progress(self, sim_time: float) -> None:
        self._progress_state = None
        self._best_progress_score = None
        self._last_progress_time = float(sim_time)

    def _transition(
        self,
        state: PickupState,
        observation: ForkliftObservation,
    ) -> None:
        previous_state = self.state
        now = float(observation.sim_time)
        if previous_state == PickupState.PLACE_PRECISION and state != PickupState.PLACE_PRECISION:
            self._post_closure_basin_ownership_active = False
        if (
            previous_state == PickupState.PLACE_ALIGN
            and state != PickupState.PLACE_ALIGN
            and self.parameters.placement_terminal_ownership_enabled > 0.5
        ):
            align_elapsed = max(0.0, now - self._state_enter_time)
            self._terminal_ownership_total_align_seconds += align_elapsed
            self._terminal_ownership_max_align_seconds = max(
                self._terminal_ownership_max_align_seconds, align_elapsed
            )
            if self._terminal_ownership_supervisor is not None:
                self._terminal_ownership_supervisor.reset()
        self.state = state
        self._state_enter_time = now
        self._alignment_condition_since = None
        self._reset_progress(float(observation.sim_time))
        if state == PickupState.VERIFY_LIFT:
            self._carried_load_pose_samples = []
            self._carried_load_pose_last_sample_time = None
            self._carried_load_pose_last_update_time = None
            self._carried_load_observer = None
            self._carried_load_pose_in_base = None
            self._carried_load_fast_pose_in_base = None
            self._carried_load_pose_position_std_m = 0.0
            self._carried_load_pose_yaw_std_deg = 0.0
            self._carried_load_observer_update_count = 0
            self._carried_load_observer_rejection_count = 0
            self._carried_load_observer_disagreement_position_m = 0.0
            self._carried_load_observer_disagreement_yaw_deg = 0.0
            self._carried_load_visual_authority_locked = False
            self._carried_load_visual_last_rgb_time = None
            self._carried_load_belief_mode = "UNAVAILABLE"
            self._carried_load_belief_last_vehicle_pose = None
            self._carried_load_belief_last_motion_time = None
            self._carried_load_belief_distance_since_visual_m = 0.0
            self._carried_load_belief_turn_since_visual_rad = 0.0
            self._carried_load_belief_reverse_since_visual_m = 0.0
            self._carried_load_belief_extra_position_sigma_m = 0.0
            self._carried_load_belief_extra_yaw_sigma_rad = 0.0
        if state == PickupState.PLACE_ALIGN:
            if self.parameters.placement_terminal_ownership_enabled > 0.5:
                if self._terminal_ownership_supervisor is not None:
                    self._terminal_ownership_supervisor.reset()
            if self._placement_terminal_start_time is None:
                self._placement_terminal_start_time = float(observation.sim_time)
            self._placement_precision_entry_since = None
            self._placement_condition_since = None
            self._placement_condition_mode = None
            self._placement_best_progress_score = None
            self._placement_last_progress_time = float(observation.sim_time)
            self._placement_guard_hold_since = None
            self._placement_guard_brake_used = False
            self._placement_operational_enter_time = None
            self._placement_precision_settle_best = None
            self._placement_precision_settle_last_improve_time = None
        if state == PickupState.PLACE_PRECISION:
            if self.parameters.placement_terminal_ownership_enabled > 0.5:
                self._terminal_ownership_mpc_entered = True
            if self._placement_terminal_start_time is None:
                self._placement_terminal_start_time = float(observation.sim_time)
            self._placement_precision_entry_since = None
            self._placement_precision_best_score = None
            self._placement_precision_best_distance = None
            self._placement_precision_last_progress_time = float(observation.sim_time)
            self._placement_precision_filtered_error = None
            self._placement_precision_filtered_command_longitudinal = None
            self._placement_precision_direction = 0
            self._placement_precision_phase = (
                "MPC" if self.parameters.placement_mpc_enabled > 0.0 else "CLOSE"
            )
            self._placement_mpc_last_solve_time = None
            self._placement_mpc_last_plan = None
            self._placement_mpc_last_speed = 0.0
            self._placement_mpc_last_steering = 0.0
            self._placement_mpc_consecutive_infeasible_solve_count = 0
            self._terminal_micro_primitive_active = None
            self._terminal_micro_primitive_end_time = None
            self._terminal_ownership_precision_violation_since = None
            self._placement_release_evidence_seconds = 0.0
            self._placement_release_last_update_time = float(observation.sim_time)
            self._placement_release_commit_start_time = None
            self._placement_release_prebrake_since = None
            self._placement_release_hard_violation_since = None
            self._placement_precision_recenter_start_xy = None
            self._placement_precision_recenter_start_time = None
            self._placement_precision_recenter_travel_m = 0.0
            self._placement_precision_rejoin_start_time = None
            self._placement_condition_since = None
            self._placement_condition_mode = None
            self._placement_best_progress_score = None
            self._placement_last_progress_time = float(observation.sim_time)
            self._placement_guard_hold_since = None
        if state == PickupState.PLACE_RECOVER_REVERSE:
            pose = observation.vehicle_pose_world
            self._placement_recovery_start_xy = (pose.x, pose.y)
            self._placement_recovery_live_runway = None
            self._placement_recovery_reentry_ready = None
            self._placement_condition_since = None
            self._placement_condition_mode = None
            self._placement_guard_hold_since = None
        if state == PickupState.LOWER_LOAD:
            pallet = observation.pallet_pose_world
            self._placement_lower_start_world_xy = (pallet.x, pallet.y)
        if state == PickupState.RETREAT:
            pose = observation.vehicle_pose_world
            self._retreat_start_xy = (pose.x, pose.y)
        if state == PickupState.RECOVER_REVERSE:
            self._recovery_start_xy = None
            self._recovery_motion_start_time = None
            self._recovery_centered_since = None
        if state == PickupState.TRANSPORT_REPOSITION:
            pose = observation.vehicle_pose_world
            self._transport_reposition_start_xy = (pose.x, pose.y)
            self._transport_path = None
            self._transport_path_progress_index = 0
            self._transport_goal_world = None
        if state == PickupState.TRANSPORT_APPROACH:
            self._transport_path = None
            self._transport_path_progress_index = 0
            self._transport_goal_world = None
        if state == PickupState.PLACE_CORRIDOR:
            self._transport_path = None
            self._transport_path_progress_index = 0
            self._transport_goal_world = None
            self._terminal_corridor_last_replan_time = None
            self._terminal_corridor_phase = "ENTRY"
            self._terminal_corridor_entry_since = None
        if state == PickupState.PLACE_RETREAT:
            vehicle = observation.vehicle_pose_world
            pallet = observation.pallet_pose_world
            self._placement_retreat_start_xy = (vehicle.x, vehicle.y)
            self._placed_pallet_world_pose = (pallet.x, pallet.y, pallet.yaw)

    def _decision(
        self,
        *,
        action: ForkliftAction,
        observation: ForkliftObservation,
        status: str,
        error: DockingError | None = None,
        progress_score: float | None = None,
        corridor_error: AxisCorridorError | None = None,
        placement_error: DockingError | None = None,
    ) -> PickupDecision:
        action = self._belief_conditioned_action(action, observation)
        return PickupDecision(
            action=action,
            state=self.state,
            state_elapsed=self._elapsed(observation),
            status=status,
            error=error,
            failure_reason=self.failure_reason,
            recovery_count=self._recovery_count,
            progress_score=progress_score,
            recovery_reason=self._recovery_reason,
            placement_recovery_count=self._placement_recovery_count,
            placement_recovery_reason=self._placement_recovery_reason,
            placement_recovery_target_distance=(
                self._placement_recovery_target_distance
                if self._placement_recovery_count > 0 else None
            ),
            placement_recovery_required_runway=(
                self._placement_recovery_required_runway
                if self._placement_recovery_count > 0 else None
            ),
            placement_recovery_live_runway=self._placement_recovery_live_runway,
            placement_recovery_reentry_ready=self._placement_recovery_reentry_ready,
            placement_guard_brake_count=self._placement_guard_brake_count,
            placement_precision_settle_active=(
                self._placement_operational_enter_time is not None
                and self._placement_precision_settle_best is not None
            ),
            placement_precision_settle_elapsed=(
                None if self._placement_operational_enter_time is None
                else max(0.0, float(observation.sim_time)
                         - self._placement_operational_enter_time)
            ),
            placement_precision_phase=(
                self._placement_precision_phase
                if self.state == PickupState.PLACE_PRECISION else None
            ),
            placement_precision_filtered_position_error_m=(
                None
                if self._placement_precision_filtered_error is None
                else float(self._placement_precision_filtered_error.distance)
            ),
            placement_precision_filtered_yaw_error_deg=(
                None
                if self._placement_precision_filtered_error is None
                else math.degrees(
                    float(self._placement_precision_filtered_error.yaw)
                )
            ),
            placement_precision_filtered_command_longitudinal_m=(
                self._placement_precision_filtered_command_longitudinal
            ),
            placement_precision_recenter_cycle_count=(
                self._placement_precision_recenter_cycle_count
            ),
            placement_precision_recenter_travel_m=(
                self._placement_precision_recenter_travel_m
            ),
            placement_precision_direction_switch_count=(
                self._placement_precision_direction_switch_count
            ),
            placement_mpc_mode=(
                None if self._placement_mpc_last_plan is None
                else self._placement_mpc_last_plan.mode
            ),
            placement_mpc_cost=(
                None if self._placement_mpc_last_plan is None
                else self._placement_mpc_last_plan.cost
            ),
            placement_mpc_predicted_position_error_m=(
                None if self._placement_mpc_last_plan is None
                else self._placement_mpc_last_plan.predicted_distance
            ),
            placement_mpc_predicted_yaw_error_deg=(
                None if self._placement_mpc_last_plan is None
                else math.degrees(self._placement_mpc_last_plan.predicted_yaw)
            ),
            placement_release_evidence_seconds=(
                self._placement_release_evidence_seconds
            ),
            placement_release_commit_active=(
                self._placement_precision_phase == "RELEASE_COMMIT"
            ),
            placement_release_block_observer_frames=self._placement_release_block_observer_frames,
            placement_carried_observer_active=(
                self._carried_load_pose_in_base is not None
            ),
            placement_carried_observer_sample_count=(
                len(self._carried_load_pose_samples)
            ),
            placement_carried_observer_position_std_m=(
                self._carried_load_pose_position_std_m
            ),
            placement_carried_observer_yaw_std_deg=(
                self._carried_load_pose_yaw_std_deg
            ),
            placement_carried_observer_update_count=self._carried_load_observer_update_count,
            placement_carried_observer_rejection_count=self._carried_load_observer_rejection_count,
            placement_carried_observer_disagreement_position_m=self._carried_load_observer_disagreement_position_m,
            placement_carried_observer_disagreement_yaw_deg=self._carried_load_observer_disagreement_yaw_deg,
            placement_mpc_model_id_sample_count=self.placement_mpc_model_id_sample_count,
            placement_mpc_model_id_longitudinal_rmse_m=self.placement_mpc_model_id_longitudinal_rmse_m,
            placement_mpc_model_id_lateral_rmse_m=self.placement_mpc_model_id_lateral_rmse_m,
            placement_mpc_model_id_yaw_rmse_deg=self.placement_mpc_model_id_yaw_rmse_deg,
            placement_terminal_elapsed=(
                None if self._placement_terminal_start_time is None
                else self.placement_terminal_elapsed(observation.sim_time)
            ),
            placement_terminal_budget_remaining=(
                None
                if (self._placement_terminal_start_time is None
                    or self.parameters.placement_terminal_budget_seconds <= 0.0)
                else max(
                    0.0,
                    self.parameters.placement_terminal_budget_seconds
                    - self.placement_terminal_elapsed(observation.sim_time),
                )
            ),
            placement_terminal_budget_exhausted=(
                self._placement_terminal_budget_exhausted
            ),
            terminal_corridor_mode=(
                "ROLLING" if self.state == PickupState.PLACE_CORRIDOR
                and self.parameters.terminal_approach_corridor_rolling_enabled > 0.5
                else self._terminal_corridor_phase if self.state == PickupState.PLACE_CORRIDOR
                else None
            ),
            terminal_corridor_rolling_frame_count=self._terminal_corridor_rolling_frame_count,
            terminal_corridor_handoff_count=self._terminal_corridor_handoff_count,
            terminal_corridor_timeout_handoff_count=self._terminal_corridor_timeout_handoff_count,
            terminal_corridor_reacquire_count=self._terminal_corridor_reacquire_count,
            terminal_corridor_visual_coarse_frame_count=self._terminal_corridor_visual_coarse_frame_count,
            terminal_corridor_visual_stale_frame_count=self._terminal_corridor_visual_stale_frame_count,
            terminal_vision_authority=self._terminal_visual_authority,
            carried_load_visual_authority=self._pickup_visual_authority,
            carried_load_visual_source=self._pickup_visual_source,
            carried_load_visual_stale_seconds=(
                None if not math.isfinite(self._pickup_visual_stale_seconds)
                else self._pickup_visual_stale_seconds
            ),
            carried_load_visual_locked=self._carried_load_visual_authority_locked,
            carried_load_visual_rgb_update_count=self._carried_load_visual_rgb_update_count,
            carried_load_visual_guide_reject_count=self._carried_load_visual_guide_reject_count,
            carried_load_visual_handoff_seed_count=self._carried_load_visual_handoff_seed_count,
            carried_load_yaw_anchor_used=self._carried_load_yaw_anchor_used,
            carried_load_yaw_anchor_sample_count=(
                0 if self._carried_load_yaw_anchor_estimate is None
                else int(self._carried_load_yaw_anchor_estimate.sample_count)
            ),
            carried_load_yaw_anchor_spread_deg=(
                None if self._carried_load_yaw_anchor_estimate is None
                else math.degrees(float(self._carried_load_yaw_anchor_estimate.spread_rad))
            ),
            carried_load_yaw_anchor_delta_from_latest_deg=self._carried_load_yaw_anchor_delta_from_latest_deg,
            carried_load_yaw_anchor_world_yaw_deg=(
                None if self._carried_load_yaw_anchor_estimate is None
                else math.degrees(float(self._carried_load_yaw_anchor_estimate.world_yaw_rad))
            ),
            carried_load_yaw_anchor_seed_sigma_deg=(
                None if self._carried_load_yaw_anchor_seed_sigma_rad is None
                else math.degrees(float(self._carried_load_yaw_anchor_seed_sigma_rad))
            ),
            carried_load_translation_evidence_stale_seconds=(
                None
                if not math.isfinite(self._carried_visual_stale_for_release(observation.sim_time))
                else self._carried_visual_stale_for_release(observation.sim_time)
            ),
            carried_load_yaw_evidence_stale_seconds=(
                None
                if not math.isfinite(self._carried_yaw_stale_for_release(observation.sim_time))
                else self._carried_yaw_stale_for_release(observation.sim_time)
            ),
            carried_load_yaw_evidence_source=self._carried_load_yaw_evidence_source,
            carried_load_motion_yaw_sigma_deg=math.degrees(
                self._motion_carried_load_yaw_sigma_rad()
            ),
            carried_load_release_yaw_sigma_deg=math.degrees(
                self._effective_carried_load_yaw_sigma_rad()
            ),
            carried_load_seed_provenance=self._carried_load_seed_provenance,
            carried_load_seed_trusted_for_aggressive_risk=self._carried_load_seed_trusted_for_aggressive_risk,
            carried_load_seed_age_seconds=(
                None if not math.isfinite(self._carried_load_seed_age_seconds)
                else self._carried_load_seed_age_seconds
            ),
            carried_load_seed_confidence=self._carried_load_seed_confidence,
            carried_load_seed_reprojection_error_px=self._carried_load_seed_reprojection_error_px,
            carried_load_seed_reason=self._carried_load_seed_reason,
            strict_release_risk_budget_mode=("RSS_TRUSTED" if self._strict_release_risk_budget_rss_active else "ADDITIVE"),
            strict_release_yaw_risk_budget_mode=("CENTER_YAW_RSS" if self._strict_release_yaw_rss_active else "ADDITIVE"),
            strict_release_center_yaw_anchor_active=bool(
                self.parameters.placement_strict_release_center_yaw_anchor_enabled > 0.5
                and self._placement_release_center_yaw_target_pose_in_base is not None
                and not self._strict_release_center_yaw_conflict_active
            ),
            strict_release_center_yaw_conflict_active=bool(self._strict_release_center_yaw_conflict_active),
            strict_release_center_yaw_current_jump_deg=(
                None if self._strict_release_center_yaw_current_jump_rad is None
                else math.degrees(float(self._strict_release_center_yaw_current_jump_rad))
            ),
            strict_release_center_yaw_conflict_count=self._strict_release_center_yaw_conflict_count,
            strict_release_center_yaw_revalidation_count=self._strict_release_center_yaw_revalidation_count,
            strict_release_center_yaw_conflict_fallback_frame_count=self._strict_release_center_yaw_conflict_fallback_frame_count,
            strict_release_center_yaw_conflict_last_jump_deg=(
                None if self._strict_release_center_yaw_conflict_last_jump_rad is None
                else math.degrees(float(self._strict_release_center_yaw_conflict_last_jump_rad))
            ),
            strict_release_center_yaw_conflict_last_load_stale_seconds=self._strict_release_center_yaw_conflict_last_load_stale_seconds,
            strict_release_certified=self._strict_release_certification_last_result,
            strict_release_certification_position_error_m=(
                None if self._strict_release_certification_last_error is None
                else float(self._strict_release_certification_last_error.distance)
            ),
            strict_release_certification_yaw_error_deg=(
                None if self._strict_release_certification_last_error is None
                else math.degrees(abs(float(self._strict_release_certification_last_error.yaw)))
            ),
            strict_release_certification_target_source=(
                "MULTIVIEW_CONFLICT_FALLBACK"
                if self._strict_release_center_yaw_conflict_active
                and self._placement_target_multiview_ready
                and self._placement_certification_target_pose_in_base is not None
                else "FAST_CONFLICT_FALLBACK"
                if self._strict_release_center_yaw_conflict_active
                else "CENTER_YAW_ANCHOR"
                if self.parameters.placement_strict_release_center_yaw_anchor_enabled > 0.5
                and self._placement_release_center_yaw_target_pose_in_base is not None
                else "MULTIVIEW"
                if self._placement_target_multiview_ready
                and self._placement_certification_target_pose_in_base is not None
                else "FAST"
            ),
            strict_release_certification_load_yaw_deg=(
                math.degrees(float(self._effective_pallet_pose_in_base(observation).yaw))
                if observation.load_state.startswith("LIFTED") else None
            ),
            strict_release_certification_target_yaw_deg=(
                math.degrees(float(self._strict_release_target_pose_in_base(observation).yaw))
                if observation.load_state.startswith("LIFTED") else None
            ),
            strict_release_position_margin_m=self._strict_release_certification_last_position_margin_m,
            strict_release_yaw_margin_deg=self._strict_release_certification_last_yaw_margin_deg,
            strict_release_target_position_margin_m=self._strict_release_certification_last_target_position_margin_m,
            strict_release_target_yaw_margin_deg=self._strict_release_certification_last_target_yaw_margin_deg,
            certified_basin_active=(False if self._certified_basin is None else bool(self._certified_basin.active)),
            certified_basin_source=self._certified_basin_last_source,
            certified_basin_age_seconds=self._certified_basin_last_age_seconds,
            certified_basin_consensus_evidence_seconds=(
                0.0 if self._certified_basin is None else float(self._certified_basin.consensus_evidence_seconds)
            ),
            certified_basin_enter_count=self.certified_basin_enter_count,
            certified_basin_exit_count=self.certified_basin_exit_count,
            certified_basin_strict_enter_count=self.certified_basin_strict_enter_count,
            certified_basin_consensus_enter_count=self.certified_basin_consensus_enter_count,
            certified_basin_persisted_pass_count=self.certified_basin_persisted_pass_count,
            strict_release_certification_blocker=self._strict_release_certification_last_blocker,
            strict_release_certification_blocker_counts=self.strict_release_certification_blocker_counts,
            placement_target_raw_position_spread_m=self._placement_target_raw_position_spread_m,
            placement_target_raw_yaw_spread_deg=(
                None if self._placement_target_raw_yaw_spread_rad is None
                else math.degrees(self._placement_target_raw_yaw_spread_rad)
            ),
            placement_target_multiview_ready=self._placement_target_multiview_ready,
            placement_target_multiview_samples=self._placement_target_multiview_samples,
            placement_target_multiview_position_spread_m=self._placement_target_multiview_position_spread_m,
            placement_target_multiview_yaw_spread_deg=(
                None if self._placement_target_multiview_yaw_spread_rad is None
                else math.degrees(self._placement_target_multiview_yaw_spread_rad)
            ),
            placement_target_fast_slow_position_disagreement_m=self._placement_target_fast_slow_position_disagreement_m,
            placement_target_fast_slow_yaw_disagreement_deg=(
                None if self._placement_target_fast_slow_yaw_disagreement_rad is None
                else math.degrees(self._placement_target_fast_slow_yaw_disagreement_rad)
            ),
            release_witness_active=self._release_certification_witness_error is not None,
            release_witness_age_seconds=(
                None if self._release_certification_witness_time is None
                else max(0.0, float(observation.sim_time) - self._release_certification_witness_time)
            ),
            release_witness_position_drift_m=self._release_witness_position_drift_m,
            release_witness_yaw_drift_deg=math.degrees(self._release_witness_yaw_drift_rad),
            release_witness_capture_count=self._release_witness_capture_count,
            release_witness_drift_abort_count=self._release_witness_drift_abort_count,
            release_witness_instant_strict_gate_block_count=self._release_witness_instant_strict_gate_block_count,
            release_snapshot_active=self._release_snapshot_error is not None,
            placement_mpc_yaw_escrow_activation_count=self._placement_mpc_yaw_escrow_activation_count,
            placement_mpc_yaw_escrow_active=(
                self._placement_mpc_yaw_escrow_active_until is not None
                and float(observation.sim_time) <= self._placement_mpc_yaw_escrow_active_until
            ),
            placement_mpc_near_basin_escrow_activation_count=self.placement_mpc_near_basin_escrow_activation_count,
            placement_mpc_near_basin_escrow_accepted_plan_count=self.placement_mpc_near_basin_escrow_accepted_plan_count,
            placement_mpc_near_basin_escrow_active=(
                self._near_basin_escrow is not None
                and self._near_basin_escrow.active_until is not None
                and float(observation.sim_time) <= self._near_basin_escrow.active_until
            ),
            placement_mpc_near_basin_last_deficit_improvement=self.placement_mpc_near_basin_last_deficit_improvement,
            terminal_load_reacquisition_update_count=self.terminal_load_reacquisition_update_count,
            terminal_load_reacquisition_rejection_count=self.terminal_load_reacquisition_rejection_count,
            terminal_load_reacquisition_position_only_update_count=self.terminal_load_reacquisition_position_only_update_count,
            terminal_load_reacquisition_yaw_suppressed_count=self.terminal_load_reacquisition_yaw_suppressed_count,
            terminal_load_reacquisition_yaw_authority_enabled=self.terminal_load_reacquisition_yaw_authority_enabled,
            terminal_load_reacquisition_last_position_innovation_m=self.terminal_load_reacquisition_last_position_innovation_m,
            terminal_load_reacquisition_last_yaw_innovation_deg=self.terminal_load_reacquisition_last_yaw_innovation_deg,
            terminal_load_reacquisition_last_measurement_yaw_deg=self.terminal_load_reacquisition_last_measurement_yaw_deg,
            terminal_load_reacquisition_last_posterior_yaw_deg=self.terminal_load_reacquisition_last_posterior_yaw_deg,
            placement_micro_primitive_search_count=self.placement_micro_primitive_search_count,
            placement_micro_primitive_activation_count=self.placement_micro_primitive_activation_count,
            placement_micro_primitive_accepted_count=self.placement_micro_primitive_accepted_count,
            placement_micro_primitive_candidate_count=self.placement_micro_primitive_candidate_count,
            placement_micro_primitive_active=(self._terminal_micro_primitive_active is not None),
            placement_micro_primitive_last_deficit_improvement=self.placement_micro_primitive_last_deficit_improvement,
            rigid_load_constraint_active=self.rigid_load_constraint_active,
            rigid_load_constraint_activation_count=self.rigid_load_constraint_activation_count,
            rigid_load_constraint_total_active_seconds=self.rigid_load_constraint_total_active_seconds,
            placement_yaw_tail_reserve_search_count=self.placement_yaw_tail_reserve_search_count,
            placement_yaw_tail_reserve_activation_count=self.placement_yaw_tail_reserve_activation_count,
            placement_yaw_tail_reserve_candidate_count=self.placement_yaw_tail_reserve_candidate_count,
            placement_strict_recovery_retention_search_count=self.placement_strict_recovery_retention_search_count,
            placement_strict_recovery_retention_activation_count=self.placement_strict_recovery_retention_activation_count,
            placement_strict_recovery_retention_candidate_count=self.placement_strict_recovery_retention_candidate_count,
            placement_strict_recovery_retention_active=(self._strict_recovery_retention_active is not None),
            placement_strict_recovery_retention_last_deficit_improvement=self.placement_strict_recovery_retention_last_deficit_improvement,
            placement_strict_recovery_final_settle_count=self.placement_strict_recovery_final_settle_count,
            placement_strict_recovery_final_settle_consumed=self._strict_recovery_retention_final_settle_consumed,
            placement_fresh_rgb_yaw_closure_search_count=self.placement_fresh_rgb_yaw_closure_search_count,
            placement_fresh_rgb_yaw_closure_activation_count=self.placement_fresh_rgb_yaw_closure_activation_count,
            placement_fresh_rgb_yaw_closure_candidate_count=self.placement_fresh_rgb_yaw_closure_candidate_count,
            placement_fresh_rgb_yaw_closure_active=(self._fresh_rgb_yaw_closure_active is not None),
            placement_fresh_rgb_yaw_closure_phase=self._fresh_rgb_yaw_closure_phase,
            placement_fresh_rgb_yaw_closure_feedback_reject_count=self.placement_fresh_rgb_yaw_closure_feedback_reject_count,
            placement_fresh_rgb_yaw_closure_last_predicted_yaw_improvement_deg=self.placement_fresh_rgb_yaw_closure_last_predicted_yaw_improvement_deg,
            placement_fresh_rgb_yaw_closure_last_measured_yaw_improvement_deg=self.placement_fresh_rgb_yaw_closure_last_measured_yaw_improvement_deg,
            placement_fresh_rgb_yaw_closure_post_motion_rgb_updates=self._fresh_rgb_yaw_closure_post_motion_rgb_updates,
            placement_fresh_rgb_yaw_closure_total_candidate_count=self.placement_fresh_rgb_yaw_closure_total_candidate_count,
            placement_fresh_rgb_yaw_closure_no_candidate_search_count=self.placement_fresh_rgb_yaw_closure_no_candidate_search_count,
            placement_post_closure_basin_ownership_active=self._post_closure_basin_ownership_active,
            placement_post_closure_basin_ownership_entry_count=self.placement_post_closure_basin_ownership_entry_count,
            placement_post_closure_mpc_veto_count=self.placement_post_closure_mpc_veto_count,
            placement_post_closure_mpc_safe_allow_count=self.placement_post_closure_mpc_safe_allow_count,
            placement_post_closure_certification_handoff_count=self.placement_post_closure_certification_handoff_count,
            placement_post_closure_continuation_search_count=self.placement_post_closure_continuation_search_count,
            placement_post_closure_continuation_activation_count=self.placement_post_closure_continuation_activation_count,
            placement_post_closure_last_certification_position_m=self._post_closure_last_certification_position_m,
            placement_post_closure_last_certification_yaw_deg=(
                None if self._post_closure_last_certification_yaw_rad is None
                else math.degrees(self._post_closure_last_certification_yaw_rad)
            ),
            placement_post_closure_gray_zone_hold_count=self.placement_post_closure_gray_zone_hold_count,
            placement_certification_basin_closure_search_count=self.placement_certification_basin_closure_search_count,
            placement_certification_basin_closure_activation_count=self.placement_certification_basin_closure_activation_count,
            placement_certification_basin_closure_candidate_count=self.placement_certification_basin_closure_candidate_count,
            placement_certification_basin_closure_total_candidate_count=self.placement_certification_basin_closure_total_candidate_count,
            placement_certification_basin_closure_no_candidate_search_count=self.placement_certification_basin_closure_no_candidate_search_count,
            placement_certification_basin_closure_feedback_reject_count=self.placement_certification_basin_closure_feedback_reject_count,
            placement_certification_basin_closure_phase=self._certification_basin_closure_phase,
            placement_certification_basin_closure_last_predicted_deficit_improvement=self._certification_basin_closure_last_predicted_deficit_improvement,
            placement_certification_basin_closure_last_measured_deficit_improvement=self._certification_basin_closure_last_measured_deficit_improvement,
            placement_certification_basin_closure_last_current_deficit=self._certification_basin_closure_last_current_deficit,
            placement_certification_basin_closure_last_predicted_deficit=self._certification_basin_closure_last_predicted_deficit,
            placement_certification_basin_closure_post_motion_rgb_updates=self._certification_basin_closure_post_motion_rgb_updates,
            placement_certification_basin_closure_supervisor_retry_suppressed_count=self.placement_certification_basin_closure_supervisor_retry_suppressed_count,
            placement_certification_basin_closure_full_pose_search_count=self.placement_certification_basin_closure_full_pose_search_count,
            placement_certification_basin_closure_legacy_error_space_search_count=self.placement_certification_basin_closure_legacy_error_space_search_count,
            placement_certification_basin_closure_last_certification_longitudinal_m=self._certification_basin_closure_last_certification_longitudinal_m,
            placement_certification_basin_closure_last_certification_lateral_m=self._certification_basin_closure_last_certification_lateral_m,
            placement_position_blocker_recenter_search_count=self.placement_position_blocker_recenter_search_count,
            placement_position_blocker_recenter_activation_count=self.placement_position_blocker_recenter_activation_count,
            placement_position_blocker_recenter_candidate_count=self.placement_position_blocker_recenter_candidate_count,
            placement_position_blocker_recenter_total_candidate_count=self.placement_position_blocker_recenter_total_candidate_count,
            placement_position_blocker_recenter_return_replan_count=self.placement_position_blocker_recenter_return_replan_count,
            placement_position_blocker_recenter_return_candidate_count=self.placement_position_blocker_recenter_return_candidate_count,
            placement_position_blocker_recenter_feedback_reject_count=self.placement_position_blocker_recenter_feedback_reject_count,
            placement_position_blocker_recenter_abort_count=self.placement_position_blocker_recenter_abort_count,
            placement_position_blocker_recenter_midpoint_replan_fail_count=self.placement_position_blocker_recenter_midpoint_replan_fail_count,
            placement_position_blocker_recenter_phase=self._position_blocker_recenter_phase,
            placement_position_blocker_recenter_mid_rgb_updates=self._position_blocker_recenter_mid_rgb_updates,
            placement_position_blocker_recenter_final_rgb_updates=self._position_blocker_recenter_final_rgb_updates,
            placement_position_blocker_recenter_last_predicted_effective_position_m=self._position_blocker_recenter_last_predicted_effective_position_m,
            placement_position_blocker_recenter_last_predicted_effective_yaw_deg=math.degrees(self._position_blocker_recenter_last_predicted_effective_yaw_rad),
            placement_position_blocker_recenter_last_measured_effective_position_m=self._position_blocker_recenter_last_measured_effective_position_m,
            placement_position_blocker_recenter_last_measured_effective_yaw_deg=math.degrees(self._position_blocker_recenter_last_measured_effective_yaw_rad),
            placement_position_blocker_recenter_last_measured_position_improvement_m=self._position_blocker_recenter_last_measured_position_improvement_m,
            placement_position_blocker_recenter_presteer_timeout_count=self.placement_position_blocker_recenter_presteer_timeout_count,
            placement_position_blocker_recenter_last_effective_steering_deg=math.degrees(self._position_blocker_recenter_last_effective_steering_rad),
            placement_position_blocker_recenter_last_departure_odometry_m=self._position_blocker_recenter_last_departure_odometry_m,
            placement_position_blocker_recenter_last_return_odometry_m=self._position_blocker_recenter_last_return_odometry_m,
            placement_position_blocker_recenter_midpoint_position_deviation_m=self._position_blocker_recenter_midpoint_position_deviation_m,
            placement_position_blocker_recenter_midpoint_yaw_deviation_deg=math.degrees(self._position_blocker_recenter_midpoint_yaw_deviation_rad),
            placement_position_blocker_recenter_full_pose_model_active=self._position_blocker_recenter_full_pose_model_active,
            placement_position_blocker_recenter_full_pose_search_count=self.placement_position_blocker_recenter_full_pose_search_count,
            placement_position_blocker_recenter_full_pose_return_replan_count=self.placement_position_blocker_recenter_full_pose_return_replan_count,
            placement_position_blocker_recenter_legacy_error_space_search_count=self.placement_position_blocker_recenter_legacy_error_space_search_count,
            placement_position_blocker_recenter_rollback_count=self._position_blocker_recenter_rollback_count,
            placement_position_blocker_recenter_rollback_success_count=self._position_blocker_recenter_rollback_success_count,
            placement_position_blocker_recenter_rollback_failure_count=self._position_blocker_recenter_rollback_failure_count,
            placement_position_blocker_recenter_rollback_target_odometry_m=self._position_blocker_recenter_rollback_target_odometry_m,
            placement_position_blocker_recenter_last_rollback_odometry_m=self._position_blocker_recenter_last_rollback_odometry_m,
            placement_position_blocker_recenter_last_return_unwind_odometry_m=self._position_blocker_recenter_last_return_unwind_odometry_m,
            placement_position_blocker_recenter_rollback_rgb_updates=self._position_blocker_recenter_rollback_rgb_updates,
            placement_position_blocker_recenter_rollback_reason=self._position_blocker_recenter_rollback_reason,
            placement_position_blocker_recenter_yaw_handoff_ready=self._position_blocker_recenter_yaw_handoff_ready,
            placement_position_blocker_recenter_yaw_handoff_count=self._position_blocker_recenter_yaw_handoff_count,
            placement_position_blocker_recenter_retrace_candidate_reject_count=(
                0 if self._position_blocker_recenter_planner is None
                else self._position_blocker_recenter_planner.retrace_candidate_reject_count
            ),
            placement_position_blocker_recenter_topology_candidate_count=(
                0 if self._position_blocker_recenter_planner is None
                else self._position_blocker_recenter_planner.topology_candidate_count
            ),
            placement_position_blocker_recenter_final_evidence_consistent_rgb_updates=(
                self._position_blocker_recenter_final_evidence_consistent_rgb_updates
            ),
            placement_position_blocker_recenter_final_live_strict_attempt_count=(
                self._position_blocker_recenter_final_live_strict_attempt_count
            ),
            placement_position_blocker_recenter_final_evidence_timeout_count=(
                self._position_blocker_recenter_final_evidence_timeout_count
            ),
            terminal_corridor_timeout_handoff_guard_reject_count=(
                self._terminal_corridor_timeout_handoff_guard_reject_count
            ),
            terminal_ownership_mpc_entered=self._terminal_ownership_mpc_entered,
            terminal_ownership_direct_mpc_count=self._terminal_ownership_direct_mpc_count,
            terminal_ownership_forced_mpc_count=self._terminal_ownership_forced_mpc_count,
            terminal_ownership_align_timeout_count=self._terminal_ownership_align_timeout_count,
            terminal_ownership_reacquire_count=self._terminal_ownership_reacquire_count,
            terminal_ownership_total_align_seconds=self._terminal_ownership_total_align_seconds,
            terminal_ownership_max_align_seconds=self._terminal_ownership_max_align_seconds,
            carried_load_belief_mode=self._carried_load_belief_mode,
            carried_load_belief_position_sigma_m=self._effective_carried_load_position_sigma_m(),
            carried_load_belief_yaw_sigma_deg=math.degrees(
                self._effective_carried_load_yaw_sigma_rad()
            ),
            carried_load_belief_distance_since_visual_m=(
                self._carried_load_belief_distance_since_visual_m
            ),
            carried_load_belief_turn_since_visual_deg=math.degrees(
                self._carried_load_belief_turn_since_visual_rad
            ),
            carried_load_belief_transport_scaled_frames=(
                self._carried_load_belief_transport_scaled_frames
            ),
            corridor_error=corridor_error,
            placement_error=placement_error,
        )

    def _fail(
        self,
        reason: str,
        observation: ForkliftObservation,
    ) -> PickupDecision:
        self.failure_reason = reason
        self._transition(PickupState.FAILED, observation)
        return PickupDecision(
            action=ForkliftAction.stopped(
                lift_target=observation.lift_position
            ),
            state=self.state,
            state_elapsed=0.0,
            status="Autonomous pickup failed",
            failure_reason=reason,
            recovery_count=self._recovery_count,
            recovery_reason=self._recovery_reason,
            placement_recovery_count=self._placement_recovery_count,
            placement_recovery_reason=self._placement_recovery_reason,
            placement_terminal_elapsed=(
                None if self._placement_terminal_start_time is None
                else self.placement_terminal_elapsed(observation.sim_time)
            ),
            placement_terminal_budget_remaining=(
                None
                if (self._placement_terminal_start_time is None
                    or self.parameters.placement_terminal_budget_seconds <= 0.0)
                else max(
                    0.0,
                    self.parameters.placement_terminal_budget_seconds
                    - self.placement_terminal_elapsed(observation.sim_time),
                )
            ),
            placement_terminal_budget_exhausted=(
                self._placement_terminal_budget_exhausted
            ),
        )

    def _axis_docking_enabled(self) -> bool:
        return self.parameters.axis_docking_enabled > 0.5

    def _fork_corridor_enabled(self) -> bool:
        p = self.parameters
        return (
            self._axis_docking_enabled()
            and p.fork_root_distance > 0.0
            and p.fork_tip_distance > p.fork_root_distance
            and p.pallet_half_length > 0.0
            and p.alignment_preview_tolerance > 0.0
            and p.insertion_corridor_tolerance > 0.0
        )

    def _corridor_control_enabled(self) -> bool:
        p = self.parameters
        return (
            p.corridor_control_enabled > 0.5
            and self._fork_corridor_enabled()
        )

    @staticmethod
    def _corridor_reference_distance(
        corridor_error: AxisCorridorError,
    ) -> float:
        return 0.5 * (
            float(corridor_error.near_reference)
            + float(corridor_error.far_reference)
        )

    def _corridor_command_overrides(
        self,
        corridor_error: AxisCorridorError | None,
    ) -> dict[str, float]:
        if corridor_error is None or not self._corridor_control_enabled():
            return {}
        p = self.parameters
        return {
            "lateral_reference_distance": (
                self._corridor_reference_distance(corridor_error)
            ),
            "lateral_gain_override": p.corridor_control_lateral_gain,
            "yaw_gain_override": p.corridor_control_yaw_gain,
            "lookahead_distance_override": p.corridor_control_lookahead,
        }

    def _fork_corridor_error(
        self,
        observation: ForkliftObservation,
        *,
        object_center_distance: float,
    ) -> AxisCorridorError:
        p = self.parameters
        return object_axis_corridor_error(
            observation.pallet_pose_in_base,
            fork_root_distance=p.fork_root_distance,
            fork_tip_distance=p.fork_tip_distance,
            object_half_length=p.pallet_half_length,
            object_center_distance=object_center_distance,
        )

    def _placement_enabled(self) -> bool:
        return self.parameters.placement_enabled > 0.5

    def _competition_precision_enabled(self) -> bool:
        return self.parameters.placement_competition_precision_enabled > 0.5

    def _placement_precision_reverse_action(
        self, observation: ForkliftObservation, command_error: DockingError,
    ) -> ForkliftAction | None:
        """Return a bounded reverse correction from desired-vehicle residual.

        ``DockingController.pose_command`` is explicitly forward-only, so its
        longitudinal error is the authoritative sign for whether the desired
        vehicle pose lies ahead of or behind the chassis.  The pallet-to-target
        longitudinal residual is expressed in the placement-target frame and
        must not be mapped directly to vehicle throttle direction.
        """
        p = self.parameters
        if (
            abs(float(command_error.longitudinal))
            > p.placement_precision_reverse_longitudinal_limit
            or abs(float(command_error.lateral))
            > p.placement_precision_reverse_lateral_tolerance
            or abs(float(command_error.yaw))
            > p.placement_precision_reverse_yaw_tolerance
        ):
            return None

        forward_speed = self._vehicle_forward_speed(observation)
        if forward_speed > p.placement_precision_direction_change_speed_epsilon:
            return ForkliftAction.stopped(lift_target=p.transport_lift_target)

        residual = max(
            0.0,
            abs(float(command_error.longitudinal))
            - p.placement_precision_longitudinal_deadband,
        )
        speed = min(
            p.placement_precision_reverse_max_speed,
            p.placement_precision_speed_gain * residual,
        )
        if speed <= 1e-6:
            return ForkliftAction.stopped(lift_target=p.transport_lift_target)
        steering = self._placement_recovery_reverse_steering(command_error)
        return ForkliftAction(
            speed_target=-float(speed),
            steering_command=float(steering),
            lift_target=p.transport_lift_target,
        )

    def _placement_precision_entry_ready(
        self, error: DockingError
    ) -> bool:
        p = self.parameters
        return (
            error.distance <= p.placement_precision_entry_position_tolerance
            and abs(error.lateral)
            <= p.placement_precision_entry_lateral_tolerance
            and abs(error.yaw) <= p.placement_precision_entry_yaw_tolerance
        )

    def _placement_precision_progress_score(
        self, error: DockingError
    ) -> float:
        """Normalized worst-axis precision error; lower is better."""
        p = self.parameters
        return max(
            float(error.distance) / max(1e-9, p.placement_position_tolerance),
            abs(float(error.lateral))
            / max(1e-9, p.placement_precision_entry_lateral_tolerance),
            abs(float(error.yaw)) / max(1e-9, p.placement_yaw_tolerance),
        )

    def _placement_precision_stalled_or_regressed(
        self, observation: ForkliftObservation, error: DockingError
    ) -> tuple[bool, bool, float]:
        """Detect local closure that is no longer converging.

        V9.2.1 reused the long terminal progress timer and could spend most of
        the 75/90 s terminal budget cycling between precision and alignment.
        V9.2.3 uses a short precision-only timer and a distance trust region.
        """
        p = self.parameters
        now = float(observation.sim_time)
        score = self._placement_precision_progress_score(error)
        distance = float(error.distance)
        if self._placement_precision_best_score is None:
            self._placement_precision_best_score = score
            self._placement_precision_best_distance = distance
            self._placement_precision_last_progress_time = now
            return False, False, score

        if score <= (
            self._placement_precision_best_score
            - p.placement_precision_progress_improvement
        ):
            self._placement_precision_best_score = score
            self._placement_precision_last_progress_time = now
        if (
            self._placement_precision_best_distance is None
            or distance < self._placement_precision_best_distance
        ):
            self._placement_precision_best_distance = distance

        regressed = (
            self._placement_precision_best_distance is not None
            and distance
            > self._placement_precision_best_distance
            + p.placement_precision_maximum_regression_m
        )
        stalled = (
            self._placement_precision_last_progress_time is not None
            and now - self._placement_precision_last_progress_time
            >= p.placement_precision_progress_timeout
        )
        return bool(stalled), bool(regressed), score

    def _placement_precision_forward_action(self, command: Any) -> ForkliftAction:
        """Forward micro-motion shaped by desired-vehicle longitudinal error."""
        p = self.parameters
        residual = max(
            0.0,
            float(command.error.longitudinal)
            - p.placement_precision_longitudinal_deadband,
        )
        speed = min(
            p.placement_precision_forward_max_speed,
            p.placement_precision_speed_gain * residual,
        )
        if speed <= 1e-6:
            return ForkliftAction.stopped(lift_target=p.transport_lift_target)
        return ForkliftAction(
            speed_target=float(speed),
            steering_command=float(command.action.steering_command),
            lift_target=p.transport_lift_target,
        )

    def _placement_precision_geometry_action(
        self, observation: ForkliftObservation, command: Any,
    ) -> ForkliftAction:
        """Use a tiny bidirectional Ackermann shunt near zero longitudinal error.

        When the desired vehicle x residual is essentially zero but lateral or
        yaw error remains, a complete stop cannot improve Ackermann geometry.
        A tiny pulse is therefore allowed and its direction follows the signed
        desired-vehicle residual (zero defaults to forward).  The next control
        step can reverse the pulse if the desired pose moves behind the chassis.
        """
        p = self.parameters
        severity = max(
            abs(float(command.error.lateral))
            / max(1e-9, p.placement_precision_reverse_lateral_tolerance),
            abs(float(command.error.yaw))
            / max(1e-9, p.placement_precision_reverse_yaw_tolerance),
        )
        speed = p.placement_precision_geometry_max_speed * min(1.0, severity)
        if speed <= 1e-6:
            return ForkliftAction.stopped(lift_target=p.transport_lift_target)

        command_longitudinal = float(command.error.longitudinal)
        forward_speed = self._vehicle_forward_speed(observation)
        epsilon = p.placement_precision_direction_change_speed_epsilon
        if command_longitudinal < 0.0:
            if forward_speed > epsilon:
                return ForkliftAction.stopped(lift_target=p.transport_lift_target)
            steering = self._placement_recovery_reverse_steering(command.error)
            return ForkliftAction(
                speed_target=-float(speed),
                steering_command=float(steering),
                lift_target=p.transport_lift_target,
            )

        if forward_speed < -epsilon:
            return ForkliftAction.stopped(lift_target=p.transport_lift_target)
        return ForkliftAction(
            speed_target=float(speed),
            steering_command=float(command.action.steering_command),
            lift_target=p.transport_lift_target,
        )

    def _v924_precision_enabled(self) -> bool:
        """Return whether the V9.3.0 terminal controller is configured."""
        return (
            self._competition_precision_enabled()
            and self.parameters.placement_precision_filter_alpha > 0.0
        )

    def _placement_precision_update_filter(
        self,
        task_error: DockingError,
        command_error: DockingError,
    ) -> tuple[DockingError, float]:
        """Filter terminal task error and signed vehicle residual.

        V9.2.3 proved that the physical pallet can remain inside the official
        competition envelope while the instantaneous estimated error repeatedly
        crosses the strict release gate.  The filter reduces that measurement
        chatter; it does not add any target offset or truth-derived correction.
        """
        p = self.parameters
        alpha = p.placement_precision_filter_alpha
        if alpha <= 0.0 or self._placement_precision_filtered_error is None:
            filtered = task_error
            filtered_command_longitudinal = float(command_error.longitudinal)
        else:
            old = self._placement_precision_filtered_error
            longitudinal = (
                (1.0 - alpha) * float(old.longitudinal)
                + alpha * float(task_error.longitudinal)
            )
            lateral = (
                (1.0 - alpha) * float(old.lateral)
                + alpha * float(task_error.lateral)
            )
            yaw_delta = wrap_angle(
                float(task_error.yaw) - float(old.yaw)
            )
            yaw = wrap_angle(float(old.yaw) + alpha * yaw_delta)
            distance = math.hypot(longitudinal, lateral)
            heading = (
                math.atan2(lateral, longitudinal)
                if distance > 1e-9 else 0.0
            )
            filtered = DockingError(
                longitudinal=float(longitudinal),
                lateral=float(lateral),
                distance=float(distance),
                heading=wrap_angle(heading),
                yaw=float(yaw),
            )
            old_command = (
                float(command_error.longitudinal)
                if self._placement_precision_filtered_command_longitudinal is None
                else float(
                    self._placement_precision_filtered_command_longitudinal
                )
            )
            filtered_command_longitudinal = (
                (1.0 - alpha) * old_command
                + alpha * float(command_error.longitudinal)
            )

        self._placement_precision_filtered_error = filtered
        self._placement_precision_filtered_command_longitudinal = float(
            filtered_command_longitudinal
        )
        return filtered, float(filtered_command_longitudinal)

    def _placement_precision_task_steering(
        self,
        error: DockingError,
        *,
        reverse: bool,
    ) -> float:
        """Task-space steering for the carried pallet pose.

        Near placement, the generic desired-vehicle pose controller can make
        its lateral and yaw terms fight because the pallet is carried ahead of
        the chassis.  V9.3.0 therefore steers directly from the pallet-to-target
        lateral/yaw residual.  Reverse motion flips the virtual curvature sign,
        matching rear-Ackermann kinematics.
        """
        p = self.parameters
        lateral_angle = math.atan2(
            p.placement_precision_task_lateral_gain * float(error.lateral),
            p.placement_precision_task_lookahead,
        )
        steering = (
            lateral_angle
            + p.placement_precision_task_yaw_gain * float(error.yaw)
        )
        if reverse:
            steering = -steering
        limit = min(
            p.placement_precision_task_steering_limit,
            p.place_steering_limit,
        )
        return max(-limit, min(limit, float(steering)))

    def _placement_precision_set_direction(self, direction: int) -> None:
        direction = 1 if direction > 0 else (-1 if direction < 0 else 0)
        if direction != self._placement_precision_direction:
            if (
                self._placement_precision_direction != 0
                and direction != 0
            ):
                self._placement_precision_direction_switch_count += 1
            self._placement_precision_direction = direction

    def _placement_precision_close_action(
        self,
        observation: ForkliftObservation,
        *,
        command_longitudinal: float,
        filtered_error: DockingError,
    ) -> tuple[ForkliftAction, str]:
        """Schmitt-triggered bidirectional closure with task-space steering."""
        p = self.parameters
        deadband = p.placement_precision_longitudinal_deadband
        switch = p.placement_precision_direction_switch_hysteresis
        direction = self._placement_precision_direction

        if direction > 0:
            if command_longitudinal < -switch:
                direction = -1
            elif command_longitudinal <= deadband:
                direction = 0
        elif direction < 0:
            if command_longitudinal > switch:
                direction = 1
            elif command_longitudinal >= -deadband:
                direction = 0
        else:
            if command_longitudinal > switch:
                direction = 1
            elif command_longitudinal < -switch:
                direction = -1

        self._placement_precision_set_direction(direction)
        forward_speed = self._vehicle_forward_speed(observation)
        epsilon = p.placement_precision_direction_change_speed_epsilon

        if direction > 0:
            if forward_speed < -epsilon:
                self._placement_precision_hold_frame_count += 1
                return (
                    ForkliftAction.stopped(
                        lift_target=p.transport_lift_target
                    ),
                    "V9.3.0 direction-change brake before forward closure",
                )
            residual = max(0.0, command_longitudinal - deadband)
            speed = min(
                p.placement_precision_forward_max_speed,
                p.placement_precision_speed_gain * residual,
            )
            steering = self._placement_precision_task_steering(
                filtered_error, reverse=False
            )
            if speed <= 1e-6:
                self._placement_precision_hold_frame_count += 1
                return (
                    ForkliftAction.stopped(
                        lift_target=p.transport_lift_target
                    ),
                    "V9.3.0 filtered longitudinal deadband hold",
                )
            self._placement_precision_forward_frame_count += 1
            return (
                ForkliftAction(
                    speed_target=float(speed),
                    steering_command=float(steering),
                    lift_target=p.transport_lift_target,
                ),
                "V9.3.0 task-space precision forward closure",
            )

        if direction < 0:
            if forward_speed > epsilon:
                self._placement_precision_hold_frame_count += 1
                return (
                    ForkliftAction.stopped(
                        lift_target=p.transport_lift_target
                    ),
                    "V9.3.0 direction-change brake before reverse closure",
                )
            residual = max(0.0, abs(command_longitudinal) - deadband)
            speed = min(
                p.placement_precision_reverse_max_speed,
                p.placement_precision_speed_gain * residual,
            )
            steering = self._placement_precision_task_steering(
                filtered_error, reverse=True
            )
            if speed <= 1e-6:
                self._placement_precision_hold_frame_count += 1
                return (
                    ForkliftAction.stopped(
                        lift_target=p.transport_lift_target
                    ),
                    "V9.3.0 filtered longitudinal deadband hold",
                )
            self._placement_precision_reverse_frame_count += 1
            return (
                ForkliftAction(
                    speed_target=-float(speed),
                    steering_command=float(steering),
                    lift_target=p.transport_lift_target,
                ),
                "V9.3.0 task-space precision reverse closure",
            )

        self._placement_precision_hold_frame_count += 1
        return (
            ForkliftAction.stopped(lift_target=p.transport_lift_target),
            "V9.3.0 filtered longitudinal deadband hold",
        )

    def _placement_precision_recenter_needed(
        self,
        filtered_error: DockingError,
        filtered_command_longitudinal: float,
    ) -> bool:
        p = self.parameters
        if (
            self._placement_precision_recenter_cycle_count
            >= p.placement_precision_recenter_max_cycles
        ):
            return False
        geometry_bad = (
            abs(float(filtered_error.lateral))
            >= p.placement_precision_recenter_trigger_lateral
            or abs(float(filtered_error.yaw))
            >= p.placement_precision_recenter_trigger_yaw
        )
        return (
            geometry_bad
            and abs(float(filtered_command_longitudinal))
            <= p.placement_precision_recenter_activation_longitudinal
        )

    def _placement_precision_start_recenter(
        self,
        observation: ForkliftObservation,
    ) -> None:
        pose = observation.vehicle_pose_world
        self._placement_precision_phase = "RECENTER_REVERSE"
        self._placement_precision_recenter_start_xy = (
            float(pose.x),
            float(pose.y),
        )
        self._placement_precision_recenter_start_time = float(
            observation.sim_time
        )
        self._placement_precision_recenter_travel_m = 0.0
        self._placement_precision_recenter_cycle_count += 1
        self._placement_precision_set_direction(-1)
        self._placement_condition_since = None

    def _placement_precision_recenter_action(
        self,
        observation: ForkliftObservation,
        filtered_error: DockingError,
    ) -> tuple[ForkliftAction, str, bool]:
        """Execute one bounded reverse S-curve stroke.

        The reverse stroke creates the path length an Ackermann vehicle needs
        to reduce lateral/yaw error.  It is capped to a few decimetres and
        therefore cannot recreate the V9.2.1/V9.2.2 metre-scale recovery loop.
        """
        p = self.parameters
        pose = observation.vehicle_pose_world
        if self._placement_precision_recenter_start_xy is None:
            self._placement_precision_start_recenter(observation)
        assert self._placement_precision_recenter_start_xy is not None
        start_x, start_y = self._placement_precision_recenter_start_xy
        travelled = math.hypot(
            float(pose.x) - float(start_x),
            float(pose.y) - float(start_y),
        )
        self._placement_precision_recenter_travel_m = float(travelled)
        elapsed = (
            0.0
            if self._placement_precision_recenter_start_time is None
            else max(
                0.0,
                float(observation.sim_time)
                - self._placement_precision_recenter_start_time,
            )
        )
        geometry_ready = (
            abs(float(filtered_error.lateral))
            <= p.placement_precision_recenter_exit_lateral
            and abs(float(filtered_error.yaw))
            <= p.placement_precision_recenter_exit_yaw
        )
        finished = (
            (
                travelled >= p.placement_precision_recenter_min_distance
                and geometry_ready
            )
            or travelled >= p.placement_precision_recenter_max_distance
            or elapsed >= p.placement_precision_recenter_max_seconds
        )
        if finished:
            # V9.3.0: do not throw the vehicle back to coarse PLACE_ALIGN as
            # soon as a bounded reverse stroke creates useful runway.  The
            # V9.2.5 failure traces showed a deterministic limit cycle:
            # recenter -> ~0.35-0.45 m runway -> capture-loss reentry ->
            # forward-only PLACE_ALIGN -> same bad terminal geometry.  Keep
            # ownership in PLACE_PRECISION and let the MPC exploit the runway.
            self._placement_precision_phase = "MPC_REJOIN"
            self._placement_precision_rejoin_start_time = float(
                observation.sim_time
            )
            self._placement_precision_recenter_start_xy = None
            self._placement_precision_recenter_start_time = None
            self._placement_precision_recenter_travel_m = 0.0
            self._placement_precision_set_direction(0)
            self._placement_precision_best_score = None
            self._placement_precision_best_distance = None
            self._placement_precision_last_progress_time = float(
                observation.sim_time
            )
            self._placement_precision_hold_frame_count += 1
            return (
                ForkliftAction.stopped(lift_target=p.transport_lift_target),
                "V9.3.0 bounded precision recenter stroke completed",
                True,
            )

        forward_speed = self._vehicle_forward_speed(observation)
        if (
            forward_speed
            > p.placement_precision_direction_change_speed_epsilon
        ):
            self._placement_precision_hold_frame_count += 1
            return (
                ForkliftAction.stopped(lift_target=p.transport_lift_target),
                "V9.3.0 braking before bounded precision recenter reverse",
                False,
            )

        steering = self._placement_precision_task_steering(
            filtered_error, reverse=True
        )
        self._placement_precision_reverse_frame_count += 1
        self._placement_precision_recenter_frame_count += 1
        return (
            ForkliftAction(
                speed_target=-min(
                    p.placement_precision_reverse_max_speed,
                    p.placement_precision_recenter_reverse_speed,
                ),
                steering_command=float(steering),
                lift_target=p.transport_lift_target,
            ),
            (
                "V9.3.0 bounded reverse S-curve recenter "
                f"({travelled:.3f}/"
                f"{p.placement_precision_recenter_max_distance:.3f}m)"
            ),
            False,
        )

    def _v925_mpc_enabled(self) -> bool:
        return (
            self._v924_precision_enabled()
            and self.parameters.placement_mpc_enabled > 0.0
        )

    def _terminal_mpc_controller(self) -> TerminalKinematicMPC:
        if self._terminal_mpc is None:
            p = self.parameters
            terminal_scale = p.placement_mpc_terminal_scale
            self._terminal_mpc = TerminalKinematicMPC(
                TerminalMPCConfig(
                    wheelbase=p.transport_path_wheelbase,
                    horizon_steps=p.placement_mpc_horizon_steps,
                    prediction_dt=p.placement_mpc_prediction_dt,
                    forward_max_speed=p.placement_mpc_forward_max_speed,
                    reverse_max_speed=p.placement_mpc_reverse_max_speed,
                    steering_limit=p.placement_mpc_steering_limit,
                    speed_gain=p.placement_precision_speed_gain,
                    geometry_speed_floor=p.placement_mpc_geometry_speed_floor,
                    geometry_trigger_lateral=min(
                        p.placement_precision_recenter_trigger_lateral, 0.055
                    ),
                    geometry_trigger_yaw=min(
                        p.placement_precision_recenter_trigger_yaw,
                        math.radians(3.0),
                    ),
                    trust_radius=p.placement_mpc_trust_radius,
                    weight_longitudinal=2.0,
                    weight_lateral=p.placement_mpc_weight_lateral,
                    weight_yaw=p.placement_mpc_weight_yaw,
                    terminal_weight_longitudinal=2.0 * terminal_scale,
                    terminal_weight_lateral=p.placement_mpc_weight_lateral * terminal_scale,
                    terminal_weight_yaw=p.placement_mpc_weight_yaw * terminal_scale,
                    weight_speed=0.02,
                    weight_steering=0.08,
                    weight_steering_change=0.08,
                    reverse_penalty=0.002,
                    # V9.3.0: V9.2.5 finals traces showed 130-151 physical
                    # direction switches in several near-goal episodes.  The
                    # first-action Schmitt lock below is the main protection;
                    # this larger horizon penalty also discourages gratuitous
                    # FWD_REV/REV_FWD plans when a single-direction approach
                    # has comparable geometric cost.
                    direction_switch_penalty=0.15,
                    task_lateral_gain=p.placement_precision_task_lateral_gain,
                    task_yaw_gain=p.placement_precision_task_yaw_gain,
                    task_lookahead=p.placement_precision_task_lookahead,
                )
            )
        return self._terminal_mpc

    def _placement_mpc_action(
        self,
        observation: ForkliftObservation,
        *,
        command_error: DockingError,
        filtered_error: DockingError,
        filtered_command_longitudinal: float,
        placement_vision_ready: bool,
    ) -> tuple[ForkliftAction, str, bool]:
        """Run or reuse the cached V9.3.0 terminal MPC solution."""
        p = self.parameters
        now = float(observation.sim_time)
        current_speed = self._vehicle_forward_speed(observation)

        # V9.3.12-R4-E5: full-pose, load-offset-aware POSITION recenter.
        #
        # E4 physically validated steering conditioning and odometry closure:
        # the commanded 0.300 m departure became 0.297 m truth path with the
        # expected Ackermann yaw.  Its remaining 8.4 cm midpoint mismatch came
        # from propagating DockingError as a target pose, which omits the rigid
        # carried-load lever arm under vehicle rotation.  E5 therefore:
        #   1) plans in full pose space (rigid load + world-fixed targets);
        #   2) uses fresh RGB midpoint poses directly for one RETURN replan;
        #   3) treats model-vs-measurement midpoint error as diagnostic only;
        #   4) retraces the completed DEPART arc if midpoint/replan authority
        #      fails before RETURN, instead of abandoning the vehicle at the
        #      excursion apex.
        # Release authority remains unchanged: Supervisor -> instantaneous
        # STRICT -> Witness -> execute.
        recenter_plan = self._position_blocker_recenter_active
        if recenter_plan is not None or self._position_blocker_recenter_phase != "IDLE":
            epsilon = p.placement_precision_direction_change_speed_epsilon
            live_distance = float(filtered_error.distance)
            live_abs_yaw = abs(float(filtered_error.yaw))

            def _measured_effective_steering() -> float:
                measured = -0.5 * (
                    float(observation.steering_left)
                    + float(observation.steering_right)
                )
                self._position_blocker_recenter_last_effective_steering_rad = float(measured)
                return float(measured)

            def _reset_leg_odometry() -> None:
                self._position_blocker_recenter_leg_start_time = now
                self._position_blocker_recenter_odom_last_x = float(
                    observation.vehicle_pose_world.x
                )
                self._position_blocker_recenter_odom_last_y = float(
                    observation.vehicle_pose_world.y
                )
                self._position_blocker_recenter_odom_distance_m = 0.0

            def _update_leg_odometry() -> float:
                x = float(observation.vehicle_pose_world.x)
                y = float(observation.vehicle_pose_world.y)
                if (
                    self._position_blocker_recenter_odom_last_x is None
                    or self._position_blocker_recenter_odom_last_y is None
                ):
                    self._position_blocker_recenter_odom_last_x = x
                    self._position_blocker_recenter_odom_last_y = y
                    return float(self._position_blocker_recenter_odom_distance_m)
                self._position_blocker_recenter_odom_distance_m += math.hypot(
                    x - float(self._position_blocker_recenter_odom_last_x),
                    y - float(self._position_blocker_recenter_odom_last_y),
                )
                self._position_blocker_recenter_odom_last_x = x
                self._position_blocker_recenter_odom_last_y = y
                return float(self._position_blocker_recenter_odom_distance_m)

            def _reset_motion_odom_state() -> None:
                self._position_blocker_recenter_leg_start_time = None
                self._position_blocker_recenter_odom_last_x = None
                self._position_blocker_recenter_odom_last_y = None
                self._position_blocker_recenter_odom_distance_m = 0.0

            def _begin_departure_rollback(reason: str) -> bool:
                """Own the chassis until the completed DEPART arc is retraced."""
                if recenter_plan is None:
                    return False
                target = float(self._position_blocker_recenter_last_departure_odometry_m)
                if target <= 1e-4:
                    return False
                self._position_blocker_recenter_rollback_count += 1
                self._position_blocker_recenter_rollback_reason = str(reason)
                self._position_blocker_recenter_rollback_target_odometry_m = target
                self._position_blocker_recenter_return_active = None
                self._position_blocker_recenter_phase = "ROLLBACK_PRESTEER"
                self._position_blocker_recenter_presteer_start_time = None
                self._position_blocker_recenter_rollback_settle_until = None
                self._position_blocker_recenter_rollback_settle_deadline = None
                self._position_blocker_recenter_rollback_rgb_updates = 0
                _reset_motion_odom_state()
                self._placement_mpc_last_plan = None
                self._placement_mpc_last_solve_time = None
                self._placement_precision_set_direction(0)
                return True

            def _begin_completed_macro_rollback(reason: str) -> bool:
                """Undo the completed RETURN first, then retrace DEPART.

                E5 only guaranteed rollback for failures *before* a successful
                RETURN.  Its actual hard-tail failed after final RGB feedback,
                so ownership was released while the macro state was still
                uncertified.  E6 closes that missing failure edge.
                """
                completed = self._position_blocker_recenter_completed_return_plan
                completed_distance = float(
                    self._position_blocker_recenter_last_return_odometry_m
                )
                if completed is None or completed_distance <= 1e-4:
                    return _begin_departure_rollback(reason)
                self._position_blocker_recenter_rollback_count += 1
                self._position_blocker_recenter_rollback_reason = str(reason)
                self._position_blocker_recenter_return_active = completed
                self._position_blocker_recenter_return_unwind_target_odometry_m = (
                    completed_distance
                )
                self._position_blocker_recenter_phase = (
                    "ROLLBACK_RETURN_UNWIND_PRESTEER"
                )
                self._position_blocker_recenter_presteer_start_time = None
                self._position_blocker_recenter_rollback_settle_until = None
                self._position_blocker_recenter_rollback_settle_deadline = None
                self._position_blocker_recenter_rollback_rgb_updates = 0
                _reset_motion_odom_state()
                self._placement_mpc_last_plan = None
                self._placement_mpc_last_solve_time = None
                self._placement_precision_set_direction(0)
                return True

            def _hard_stop_recenter(reason: str, *, rollback_failure: bool = False) -> tuple[ForkliftAction, str, bool]:
                self._position_blocker_recenter_abort_count += 1
                if rollback_failure:
                    self._position_blocker_recenter_rollback_failure_count += 1
                self._position_blocker_recenter_active = None
                self._position_blocker_recenter_return_active = None
                self._position_blocker_recenter_completed_return_plan = None
                self._position_blocker_recenter_phase = "IDLE"
                self._position_blocker_recenter_feedback_blocked = True
                self._position_blocker_recenter_full_pose_model_active = False
                self._post_closure_basin_ownership_active = False
                self._placement_mpc_last_plan = None
                self._placement_mpc_last_solve_time = None
                self._placement_precision_set_direction(0)
                _reset_motion_odom_state()
                return (
                    ForkliftAction.stopped(lift_target=p.transport_lift_target),
                    str(reason),
                    True,
                )

            if (
                live_distance > p.placement_position_blocker_recenter_hard_abort_distance_m
                or live_abs_yaw > p.placement_position_blocker_recenter_hard_abort_yaw_rad
            ):
                return _hard_stop_recenter(
                    "V9.3.12-R4-E5 recenter HARD SAFETY ABORT; "
                    f"live={live_distance:.3f}m/{math.degrees(live_abs_yaw):.1f}deg",
                    rollback_failure=self._position_blocker_recenter_phase.startswith("ROLLBACK"),
                )

            if self._position_blocker_recenter_phase == "DEPART_PRESTEER":
                assert recenter_plan is not None
                desired = float(recenter_plan.departure_steering_rad)
                measured = _measured_effective_steering()
                if self._position_blocker_recenter_presteer_start_time is None:
                    self._position_blocker_recenter_presteer_start_time = now
                ready = (
                    abs(measured - desired)
                    <= p.placement_position_blocker_recenter_presteer_ready_tolerance_rad
                )
                timed_out = (
                    now - float(self._position_blocker_recenter_presteer_start_time)
                    >= p.placement_position_blocker_recenter_presteer_max_seconds
                )
                if ready:
                    self._position_blocker_recenter_phase = "DEPART"
                    self._position_blocker_recenter_presteer_start_time = None
                    _reset_leg_odometry()
                    self._placement_precision_set_direction(0)
                    return (
                        ForkliftAction(
                            speed_target=0.0,
                            steering_command=desired,
                            lift_target=p.transport_lift_target,
                        ),
                        (
                            "V9.3.12-R4-E5 DEPART presteer READY "
                            f"measured={measured:.3f} target={desired:.3f}"
                        ),
                        True,
                    )
                if timed_out:
                    self._position_blocker_recenter_presteer_timeout_count += 1
                    return _hard_stop_recenter(
                        "V9.3.12-R4-E5 DEPART presteer TIMEOUT "
                        f"measured={measured:.3f} target={desired:.3f}"
                    )
                overdrive = math.copysign(
                    p.placement_position_blocker_recenter_presteer_command_rad,
                    desired,
                )
                self._placement_precision_set_direction(0)
                self._placement_precision_hold_frame_count += 1
                return (
                    ForkliftAction(
                        speed_target=0.0,
                        steering_command=overdrive,
                        lift_target=p.transport_lift_target,
                    ),
                    (
                        "V9.3.12-R4-E5 DEPART presteer "
                        f"measured={measured:.3f} target={desired:.3f}"
                    ),
                    True,
                )

            if self._position_blocker_recenter_phase == "DEPART":
                assert recenter_plan is not None
                requested_speed = float(recenter_plan.departure_speed_mps)
                requested_steering = float(recenter_plan.departure_steering_rad)
                if self._position_blocker_recenter_leg_start_time is None:
                    _reset_leg_odometry()
                traveled = _update_leg_odometry()
                target_travel = abs(
                    requested_speed * float(recenter_plan.departure_duration_seconds)
                )
                elapsed = max(
                    0.0,
                    now - float(self._position_blocker_recenter_leg_start_time or now),
                )
                timed_out = (
                    elapsed
                    >= float(recenter_plan.departure_duration_seconds)
                    * p.placement_position_blocker_recenter_odometry_timeout_scale
                )
                if traveled + 1e-4 < target_travel and not timed_out:
                    direction = 1 if requested_speed > 0.0 else -1
                    self._placement_precision_set_direction(direction)
                    if direction > 0:
                        self._placement_precision_forward_frame_count += 1
                    else:
                        self._placement_precision_reverse_frame_count += 1
                    return (
                        ForkliftAction(
                            speed_target=requested_speed,
                            steering_command=requested_steering,
                            lift_target=p.transport_lift_target,
                        ),
                        (
                            "V9.3.12-R4-E5 DEPART odom "
                            f"{traveled:.3f}/{target_travel:.3f}m"
                        ),
                        True,
                    )
                if timed_out and traveled + 1e-3 < target_travel:
                    self._position_blocker_recenter_presteer_timeout_count += 1
                    return _hard_stop_recenter(
                        "V9.3.12-R4-E5 DEPART odometry TIMEOUT "
                        f"{traveled:.3f}/{target_travel:.3f}m"
                    )
                self._position_blocker_recenter_last_departure_odometry_m = float(traveled)
                _reset_motion_odom_state()
                self._position_blocker_recenter_phase = "MID_BRAKE"

            if self._position_blocker_recenter_phase == "MID_BRAKE":
                if abs(current_speed) > epsilon:
                    self._placement_precision_set_direction(0)
                    self._placement_precision_hold_frame_count += 1
                    return (
                        ForkliftAction.stopped(lift_target=p.transport_lift_target),
                        "V9.3.12-R4-E5 midpoint brake",
                        True,
                    )
                self._position_blocker_recenter_phase = "MID_RGB_SETTLE"

            if self._position_blocker_recenter_phase == "MID_RGB_SETTLE":
                assert recenter_plan is not None
                if self._position_blocker_recenter_mid_settle_until is None:
                    self._position_blocker_recenter_mid_settle_until = (
                        now + p.placement_position_blocker_recenter_midpoint_settle_seconds
                    )
                    self._position_blocker_recenter_mid_settle_deadline = (
                        now + p.placement_position_blocker_recenter_midpoint_max_wait_seconds
                    )
                    self._position_blocker_recenter_mid_start_update_count = (
                        self._terminal_load_reacquisition_update_count
                    )
                updates = max(
                    0,
                    int(self._terminal_load_reacquisition_update_count)
                    - int(self._position_blocker_recenter_mid_start_update_count),
                )
                self._position_blocker_recenter_mid_rgb_updates = updates
                settle_done = now >= float(self._position_blocker_recenter_mid_settle_until)
                deadline_done = bool(
                    self._position_blocker_recenter_mid_settle_deadline is not None
                    and now >= float(self._position_blocker_recenter_mid_settle_deadline)
                )
                updates_ready = (
                    updates >= p.placement_position_blocker_recenter_midpoint_minimum_rgb_updates
                )
                if settle_done and updates_ready:
                    # E5 diagnostic only: compare the instantaneous task error
                    # with the full-pose preview.  Unlike E4, this is not an
                    # authority gate; fresh poses are the return-planning state.
                    live_task_error = self._load_to_placement_error(observation)
                    position_deviation = math.hypot(
                        float(live_task_error.longitudinal)
                        - float(recenter_plan.predicted_mid_filtered_x_m),
                        float(live_task_error.lateral)
                        - float(recenter_plan.predicted_mid_filtered_y_m),
                    )
                    yaw_deviation = abs(
                        wrap_angle(
                            float(live_task_error.yaw)
                            - float(recenter_plan.predicted_mid_filtered_yaw_rad)
                        )
                    )
                    self._position_blocker_recenter_midpoint_position_deviation_m = float(
                        position_deviation
                    )
                    self._position_blocker_recenter_midpoint_yaw_deviation_rad = float(
                        yaw_deviation
                    )

                    certification_error = self._load_to_certification_error(observation)
                    budget_remaining = max(
                        0.0,
                        p.placement_terminal_budget_seconds - self.placement_terminal_elapsed(now),
                    )
                    position_margin = max(
                        0.0,
                        float(self._strict_release_certification_last_position_margin_m),
                    )
                    yaw_margin = math.radians(
                        max(
                            0.0,
                            float(self._strict_release_certification_last_yaw_margin_deg),
                        )
                    )
                    load_pose = self._effective_pallet_pose_in_base(observation)
                    task_target_pose = observation.placement_pose_in_base
                    certification_target_pose = self._certification_target_pose_in_base(observation)
                    return_plan = self._position_blocker_recenter_controller().search_return(
                        filtered_x_m=float(filtered_error.longitudinal),
                        filtered_y_m=float(filtered_error.lateral),
                        filtered_yaw_rad=float(filtered_error.yaw),
                        certification_x_m=float(certification_error.longitudinal),
                        certification_y_m=float(certification_error.lateral),
                        certification_yaw_rad=float(certification_error.yaw),
                        position_margin_m=position_margin,
                        yaw_margin_rad=yaw_margin,
                        preferred_speed_sign=(
                            -1 if recenter_plan.nominal_return_speed_mps < 0.0 else 1
                        ),
                        terminal_budget_remaining_s=float(budget_remaining),
                        departure_steering_rad=float(recenter_plan.departure_steering_rad),
                        departure_speed_mps=float(recenter_plan.departure_speed_mps),
                        load_pose_in_base=(
                            float(load_pose.x), float(load_pose.y), float(load_pose.yaw)
                        ),
                        task_target_pose_in_base=(
                            float(task_target_pose.x),
                            float(task_target_pose.y),
                            float(task_target_pose.yaw),
                        ),
                        certification_target_pose_in_base=(
                            float(certification_target_pose.x),
                            float(certification_target_pose.y),
                            float(certification_target_pose.yaw),
                        ),
                    )
                    if return_plan is not None:
                        self._position_blocker_recenter_return_active = return_plan
                        self._position_blocker_recenter_phase = "RETURN_PRESTEER"
                        self._position_blocker_recenter_presteer_start_time = None
                        self._position_blocker_recenter_mid_settle_until = None
                        self._position_blocker_recenter_mid_settle_deadline = None
                        return (
                            ForkliftAction.stopped(lift_target=p.transport_lift_target),
                            (
                                "V9.3.12-R4-E5 fresh full-pose RETURN selected; "
                                f"diag-dev={position_deviation:.3f}m/"
                                f"{math.degrees(yaw_deviation):.2f}deg "
                                f"pred={return_plan.predicted_effective_position_m:.3f}m/"
                                f"{math.degrees(return_plan.predicted_effective_yaw_rad):.2f}deg"
                            ),
                            True,
                        )
                    self._position_blocker_recenter_midpoint_replan_fail_count += 1
                    self._position_blocker_recenter_abort_count += 1
                    if _begin_departure_rollback("MIDPOINT_RETURN_UNAVAILABLE"):
                        return (
                            ForkliftAction.stopped(lift_target=p.transport_lift_target),
                            (
                                "V9.3.12-R4-E5 fresh RETURN unavailable -> guaranteed rollback; "
                                f"diag-dev={position_deviation:.3f}m/"
                                f"{math.degrees(yaw_deviation):.2f}deg"
                            ),
                            True,
                        )
                    return _hard_stop_recenter(
                        "V9.3.12-R4-E5 fresh RETURN unavailable and rollback unavailable"
                    )
                if deadline_done:
                    self._position_blocker_recenter_midpoint_replan_fail_count += 1
                    self._position_blocker_recenter_abort_count += 1
                    if _begin_departure_rollback("MIDPOINT_RGB_TIMEOUT"):
                        return (
                            ForkliftAction.stopped(lift_target=p.transport_lift_target),
                            "V9.3.12-R4-E5 midpoint RGB timeout -> guaranteed rollback",
                            True,
                        )
                    return _hard_stop_recenter(
                        "V9.3.12-R4-E5 midpoint RGB timeout and rollback unavailable"
                    )
                self._placement_mpc_last_plan = None
                self._placement_mpc_last_solve_time = None
                self._placement_precision_set_direction(0)
                self._placement_precision_hold_frame_count += 1
                return (
                    ForkliftAction.stopped(lift_target=p.transport_lift_target),
                    (
                        "V9.3.12-R4-E5 midpoint RGB settle "
                        f"updates={updates}/{p.placement_position_blocker_recenter_midpoint_minimum_rgb_updates}"
                    ),
                    True,
                )

            if self._position_blocker_recenter_phase == "RETURN_PRESTEER":
                return_plan = self._position_blocker_recenter_return_active
                assert return_plan is not None
                desired = float(return_plan.steering_rad)
                measured = _measured_effective_steering()
                if self._position_blocker_recenter_presteer_start_time is None:
                    self._position_blocker_recenter_presteer_start_time = now
                ready = (
                    abs(measured - desired)
                    <= p.placement_position_blocker_recenter_presteer_ready_tolerance_rad
                )
                timed_out = (
                    now - float(self._position_blocker_recenter_presteer_start_time)
                    >= p.placement_position_blocker_recenter_presteer_max_seconds
                )
                if ready:
                    self._position_blocker_recenter_phase = "RETURN"
                    self._position_blocker_recenter_presteer_start_time = None
                    _reset_leg_odometry()
                    return (
                        ForkliftAction(
                            speed_target=0.0,
                            steering_command=desired,
                            lift_target=p.transport_lift_target,
                        ),
                        (
                            "V9.3.12-R4-E5 RETURN presteer READY "
                            f"measured={measured:.3f} target={desired:.3f}"
                        ),
                        True,
                    )
                if timed_out:
                    self._position_blocker_recenter_presteer_timeout_count += 1
                    self._position_blocker_recenter_abort_count += 1
                    if _begin_departure_rollback("RETURN_PRESTEER_TIMEOUT"):
                        return (
                            ForkliftAction.stopped(lift_target=p.transport_lift_target),
                            "V9.3.12-R4-E5 RETURN presteer timeout -> guaranteed rollback",
                            True,
                        )
                    return _hard_stop_recenter(
                        "V9.3.12-R4-E5 RETURN presteer timeout and rollback unavailable"
                    )
                overdrive = math.copysign(
                    p.placement_position_blocker_recenter_presteer_command_rad,
                    desired,
                )
                self._placement_precision_set_direction(0)
                self._placement_precision_hold_frame_count += 1
                return (
                    ForkliftAction(
                        speed_target=0.0,
                        steering_command=overdrive,
                        lift_target=p.transport_lift_target,
                    ),
                    (
                        "V9.3.12-R4-E5 RETURN presteer "
                        f"measured={measured:.3f} target={desired:.3f}"
                    ),
                    True,
                )

            if self._position_blocker_recenter_phase == "RETURN":
                return_plan = self._position_blocker_recenter_return_active
                assert return_plan is not None
                certification_error = self._load_to_certification_error(observation)
                live_effective_position = float(
                    certification_error.distance
                    + max(0.0, self._strict_release_certification_last_position_margin_m)
                )
                live_effective_yaw = float(
                    abs(certification_error.yaw)
                    + math.radians(
                        max(0.0, self._strict_release_certification_last_yaw_margin_deg)
                    )
                )
                if (
                    filtered_error.distance
                    <= p.placement_position_blocker_recenter_final_filtered_position_guard_m
                    and abs(filtered_error.yaw)
                    <= p.placement_position_blocker_recenter_final_filtered_yaw_guard_rad
                    and live_effective_position
                    <= p.placement_strict_release_position_limit_m
                    and live_effective_yaw
                    <= p.placement_strict_release_yaw_limit_rad
                ):
                    self._position_blocker_recenter_return_active = None
                    self._position_blocker_recenter_phase = "FINAL_RGB_SETTLE"
                    _reset_motion_odom_state()
                    return (
                        ForkliftAction.stopped(lift_target=p.transport_lift_target),
                        (
                            "V9.3.12-R4-E5 live strict capture; "
                            f"effective={live_effective_position:.3f}m/"
                            f"{math.degrees(live_effective_yaw):.2f}deg"
                        ),
                        True,
                    )

                requested_speed = float(return_plan.speed_mps)
                requested_steering = float(return_plan.steering_rad)
                if self._position_blocker_recenter_leg_start_time is None:
                    _reset_leg_odometry()
                traveled = _update_leg_odometry()
                target_travel = abs(
                    requested_speed * float(return_plan.duration_seconds)
                )
                elapsed = max(
                    0.0,
                    now - float(self._position_blocker_recenter_leg_start_time or now),
                )
                timed_out = (
                    elapsed
                    >= float(return_plan.duration_seconds)
                    * p.placement_position_blocker_recenter_odometry_timeout_scale
                )
                if traveled + 1e-4 < target_travel and not timed_out:
                    direction = 1 if requested_speed > 0.0 else -1
                    self._placement_precision_set_direction(direction)
                    if direction > 0:
                        self._placement_precision_forward_frame_count += 1
                    else:
                        self._placement_precision_reverse_frame_count += 1
                    return (
                        ForkliftAction(
                            speed_target=requested_speed,
                            steering_command=requested_steering,
                            lift_target=p.transport_lift_target,
                        ),
                        (
                            "V9.3.12-R4-E5 RETURN odom "
                            f"{traveled:.3f}/{target_travel:.3f}m"
                        ),
                        True,
                    )
                if timed_out and traveled + 1e-3 < target_travel:
                    # The return has already moved.  First retrace that partial
                    # return to the RGB midpoint, then retrace DEPART.
                    self._position_blocker_recenter_abort_count += 1
                    self._position_blocker_recenter_rollback_count += 1
                    self._position_blocker_recenter_rollback_reason = "RETURN_ODOMETRY_TIMEOUT"
                    self._position_blocker_recenter_return_unwind_target_odometry_m = float(traveled)
                    self._position_blocker_recenter_phase = "ROLLBACK_RETURN_UNWIND_PRESTEER"
                    self._position_blocker_recenter_presteer_start_time = None
                    _reset_motion_odom_state()
                    return (
                        ForkliftAction.stopped(lift_target=p.transport_lift_target),
                        (
                            "V9.3.12-R4-E5 RETURN odometry timeout -> unwind+rollback; "
                            f"partial={traveled:.3f}m"
                        ),
                        True,
                    )
                self._position_blocker_recenter_last_return_odometry_m = float(traveled)
                # E6 keeps the actual fresh-midpoint RETURN command until final
                # evidence adjudication. If the completed macro still fails
                # POSITION, this exact leg can be unwound before DEPART rollback.
                self._position_blocker_recenter_completed_return_plan = return_plan
                self._position_blocker_recenter_return_active = None
                _reset_motion_odom_state()
                self._position_blocker_recenter_phase = "FINAL_RGB_SETTLE"

            if self._position_blocker_recenter_phase == "ROLLBACK_RETURN_UNWIND_PRESTEER":
                return_plan = self._position_blocker_recenter_return_active
                if return_plan is None:
                    return _hard_stop_recenter(
                        "V9.3.12-R4-E5 return-unwind lost return plan",
                        rollback_failure=True,
                    )
                desired = float(return_plan.steering_rad)
                measured = _measured_effective_steering()
                if self._position_blocker_recenter_presteer_start_time is None:
                    self._position_blocker_recenter_presteer_start_time = now
                ready = (
                    abs(measured - desired)
                    <= p.placement_position_blocker_recenter_presteer_ready_tolerance_rad
                )
                timed_out = (
                    now - float(self._position_blocker_recenter_presteer_start_time)
                    >= p.placement_position_blocker_recenter_presteer_max_seconds
                )
                if ready:
                    self._position_blocker_recenter_phase = "ROLLBACK_RETURN_UNWIND"
                    self._position_blocker_recenter_presteer_start_time = None
                    _reset_leg_odometry()
                    return (
                        ForkliftAction(
                            speed_target=0.0,
                            steering_command=desired,
                            lift_target=p.transport_lift_target,
                        ),
                        "V9.3.12-R4-E5 return-unwind presteer READY",
                        True,
                    )
                if timed_out:
                    return _hard_stop_recenter(
                        "V9.3.12-R4-E5 return-unwind presteer TIMEOUT",
                        rollback_failure=True,
                    )
                overdrive = math.copysign(
                    p.placement_position_blocker_recenter_presteer_command_rad,
                    desired,
                )
                return (
                    ForkliftAction(
                        speed_target=0.0,
                        steering_command=overdrive,
                        lift_target=p.transport_lift_target,
                    ),
                    "V9.3.12-R4-E5 return-unwind presteer",
                    True,
                )

            if self._position_blocker_recenter_phase == "ROLLBACK_RETURN_UNWIND":
                return_plan = self._position_blocker_recenter_return_active
                if return_plan is None:
                    return _hard_stop_recenter(
                        "V9.3.12-R4-E5 return-unwind lost return plan",
                        rollback_failure=True,
                    )
                requested_speed = -float(return_plan.speed_mps)
                requested_steering = float(return_plan.steering_rad)
                if self._position_blocker_recenter_leg_start_time is None:
                    _reset_leg_odometry()
                traveled = _update_leg_odometry()
                target = float(self._position_blocker_recenter_return_unwind_target_odometry_m)
                # Use the original return duration scale as a wall-clock fault guard.
                elapsed = max(
                    0.0,
                    now - float(self._position_blocker_recenter_leg_start_time or now),
                )
                timed_out = (
                    elapsed
                    >= float(return_plan.duration_seconds)
                    * p.placement_position_blocker_recenter_odometry_timeout_scale
                )
                if traveled + 1e-4 < target and not timed_out:
                    direction = 1 if requested_speed > 0.0 else -1
                    self._placement_precision_set_direction(direction)
                    return (
                        ForkliftAction(
                            speed_target=requested_speed,
                            steering_command=requested_steering,
                            lift_target=p.transport_lift_target,
                        ),
                        f"V9.3.12-R4-E5 return-unwind odom {traveled:.3f}/{target:.3f}m",
                        True,
                    )
                if timed_out and traveled + 1e-3 < target:
                    return _hard_stop_recenter(
                        "V9.3.12-R4-E5 return-unwind odometry TIMEOUT",
                        rollback_failure=True,
                    )
                self._position_blocker_recenter_last_return_unwind_odometry_m = float(traveled)
                self._position_blocker_recenter_return_active = None
                self._position_blocker_recenter_rollback_target_odometry_m = float(
                    self._position_blocker_recenter_last_departure_odometry_m
                )
                self._position_blocker_recenter_phase = "ROLLBACK_PRESTEER"
                self._position_blocker_recenter_presteer_start_time = None
                _reset_motion_odom_state()

            if self._position_blocker_recenter_phase == "ROLLBACK_PRESTEER":
                if recenter_plan is None:
                    return _hard_stop_recenter(
                        "V9.3.12-R4-E5 rollback lost departure plan",
                        rollback_failure=True,
                    )
                desired = float(recenter_plan.departure_steering_rad)
                measured = _measured_effective_steering()
                if self._position_blocker_recenter_presteer_start_time is None:
                    self._position_blocker_recenter_presteer_start_time = now
                ready = (
                    abs(measured - desired)
                    <= p.placement_position_blocker_recenter_presteer_ready_tolerance_rad
                )
                timed_out = (
                    now - float(self._position_blocker_recenter_presteer_start_time)
                    >= p.placement_position_blocker_recenter_presteer_max_seconds
                )
                if ready:
                    self._position_blocker_recenter_phase = "ROLLBACK"
                    self._position_blocker_recenter_presteer_start_time = None
                    _reset_leg_odometry()
                    return (
                        ForkliftAction(
                            speed_target=0.0,
                            steering_command=desired,
                            lift_target=p.transport_lift_target,
                        ),
                        "V9.3.12-R4-E5 rollback presteer READY",
                        True,
                    )
                if timed_out:
                    return _hard_stop_recenter(
                        "V9.3.12-R4-E5 rollback presteer TIMEOUT",
                        rollback_failure=True,
                    )
                overdrive = math.copysign(
                    p.placement_position_blocker_recenter_presteer_command_rad,
                    desired,
                )
                return (
                    ForkliftAction(
                        speed_target=0.0,
                        steering_command=overdrive,
                        lift_target=p.transport_lift_target,
                    ),
                    (
                        "V9.3.12-R4-E5 rollback presteer "
                        f"measured={measured:.3f} target={desired:.3f}"
                    ),
                    True,
                )

            if self._position_blocker_recenter_phase == "ROLLBACK":
                if recenter_plan is None:
                    return _hard_stop_recenter(
                        "V9.3.12-R4-E5 rollback lost departure plan",
                        rollback_failure=True,
                    )
                requested_speed = -float(recenter_plan.departure_speed_mps)
                requested_steering = float(recenter_plan.departure_steering_rad)
                target = float(self._position_blocker_recenter_rollback_target_odometry_m)
                if self._position_blocker_recenter_leg_start_time is None:
                    _reset_leg_odometry()
                traveled = _update_leg_odometry()
                elapsed = max(
                    0.0,
                    now - float(self._position_blocker_recenter_leg_start_time or now),
                )
                timed_out = (
                    elapsed
                    >= float(recenter_plan.departure_duration_seconds)
                    * p.placement_position_blocker_recenter_odometry_timeout_scale
                )
                if traveled + 1e-4 < target and not timed_out:
                    direction = 1 if requested_speed > 0.0 else -1
                    self._placement_precision_set_direction(direction)
                    return (
                        ForkliftAction(
                            speed_target=requested_speed,
                            steering_command=requested_steering,
                            lift_target=p.transport_lift_target,
                        ),
                        f"V9.3.12-R4-E5 rollback odom {traveled:.3f}/{target:.3f}m",
                        True,
                    )
                if timed_out and traveled + 1e-3 < target:
                    return _hard_stop_recenter(
                        "V9.3.12-R4-E5 rollback odometry TIMEOUT",
                        rollback_failure=True,
                    )
                self._position_blocker_recenter_last_rollback_odometry_m = float(traveled)
                _reset_motion_odom_state()
                self._position_blocker_recenter_phase = "ROLLBACK_BRAKE"

            if self._position_blocker_recenter_phase == "ROLLBACK_BRAKE":
                if abs(current_speed) > epsilon:
                    self._placement_precision_set_direction(0)
                    self._placement_precision_hold_frame_count += 1
                    return (
                        ForkliftAction.stopped(lift_target=p.transport_lift_target),
                        "V9.3.12-R4-E5 rollback brake",
                        True,
                    )
                self._position_blocker_recenter_phase = "ROLLBACK_RGB_SETTLE"

            if self._position_blocker_recenter_phase == "ROLLBACK_RGB_SETTLE":
                if self._position_blocker_recenter_rollback_settle_until is None:
                    self._position_blocker_recenter_rollback_settle_until = (
                        now + p.placement_position_blocker_recenter_midpoint_settle_seconds
                    )
                    self._position_blocker_recenter_rollback_settle_deadline = (
                        now + p.placement_position_blocker_recenter_midpoint_max_wait_seconds
                    )
                    self._position_blocker_recenter_rollback_start_update_count = (
                        self._terminal_load_reacquisition_update_count
                    )
                updates = max(
                    0,
                    int(self._terminal_load_reacquisition_update_count)
                    - int(self._position_blocker_recenter_rollback_start_update_count),
                )
                self._position_blocker_recenter_rollback_rgb_updates = updates
                settle_done = now >= float(self._position_blocker_recenter_rollback_settle_until)
                deadline_done = bool(
                    self._position_blocker_recenter_rollback_settle_deadline is not None
                    and now >= float(self._position_blocker_recenter_rollback_settle_deadline)
                )
                updates_ready = (
                    updates >= p.placement_position_blocker_recenter_midpoint_minimum_rgb_updates
                )
                if not (settle_done and updates_ready) and not deadline_done:
                    self._placement_precision_set_direction(0)
                    self._placement_precision_hold_frame_count += 1
                    return (
                        ForkliftAction.stopped(lift_target=p.transport_lift_target),
                        (
                            "V9.3.12-R4-E5 rollback RGB settle "
                            f"updates={updates}/{p.placement_position_blocker_recenter_midpoint_minimum_rgb_updates}"
                        ),
                        True,
                    )
                safe_return = bool(
                    updates_ready
                    and live_distance
                    <= max(
                        p.placement_position_blocker_recenter_filtered_position_activation_m + 0.03,
                        self._position_blocker_recenter_pre_macro_filtered_position_m + 0.04,
                    )
                    and live_abs_yaw
                    <= max(
                        p.placement_position_blocker_recenter_filtered_yaw_activation_rad + math.radians(1.0),
                        self._position_blocker_recenter_pre_macro_filtered_yaw_rad + math.radians(2.0),
                    )
                )
                if safe_return:
                    self._position_blocker_recenter_rollback_success_count += 1
                else:
                    self._position_blocker_recenter_rollback_failure_count += 1
                self._position_blocker_recenter_active = None
                self._position_blocker_recenter_return_active = None
                self._position_blocker_recenter_completed_return_plan = None
                self._position_blocker_recenter_phase = "IDLE"
                self._position_blocker_recenter_feedback_blocked = True
                self._position_blocker_recenter_full_pose_model_active = False
                # E6 failure-closed ownership: a verified safe rollback returns
                # to the near-pre-macro basin. Keep the post-closure shield so
                # unrestricted ordinary MPC cannot immediately destroy it.
                self._post_closure_basin_ownership_active = bool(safe_return)
                self._placement_mpc_last_plan = None
                self._placement_mpc_last_solve_time = None
                self._placement_precision_set_direction(0)
                return (
                    ForkliftAction.stopped(lift_target=p.transport_lift_target),
                    (
                        "V9.3.12-R4-E5 rollback complete "
                        f"safe={safe_return} updates={updates} reason="
                        f"{self._position_blocker_recenter_rollback_reason}"
                    ),
                    True,
                )

            # Historical regression marker: V9.3.12-R4-E5 final RGB settle.
            # E6 extends this state into FINAL_EVIDENCE_HOLD rather than adjudicating immediately.
            if self._position_blocker_recenter_phase == "FINAL_RGB_SETTLE":
                if self._position_blocker_recenter_final_settle_until is None:
                    self._position_blocker_recenter_final_settle_until = (
                        now + p.placement_position_blocker_recenter_final_settle_seconds
                    )
                    self._position_blocker_recenter_final_settle_deadline = (
                        now + p.placement_position_blocker_recenter_final_max_wait_seconds
                    )
                    self._position_blocker_recenter_final_start_update_count = (
                        self._terminal_load_reacquisition_update_count
                    )
                updates = max(
                    0,
                    int(self._terminal_load_reacquisition_update_count)
                    - int(self._position_blocker_recenter_final_start_update_count),
                )
                self._position_blocker_recenter_final_rgb_updates = updates
                settle_done = now >= float(self._position_blocker_recenter_final_settle_until)
                deadline_done = bool(
                    self._position_blocker_recenter_final_settle_deadline is not None
                    and now >= float(self._position_blocker_recenter_final_settle_deadline)
                )
                updates_ready = (
                    updates >= p.placement_position_blocker_recenter_final_minimum_rgb_updates
                )
                if not (settle_done and updates_ready) and not deadline_done:
                    self._placement_mpc_last_plan = None
                    self._placement_mpc_last_solve_time = None
                    self._placement_precision_set_direction(0)
                    self._placement_precision_hold_frame_count += 1
                    return (
                        ForkliftAction.stopped(lift_target=p.transport_lift_target),
                        (
                            "V9.3.12-R4-E6 final RGB settle "
                            f"updates={updates}/{p.placement_position_blocker_recenter_final_minimum_rgb_updates}"
                        ),
                        True,
                    )
                if not updates_ready:
                    self._position_blocker_recenter_feedback_reject_count += 1
                    self._position_blocker_recenter_abort_count += 1
                    if _begin_completed_macro_rollback("FINAL_RGB_TIMEOUT"):
                        return (
                            ForkliftAction.stopped(lift_target=p.transport_lift_target),
                            "V9.3.12-R4-E6 final RGB timeout -> full macro rollback",
                            True,
                        )
                    return _hard_stop_recenter(
                        "V9.3.12-R4-E6 final RGB timeout and rollback unavailable"
                    )

                # E6 does not adjudicate on the very first minimum sample count.
                # E5 did exactly that while FAST/SLOW target disagreement was at
                # its local maximum, then dropped post-closure ownership.  Hold
                # still and wait for a short run of internally consistent fresh
                # target/load evidence before refreshing strict certification.
                self._position_blocker_recenter_phase = "FINAL_EVIDENCE_HOLD"
                self._position_blocker_recenter_final_evidence_start_time = now
                self._position_blocker_recenter_final_evidence_deadline = (
                    now
                    + p.placement_position_blocker_recenter_final_evidence_max_wait_seconds
                )
                self._position_blocker_recenter_final_evidence_consistent_rgb_updates = 0
                self._position_blocker_recenter_final_evidence_last_update_count = int(
                    self._terminal_load_reacquisition_update_count
                )
                self._placement_mpc_last_plan = None
                self._placement_mpc_last_solve_time = None
                self._placement_precision_set_direction(0)
                self._placement_precision_hold_frame_count += 1
                return (
                    ForkliftAction.stopped(lift_target=p.transport_lift_target),
                    "V9.3.12-R4-E6 final evidence lease armed",
                    True,
                )

            if self._position_blocker_recenter_phase == "FINAL_EVIDENCE_HOLD":
                start_time = self._position_blocker_recenter_final_evidence_start_time
                if start_time is None:
                    start_time = now
                    self._position_blocker_recenter_final_evidence_start_time = now
                deadline = self._position_blocker_recenter_final_evidence_deadline
                if deadline is None:
                    deadline = (
                        now
                        + p.placement_position_blocker_recenter_final_evidence_max_wait_seconds
                    )
                    self._position_blocker_recenter_final_evidence_deadline = deadline

                current_update_count = int(self._terminal_load_reacquisition_update_count)
                update_delta = max(
                    0,
                    current_update_count
                    - int(self._position_blocker_recenter_final_evidence_last_update_count),
                )
                if update_delta > 0:
                    self._position_blocker_recenter_final_evidence_last_update_count = (
                        current_update_count
                    )

                target_consistent = bool(
                    placement_vision_ready
                    and self._placement_target_multiview_ready
                    and self._placement_target_fast_slow_position_disagreement_m is not None
                    and self._placement_target_fast_slow_yaw_disagreement_rad is not None
                    and self._placement_target_multiview_position_spread_m is not None
                    and self._placement_target_multiview_yaw_spread_rad is not None
                    and self._placement_target_fast_slow_position_disagreement_m
                    <= p.placement_certified_basin_consensus_max_fast_slow_position_m
                    and self._placement_target_fast_slow_yaw_disagreement_rad
                    <= p.placement_certified_basin_consensus_max_fast_slow_yaw_rad
                    and self._placement_target_multiview_position_spread_m
                    <= p.placement_certified_basin_consensus_max_target_position_spread_m
                    and self._placement_target_multiview_yaw_spread_rad
                    <= p.placement_certified_basin_consensus_max_target_yaw_spread_rad
                    and abs(current_speed) <= p.placement_precision_release_max_speed
                )
                if update_delta > 0:
                    if target_consistent:
                        self._position_blocker_recenter_final_evidence_consistent_rgb_updates += (
                            update_delta
                        )
                    else:
                        # Require *consecutive* fresh evidence. A transient
                        # FAST/SLOW split cannot certify or end the lease.
                        self._position_blocker_recenter_final_evidence_consistent_rgb_updates = 0

                hold_done = bool(
                    now - float(start_time)
                    >= p.placement_position_blocker_recenter_final_evidence_hold_seconds
                )
                evidence_ready = bool(
                    hold_done
                    and target_consistent
                    and self._position_blocker_recenter_final_evidence_consistent_rgb_updates
                    >= p.placement_position_blocker_recenter_final_evidence_minimum_consistent_rgb_updates
                )
                deadline_done = now >= float(deadline)

                if evidence_ready and update_delta > 0:
                    certification_error = self._load_to_strict_release_error(observation)
                    self._position_blocker_recenter_final_live_strict_attempt_count += 1
                    # Refresh the exact current uncertainty budget and blocker.
                    # This is a certification *assessment* only. Supervisor,
                    # Witness and execute authority remain unchanged.
                    strict_now = self._strict_release_certified(
                        certification_error=certification_error,
                        now=now,
                        placement_vision_ready=placement_vision_ready,
                    )
                    effective_position = float(
                        certification_error.distance
                        + max(
                            0.0,
                            self._strict_release_certification_last_position_margin_m,
                        )
                    )
                    effective_yaw = float(
                        abs(certification_error.yaw)
                        + math.radians(
                            max(
                                0.0,
                                self._strict_release_certification_last_yaw_margin_deg,
                            )
                        )
                    )
                    self._position_blocker_recenter_last_measured_effective_position_m = (
                        effective_position
                    )
                    self._position_blocker_recenter_last_measured_effective_yaw_rad = (
                        effective_yaw
                    )
                    reference = self._position_blocker_recenter_reference_effective_position_m
                    improvement = (
                        0.0 if reference is None else float(reference) - effective_position
                    )
                    self._position_blocker_recenter_last_measured_position_improvement_m = (
                        float(improvement)
                    )

                    if strict_now:
                        # Keep the basin shield; on the next control frame the
                        # unchanged Release Supervisor gets first priority.
                        self._post_closure_basin_ownership_active = True
                        self._position_blocker_recenter_feedback_blocked = False
                        self._position_blocker_recenter_yaw_handoff_ready = False
                        self._position_blocker_recenter_active = None
                        self._position_blocker_recenter_return_active = None
                        self._position_blocker_recenter_completed_return_plan = None
                        self._position_blocker_recenter_phase = "IDLE"
                        self._position_blocker_recenter_full_pose_model_active = False
                        self._placement_mpc_last_plan = None
                        self._placement_mpc_last_solve_time = None
                        self._placement_precision_set_direction(0)
                        self._placement_precision_hold_frame_count += 1
                        return (
                            ForkliftAction.stopped(lift_target=p.transport_lift_target),
                            (
                                "V9.3.12-R4-E6 final live STRICT refreshed; "
                                f"effective={effective_position:.3f}m/"
                                f"{math.degrees(effective_yaw):.2f}deg -> Supervisor"
                            ),
                            True,
                        )

                    yaw_handoff = bool(
                        effective_position <= p.placement_strict_release_position_limit_m
                        and effective_yaw > p.placement_strict_release_yaw_limit_rad
                        and effective_yaw
                        <= p.placement_position_blocker_recenter_certification_yaw_activation_rad
                    )
                    if yaw_handoff:
                        self._position_blocker_recenter_yaw_handoff_ready = True
                        self._position_blocker_recenter_yaw_handoff_count += 1
                        self._post_closure_basin_ownership_active = True
                        self._position_blocker_recenter_feedback_blocked = False
                        self._position_blocker_recenter_active = None
                        self._position_blocker_recenter_return_active = None
                        self._position_blocker_recenter_completed_return_plan = None
                        self._position_blocker_recenter_phase = "IDLE"
                        self._position_blocker_recenter_full_pose_model_active = False
                        self._placement_mpc_last_plan = None
                        self._placement_mpc_last_solve_time = None
                        self._placement_precision_set_direction(0)
                        return (
                            ForkliftAction.stopped(lift_target=p.transport_lift_target),
                            (
                                "V9.3.12-R4-E6 POSITION cleared -> explicit YAW handoff; "
                                f"effective={effective_position:.3f}m/"
                                f"{math.degrees(effective_yaw):.2f}deg"
                            ),
                            True,
                        )

                if deadline_done:
                    self._position_blocker_recenter_final_evidence_timeout_count += 1
                    self._position_blocker_recenter_feedback_reject_count += 1
                    self._position_blocker_recenter_abort_count += 1
                    self._position_blocker_recenter_feedback_blocked = True
                    if _begin_completed_macro_rollback("FINAL_EVIDENCE_NOT_CERTIFIED"):
                        return (
                            ForkliftAction.stopped(lift_target=p.transport_lift_target),
                            (
                                "V9.3.12-R4-E6 final evidence not certified -> "
                                "unwind RETURN + rollback DEPART"
                            ),
                            True,
                        )
                    return _hard_stop_recenter(
                        "V9.3.12-R4-E6 final evidence failed and rollback unavailable"
                    )

                self._placement_mpc_last_plan = None
                self._placement_mpc_last_solve_time = None
                self._placement_precision_set_direction(0)
                self._placement_precision_hold_frame_count += 1
                return (
                    ForkliftAction.stopped(lift_target=p.transport_lift_target),
                    (
                        "V9.3.12-R4-E6 final evidence hold "
                        f"consistent-updates="
                        f"{self._position_blocker_recenter_final_evidence_consistent_rgb_updates}/"
                        f"{p.placement_position_blocker_recenter_final_evidence_minimum_consistent_rgb_updates}"
                    ),
                    True,
                )

        # V9.3.12-R4-E2: once a strict certification attempt has exposed the
        # conservative residual, execute only the tiny certification-space
        # sequence selected below.  This layer is observation-only motion
        # authority; Supervisor/STRICT/Witness remain the only release path.
        certification_sequence = self._certification_basin_closure_active
        if certification_sequence is not None:
            epsilon = p.placement_precision_direction_change_speed_epsilon
            if self._certification_basin_closure_phase == "LEG1":
                requested_speed = float(certification_sequence.first_speed_mps)
                requested_steering = float(certification_sequence.first_steering_rad)
                if self._certification_basin_closure_leg_end_time is None:
                    if current_speed * requested_speed < 0.0 and abs(current_speed) > epsilon:
                        self._placement_precision_hold_frame_count += 1
                        return (
                            ForkliftAction.stopped(lift_target=p.transport_lift_target),
                            "V9.3.12-R4-E2 certification-basin pre-leg brake",
                            True,
                        )
                    self._certification_basin_closure_leg_end_time = (
                        now + float(certification_sequence.first_duration_seconds)
                    )
                if now < float(self._certification_basin_closure_leg_end_time) - 1e-9:
                    direction = 1 if requested_speed > 0.0 else -1
                    self._placement_precision_set_direction(direction)
                    if direction > 0:
                        self._placement_precision_forward_frame_count += 1
                    else:
                        self._placement_precision_reverse_frame_count += 1
                    return (
                        ForkliftAction(
                            speed_target=requested_speed,
                            steering_command=requested_steering,
                            lift_target=p.transport_lift_target,
                        ),
                        (
                            "V9.3.12-R4-E2 certification-basin LEG1 "
                            f"deficit={certification_sequence.current_strict_deficit:.2f}->"
                            f"{certification_sequence.predicted_strict_deficit:.2f}"
                        ),
                        True,
                    )
                self._certification_basin_closure_leg_end_time = None
                if certification_sequence.has_second_leg:
                    self._certification_basin_closure_phase = "MID_BRAKE"
                else:
                    self._certification_basin_closure_active = None
                    self._certification_basin_closure_phase = "RGB_SETTLE"

            if self._certification_basin_closure_phase == "MID_BRAKE":
                if abs(current_speed) > epsilon:
                    self._placement_precision_set_direction(0)
                    self._placement_precision_hold_frame_count += 1
                    return (
                        ForkliftAction.stopped(lift_target=p.transport_lift_target),
                        "V9.3.12-R4-E2 certification-basin midpoint brake",
                        True,
                    )
                self._certification_basin_closure_phase = "LEG2"

            if self._certification_basin_closure_phase == "LEG2":
                requested_speed = float(certification_sequence.second_speed_mps)
                requested_steering = float(certification_sequence.second_steering_rad)
                if self._certification_basin_closure_leg_end_time is None:
                    self._certification_basin_closure_leg_end_time = (
                        now + float(certification_sequence.second_duration_seconds)
                    )
                if now < float(self._certification_basin_closure_leg_end_time) - 1e-9:
                    direction = 1 if requested_speed > 0.0 else -1
                    self._placement_precision_set_direction(direction)
                    if direction > 0:
                        self._placement_precision_forward_frame_count += 1
                    else:
                        self._placement_precision_reverse_frame_count += 1
                    return (
                        ForkliftAction(
                            speed_target=requested_speed,
                            steering_command=requested_steering,
                            lift_target=p.transport_lift_target,
                        ),
                        "V9.3.12-R4-E2 certification-basin LEG2",
                        True,
                    )
                self._certification_basin_closure_active = None
                self._certification_basin_closure_phase = "RGB_SETTLE"
                self._certification_basin_closure_leg_end_time = None

            if self._certification_basin_closure_phase == "RGB_SETTLE":
                if self._certification_basin_closure_post_settle_until is None:
                    self._certification_basin_closure_post_settle_until = (
                        now + p.placement_certification_basin_closure_post_motion_settle_seconds
                    )
                    self._certification_basin_closure_post_settle_deadline = (
                        now + p.placement_certification_basin_closure_post_motion_max_wait_seconds
                    )
                    self._certification_basin_closure_post_settle_start_update_count = (
                        self._terminal_load_reacquisition_update_count
                    )
                self._placement_mpc_last_plan = None
                self._placement_mpc_last_solve_time = None
                self._placement_precision_set_direction(0)
                self._placement_precision_hold_frame_count += 1
                return (
                    ForkliftAction.stopped(lift_target=p.transport_lift_target),
                    "V9.3.12-R4-E2 certification-basin motion complete; waiting for fresh RGB",
                    True,
                )

        if self._certification_basin_closure_phase == "RGB_SETTLE":
            updates = max(
                0,
                int(self._terminal_load_reacquisition_update_count)
                - int(self._certification_basin_closure_post_settle_start_update_count),
            )
            self._certification_basin_closure_post_motion_rgb_updates = updates
            settle_done = bool(
                self._certification_basin_closure_post_settle_until is not None
                and now >= self._certification_basin_closure_post_settle_until
            )
            deadline_done = bool(
                self._certification_basin_closure_post_settle_deadline is not None
                and now >= self._certification_basin_closure_post_settle_deadline
            )
            updates_ready = (
                updates >= p.placement_certification_basin_closure_minimum_post_motion_rgb_updates
            )
            if not (settle_done and updates_ready) and not deadline_done:
                self._placement_mpc_last_plan = None
                self._placement_mpc_last_solve_time = None
                self._placement_precision_set_direction(0)
                self._placement_precision_hold_frame_count += 1
                return (
                    ForkliftAction.stopped(lift_target=p.transport_lift_target),
                    (
                        "V9.3.12-R4-E2 certification-basin RGB settle "
                        f"updates={updates}/{p.placement_certification_basin_closure_minimum_post_motion_rgb_updates}"
                    ),
                    True,
                )
            certification_error = self._load_to_certification_error(observation)
            self._certification_basin_closure_last_certification_longitudinal_m = float(certification_error.longitudinal)
            self._certification_basin_closure_last_certification_lateral_m = float(certification_error.lateral)
            measured_deficit = self._certification_strict_deficit(certification_error)
            reference_deficit = self._certification_basin_closure_reference_deficit
            measured_improvement = (
                0.0 if reference_deficit is None
                else float(reference_deficit) - float(measured_deficit)
            )
            self._certification_basin_closure_last_measured_deficit_improvement = float(measured_improvement)
            if (
                not updates_ready
                or measured_improvement
                < p.placement_certification_basin_closure_minimum_measured_deficit_improvement
            ):
                self._certification_basin_closure_feedback_reject_count += 1
                self._certification_basin_closure_feedback_blocked = True
            self._certification_basin_closure_phase = "IDLE"
            self._certification_basin_closure_post_settle_until = None
            self._certification_basin_closure_post_settle_deadline = None
            self._certification_basin_closure_reference_deficit = None
            self._placement_mpc_last_plan = None
            self._placement_mpc_last_solve_time = None
            # Hold this frame. On the next frame the unchanged Supervisor gets
            # first opportunity to re-enter SETTLE with the refreshed state.
            self._placement_precision_set_direction(0)
            self._placement_precision_hold_frame_count += 1
            return (
                ForkliftAction.stopped(lift_target=p.transport_lift_target),
                (
                    "V9.3.12-R4-E2 certification-basin feedback "
                    f"deficit improvement={measured_improvement:.2f}"
                ),
                True,
            )

        # V9.3.12-R4-E: execute a selected paired yaw-closure sequence under
        # exclusive motion ownership. Direction reversal is always separated
        # by a physical brake. Once both legs finish, hold long enough for new
        # terminal RGB measurements to update the observer before considering
        # another activation.
        fresh_sequence = self._fresh_rgb_yaw_closure_active
        if fresh_sequence is not None:
            epsilon = p.placement_precision_direction_change_speed_epsilon
            if self._fresh_rgb_yaw_closure_phase == "LEG1":
                requested_speed = float(fresh_sequence.first_speed_mps)
                requested_steering = float(fresh_sequence.first_steering_rad)
                if self._fresh_rgb_yaw_closure_end_time is None:
                    if current_speed * requested_speed < 0.0 and abs(current_speed) > epsilon:
                        self._placement_precision_hold_frame_count += 1
                        return (
                            ForkliftAction.stopped(lift_target=p.transport_lift_target),
                            "V9.3.12-R4-E fresh-RGB yaw closure pre-leg brake",
                            True,
                        )
                    self._fresh_rgb_yaw_closure_end_time = now + float(fresh_sequence.leg_duration_seconds)
                if now < float(self._fresh_rgb_yaw_closure_end_time) - 1e-9:
                    direction = 1 if requested_speed > 0.0 else -1
                    self._placement_precision_set_direction(direction)
                    if direction > 0:
                        self._placement_precision_forward_frame_count += 1
                    else:
                        self._placement_precision_reverse_frame_count += 1
                    return (
                        ForkliftAction(
                            speed_target=requested_speed,
                            steering_command=requested_steering,
                            lift_target=p.transport_lift_target,
                        ),
                        (
                            "V9.3.12-R4-E fresh-RGB yaw closure LEG1 "
                            f"pred-final={math.hypot(fresh_sequence.predicted_final_x_m, fresh_sequence.predicted_final_y_m):.3f}m/"
                            f"{math.degrees(fresh_sequence.predicted_final_yaw_rad):.2f}deg"
                        ),
                        True,
                    )
                self._fresh_rgb_yaw_closure_phase = "MID_BRAKE"
                self._fresh_rgb_yaw_closure_end_time = None

            if self._fresh_rgb_yaw_closure_phase == "MID_BRAKE":
                if abs(current_speed) > epsilon:
                    self._placement_precision_set_direction(0)
                    self._placement_precision_hold_frame_count += 1
                    return (
                        ForkliftAction.stopped(lift_target=p.transport_lift_target),
                        "V9.3.12-R4-E fresh-RGB yaw closure midpoint brake",
                        True,
                    )
                self._fresh_rgb_yaw_closure_phase = "LEG2"

            if self._fresh_rgb_yaw_closure_phase == "LEG2":
                requested_speed = float(fresh_sequence.second_speed_mps)
                requested_steering = float(fresh_sequence.second_steering_rad)
                if self._fresh_rgb_yaw_closure_end_time is None:
                    self._fresh_rgb_yaw_closure_end_time = now + float(fresh_sequence.leg_duration_seconds)
                if now < float(self._fresh_rgb_yaw_closure_end_time) - 1e-9:
                    direction = 1 if requested_speed > 0.0 else -1
                    self._placement_precision_set_direction(direction)
                    if direction > 0:
                        self._placement_precision_forward_frame_count += 1
                    else:
                        self._placement_precision_reverse_frame_count += 1
                    return (
                        ForkliftAction(
                            speed_target=requested_speed,
                            steering_command=requested_steering,
                            lift_target=p.transport_lift_target,
                        ),
                        "V9.3.12-R4-E fresh-RGB yaw closure LEG2",
                        True,
                    )
                self._fresh_rgb_yaw_closure_active = None
                self._fresh_rgb_yaw_closure_phase = "RGB_SETTLE"
                self._fresh_rgb_yaw_closure_end_time = None
                self._fresh_rgb_yaw_closure_post_settle_until = (
                    now + p.placement_fresh_rgb_yaw_closure_post_motion_settle_seconds
                )
                self._fresh_rgb_yaw_closure_post_settle_deadline = (
                    now + p.placement_fresh_rgb_yaw_closure_post_motion_max_wait_seconds
                )
                self._fresh_rgb_yaw_closure_post_settle_start_update_count = (
                    self._terminal_load_reacquisition_update_count
                )
                self._fresh_rgb_yaw_closure_post_motion_rgb_updates = 0
                self._placement_mpc_last_plan = None
                self._placement_mpc_last_solve_time = None
                self._placement_precision_set_direction(0)
                self._placement_precision_hold_frame_count += 1
                return (
                    ForkliftAction.stopped(lift_target=p.transport_lift_target),
                    "V9.3.12-R4-E fresh-RGB yaw closure complete; waiting for post-motion RGB",
                    True,
                )

        if self._fresh_rgb_yaw_closure_phase == "RGB_SETTLE":
            updates = max(
                0,
                int(self._terminal_load_reacquisition_update_count)
                - int(self._fresh_rgb_yaw_closure_post_settle_start_update_count),
            )
            self._fresh_rgb_yaw_closure_post_motion_rgb_updates = updates
            settle_done = bool(
                self._fresh_rgb_yaw_closure_post_settle_until is not None
                and now >= self._fresh_rgb_yaw_closure_post_settle_until
            )
            deadline_done = bool(
                self._fresh_rgb_yaw_closure_post_settle_deadline is not None
                and now >= self._fresh_rgb_yaw_closure_post_settle_deadline
            )
            updates_ready = updates >= p.placement_fresh_rgb_yaw_closure_minimum_post_motion_rgb_updates
            if not (settle_done and updates_ready) and not deadline_done:
                self._placement_mpc_last_plan = None
                self._placement_mpc_last_solve_time = None
                self._placement_precision_set_direction(0)
                self._placement_precision_hold_frame_count += 1
                return (
                    ForkliftAction.stopped(lift_target=p.transport_lift_target),
                    (
                        "V9.3.12-R4-E post-motion RGB settle "
                        f"updates={updates}/{p.placement_fresh_rgb_yaw_closure_minimum_post_motion_rgb_updates}"
                    ),
                    True,
                )
            reference = self._fresh_rgb_yaw_closure_reference_abs_yaw_rad
            measured_improvement = (
                0.0 if reference is None
                else float(reference) - abs(float(filtered_error.yaw))
            )
            self._fresh_rgb_yaw_closure_last_measured_yaw_improvement_rad = float(measured_improvement)
            if (
                not updates_ready
                or measured_improvement < p.placement_fresh_rgb_yaw_closure_minimum_measured_yaw_improvement_rad
            ):
                self._fresh_rgb_yaw_closure_feedback_reject_count += 1
                self._fresh_rgb_yaw_closure_feedback_blocked = True
            else:
                # V9.3.12-R4-E1: positive Fresh-RGB feedback transfers motion
                # ownership to a basin-preserving handoff layer.  It has no
                # release authority.  It only prevents normal MPC from undoing
                # the verified correction before certification can take over.
                post_guard = self._post_closure_basin_guard_controller()
                if (
                    post_guard is not None
                    and post_guard.pose_guarded(
                        float(filtered_error.distance),
                        float(filtered_error.yaw),
                    )
                ):
                    if not self._post_closure_basin_ownership_active:
                        self._post_closure_basin_ownership_entry_count += 1
                    self._post_closure_basin_ownership_active = True
            self._fresh_rgb_yaw_closure_phase = "IDLE"
            self._fresh_rgb_yaw_closure_post_settle_until = None
            self._fresh_rgb_yaw_closure_post_settle_deadline = None
            self._fresh_rgb_yaw_closure_reference_abs_yaw_rad = None
            self._placement_mpc_last_plan = None
            self._placement_mpc_last_solve_time = None

        # V9.3.12-R4-C: a retention primitive has a separate, stricter budget.
        # It may move the chassis but can never authorize release.
        retention_primitive = self._strict_recovery_retention_active
        if retention_primitive is not None:
            epsilon = p.placement_precision_direction_change_speed_epsilon
            requested_speed = float(retention_primitive.speed_mps)
            requested_steering = float(retention_primitive.steering_rad)
            if self._strict_recovery_retention_end_time is None:
                if current_speed * requested_speed < 0.0 and abs(current_speed) > epsilon:
                    self._placement_precision_hold_frame_count += 1
                    return (
                        ForkliftAction.stopped(lift_target=p.transport_lift_target),
                        "V9.3.12-R4-C retention direction-change brake",
                        True,
                    )
                self._strict_recovery_retention_end_time = now + float(retention_primitive.duration_seconds)
            if now < float(self._strict_recovery_retention_end_time) - 1e-9:
                direction = 1 if requested_speed > 1e-6 else -1
                self._placement_precision_set_direction(direction)
                if direction > 0:
                    self._placement_precision_forward_frame_count += 1
                else:
                    self._placement_precision_reverse_frame_count += 1
                return (
                    ForkliftAction(
                        speed_target=requested_speed,
                        steering_command=requested_steering,
                        lift_target=p.transport_lift_target,
                    ),
                    (
                        "V9.3.12-R4-C strict-recovery retention "
                        f"improve={retention_primitive.deficit_improvement:.3f} "
                        f"pred={math.hypot(retention_primitive.predicted_x_m, retention_primitive.predicted_y_m):.3f}m/"
                        f"{math.degrees(retention_primitive.predicted_yaw_rad):.1f}deg"
                    ),
                    True,
                )
            self._strict_recovery_retention_active = None
            self._strict_recovery_retention_end_time = None
            self._placement_mpc_last_plan = None
            self._placement_mpc_last_solve_time = None

        # V9.3.12: once a bounded micro-primitive is selected, execute only
        # that short Ackermann motion, then immediately hand control back to
        # MPC. A direction-change brake does not consume its execution lease.
        primitive = self._terminal_micro_primitive_active
        if primitive is not None:
            epsilon = p.placement_precision_direction_change_speed_epsilon
            requested_speed = float(primitive.speed_mps)
            requested_steering = float(primitive.steering_rad)
            if self._terminal_micro_primitive_end_time is None:
                if current_speed * requested_speed < 0.0 and abs(current_speed) > epsilon:
                    self._placement_precision_hold_frame_count += 1
                    return (
                        ForkliftAction.stopped(lift_target=p.transport_lift_target),
                        "V9.3.12 micro-primitive direction-change brake",
                        True,
                    )
                self._terminal_micro_primitive_end_time = now + float(primitive.duration_seconds)
            if now < float(self._terminal_micro_primitive_end_time) - 1e-9:
                direction = 1 if requested_speed > 1e-6 else -1
                self._placement_precision_set_direction(direction)
                if direction > 0:
                    self._placement_precision_forward_frame_count += 1
                else:
                    self._placement_precision_reverse_frame_count += 1
                return (
                    ForkliftAction(
                        speed_target=requested_speed,
                        steering_command=requested_steering,
                        lift_target=p.transport_lift_target,
                    ),
                    (
                        "V9.3.12 SE(2) micro-primitive "
                        f"improve={primitive.deficit_improvement:.3f} "
                        f"pred={math.hypot(primitive.predicted_x_m, primitive.predicted_y_m):.3f}m/"
                        f"{math.degrees(primitive.predicted_yaw_rad):.1f}deg"
                    ),
                    True,
                )
            self._terminal_micro_primitive_active = None
            self._terminal_micro_primitive_end_time = None
            self._placement_mpc_last_plan = None
            self._placement_mpc_last_solve_time = None

        # V9.3.12-R3: the general SE(2) lattice has already solved the position
        # geometry on the hard tail.  If its bounded budget is exhausted while
        # position is inside the strict basin but yaw remains just outside, one
        # separate reserve may execute a short yaw-improving arc.
        general_micro = self._micro_primitive_controller()
        yaw_tail = self._yaw_tail_reserve_controller()
        if (
            yaw_tail is not None
            and general_micro is not None
            and general_micro.activation_count >= p.placement_micro_primitive_max_activations
        ):
            selected = yaw_tail.search(
                target_x_m=float(filtered_error.longitudinal),
                target_y_m=float(filtered_error.lateral),
                target_yaw_rad=float(filtered_error.yaw),
                current_speed_mps=float(current_speed),
                current_direction=int(self._placement_precision_direction),
            )
            if selected is not None:
                self._terminal_micro_primitive_active = selected
                self._terminal_micro_primitive_last_deficit_improvement = float(selected.deficit_improvement)
                self._terminal_micro_primitive_end_time = None
                self._placement_mpc_last_plan = None
                return (
                    ForkliftAction.stopped(lift_target=p.transport_lift_target),
                    (
                        "V9.3.12-R3 yaw-tail reserve selected; braking before "
                        f"{math.degrees(selected.deficit_improvement):.2f}deg predicted yaw improvement"
                    ),
                    True,
                )

        # V9.3.12-R4-C: strict-recovery is a bounded motion-ownership regime,
        # not just a list of isolated primitives. R4-B could finish one useful
        # retention arc and then hand ordinary MPC the chassis during the
        # cooldown / physical coast. That gap can undo the correction and
        # recreate the post-basin escape this layer was designed to prevent.
        # R4-C brakes through that handoff and gives the final retained pose a
        # short stationary evidence-refresh lease. Release authority remains
        # unchanged: instantaneous STRICT -> Supervisor INTENT -> Witness -> execute.
        retention = self._strict_recovery_retention_controller()
        retention_regime = bool(
            retention is not None
            and general_micro is not None
            and yaw_tail is not None
            and general_micro.activation_count >= p.placement_micro_primitive_max_activations
            and yaw_tail.activation_count >= p.placement_yaw_tail_reserve_max_activations
        )
        if retention_regime:
            assert retention is not None
            pose_guarded = retention.pose_within_guard(
                float(filtered_error.longitudinal),
                float(filtered_error.lateral),
                float(filtered_error.yaw),
            )
            selected = retention.search(
                now=now,
                target_x_m=float(filtered_error.longitudinal),
                target_y_m=float(filtered_error.lateral),
                target_yaw_rad=float(filtered_error.yaw),
                current_speed_mps=float(current_speed),
                current_direction=int(self._placement_precision_direction),
            )
            if selected is not None:
                self._strict_recovery_retention_active = selected
                self._strict_recovery_retention_last_deficit_improvement = float(selected.deficit_improvement)
                self._strict_recovery_retention_end_time = None
                self._strict_recovery_retention_final_settle_until = None
                self._strict_recovery_retention_final_settle_consumed = False
                self._placement_mpc_last_plan = None
                self._placement_mpc_last_solve_time = None
                self._placement_precision_hold_frame_count += 1
                return (
                    ForkliftAction.stopped(lift_target=p.transport_lift_target),
                    (
                        "V9.3.12-R4-C strict-recovery retention selected; "
                        f"deficit improve={selected.deficit_improvement:.3f}"
                    ),
                    True,
                )

            if pose_guarded:
                cooldown_remaining = retention.cooldown_remaining(now)
                speed_settling = (
                    abs(float(current_speed))
                    > p.placement_strict_recovery_retention_maximum_speed_for_activation_mps
                )
                if cooldown_remaining > 1e-9 or speed_settling:
                    self._placement_mpc_last_plan = None
                    self._placement_mpc_last_solve_time = None
                    self._placement_precision_set_direction(0)
                    self._placement_precision_hold_frame_count += 1
                    return (
                        ForkliftAction.stopped(lift_target=p.transport_lift_target),
                        (
                            "V9.3.12-R4-C retention handoff interlock; "
                            f"cooldown={cooldown_remaining:.2f}s speed={current_speed:.3f}m/s"
                        ),
                        True,
                    )

                if (
                    retention.motion_budget_exhausted()
                    and p.placement_strict_recovery_retention_final_settle_seconds > 0.0
                    and not self._strict_recovery_retention_final_settle_consumed
                ):
                    if self._strict_recovery_retention_final_settle_until is None:
                        self._strict_recovery_retention_final_settle_until = (
                            now + p.placement_strict_recovery_retention_final_settle_seconds
                        )
                        self._strict_recovery_retention_final_settle_count += 1
                    settle_remaining = float(self._strict_recovery_retention_final_settle_until) - now
                    if settle_remaining > 1e-9:
                        self._placement_mpc_last_plan = None
                        self._placement_mpc_last_solve_time = None
                        self._placement_precision_set_direction(0)
                        self._placement_precision_hold_frame_count += 1
                        return (
                            ForkliftAction.stopped(lift_target=p.transport_lift_target),
                            (
                                "V9.3.12-R4-E one-shot strict-evidence settle; "
                                f"remaining={settle_remaining:.2f}s"
                            ),
                            True,
                        )
                    self._strict_recovery_retention_final_settle_until = None
                    self._strict_recovery_retention_final_settle_consumed = True
            else:
                # If a started lease leaves the retention guard, consume it.
                # R4-E must never recreate the R4-C indefinite re-arm loop by
                # restarting the same evidence lease after a guard excursion.
                if self._strict_recovery_retention_final_settle_until is not None:
                    self._strict_recovery_retention_final_settle_consumed = True
                self._strict_recovery_retention_final_settle_until = None

        # V9.3.12-R4-E4: a POSITION strict blocker is not a scalar-deficit
        # problem.  E2 proved that a tiny yaw shunt can reduce the summed
        # deficit while leaving the lexicographically first POSITION blocker
        # unchanged.  Once E1 ownership is active and a real STRICT attempt has
        # exposed POSITION, search a bounded parking-style lateral recenter.
        # Only the DEPART leg is committed here; after braking, fresh terminal
        # RGB is mandatory and the RETURN leg is re-planned from that observed
        # midpoint.  Release authority remains entirely with the unchanged
        # Supervisor -> instantaneous STRICT -> Witness chain.
        position_recenter = self._position_blocker_recenter_controller()
        if (
            position_recenter is not None
            and self._post_closure_basin_ownership_active
            and self._position_blocker_recenter_active is None
            and self._position_blocker_recenter_phase == "IDLE"
            and position_recenter.activation_count < 1
            and self._strict_release_certification_reject_count > 0
            and self._strict_release_certification_last_blocker == "POSITION"
            and not self._position_blocker_recenter_feedback_blocked
            and placement_vision_ready
            and self._placement_target_multiview_ready
            and self._carried_load_seed_provenance == LoadSeedProvenance.TERMINAL_RGB.value
            and self._carried_visual_stale_for_release(now)
            <= p.placement_fresh_rgb_yaw_closure_maximum_rgb_stale_seconds
            and self._motion_carried_load_yaw_sigma_rad()
            <= p.placement_fresh_rgb_yaw_closure_maximum_observer_yaw_sigma_rad
            and self._placement_target_fast_slow_position_disagreement_m is not None
            and self._placement_target_fast_slow_position_disagreement_m
            <= p.placement_certified_basin_consensus_max_fast_slow_position_m
            and self._placement_target_fast_slow_yaw_disagreement_rad is not None
            and self._placement_target_fast_slow_yaw_disagreement_rad
            <= p.placement_certified_basin_consensus_max_fast_slow_yaw_rad
            and (
                self._position_blocker_recenter_last_search_time is None
                or now - self._position_blocker_recenter_last_search_time
                >= p.placement_position_blocker_recenter_search_period_s
            )
        ):
            self._position_blocker_recenter_last_search_time = now
            budget_remaining = max(
                0.0,
                p.placement_terminal_budget_seconds - self.placement_terminal_elapsed(now),
            )
            if (
                budget_remaining
                >= p.placement_position_blocker_recenter_minimum_terminal_budget_remaining_s
            ):
                certification_error = self._load_to_certification_error(observation)
                position_margin = max(
                    0.0, float(self._strict_release_certification_last_position_margin_m)
                )
                yaw_margin = math.radians(
                    max(0.0, float(self._strict_release_certification_last_yaw_margin_deg))
                )
                # V9.3.12-R4-E5: the recenter preview must propagate full
                # poses, not DockingError values.  The carried load remains
                # rigid in the base frame while both world-fixed targets move
                # through the hypothetical vehicle frame.
                load_pose = self._effective_pallet_pose_in_base(observation)
                task_target_pose = observation.placement_pose_in_base
                certification_target_pose = self._certification_target_pose_in_base(observation)
                selected_recenter = position_recenter.search_departure(
                    filtered_x_m=float(filtered_error.longitudinal),
                    filtered_y_m=float(filtered_error.lateral),
                    filtered_yaw_rad=float(filtered_error.yaw),
                    certification_x_m=float(certification_error.longitudinal),
                    certification_y_m=float(certification_error.lateral),
                    certification_yaw_rad=float(certification_error.yaw),
                    position_margin_m=position_margin,
                    yaw_margin_rad=yaw_margin,
                    current_speed_mps=float(current_speed),
                    terminal_budget_remaining_s=float(budget_remaining),
                    load_pose_in_base=(
                        float(load_pose.x), float(load_pose.y), float(load_pose.yaw)
                    ),
                    task_target_pose_in_base=(
                        float(task_target_pose.x),
                        float(task_target_pose.y),
                        float(task_target_pose.yaw),
                    ),
                    certification_target_pose_in_base=(
                        float(certification_target_pose.x),
                        float(certification_target_pose.y),
                        float(certification_target_pose.yaw),
                    ),
                )
                if selected_recenter is not None:
                    self._position_blocker_recenter_active = selected_recenter
                    self._position_blocker_recenter_return_active = None
                    self._position_blocker_recenter_completed_return_plan = None
                    self._position_blocker_recenter_full_pose_model_active = (
                        selected_recenter.model_mode == PositionBlockerRecenterPlanner.FULL_POSE_MODEL
                    )
                    self._position_blocker_recenter_phase = "DEPART_PRESTEER"
                    self._position_blocker_recenter_presteer_start_time = None
                    self._position_blocker_recenter_leg_start_time = None
                    self._position_blocker_recenter_odom_last_x = None
                    self._position_blocker_recenter_odom_last_y = None
                    self._position_blocker_recenter_odom_distance_m = 0.0
                    self._position_blocker_recenter_last_departure_odometry_m = 0.0
                    self._position_blocker_recenter_last_return_odometry_m = 0.0
                    self._position_blocker_recenter_midpoint_position_deviation_m = 0.0
                    self._position_blocker_recenter_midpoint_yaw_deviation_rad = 0.0
                    self._position_blocker_recenter_leg_end_time = None
                    self._position_blocker_recenter_mid_settle_until = None
                    self._position_blocker_recenter_mid_settle_deadline = None
                    self._position_blocker_recenter_mid_rgb_updates = 0
                    self._position_blocker_recenter_final_settle_until = None
                    self._position_blocker_recenter_final_settle_deadline = None
                    self._position_blocker_recenter_final_rgb_updates = 0
                    self._position_blocker_recenter_final_evidence_start_time = None
                    self._position_blocker_recenter_final_evidence_deadline = None
                    self._position_blocker_recenter_final_evidence_consistent_rgb_updates = 0
                    self._position_blocker_recenter_final_evidence_last_update_count = (
                        self._terminal_load_reacquisition_update_count
                    )
                    self._position_blocker_recenter_final_live_strict_attempt_count = 0
                    self._position_blocker_recenter_reference_effective_position_m = float(
                        certification_error.distance + position_margin
                    )
                    # E5 rollback verification is relative to the state at the
                    # moment this macro actually acquires chassis authority.
                    self._position_blocker_recenter_pre_macro_filtered_position_m = float(
                        filtered_error.distance
                    )
                    self._position_blocker_recenter_pre_macro_filtered_yaw_rad = abs(
                        float(filtered_error.yaw)
                    )
                    self._position_blocker_recenter_rollback_target_odometry_m = 0.0
                    self._position_blocker_recenter_last_rollback_odometry_m = 0.0
                    self._position_blocker_recenter_return_unwind_target_odometry_m = 0.0
                    self._position_blocker_recenter_last_return_unwind_odometry_m = 0.0
                    self._position_blocker_recenter_rollback_settle_until = None
                    self._position_blocker_recenter_rollback_settle_deadline = None
                    self._position_blocker_recenter_rollback_rgb_updates = 0
                    self._position_blocker_recenter_rollback_reason = ""
                    self._position_blocker_recenter_yaw_handoff_ready = False
                    self._position_blocker_recenter_last_predicted_effective_position_m = float(
                        selected_recenter.predicted_effective_position_m
                    )
                    self._position_blocker_recenter_last_predicted_effective_yaw_rad = float(
                        selected_recenter.predicted_effective_yaw_rad
                    )
                    self._placement_mpc_last_plan = None
                    self._placement_mpc_last_solve_time = None
                    self._placement_precision_set_direction(0)
                    self._placement_precision_hold_frame_count += 1
                    return (
                        ForkliftAction.stopped(lift_target=p.transport_lift_target),
                        (
                            "V9.3.12-R4-E5 POSITION blocker full-pose recenter selected; "
                            f"effective-pos={certification_error.distance + position_margin:.3f}"
                            f"->{selected_recenter.predicted_effective_position_m:.3f}m "
                            f"pred-apex={selected_recenter.maximum_predicted_filtered_excursion_m:.3f}m"
                        ),
                        True,
                    )

        # V9.3.12-R4-E2: after the first strict certification reject, stop
        # replaying the same conservative state through repeated Supervisor
        # settles. Search one tiny observation-derived recenter sequence that
        # reduces the full strict deficit (position + hidden yaw) while the
        # filtered state remains inside the retained physical/control basin.
        certification_closure = self._certification_basin_closure_controller()
        if (
            certification_closure is not None
            and self._post_closure_basin_ownership_active
            and self._strict_release_certification_reject_count > 0
            and (
                self._strict_release_certification_last_blocker == "YAW"
                or (
                    self._position_blocker_recenter_yaw_handoff_ready
                    and self._load_to_certification_error(observation).distance
                    + max(0.0, self._strict_release_certification_last_position_margin_m)
                    <= p.placement_strict_release_position_limit_m
                )
            )
            and not self._certification_basin_closure_feedback_blocked
            and placement_vision_ready
            and self._placement_target_multiview_ready
            and self._carried_load_seed_provenance == LoadSeedProvenance.TERMINAL_RGB.value
            and self._carried_visual_stale_for_release(now)
            <= p.placement_fresh_rgb_yaw_closure_maximum_rgb_stale_seconds
            and self._motion_carried_load_yaw_sigma_rad()
            <= p.placement_fresh_rgb_yaw_closure_maximum_observer_yaw_sigma_rad
            and self._placement_target_fast_slow_position_disagreement_m is not None
            and self._placement_target_fast_slow_position_disagreement_m
            <= p.placement_certified_basin_consensus_max_fast_slow_position_m
            and self._placement_target_fast_slow_yaw_disagreement_rad is not None
            and self._placement_target_fast_slow_yaw_disagreement_rad
            <= p.placement_certified_basin_consensus_max_fast_slow_yaw_rad
            and (
                self._certification_basin_closure_last_search_time is None
                or now - self._certification_basin_closure_last_search_time
                >= p.placement_certification_basin_closure_search_period_s
            )
        ):
            certification_error = self._load_to_certification_error(observation)
            self._certification_basin_closure_last_search_time = now
            self._certification_basin_closure_last_certification_longitudinal_m = float(certification_error.longitudinal)
            self._certification_basin_closure_last_certification_lateral_m = float(certification_error.lateral)
            current_deficit = self._certification_strict_deficit(certification_error)
            self._certification_basin_closure_last_current_deficit = float(current_deficit)
            # E5: the follow-up certification/YAW closure must use the same
            # full-pose semantics as the POSITION corridor. Reusing the E2
            # error-space propagation here would reintroduce the carried-load
            # lever-arm bug that E5 was created to remove.
            e5_load_pose = self._effective_pallet_pose_in_base(observation)
            e5_task_target_pose = observation.placement_pose_in_base
            e5_certification_target_pose = self._certification_target_pose_in_base(observation)
            selected = certification_closure.search(
                filtered_x_m=float(filtered_error.longitudinal),
                filtered_y_m=float(filtered_error.lateral),
                filtered_yaw_rad=float(filtered_error.yaw),
                certification_x_m=float(certification_error.longitudinal),
                certification_y_m=float(certification_error.lateral),
                certification_yaw_rad=float(certification_error.yaw),
                position_margin_m=float(self._strict_release_certification_last_position_margin_m),
                yaw_margin_rad=math.radians(float(self._strict_release_certification_last_yaw_margin_deg)),
                current_speed_mps=float(current_speed),
                current_direction=int(self._placement_precision_direction),
                load_pose_in_base=(
                    float(e5_load_pose.x), float(e5_load_pose.y), float(e5_load_pose.yaw)
                ),
                task_target_pose_in_base=(
                    float(e5_task_target_pose.x),
                    float(e5_task_target_pose.y),
                    float(e5_task_target_pose.yaw),
                ),
                certification_target_pose_in_base=(
                    float(e5_certification_target_pose.x),
                    float(e5_certification_target_pose.y),
                    float(e5_certification_target_pose.yaw),
                ),
            )
            if selected is not None:
                self._position_blocker_recenter_yaw_handoff_ready = False
                self._certification_basin_closure_active = selected
                self._certification_basin_closure_phase = "LEG1"
                self._certification_basin_closure_leg_end_time = None
                self._certification_basin_closure_post_settle_until = None
                self._certification_basin_closure_post_settle_deadline = None
                self._certification_basin_closure_post_motion_rgb_updates = 0
                self._certification_basin_closure_reference_deficit = float(current_deficit)
                self._certification_basin_closure_last_predicted_deficit_improvement = float(selected.deficit_improvement)
                self._certification_basin_closure_last_predicted_deficit = float(selected.predicted_strict_deficit)
                self._placement_mpc_last_plan = None
                self._placement_mpc_last_solve_time = None
                self._placement_precision_set_direction(0)
                self._placement_precision_hold_frame_count += 1
                return (
                    ForkliftAction.stopped(lift_target=p.transport_lift_target),
                    (
                        "V9.3.12-R4-E2 certification-basin closure selected; "
                        f"deficit={current_deficit:.2f}->{selected.predicted_strict_deficit:.2f} "
                        f"filtered-max={selected.maximum_predicted_filtered_distance_m:.3f}m"
                    ),
                    True,
                )

        # V9.3.12-R4-E: after the normal micro/yaw-tail/retention
        # budgets and one evidence settle have been consumed, a fresh terminal
        # RGB state may authorize *motion search only*. The paired shunt has no
        # release authority and is rejected unless load/target estimates are
        # fresh, low-uncertainty and mutually consistent.
        fresh_closure = self._fresh_rgb_yaw_closure_controller()
        if (
            fresh_closure is not None
            and retention_regime
            and retention is not None
            and retention.motion_budget_exhausted()
            and self._strict_recovery_retention_final_settle_consumed
            and not self._fresh_rgb_yaw_closure_feedback_blocked
            and placement_vision_ready
            and self._terminal_load_reacquisition_update_count
            >= p.placement_fresh_rgb_yaw_closure_minimum_terminal_rgb_updates
            and self._carried_load_seed_provenance == LoadSeedProvenance.TERMINAL_RGB.value
            and self._carried_visual_stale_for_release(now)
            <= p.placement_fresh_rgb_yaw_closure_maximum_rgb_stale_seconds
            and self._motion_carried_load_yaw_sigma_rad()
            <= p.placement_fresh_rgb_yaw_closure_maximum_observer_yaw_sigma_rad
            and self._placement_target_multiview_ready
            and self._placement_target_fast_slow_yaw_disagreement_rad is not None
            and self._placement_target_fast_slow_yaw_disagreement_rad
            <= p.placement_fresh_rgb_yaw_closure_maximum_target_fast_slow_yaw_disagreement_rad
        ):
            continuation = bool(
                self._post_closure_basin_ownership_active
                and fresh_closure.activation_count > 0
            )
            if continuation:
                self._post_closure_continuation_search_count += 1
            selected = fresh_closure.search(
                target_x_m=float(filtered_error.longitudinal),
                target_y_m=float(filtered_error.lateral),
                target_yaw_rad=float(filtered_error.yaw),
                current_speed_mps=float(current_speed),
                current_direction=int(self._placement_precision_direction),
                position_gate_override_m=(
                    p.placement_post_closure_continuation_position_gate_m
                    if continuation else None
                ),
            )
            if selected is not None:
                if continuation:
                    self._post_closure_continuation_activation_count += 1
                self._fresh_rgb_yaw_closure_active = selected
                self._fresh_rgb_yaw_closure_phase = "LEG1"
                self._fresh_rgb_yaw_closure_end_time = None
                self._fresh_rgb_yaw_closure_reference_abs_yaw_rad = abs(float(filtered_error.yaw))
                self._fresh_rgb_yaw_closure_last_predicted_yaw_improvement_rad = float(selected.yaw_improvement_rad)
                self._fresh_rgb_yaw_closure_post_motion_rgb_updates = 0
                self._placement_mpc_last_plan = None
                self._placement_mpc_last_solve_time = None
                self._placement_precision_set_direction(0)
                self._placement_precision_hold_frame_count += 1
                return (
                    ForkliftAction.stopped(lift_target=p.transport_lift_target),
                    (
                        "V9.3.12-R4-E fresh-RGB yaw closure selected; "
                        f"pred improve={math.degrees(selected.yaw_improvement_rad):.2f}deg "
                        f"final={math.hypot(selected.predicted_final_x_m, selected.predicted_final_y_m):.3f}m/"
                        f"{math.degrees(selected.predicted_final_yaw_rad):.2f}deg"
                    ),
                    True,
                )

        solve_due = (
            self._placement_mpc_last_plan is None
            or self._placement_mpc_last_solve_time is None
            or now - self._placement_mpc_last_solve_time >= p.placement_mpc_update_period
        )
        if solve_due and self._placement_mpc_pending_prediction is not None:
            due, pred_x, pred_y, pred_yaw = self._placement_mpc_pending_prediction
            if now + 1e-6 >= due:
                dx = float(command_error.longitudinal) - pred_x
                dy = float(command_error.lateral) - pred_y
                dyaw = wrap_angle(float(command_error.yaw) - pred_yaw)
                self._placement_mpc_model_id_sample_count += 1
                self._placement_mpc_model_id_longitudinal_sq_sum += dx * dx
                self._placement_mpc_model_id_lateral_sq_sum += dy * dy
                self._placement_mpc_model_id_yaw_sq_sum += dyaw * dyaw
                self._placement_mpc_pending_prediction = None
        if solve_due:
            switch = (
                p.placement_precision_longitudinal_deadband
                + p.placement_precision_direction_switch_hysteresis
            )
            current_direction = int(self._placement_precision_direction)
            first_direction_constraint = 0
            if (
                current_direction > 0
                and float(filtered_command_longitudinal) > -switch
            ):
                first_direction_constraint = 1
            elif (
                current_direction < 0
                and float(filtered_command_longitudinal) < switch
            ):
                first_direction_constraint = -1
            plan = self._terminal_mpc_controller().solve(
                target_x=float(command_error.longitudinal),
                target_y=float(command_error.lateral),
                target_yaw=float(command_error.yaw),
                task_lateral=float(filtered_error.lateral),
                task_yaw=float(filtered_error.yaw),
                current_speed=float(current_speed),
                previous_steering=float(self._placement_mpc_last_steering),
                first_direction_constraint=first_direction_constraint,
            )
            self._placement_mpc_last_plan = plan
            self._placement_mpc_last_solve_time = now
            self._placement_mpc_solve_count += 1
        else:
            assert self._placement_mpc_last_plan is not None
            plan = self._placement_mpc_last_plan

        if not math.isfinite(float(plan.cost)) or plan.feasible_candidate_count <= 0:
            self._placement_mpc_fallback_count += 1
            if solve_due:
                self._placement_mpc_infeasible_solve_count += 1
                self._placement_mpc_consecutive_infeasible_solve_count += 1
            return (
                ForkliftAction.stopped(lift_target=p.transport_lift_target),
                "V9.3.0 terminal MPC infeasible; requesting bounded fallback",
                False,
            )

        if solve_due:
            self._placement_mpc_consecutive_infeasible_solve_count = 0

        # V9.3.12-R4-E1 post-closure basin shield.  Once a Fresh-RGB closure
        # has produced positive measured yaw improvement, normal MPC may only
        # execute if its *own horizon* stays inside the retained position basin
        # and does not buy yaw by materially regressing position.  Unsafe plans
        # are vetoed before reaching the actuators.  The vehicle is held and a
        # fresh solve/continuation-closure opportunity is requested next frame.
        post_closure_safe_mpc_override = False
        if self._post_closure_basin_ownership_active:
            post_guard = self._post_closure_basin_guard_controller()
            post_guarded = bool(
                post_guard is not None
                and post_guard.pose_guarded(
                    float(filtered_error.distance),
                    float(filtered_error.yaw),
                )
            )
            if post_guarded and post_guard is not None:
                if not post_guard.mpc_plan_safe(
                    current_distance_m=float(filtered_error.distance),
                    current_yaw_rad=float(filtered_error.yaw),
                    predicted_distance_m=float(plan.predicted_distance),
                    predicted_yaw_rad=float(plan.predicted_yaw),
                ):
                    self._post_closure_mpc_veto_count += 1
                    self._placement_mpc_last_plan = None
                    self._placement_mpc_last_solve_time = None
                    self._placement_precision_set_direction(0)
                    self._placement_precision_hold_frame_count += 1
                    return (
                        ForkliftAction.stopped(lift_target=p.transport_lift_target),
                        (
                            "V9.3.12-R4-E1 post-closure MPC veto; "
                            f"current={filtered_error.distance:.3f}m/{math.degrees(filtered_error.yaw):.2f}deg "
                            f"pred={plan.predicted_distance:.3f}m/{math.degrees(plan.predicted_yaw):.2f}deg"
                        ),
                        True,
                    )
                self._post_closure_mpc_safe_allow_count += 1
                post_closure_safe_mpc_override = True
            else:
                # V9.3.12-R4-E2 closes E1's 10.5--12.5 cm gray zone.  While
                # retained ownership is still inside the larger exit envelope,
                # ordinary MPC is *not* allowed to run unrestricted.  E2 either
                # actively recenters from certification space (above) or holds
                # for the next fresh observation / Supervisor retry.
                inside_exit_envelope = bool(
                    post_guard is not None
                    and float(filtered_error.distance)
                    <= p.placement_post_closure_exit_position_guard_m + 1e-9
                    and abs(float(filtered_error.yaw))
                    <= p.placement_post_closure_exit_yaw_guard_rad + 1e-9
                )
                if inside_exit_envelope:
                    self._post_closure_gray_zone_hold_count += 1
                    self._placement_mpc_last_plan = None
                    self._placement_mpc_last_solve_time = None
                    self._placement_precision_set_direction(0)
                    self._placement_precision_hold_frame_count += 1
                    return (
                        ForkliftAction.stopped(lift_target=p.transport_lift_target),
                        (
                            "V9.3.12-R4-E2 post-closure gray-zone hold; "
                            f"current={filtered_error.distance:.3f}m/{math.degrees(filtered_error.yaw):.2f}deg"
                        ),
                        True,
                    )
                # A genuine estimate escape beyond the larger envelope releases
                # dedicated ownership and lets the existing broad recovery stack
                # regain control.
                self._post_closure_basin_ownership_active = False

        # MPC is a local precision planner, not a license to recreate the old
        # metre-scale recovery loop.  Reject a plan whose predicted terminal
        # base-goal distance regresses beyond the already accepted local
        # precision regression allowance.  The bounded V9.2.4 S-curve remains
        # the deterministic feasibility fallback for strongly nonholonomic
        # geometry.
        yaw_weight = max(0.0, p.placement_mpc_progress_yaw_weight_m_per_rad)
        initial_progress_score = (
            math.hypot(float(command_error.longitudinal), float(command_error.lateral))
            + yaw_weight * abs(float(command_error.yaw))
        )
        predicted_progress_score = (
            float(plan.predicted_distance)
            + yaw_weight * abs(float(plan.predicted_yaw))
        )
        uncertainty_allowance = min(
            0.04,
            0.5 * self._carried_load_pose_position_std_m
            + 0.25 * self._carried_load_observer_disagreement_position_m,
        )
        regression_allowance = max(
            p.placement_precision_maximum_regression_m,
            p.placement_mpc_progress_regression_tolerance_m,
        ) + uncertainty_allowance
        regression_violation = (
            predicted_progress_score > initial_progress_score + regression_allowance
            and not post_closure_safe_mpc_override
        )
        if regression_violation:
            # V9.3.9 semantic fix: the escrow activation envelope is defined
            # in carried-load placement task space, not vehicle docking-command
            # space. The latter can be 20+ cm even when the pallet is already
            # within the intended 16 cm task basin.
            current_distance = float(filtered_error.distance)
            current_abs_yaw = abs(float(filtered_error.yaw))
            predicted_abs_yaw = abs(float(plan.predicted_yaw))

            # V9.3.11 near-basin feasibility escrow. Evaluate the first MPC
            # action in *pallet task space* over a bounded preview. If it
            # reduces normalized official-boundary deficit, the generic
            # progress corridor may temporarily yield to the nonholonomic arc.
            near_basin_allowed = False
            near_basin = self._near_basin_escrow_controller()
            if near_basin is not None:
                preview_steering = max(
                    -p.placement_mpc_steering_limit,
                    min(p.placement_mpc_steering_limit, float(plan.steering)),
                )
                preview_x, preview_y, preview_yaw = TerminalKinematicMPC.predict_target_pose(
                    float(filtered_error.longitudinal),
                    float(filtered_error.lateral),
                    float(filtered_error.yaw),
                    speed=float(plan.speed),
                    steering=preview_steering,
                    wheelbase=p.transport_path_wheelbase,
                    dt=p.placement_mpc_near_basin_preview_seconds,
                )
                near_basin_allowed = near_basin.allow(
                    now,
                    current_distance_m=current_distance,
                    current_abs_yaw_rad=current_abs_yaw,
                    predicted_distance_m=math.hypot(preview_x, preview_y),
                    predicted_abs_yaw_rad=abs(float(preview_yaw)),
                    position_limit_m=p.placement_strict_release_position_limit_m,
                    yaw_limit_rad=p.placement_strict_release_yaw_limit_rad,
                )

            # V9.3.12: if the generic MPC progress guard rejects a local arc,
            # search a tiny deterministic SE(2) lattice in carried-load task
            # space. The selected primitive must reduce normalized strict-basin
            # deficit and is executed for at most 0.3-0.7s before MPC resumes.
            micro = self._micro_primitive_controller()
            if not near_basin_allowed and micro is not None:
                selected = micro.search(
                    now=now,
                    target_x_m=float(filtered_error.longitudinal),
                    target_y_m=float(filtered_error.lateral),
                    target_yaw_rad=float(filtered_error.yaw),
                    current_direction=int(self._placement_precision_direction),
                )
                if selected is not None:
                    self._terminal_micro_primitive_active = selected
                    self._terminal_micro_primitive_last_deficit_improvement = float(selected.deficit_improvement)
                    epsilon = p.placement_precision_direction_change_speed_epsilon
                    if current_speed * selected.speed_mps < 0.0 and abs(current_speed) > epsilon:
                        self._terminal_micro_primitive_end_time = None
                        self._placement_precision_hold_frame_count += 1
                        return (
                            ForkliftAction.stopped(lift_target=p.transport_lift_target),
                            "V9.3.12 micro-primitive selected; braking for direction change",
                            True,
                        )
                    self._terminal_micro_primitive_end_time = now + float(selected.duration_seconds)
                    direction = 1 if selected.speed_mps > 0.0 else -1
                    self._placement_precision_set_direction(direction)
                    if direction > 0:
                        self._placement_precision_forward_frame_count += 1
                    else:
                        self._placement_precision_reverse_frame_count += 1
                    return (
                        ForkliftAction(
                            speed_target=float(selected.speed_mps),
                            steering_command=float(selected.steering_rad),
                            lift_target=p.transport_lift_target,
                        ),
                        (
                            "V9.3.12 SE(2) micro-primitive selected "
                            f"deficit {selected.current_deficit:.3f}->{selected.predicted_deficit:.3f}"
                        ),
                        True,
                    )

            escrow_active = (
                p.placement_mpc_yaw_escrow_enabled > 0.5
                and self._placement_mpc_yaw_escrow_active_until is not None
                and now <= self._placement_mpc_yaw_escrow_active_until
            )
            escrow_candidate = (
                p.placement_mpc_yaw_escrow_enabled > 0.5
                and self._placement_precision_recenter_cycle_count
                >= p.placement_precision_recenter_max_cycles
                and self._placement_mpc_yaw_escrow_activation_count
                < p.placement_mpc_yaw_escrow_max_activations
                and current_distance <= p.placement_mpc_yaw_escrow_activation_distance_m
                and current_abs_yaw >= p.placement_mpc_yaw_escrow_activation_yaw_rad
                and float(plan.predicted_distance)
                <= p.placement_mpc_yaw_escrow_predicted_max_distance_m
                and current_abs_yaw - predicted_abs_yaw
                >= p.placement_mpc_yaw_escrow_required_improvement_rad
            )
            escrow_plan_safe = (
                float(plan.predicted_distance)
                <= p.placement_mpc_yaw_escrow_predicted_max_distance_m
                and predicted_abs_yaw <= current_abs_yaw + math.radians(0.5)
            )
            if escrow_candidate:
                self._placement_mpc_yaw_escrow_activation_count += 1
                self._placement_mpc_yaw_escrow_active_until = (
                    now + p.placement_mpc_yaw_escrow_max_seconds
                )
                escrow_active = True
            if not (near_basin_allowed or (escrow_active and escrow_plan_safe)):
                self._placement_mpc_fallback_count += 1
                if solve_due:
                    self._placement_mpc_regression_reject_solve_count += 1
                return (
                    ForkliftAction.stopped(lift_target=p.transport_lift_target),
                    "V9.3.12 MPC task-space prediction leaves local progress corridor; requesting bounded fallback",
                    False,
                )

        requested_speed = float(plan.speed)
        requested_steering = max(
            -p.placement_mpc_steering_limit,
            min(p.placement_mpc_steering_limit, float(plan.steering)),
        )
        if solve_due:
            pred_x, pred_y, pred_yaw = TerminalKinematicMPC.predict_target_pose(
                float(command_error.longitudinal),
                float(command_error.lateral),
                float(command_error.yaw),
                speed=requested_speed,
                steering=requested_steering,
                wheelbase=p.transport_path_wheelbase,
                dt=p.placement_mpc_update_period,
            )
            self._placement_mpc_pending_prediction = (
                now + p.placement_mpc_update_period, pred_x, pred_y, pred_yaw
            )

        epsilon = p.placement_precision_direction_change_speed_epsilon
        if current_speed * requested_speed < 0.0 and abs(current_speed) > epsilon:
            self._placement_precision_hold_frame_count += 1
            return (
                ForkliftAction.stopped(lift_target=p.transport_lift_target),
                "V9.3.0 MPC direction-change brake",
                True,
            )

        direction = 1 if requested_speed > 1e-6 else (-1 if requested_speed < -1e-6 else 0)
        self._placement_precision_set_direction(direction)
        self._placement_mpc_last_speed = requested_speed
        self._placement_mpc_last_steering = requested_steering
        if direction > 0:
            self._placement_precision_forward_frame_count += 1
        elif direction < 0:
            self._placement_precision_reverse_frame_count += 1
        else:
            self._placement_precision_hold_frame_count += 1

        return (
            ForkliftAction(
                speed_target=requested_speed,
                steering_command=requested_steering,
                lift_target=p.transport_lift_target,
            ),
            (
                "V9.3.0 terminal MPC "
                f"{plan.mode} cost={plan.cost:.3f} "
                f"pred={plan.predicted_distance:.3f}m/"
                f"{math.degrees(plan.predicted_yaw):.1f}deg"
            ),
            True,
        )

    def _terminal_ownership_controller(self) -> TerminalOwnershipSupervisor | None:
        p = self.parameters
        if p.placement_terminal_ownership_enabled <= 0.5:
            return None
        if self._terminal_ownership_supervisor is None:
            self._terminal_ownership_supervisor = TerminalOwnershipSupervisor(
                TerminalOwnershipConfig(
                    mpc_acquire_distance_m=p.placement_terminal_ownership_mpc_acquire_distance_m,
                    mpc_acquire_lateral_m=p.placement_terminal_ownership_mpc_acquire_lateral_m,
                    mpc_acquire_yaw_rad=p.placement_terminal_ownership_mpc_acquire_yaw_rad,
                    mpc_force_distance_m=p.placement_terminal_ownership_mpc_force_distance_m,
                    mpc_force_lateral_m=p.placement_terminal_ownership_mpc_force_lateral_m,
                    mpc_force_yaw_rad=p.placement_terminal_ownership_mpc_force_yaw_rad,
                    align_soft_timeout_seconds=p.placement_terminal_ownership_align_soft_timeout_seconds,
                    align_progress_window_seconds=p.placement_terminal_ownership_align_progress_window_seconds,
                    align_progress_improvement_m=p.placement_terminal_ownership_align_progress_improvement_m,
                )
            )
        return self._terminal_ownership_supervisor

    @staticmethod
    def _terminal_ownership_progress_score(error: DockingError) -> float:
        # A small yaw term makes "distance improved while heading collapsed"
        # visible to the ownership policy without coupling it to MPC costs.
        return float(error.distance) + 0.22 * abs(float(error.yaw))

    def _terminal_ownership_acquire_ready(self, error: DockingError) -> bool:
        supervisor = self._terminal_ownership_controller()
        if supervisor is None:
            return False
        return supervisor.acquisition_ready(
            distance=float(error.distance),
            lateral=float(error.lateral),
            yaw=float(error.yaw),
        )

    def _terminal_ownership_force_ready(self, error: DockingError) -> bool:
        supervisor = self._terminal_ownership_controller()
        if supervisor is None:
            return False
        return supervisor.force_envelope_ready(
            distance=float(error.distance),
            lateral=float(error.lateral),
            yaw=float(error.yaw),
        )

    def _release_supervisor_controller(self) -> ReleaseDecisionSupervisor | None:
        p = self.parameters
        if p.placement_release_supervisor_enabled <= 0.5:
            return None
        if self._release_supervisor is None:
            self._release_supervisor = ReleaseDecisionSupervisor(
                ReleaseDecisionSupervisorConfig(
                    evidence_seconds=p.placement_release_supervisor_evidence_seconds,
                    evidence_soft_decay=p.placement_release_supervisor_evidence_soft_decay,
                    settle_timeout_seconds=p.placement_release_supervisor_settle_timeout_seconds,
                    intent_execute_delay_seconds=p.placement_release_supervisor_intent_delay_seconds,
                    hard_violation_grace_seconds=p.placement_release_supervisor_hard_violation_grace_seconds,
                    rearm_cooldown_seconds=p.placement_release_supervisor_rearm_cooldown_seconds,
                )
            )
        return self._release_supervisor

    def _placement_release_supervisor_step(
        self,
        observation: ForkliftObservation,
        *,
        filtered_error: DockingError,
        placement_vision_ready: bool,
        forward_speed: float,
        command_error: DockingError,
        placement_error: DockingError,
    ) -> PickupDecision | None:
        """V9.3.4 single-owner release decision path.

        The supervisor only owns control while SETTLE/INTENT is active.  During
        cooldown or before the broad pre-brake basin is reached, normal MPC owns
        the chassis.  This prevents stationary commit/abort chatter from
        consuming the terminal budget.
        """
        p = self.parameters
        supervisor = self._release_supervisor_controller()
        if supervisor is None:
            return None
        now = float(observation.sim_time)
        # V9.3.12-R4-E4: the POSITION-blocker corridor owns the chassis from
        # DEPART through final RGB verification.  Supervisor must not arm a
        # SETTLE at the intentionally large nonholonomic excursion apex.  The
        # unchanged release chain regains first priority immediately after E3
        # returns to IDLE.
        if (
            self._position_blocker_recenter_active is not None
            or self._position_blocker_recenter_phase != "IDLE"
        ):
            return None

        # V9.3.12-R4-E2: certification-space recenter owns motion and its
        # post-motion RGB verification exclusively. Do not let Supervisor arm
        # a new SETTLE in the middle of that feedback cycle. Once E2 returns to
        # IDLE, the unchanged Supervisor gets first opportunity on the next
        # frame.
        if (
            self._certification_basin_closure_active is not None
            or self._certification_basin_closure_phase != "IDLE"
        ):
            self._certification_basin_closure_supervisor_retry_suppressed_count += 1
            return None
        certification_error = self._load_to_strict_release_error(observation)
        post_guard = self._post_closure_basin_guard_controller()
        standard_precommit_geometry = (
            filtered_error.distance <= p.placement_release_prebrake_position_tolerance
            and abs(filtered_error.yaw) <= p.placement_release_prebrake_yaw_tolerance
            and placement_vision_ready
        )
        post_closure_handoff_ready = bool(
            self._post_closure_basin_ownership_active
            and post_guard is not None
            and placement_vision_ready
            and self._placement_target_multiview_ready
            and post_guard.certification_handoff_ready(
                filtered_distance_m=float(filtered_error.distance),
                filtered_yaw_rad=float(filtered_error.yaw),
                certification_distance_m=float(certification_error.distance),
                certification_yaw_rad=float(certification_error.yaw),
                prebrake_position_limit_m=p.placement_release_prebrake_position_tolerance,
                prebrake_yaw_limit_rad=p.placement_release_prebrake_yaw_tolerance,
            )
        )
        if self._post_closure_basin_ownership_active:
            self._post_closure_last_certification_position_m = float(certification_error.distance)
            self._post_closure_last_certification_yaw_rad = float(certification_error.yaw)
        precommit_geometry = bool(standard_precommit_geometry or post_closure_handoff_ready)
        if not supervisor.active:
            # Advance COOLDOWN -> IDLE without holding the vehicle.  MPC retains
            # ownership during the cooldown interval.
            if supervisor.mode == ReleaseDecisionSupervisor.COOLDOWN:
                supervisor.update(now, certified=False, hard_safe=True)
            if precommit_geometry and supervisor.can_arm(now):
                supervisor.begin_settle(now)
                self._placement_release_prebrake_count += 1
                if post_closure_handoff_ready and not standard_precommit_geometry:
                    self._post_closure_certification_handoff_count += 1
                self._placement_precision_phase = "RELEASE_SETTLE"
                self._placement_mpc_last_plan = None
                self._placement_precision_set_direction(0)
            else:
                if self._placement_precision_phase in ("RELEASE_SETTLE", "RELEASE_INTENT"):
                    self._placement_precision_phase = "MPC"
                return None

        post_closure_supervisor_handoff = bool(
            self._post_closure_basin_ownership_active
            and post_guard is not None
            and post_guard.pose_guarded(
                float(filtered_error.distance),
                float(filtered_error.yaw),
            )
        )
        hard_geometry_ok = (
            (
                certification_error.distance <= p.placement_release_abort_position_tolerance
                and abs(certification_error.yaw) <= p.placement_release_abort_yaw_tolerance
                and post_guard is not None
                and post_guard.pose_guarded(
                    float(filtered_error.distance),
                    float(filtered_error.yaw),
                )
            )
            if post_closure_supervisor_handoff
            else (
                filtered_error.distance <= p.placement_release_abort_position_tolerance
                and abs(filtered_error.yaw) <= p.placement_release_abort_yaw_tolerance
            )
        )
        observer_consistent = (
            not self.placement_carried_observer_active
            or (
                self._carried_load_observer_disagreement_position_m
                <= p.placement_carried_observer_release_disagreement_position_m
                and math.radians(self._carried_load_observer_disagreement_yaw_deg)
                <= p.placement_carried_observer_release_disagreement_yaw_rad
            )
        )
        strict_release_certified = self._strict_release_certified(
            certification_error=certification_error,
            now=now,
            placement_vision_ready=placement_vision_ready,
        )
        speed_ready = abs(forward_speed) <= p.placement_precision_release_max_speed
        certified_ready = bool(
            strict_release_certified
            and speed_ready
            and placement_vision_ready
            and observer_consistent
        )

        # Preserve the historical blocker counters, but align them with the
        # single strict-certification envelope instead of a contradictory
        # 6.5cm candidate gate.
        if (
            certification_error.distance
            + self._strict_release_certification_last_position_margin_m
            > p.placement_strict_release_position_limit_m
        ):
            self._placement_release_block_position_frames += 1
        if (
            abs(certification_error.yaw)
            + math.radians(self._strict_release_certification_last_yaw_margin_deg)
            > p.placement_strict_release_yaw_limit_rad
        ):
            self._placement_release_block_yaw_frames += 1
        if not speed_ready:
            self._placement_release_block_speed_frames += 1
        if not placement_vision_ready:
            self._placement_release_block_vision_frames += 1
        if not observer_consistent:
            self._placement_release_block_observer_frames += 1

        witness_hard_safe = True
        self._release_witness_drift_violation_active = False
        if (
            p.placement_release_witness_enabled > 0.5
            and supervisor.mode == ReleaseDecisionSupervisor.INTENT
            and self._release_certification_witness_error is not None
        ):
            witness = self._release_certification_witness_error
            position_drift = math.hypot(
                float(certification_error.longitudinal) - float(witness.longitudinal),
                float(certification_error.lateral) - float(witness.lateral),
            )
            yaw_drift = abs(
                wrap_angle(float(certification_error.yaw) - float(witness.yaw))
            )
            self._release_witness_position_drift_m = float(position_drift)
            self._release_witness_yaw_drift_rad = float(yaw_drift)
            witness_hard_safe = bool(
                position_drift <= p.placement_release_witness_position_drift_tolerance_m
                and yaw_drift <= p.placement_release_witness_yaw_drift_tolerance_rad
            )
            self._release_witness_drift_violation_active = not witness_hard_safe

        previous_mode = supervisor.mode
        if (
            previous_mode == ReleaseDecisionSupervisor.INTENT
            and p.placement_release_witness_enabled > 0.5
            and not witness_hard_safe
        ):
            update = supervisor.revoke_intent(now)
        else:
            instant_intent_required = (
                p.placement_release_witness_require_instant_strict_for_intent > 0.5
                and p.placement_release_witness_enabled > 0.5
            )
            intent_authorized = bool(
                not instant_intent_required
                or self._strict_release_certification_last_instant_result
            )
            if (
                supervisor.mode == ReleaseDecisionSupervisor.SETTLE
                and certified_ready
                and not intent_authorized
                and supervisor.evidence_seconds >= supervisor.config.evidence_seconds
            ):
                self._release_witness_instant_strict_gate_block_count += 1
            update = supervisor.update(
                now,
                certified=certified_ready,
                hard_safe=hard_geometry_ok,
                intent_authorized=intent_authorized,
            )
        self._placement_release_evidence_seconds = float(update.evidence_seconds)
        self._placement_release_last_update_time = now
        self._placement_mpc_last_plan = None

        if supervisor.intent_count > self._release_supervisor_last_intent_count:
            delta = supervisor.intent_count - self._release_supervisor_last_intent_count
            self._placement_release_commit_count += delta
            self._placement_release_candidate_count += delta
            self._release_supervisor_last_intent_count = supervisor.intent_count
        if supervisor.intent_abort_count > self._release_supervisor_last_intent_abort_count:
            delta = supervisor.intent_abort_count - self._release_supervisor_last_intent_abort_count
            self._placement_release_commit_abort_count += delta
            self._placement_release_prebrake_abort_count += delta
            self._release_supervisor_last_intent_abort_count = supervisor.intent_abort_count
        if supervisor.settle_timeout_count > self._release_supervisor_last_settle_timeout_count:
            delta = supervisor.settle_timeout_count - self._release_supervisor_last_settle_timeout_count
            self._placement_release_prebrake_abort_count += delta
            self._release_supervisor_last_settle_timeout_count = supervisor.settle_timeout_count

        if (
            p.placement_release_witness_enabled > 0.5
            and previous_mode == ReleaseDecisionSupervisor.SETTLE
            and update.mode == ReleaseDecisionSupervisor.INTENT
            and certified_ready
        ):
            self._release_certification_witness_error = certification_error
            self._release_certification_witness_time = now
            self._release_witness_position_drift_m = 0.0
            self._release_witness_yaw_drift_rad = 0.0
            self._release_witness_capture_count += 1

        if update.action == ReleaseDecisionSupervisor.RESUME_MPC:
            if self._release_witness_drift_violation_active:
                self._release_witness_drift_abort_count += 1
            self._release_certification_witness_error = None
            self._release_certification_witness_time = None
            self._placement_precision_phase = "MPC"
            self._placement_precision_set_direction(0)
            return self._decision(
                action=ForkliftAction.stopped(lift_target=p.transport_lift_target),
                observation=observation,
                status=(
                    "V9.3.4 release supervisor returned ownership to MPC "
                    f"after {previous_mode.lower()}"
                ),
                error=command_error,
                progress_score=self._placement_precision_progress_score(filtered_error),
                placement_error=placement_error,
            )

        self._placement_precision_set_direction(0)
        self._placement_precision_hold_frame_count += 1
        if update.action == ReleaseDecisionSupervisor.EXECUTE:
            self._placement_precision_phase = "RELEASE_INTENT"
            if p.placement_release_snapshot_enabled > 0.5:
                # V9.3.8 compatibility note: the former implementation used
                # `self._release_snapshot_error = filtered_error`; V9.3.9
                # snapshots the certification witness instead so post-release
                # geometry has the same semantics as the state that was certified.
                self._release_snapshot_error = (
                    self._release_certification_witness_error
                    if self._release_certification_witness_error is not None
                    else certification_error
                )
            self._transition(PickupState.LOWER_LOAD, observation)
            return self._decision(
                action=ForkliftAction.stopped(lift_target=p.placement_lower_target),
                observation=observation,
                status=(
                    "V9.3.4 RELEASE_INTENT executed after certified evidence "
                    f"{update.evidence_seconds:.2f}s"
                ),
                error=command_error,
                progress_score=self._placement_precision_progress_score(filtered_error),
                placement_error=placement_error,
            )

        self._placement_precision_phase = (
            "RELEASE_INTENT"
            if update.mode == ReleaseDecisionSupervisor.INTENT
            else "RELEASE_SETTLE"
        )
        return self._decision(
            action=ForkliftAction.stopped(lift_target=p.transport_lift_target),
            observation=observation,
            status=(
                f"V9.3.4 {self._placement_precision_phase.lower()} "
                f"evidence={update.evidence_seconds:.2f}/"
                f"{p.placement_release_supervisor_evidence_seconds:.2f}s"
            ),
            error=command_error,
            progress_score=self._placement_precision_progress_score(filtered_error),
            placement_error=placement_error,
        )

    def _carried_visual_stale_for_release(self, now: float) -> float:
        """Translation-evidence staleness (legacy carried RGB clock).

        R4-F3 keeps this method as the translation clock for backward
        compatibility. Terminal D2 position-only updates refresh it because
        they are genuine x/y/z evidence.
        """
        if self._carried_load_visual_last_rgb_time is None:
            return float("inf")
        return max(0.0, float(now) - self._carried_load_visual_last_rgb_time)

    def _carried_yaw_stale_for_release(self, now: float) -> float:
        """Yaw-evidence staleness, separate from translation freshness.

        With F3 enabled, a translation-only terminal reacquisition must never
        claim that carried-load yaw was freshly observed. Legacy profiles keep
        the old shared-clock semantics.
        """
        if self.parameters.placement_carried_yaw_axis_evidence_enabled <= 0.5:
            return self._carried_visual_stale_for_release(now)
        if self._carried_load_yaw_last_evidence_time is None:
            return float("inf")
        return max(0.0, float(now) - self._carried_load_yaw_last_evidence_time)

    def _motion_carried_load_yaw_sigma_rad(self) -> float:
        """Yaw uncertainty used only to authorize bounded terminal motion.

        Release certification always uses ``_effective_carried_load_yaw_sigma_rad``.
        F3 allows the already-validated E/E1 closure search to rely on the
        quality-qualified F1 anchor covariance while the rigid-load contact
        monitor is active. Long-horizon transport/slip risk therefore remains
        in the release budget without incorrectly disabling motion search.
        """
        release_sigma = self._effective_carried_load_yaw_sigma_rad()
        p = self.parameters
        if p.placement_carried_yaw_axis_evidence_enabled <= 0.5:
            return release_sigma
        if self._carried_load_yaw_evidence_source not in (
            "LATE_INSERT_ANCHOR", "PICKUP_RGB_LIVE", "TERMINAL_RGB_FULL"
        ):
            return release_sigma
        monitor = self._rigid_load_constraint_monitor
        if monitor is None or not monitor.active:
            return release_sigma
        base = math.radians(max(0.0, float(self._carried_load_pose_yaw_std_deg)))
        return float(max(p.placement_carried_observer_minimum_yaw_sigma_rad, base))

    def _certified_basin_controller(self) -> CertifiedBasinLatch | None:
        p = self.parameters
        if p.placement_certified_basin_enabled <= 0.5:
            return None
        if self._certified_basin is None:
            self._certified_basin = CertifiedBasinLatch(
                CertifiedBasinConfig(
                    hold_seconds=p.placement_certified_basin_hold_seconds,
                    consensus_evidence_seconds=p.placement_certified_basin_consensus_evidence_seconds,
                    consensus_evidence_decay=p.placement_certified_basin_consensus_evidence_decay,
                    allow_consensus_entry=(
                        p.placement_certified_basin_consensus_release_authority > 0.5
                    ),
                )
            )
        return self._certified_basin

    def _rigid_load_constraint_controller(self) -> RigidLoadConstraintMonitor | None:
        p = self.parameters
        if p.placement_rigid_load_constraint_enabled <= 0.5:
            return None
        if self._rigid_load_constraint_monitor is None:
            self._rigid_load_constraint_monitor = RigidLoadConstraintMonitor(
                RigidLoadConstraintConfig(
                    minimum_fork_contacts=p.placement_rigid_load_constraint_min_fork_contacts,
                    maximum_abs_lift_velocity=p.placement_rigid_load_constraint_max_lift_velocity,
                    minimum_stable_seconds=p.placement_rigid_load_constraint_min_stable_seconds,
                )
            )
        return self._rigid_load_constraint_monitor

    def _yaw_tail_reserve_controller(self) -> TerminalYawTailReservePlanner | None:
        p = self.parameters
        if p.placement_yaw_tail_reserve_enabled <= 0.5:
            return None
        if self._yaw_tail_reserve_planner is None:
            self._yaw_tail_reserve_planner = TerminalYawTailReservePlanner(
                YawTailReserveConfig(
                    wheelbase_m=p.transport_path_wheelbase,
                    steering_limit_rad=p.placement_mpc_steering_limit,
                    speed_mps=p.placement_yaw_tail_reserve_speed_mps,
                    position_gate_m=p.placement_yaw_tail_reserve_position_gate_m,
                    yaw_min_rad=p.placement_yaw_tail_reserve_yaw_min_rad,
                    yaw_max_rad=p.placement_yaw_tail_reserve_yaw_max_rad,
                    predicted_position_guard_m=p.placement_yaw_tail_reserve_position_guard_m,
                    required_yaw_improvement_rad=p.placement_yaw_tail_reserve_required_yaw_improvement_rad,
                    duration_options_s=(p.placement_yaw_tail_reserve_duration_short_s, p.placement_yaw_tail_reserve_duration_long_s),
                    steering_fractions=(-1.0, -0.55, 0.55, 1.0),
                    maximum_speed_for_activation_mps=p.placement_yaw_tail_reserve_maximum_speed_for_activation_mps,
                    max_activations=p.placement_yaw_tail_reserve_max_activations,
                    maximum_total_execution_seconds=p.placement_yaw_tail_reserve_maximum_total_execution_seconds,
                )
            )
        return self._yaw_tail_reserve_planner

    def _post_closure_basin_guard_controller(self) -> PostClosureBasinGuard | None:
        p = self.parameters
        if p.placement_post_closure_basin_ownership_enabled <= 0.5:
            return None
        if self._post_closure_basin_guard is None:
            self._post_closure_basin_guard = PostClosureBasinGuard(
                PostClosureBasinGuardConfig(
                    position_guard_m=p.placement_post_closure_basin_position_guard_m,
                    yaw_guard_rad=p.placement_post_closure_basin_yaw_guard_rad,
                    mpc_predicted_position_limit_m=p.placement_post_closure_mpc_predicted_position_limit_m,
                    mpc_allowed_position_regression_m=p.placement_post_closure_mpc_allowed_position_regression_m,
                    mpc_allowed_yaw_regression_rad=p.placement_post_closure_mpc_allowed_yaw_regression_rad,
                    continuation_position_gate_m=p.placement_post_closure_continuation_position_gate_m,
                )
            )
        return self._post_closure_basin_guard

    def _position_blocker_recenter_controller(self) -> PositionBlockerRecenterPlanner | None:
        p = self.parameters
        if p.placement_position_blocker_recenter_enabled <= 0.5:
            return None
        if self._position_blocker_recenter_planner is None:
            self._position_blocker_recenter_planner = PositionBlockerRecenterPlanner(
                PositionBlockerRecenterConfig(
                    wheelbase_m=p.transport_path_wheelbase,
                    steering_limit_rad=p.placement_mpc_steering_limit,
                    speed_mps=p.placement_position_blocker_recenter_speed_mps,
                    filtered_position_activation_m=p.placement_position_blocker_recenter_filtered_position_activation_m,
                    filtered_yaw_activation_rad=p.placement_position_blocker_recenter_filtered_yaw_activation_rad,
                    certification_position_activation_m=p.placement_position_blocker_recenter_certification_position_activation_m,
                    certification_yaw_activation_rad=p.placement_position_blocker_recenter_certification_yaw_activation_rad,
                    minimum_lateral_fraction=p.placement_position_blocker_recenter_minimum_lateral_fraction,
                    strict_position_limit_m=p.placement_strict_release_position_limit_m,
                    strict_yaw_limit_rad=p.placement_strict_release_yaw_limit_rad,
                    predicted_position_headroom_m=p.placement_position_blocker_recenter_predicted_position_headroom_m,
                    predicted_yaw_headroom_rad=p.placement_position_blocker_recenter_predicted_yaw_headroom_rad,
                    maximum_predicted_filtered_excursion_m=p.placement_position_blocker_recenter_maximum_predicted_excursion_m,
                    final_filtered_position_guard_m=p.placement_position_blocker_recenter_final_filtered_position_guard_m,
                    final_filtered_yaw_guard_rad=p.placement_position_blocker_recenter_final_filtered_yaw_guard_rad,
                    departure_duration_options_s=(
                        p.placement_position_blocker_recenter_departure_duration_short_s,
                        p.placement_position_blocker_recenter_departure_duration_medium_s,
                        p.placement_position_blocker_recenter_departure_duration_long_s,
                    ),
                    return_duration_options_s=(
                        p.placement_position_blocker_recenter_return_duration_short_s,
                        p.placement_position_blocker_recenter_return_duration_medium_s,
                        p.placement_position_blocker_recenter_return_duration_long_s,
                    ),
                    steering_fractions=(p.placement_position_blocker_recenter_steering_fraction, 1.0),
                    maximum_speed_for_activation_mps=p.placement_position_blocker_recenter_maximum_speed_for_activation_mps,
                    maximum_total_execution_seconds=p.placement_position_blocker_recenter_maximum_total_execution_seconds,
                    require_non_retrace_topology=(
                        p.placement_position_blocker_recenter_require_non_retrace_topology > 0.5
                    ),
                )
            )
        return self._position_blocker_recenter_planner

    def _certification_basin_closure_controller(self) -> CertificationBasinClosurePlanner | None:
        p = self.parameters
        if p.placement_certification_basin_closure_enabled <= 0.5:
            return None
        if self._certification_basin_closure_planner is None:
            self._certification_basin_closure_planner = CertificationBasinClosurePlanner(
                CertificationBasinClosureConfig(
                    wheelbase_m=p.transport_path_wheelbase,
                    steering_limit_rad=p.placement_mpc_steering_limit,
                    speed_mps=p.placement_certification_basin_closure_speed_mps,
                    filtered_position_guard_m=p.placement_certification_basin_closure_filtered_position_guard_m,
                    filtered_yaw_guard_rad=p.placement_certification_basin_closure_filtered_yaw_guard_rad,
                    certification_position_activation_m=p.placement_certification_basin_closure_certification_position_activation_m,
                    certification_yaw_activation_rad=p.placement_certification_basin_closure_certification_yaw_activation_rad,
                    predicted_filtered_position_guard_m=p.placement_certification_basin_closure_predicted_filtered_position_guard_m,
                    predicted_filtered_yaw_guard_rad=p.placement_certification_basin_closure_predicted_filtered_yaw_guard_rad,
                    strict_position_limit_m=p.placement_strict_release_position_limit_m,
                    strict_yaw_limit_rad=p.placement_strict_release_yaw_limit_rad,
                    position_scale_m=p.placement_certification_basin_closure_position_scale_m,
                    yaw_scale_rad=p.placement_certification_basin_closure_yaw_scale_rad,
                    required_predicted_deficit_improvement=p.placement_certification_basin_closure_required_predicted_deficit_improvement,
                    allowed_filtered_position_regression_m=p.placement_certification_basin_closure_allowed_filtered_position_regression_m,
                    duration_options_s=(
                        p.placement_certification_basin_closure_duration_short_s,
                        p.placement_certification_basin_closure_duration_medium_s,
                        p.placement_certification_basin_closure_duration_long_s,
                    ),
                    steering_fractions=(p.placement_certification_basin_closure_mid_steering_fraction, 1.0),
                    second_leg_duration_fractions=(0.0, p.placement_certification_basin_closure_second_leg_duration_fraction, 1.0),
                    maximum_speed_for_activation_mps=p.placement_certification_basin_closure_maximum_speed_for_activation_mps,
                    max_activations=p.placement_certification_basin_closure_max_activations,
                    maximum_total_execution_seconds=p.placement_certification_basin_closure_maximum_total_execution_seconds,
                )
            )
        return self._certification_basin_closure_planner

    def _certification_strict_deficit(self, certification_error: DockingError) -> float:
        p = self.parameters
        planner = self._certification_basin_closure_controller()
        if planner is None:
            return 0.0
        return planner.strict_deficit(
            distance_m=float(certification_error.distance),
            yaw_rad=float(certification_error.yaw),
            position_margin_m=float(self._strict_release_certification_last_position_margin_m),
            yaw_margin_rad=math.radians(float(self._strict_release_certification_last_yaw_margin_deg)),
            position_limit_m=p.placement_strict_release_position_limit_m,
            yaw_limit_rad=p.placement_strict_release_yaw_limit_rad,
            position_scale_m=p.placement_certification_basin_closure_position_scale_m,
            yaw_scale_rad=p.placement_certification_basin_closure_yaw_scale_rad,
        )

    def _fresh_rgb_yaw_closure_controller(self) -> FreshRGBYawClosurePlanner | None:
        p = self.parameters
        if p.placement_fresh_rgb_yaw_closure_enabled <= 0.5:
            return None
        if self._fresh_rgb_yaw_closure_planner is None:
            self._fresh_rgb_yaw_closure_planner = FreshRGBYawClosurePlanner(
                FreshRGBYawClosureConfig(
                    wheelbase_m=p.transport_path_wheelbase,
                    steering_limit_rad=p.placement_mpc_steering_limit,
                    speed_mps=p.placement_fresh_rgb_yaw_closure_speed_mps,
                    position_gate_m=p.placement_fresh_rgb_yaw_closure_position_gate_m,
                    yaw_min_rad=p.placement_fresh_rgb_yaw_closure_yaw_min_rad,
                    yaw_max_rad=p.placement_fresh_rgb_yaw_closure_yaw_max_rad,
                    target_yaw_rad=p.placement_fresh_rgb_yaw_closure_target_yaw_rad,
                    midpoint_position_guard_m=p.placement_fresh_rgb_yaw_closure_midpoint_position_guard_m,
                    final_position_guard_m=p.placement_fresh_rgb_yaw_closure_final_position_guard_m,
                    required_yaw_improvement_rad=p.placement_fresh_rgb_yaw_closure_required_predicted_yaw_improvement_rad,
                    duration_options_s=(
                        p.placement_fresh_rgb_yaw_closure_duration_short_s,
                        p.placement_fresh_rgb_yaw_closure_duration_medium_s,
                        p.placement_fresh_rgb_yaw_closure_duration_long_s,
                    ),
                    steering_fractions=(
                        p.placement_fresh_rgb_yaw_closure_mid_steering_fraction, 1.0
                    ),
                    maximum_speed_for_activation_mps=p.placement_fresh_rgb_yaw_closure_maximum_speed_for_activation_mps,
                    max_activations=p.placement_fresh_rgb_yaw_closure_max_activations,
                    maximum_total_execution_seconds=p.placement_fresh_rgb_yaw_closure_maximum_total_execution_seconds,
                )
            )
        return self._fresh_rgb_yaw_closure_planner

    def _strict_recovery_retention_controller(self) -> StrictRecoveryRetentionPlanner | None:
        p = self.parameters
        if p.placement_strict_recovery_retention_enabled <= 0.5:
            return None
        if self._strict_recovery_retention_planner is None:
            self._strict_recovery_retention_planner = StrictRecoveryRetentionPlanner(
                StrictRecoveryRetentionConfig(
                    wheelbase_m=p.transport_path_wheelbase,
                    steering_limit_rad=p.placement_mpc_steering_limit,
                    speed_mps=p.placement_strict_recovery_retention_speed_mps,
                    activation_distance_m=p.placement_strict_recovery_retention_activation_distance_m,
                    activation_yaw_rad=p.placement_strict_recovery_retention_activation_yaw_rad,
                    target_position_m=p.placement_strict_recovery_retention_target_position_m,
                    target_yaw_rad=p.placement_strict_recovery_retention_target_yaw_rad,
                    predicted_position_guard_m=p.placement_strict_recovery_retention_position_guard_m,
                    predicted_yaw_guard_rad=p.placement_strict_recovery_retention_yaw_guard_rad,
                    position_scale_m=p.placement_strict_recovery_retention_position_scale_m,
                    yaw_scale_rad=p.placement_strict_recovery_retention_yaw_scale_rad,
                    required_deficit_improvement=p.placement_strict_recovery_retention_required_improvement,
                    duration_options_s=(
                        p.placement_strict_recovery_retention_duration_short_s,
                        p.placement_strict_recovery_retention_duration_long_s,
                    ),
                    steering_fractions=(-1.0, -0.55, 0.0, 0.55, 1.0),
                    maximum_speed_for_activation_mps=p.placement_strict_recovery_retention_maximum_speed_for_activation_mps,
                    max_activations=p.placement_strict_recovery_retention_max_activations,
                    cooldown_seconds=p.placement_strict_recovery_retention_cooldown_seconds,
                    maximum_total_execution_seconds=p.placement_strict_recovery_retention_maximum_total_execution_seconds,
                )
            )
        return self._strict_recovery_retention_planner

    def _micro_primitive_controller(self) -> TerminalMicroPrimitivePlanner | None:
        p = self.parameters
        if p.placement_micro_primitive_enabled <= 0.5:
            return None
        if self._terminal_micro_primitive_planner is None:
            self._terminal_micro_primitive_planner = TerminalMicroPrimitivePlanner(
                TerminalMicroPrimitiveConfig(
                    wheelbase_m=p.transport_path_wheelbase,
                    steering_limit_rad=p.placement_mpc_steering_limit,
                    speed_mps=p.placement_micro_primitive_speed_mps,
                    activation_distance_m=p.placement_micro_primitive_activation_distance_m,
                    activation_yaw_rad=p.placement_micro_primitive_activation_yaw_rad,
                    maximum_predicted_distance_m=p.placement_micro_primitive_maximum_predicted_distance_m,
                    position_limit_m=p.placement_strict_release_position_limit_m,
                    yaw_limit_rad=p.placement_strict_release_yaw_limit_rad,
                    position_scale_m=p.placement_micro_primitive_position_scale_m,
                    yaw_scale_rad=p.placement_micro_primitive_yaw_scale_rad,
                    required_deficit_improvement=p.placement_micro_primitive_required_deficit_improvement,
                    duration_options_s=(
                        p.placement_micro_primitive_duration_short_s,
                        p.placement_micro_primitive_duration_medium_s,
                        p.placement_micro_primitive_duration_long_s,
                    ),
                    steering_fractions=(
                        -1.0, -p.placement_micro_primitive_mid_steering_fraction, 0.0,
                        p.placement_micro_primitive_mid_steering_fraction, 1.0,
                    ),
                    max_activations=p.placement_micro_primitive_max_activations,
                    cooldown_seconds=p.placement_micro_primitive_cooldown_seconds,
                    maximum_total_execution_seconds=p.placement_micro_primitive_maximum_total_execution_seconds,
                    reverse_penalty=p.placement_micro_primitive_reverse_penalty,
                    direction_switch_penalty=p.placement_micro_primitive_direction_switch_penalty,
                )
            )
        return self._terminal_micro_primitive_planner

    def _near_basin_escrow_controller(self) -> NearBasinFeasibilityEscrow | None:
        p = self.parameters
        if p.placement_mpc_near_basin_escrow_enabled <= 0.5:
            return None
        if self._near_basin_escrow is None:
            self._near_basin_escrow = NearBasinFeasibilityEscrow(
                NearBasinFeasibilityConfig(
                    activation_distance_m=p.placement_mpc_near_basin_activation_distance_m,
                    activation_yaw_rad=p.placement_mpc_near_basin_activation_yaw_rad,
                    maximum_predicted_distance_m=p.placement_mpc_near_basin_maximum_predicted_distance_m,
                    position_scale_m=p.placement_mpc_near_basin_position_scale_m,
                    yaw_scale_rad=p.placement_mpc_near_basin_yaw_scale_rad,
                    required_deficit_improvement=p.placement_mpc_near_basin_required_deficit_improvement,
                    allowed_active_regression=p.placement_mpc_near_basin_allowed_active_regression,
                    max_seconds=p.placement_mpc_near_basin_max_seconds,
                    max_activations=p.placement_mpc_near_basin_max_activations,
                )
            )
        return self._near_basin_escrow

    def _release_center_yaw_world_yaw(
        self, observation: ForkliftObservation, pose_in_base: Pose3D
    ) -> float:
        """Convert a release centre-yaw proposal to the world-fixed target yaw."""
        return wrap_angle(float(observation.vehicle_pose_world.yaw) + float(pose_in_base.yaw))

    def _invalidate_release_evidence_for_center_yaw_conflict(self, now: float) -> None:
        """Immediately revoke release evidence without touching motion ownership.

        S1 showed that a 2.85deg centre re-anchor can occur inside the 0.5s
        Supervisor/Witness latency budget.  Waiting for the historical hard-
        violation grace would therefore be too slow.  The supervisor exposes a
        dedicated external-evidence invalidation hook in S2 so counters/rearm
        semantics remain auditable.
        """
        self._strict_release_certification_last_result = False
        self._strict_release_certification_last_instant_result = False
        self._release_certification_witness_error = None
        self._release_certification_witness_time = None
        supervisor = self._release_supervisor
        if supervisor is None:
            self._placement_release_evidence_seconds = 0.0
            return
        before_abort = int(supervisor.intent_abort_count)
        supervisor.invalidate_external_evidence(float(now))
        self._placement_release_evidence_seconds = 0.0
        if supervisor.intent_abort_count > before_abort:
            delta = int(supervisor.intent_abort_count) - before_abort
            self._placement_release_commit_abort_count += delta
            self._placement_release_prebrake_abort_count += delta
        self._release_supervisor_last_intent_abort_count = int(supervisor.intent_abort_count)
        if self._placement_precision_phase in ("RELEASE_SETTLE", "RELEASE_INTENT"):
            self._placement_precision_phase = "MPC"

    def _update_release_center_yaw_continuity_guard(
        self, observation: ForkliftObservation
    ) -> None:
        """S2 release-only world-yaw continuity/conflict guard.

        The centre proposal continues to be observed while conflict is active,
        but it cannot replace the release target until it remains stable inside
        the configured revalidation tolerance for the configured interval.
        Non-release motion/control paths never consume this latch.
        """
        p = self.parameters
        enabled = p.placement_strict_release_center_yaw_continuity_guard_enabled > 0.5
        pose = self._placement_release_center_yaw_target_pose_in_base
        if not enabled:
            self._strict_release_center_yaw_guard = None
            self._strict_release_center_yaw_conflict_active = False
            self._strict_release_center_yaw_current_world_yaw_rad = (
                None if pose is None else self._release_center_yaw_world_yaw(observation, pose)
            )
            self._strict_release_center_yaw_current_jump_rad = None
            return

        if self._strict_release_center_yaw_guard is None:
            self._strict_release_center_yaw_guard = ReleaseCenterYawConflictGuard(
                ReleaseCenterYawConflictGuardConfig(
                    maximum_reanchor_jump_rad=p.placement_strict_release_center_yaw_max_reanchor_jump_rad,
                    revalidation_seconds=p.placement_strict_release_center_yaw_revalidation_seconds,
                    revalidation_tolerance_rad=p.placement_strict_release_center_yaw_revalidation_tolerance_rad,
                )
            )

        world_yaw = (
            None if pose is None else self._release_center_yaw_world_yaw(observation, pose)
        )
        update = self._strict_release_center_yaw_guard.update(
            float(observation.sim_time),
            proposal_world_yaw_rad=world_yaw,
            release_precision_active=self.state == PickupState.PLACE_PRECISION,
        )
        self._strict_release_center_yaw_conflict_active = bool(update.conflict_active)
        self._strict_release_center_yaw_current_world_yaw_rad = update.current_world_yaw_rad
        self._strict_release_center_yaw_current_jump_rad = update.current_jump_rad
        self._strict_release_center_yaw_conflict_count = int(update.conflict_count)
        self._strict_release_center_yaw_revalidation_count = int(update.revalidation_count)
        self._strict_release_center_yaw_conflict_last_jump_rad = update.last_conflict_jump_rad

        if update.conflict_started:
            stale = self._carried_yaw_stale_for_release(float(observation.sim_time))
            self._strict_release_center_yaw_conflict_last_load_stale_seconds = (
                float(stale) if math.isfinite(stale) else None
            )
            self._invalidate_release_evidence_for_center_yaw_conflict(
                float(observation.sim_time)
            )

    def _strict_release_certified(
        self, *, certification_error: DockingError, now: float, placement_vision_ready: bool
    ) -> bool:
        p = self.parameters
        if p.placement_strict_release_certification_enabled <= 0.5:
            return True
        translation_stale = self._carried_visual_stale_for_release(now)
        yaw_stale = self._carried_yaw_stale_for_release(now)
        visual_lock_required = p.placement_carried_visual_require_lock_for_release > 0.5

        if math.isfinite(translation_stale):
            translation_stale_for_margin = translation_stale
            if p.placement_carried_visual_release_stale_seconds > 0.0:
                translation_stale_for_margin = min(
                    translation_stale_for_margin,
                    p.placement_carried_visual_release_stale_seconds,
                )
            stale_position = (
                p.placement_carried_visual_stale_position_gain_mps
                * translation_stale_for_margin
            )
        elif visual_lock_required:
            stale_position = p.placement_strict_release_position_limit_m
        else:
            stale_position = 0.0

        if math.isfinite(yaw_stale):
            yaw_stale_for_margin = yaw_stale
            if p.placement_carried_visual_release_stale_seconds > 0.0:
                yaw_stale_for_margin = min(
                    yaw_stale_for_margin,
                    p.placement_carried_visual_release_stale_seconds,
                )
            stale_yaw = p.placement_carried_visual_stale_yaw_gain_radps * yaw_stale_for_margin
        elif visual_lock_required:
            # F3: position-only RGB cannot manufacture yaw freshness. If a
            # profile requires visual carried-load authority and no yaw evidence
            # has ever existed, keep the conservative full-yaw penalty.
            stale_yaw = p.placement_strict_release_yaw_limit_rad
        else:
            stale_yaw = 0.0
        # V9.3.8: target RGB uncertainty is independent from carried-load
        # uncertainty. Keep the filtered consensus as the release_ready gate,
        # while raw accepted RGB spread contributes only a bounded margin.
        multiview_enabled = p.placement_strict_release_multiview_enabled > 0.5
        multiview_ready = bool(
            self._placement_target_multiview_ready
            and self._placement_certification_target_pose_in_base is not None
        )
        if multiview_enabled and multiview_ready:
            target_position_spread = self._placement_target_multiview_position_spread_m
            target_yaw_spread = self._placement_target_multiview_yaw_spread_rad
        else:
            target_position_spread = self._placement_target_raw_position_spread_m
            target_yaw_spread = self._placement_target_raw_yaw_spread_rad
        target_position_margin = p.placement_strict_release_target_position_margin_floor_m
        target_yaw_margin = p.placement_strict_release_target_yaw_margin_floor_rad
        if target_position_spread is not None:
            target_position_margin = max(
                target_position_margin,
                p.placement_strict_release_target_position_spread_gain * target_position_spread,
            )
        if target_yaw_spread is not None:
            target_yaw_margin = max(
                target_yaw_margin,
                p.placement_strict_release_target_yaw_spread_gain * target_yaw_spread,
            )
        if p.placement_strict_release_target_position_margin_cap_m > 0.0:
            target_position_margin = min(
                target_position_margin,
                p.placement_strict_release_target_position_margin_cap_m,
            )
        if p.placement_strict_release_target_yaw_margin_cap_rad > 0.0:
            target_yaw_margin = min(
                target_yaw_margin,
                p.placement_strict_release_target_yaw_margin_cap_rad,
            )
        self._strict_release_certification_last_target_position_margin_m = float(target_position_margin)
        self._strict_release_certification_last_target_yaw_margin_deg = math.degrees(float(target_yaw_margin))

        # V9.3.5 certification V2 uses the effective carried-load belief.
        # V9.3.8 adds target uncertainty separately and keeps execution reserve.
        # R3 only spends the less-conservative position RSS budget when the
        # independent target tracks also agree inside the tighter consensus
        # quality envelope. Otherwise certification falls back to the legacy
        # additive margin. This prevents contact rigidity from masking a target
        # association disagreement on unseen seeds.
        trusted_seed_for_rss = bool(
            p.placement_carried_seed_provenance_enabled <= 0.5
            or p.placement_carried_seed_require_trusted_for_rss <= 0.5
            or self._carried_load_seed_trusted_for_aggressive_risk
        )
        rss_enabled = bool(
            p.placement_strict_release_rss_uncertainty_enabled > 0.5
            and trusted_seed_for_rss
            and multiview_ready
            and self._placement_target_fast_slow_position_disagreement_m is not None
            and self._placement_target_fast_slow_yaw_disagreement_rad is not None
            and self._placement_target_fast_slow_position_disagreement_m
            <= p.placement_certified_basin_consensus_max_fast_slow_position_m
            and self._placement_target_fast_slow_yaw_disagreement_rad
            <= p.placement_certified_basin_consensus_max_fast_slow_yaw_rad
        )
        self._strict_release_risk_budget_rss_active = bool(rss_enabled)
        # R4-F4: yaw kept the legacy additive budget after R3 because the old
        # carried-load yaw mean could be optimistic by >2deg. F2 removed that
        # self-confirming load-yaw authority and F3 separated motion/release
        # uncertainty.  Only when a fresh centre-PnP world-yaw anchor exists,
        # the trusted multiview position risk is already in RSS mode, and the
        # rigid-load monitor confirms the F1 load anchor remains observable,
        # may the *uncertainty* yaw terms use RSS. The full release sigma, yaw
        # staleness term, target floor/spread, and additive execution reserve
        # are all retained; no threshold or reserve is reduced.
        rigid_monitor = self._rigid_load_constraint_monitor
        center_yaw_rss_enabled = bool(
            p.placement_strict_release_center_yaw_rss_enabled > 0.5
            and p.placement_strict_release_center_yaw_anchor_enabled > 0.5
            and self._placement_release_center_yaw_target_pose_in_base is not None
            and not self._strict_release_center_yaw_conflict_active
            and rss_enabled
            and rigid_monitor is not None
            and rigid_monitor.active
            and self._motion_carried_load_yaw_sigma_rad()
            <= p.placement_fresh_rgb_yaw_closure_maximum_observer_yaw_sigma_rad
        )
        self._strict_release_yaw_rss_active = center_yaw_rss_enabled
        position_margin = combine_uncertainty_components(
            p.placement_strict_release_position_sigma_gain
            * self._effective_carried_load_position_sigma_m(),
            stale_position,
            target_position_margin,
            execution_reserve=p.placement_strict_release_execution_position_reserve_m,
            rss_enabled=rss_enabled,
        )
        # R4-F4 keeps the R3 additive yaw budget unless the independent current
        # centre-yaw anchor is live under the guarded contract above. Even in
        # CENTER_YAW_RSS mode, execution reserve remains additive inside the
        # shared risk-budget primitive.
        yaw_margin = combine_uncertainty_components(
            p.placement_strict_release_yaw_sigma_gain
            * self._effective_carried_load_yaw_sigma_rad(),
            stale_yaw,
            target_yaw_margin,
            execution_reserve=p.placement_strict_release_execution_yaw_reserve_rad,
            rss_enabled=center_yaw_rss_enabled,
        )
        self._strict_release_certification_last_position_margin_m = float(position_margin)
        self._strict_release_certification_last_yaw_margin_deg = math.degrees(float(yaw_margin))
        load_authority_ok = (
            p.placement_carried_visual_require_lock_for_release <= 0.5
            or self._carried_load_visual_authority_locked
        )
        terminal_visual_ok = (
            p.placement_strict_release_require_terminal_visual_lock <= 0.5
            or self._terminal_visual_authority == "VISUAL_LOCK"
        )
        multiview_required_ok = bool(
            p.placement_strict_release_multiview_required <= 0.5
            or multiview_ready
        )
        center_yaw_conflict_blocks_release = bool(
            self._strict_release_center_yaw_conflict_active and not multiview_ready
        )
        disagreement_position = self._placement_target_fast_slow_position_disagreement_m
        disagreement_yaw = self._placement_target_fast_slow_yaw_disagreement_rad
        multiview_consistent = bool(
            not multiview_enabled
            or not multiview_ready
            or (
                disagreement_position is not None
                and disagreement_yaw is not None
                and disagreement_position
                <= p.placement_strict_release_multiview_max_position_disagreement_m
                and disagreement_yaw
                <= p.placement_strict_release_multiview_max_yaw_disagreement_rad
            )
        )
        self._strict_release_certification_last_error = certification_error
        # Once LOAD_VISUAL_LOCK exists, lack of continued camera visibility is
        # not a reason to fall back to coarse guide; stale only increases the
        # certification margin through the gains above.
        position_ok = bool(
            certification_error.distance + position_margin
            <= p.placement_strict_release_position_limit_m
        )
        yaw_ok = bool(
            abs(certification_error.yaw) + yaw_margin
            <= p.placement_strict_release_yaw_limit_rad
        )
        instant_certified = bool(
            placement_vision_ready
            and load_authority_ok
            and terminal_visual_ok
            and multiview_required_ok
            and multiview_consistent
            and not center_yaw_conflict_blocks_release
            and position_ok
            and yaw_ok
        )
        self._strict_release_certification_last_instant_result = instant_certified

        # V9.3.11: convert frame-level certification into a bounded certified
        # basin. STRICT still has priority. A consensus entry may recover a
        # conservative false-negative only after temporally stable, independent
        # FAST/SLOW evidence is strong. Persistence may bridge short jitter but
        # never renews its own lease.
        certified = instant_certified
        basin = self._certified_basin_controller()
        if basin is not None:
            disagreement_position = self._placement_target_fast_slow_position_disagreement_m
            disagreement_yaw = self._placement_target_fast_slow_yaw_disagreement_rad
            target_position_spread_for_consensus = self._placement_target_multiview_position_spread_m
            target_yaw_spread_for_consensus = self._placement_target_multiview_yaw_spread_rad
            consensus_quality_ok = bool(
                p.placement_certified_basin_consensus_entry_enabled > 0.5
                and placement_vision_ready
                and load_authority_ok
                and terminal_visual_ok
                and multiview_required_ok
                and multiview_consistent
                and not center_yaw_conflict_blocks_release
                and disagreement_position is not None
                and disagreement_yaw is not None
                and target_position_spread_for_consensus is not None
                and target_yaw_spread_for_consensus is not None
                and disagreement_position
                <= p.placement_certified_basin_consensus_max_fast_slow_position_m
                and disagreement_yaw
                <= p.placement_certified_basin_consensus_max_fast_slow_yaw_rad
                and target_position_spread_for_consensus
                <= p.placement_certified_basin_consensus_max_target_position_spread_m
                and target_yaw_spread_for_consensus
                <= p.placement_certified_basin_consensus_max_target_yaw_spread_rad
                and self._effective_carried_load_position_sigma_m()
                <= p.placement_certified_basin_consensus_max_load_position_sigma_m
                and self._effective_carried_load_yaw_sigma_rad()
                <= p.placement_certified_basin_consensus_max_load_yaw_sigma_rad
            )
            consensus_candidate = bool(
                consensus_quality_ok
                and certification_error.distance
                <= p.placement_certified_basin_consensus_position_limit_m
                and abs(certification_error.yaw)
                <= p.placement_certified_basin_consensus_yaw_limit_rad
            )
            support_safe = bool(
                placement_vision_ready
                and load_authority_ok
                and terminal_visual_ok
                and multiview_required_ok
                and multiview_consistent
                and not center_yaw_conflict_blocks_release
                and certification_error.distance + position_margin
                <= p.placement_strict_release_position_limit_m
                + p.placement_certified_basin_position_exit_margin_m
                and abs(certification_error.yaw) + yaw_margin
                <= p.placement_strict_release_yaw_limit_rad
                + p.placement_certified_basin_yaw_exit_margin_rad
            )
            basin_update = basin.update(
                now,
                strict_certified=instant_certified,
                consensus_candidate=consensus_candidate,
                support_safe=support_safe,
            )
            certified = bool(basin_update.certified)
            self._certified_basin_last_source = basin_update.source
            self._certified_basin_last_age_seconds = basin_update.age_seconds
        else:
            self._certified_basin_last_source = "STRICT" if instant_certified else "NONE"
            self._certified_basin_last_age_seconds = 0.0

        # Explicit primary blocker telemetry. This is diagnosis only; it never
        # changes control. A basin-supplied certification clears the blocker.
        if certified:
            blocker = "NONE"
        elif not placement_vision_ready:
            blocker = "VISION"
        elif not load_authority_ok:
            blocker = "LOAD_AUTHORITY"
        elif not terminal_visual_ok:
            blocker = "TERMINAL_VISUAL"
        elif not multiview_required_ok:
            blocker = "MULTIVIEW_UNREADY"
        elif center_yaw_conflict_blocks_release:
            blocker = "CENTER_YAW_CONFLICT"
        elif not multiview_consistent:
            blocker = "FAST_SLOW_DISAGREEMENT"
        elif not position_ok:
            blocker = "POSITION"
        elif not yaw_ok:
            blocker = "YAW"
        else:
            blocker = "CONSENSUS_EVIDENCE"
        self._strict_release_certification_last_blocker = blocker
        if blocker != "NONE":
            self._strict_release_certification_blocker_counts[blocker] = (
                self._strict_release_certification_blocker_counts.get(blocker, 0) + 1
            )
        self._strict_release_certification_last_result = certified
        if certified:
            self._strict_release_certification_pass_count += 1
        else:
            self._strict_release_certification_reject_count += 1
        return certified

    def _placement_release_update_evidence(
        self,
        observation: ForkliftObservation,
        *,
        filtered_error: DockingError,
        placement_vision_ready: bool,
        forward_speed: float,
    ) -> bool:
        """Accumulate release evidence with a competition-safe hysteresis band."""
        p = self.parameters
        now = float(observation.sim_time)
        last = self._placement_release_last_update_time
        dt = 0.0 if last is None else max(0.0, min(0.20, now - last))
        self._placement_release_last_update_time = now

        # V9.3.0 uncertainty-aware dual-track release qualification.  The
        # slow observer drives control, while release additionally requires
        # agreement with its fast live track.  Covariance shrinks the internal
        # evidence gate rather than expanding the official 0.10m/5deg limit.
        position_margin = (
            p.placement_release_uncertainty_position_gain
            * self._carried_load_pose_position_std_m
        )
        yaw_margin = (
            p.placement_release_uncertainty_yaw_gain
            * math.radians(self._carried_load_pose_yaw_std_deg)
        )
        candidate_position_limit = max(
            0.01, p.placement_release_candidate_position_tolerance - position_margin
        )
        candidate_yaw_limit = max(
            math.radians(0.5), p.placement_release_candidate_yaw_tolerance - yaw_margin
        )
        position_candidate = filtered_error.distance <= candidate_position_limit
        yaw_candidate = abs(filtered_error.yaw) <= candidate_yaw_limit
        speed_ready = abs(forward_speed) <= p.placement_precision_release_max_speed
        observer_consistent = (
            not self.placement_carried_observer_active
            or (
                self._carried_load_observer_disagreement_position_m
                <= p.placement_carried_observer_release_disagreement_position_m
                and math.radians(self._carried_load_observer_disagreement_yaw_deg)
                <= p.placement_carried_observer_release_disagreement_yaw_rad
            )
        )
        candidate = (
            position_candidate and yaw_candidate and speed_ready
            and placement_vision_ready and observer_consistent
        )
        soft_envelope = (
            filtered_error.distance <= p.placement_release_abort_position_tolerance
            and abs(filtered_error.yaw) <= p.placement_release_abort_yaw_tolerance
            and (
                observer_consistent
                or self._carried_load_observer_disagreement_position_m
                <= 1.5 * p.placement_carried_observer_release_disagreement_position_m
            )
        )

        if candidate:
            if self._placement_release_evidence_seconds <= 1e-9:
                self._placement_release_candidate_count += 1
            self._placement_release_evidence_seconds += dt
        elif soft_envelope:
            self._placement_release_evidence_seconds = max(
                0.0,
                self._placement_release_evidence_seconds
                - p.placement_release_evidence_soft_decay * dt,
            )
        else:
            self._placement_release_evidence_seconds = 0.0

        if not position_candidate:
            self._placement_release_block_position_frames += 1
        if not yaw_candidate:
            self._placement_release_block_yaw_frames += 1
        if not speed_ready:
            self._placement_release_block_speed_frames += 1
        if not placement_vision_ready:
            self._placement_release_block_vision_frames += 1
        if not observer_consistent:
            self._placement_release_block_observer_frames += 1

        return self._placement_release_evidence_seconds >= p.placement_release_evidence_seconds

    def _step_place_precision_v925(
        self,
        observation: ForkliftObservation,
        *,
        placement_vision_ready: bool,
    ) -> PickupDecision:
        """V9.3.0 terminal MPC plus an independent release-commit latch."""
        p = self.parameters
        if not observation.load_state.startswith("LIFTED"):
            return self._fail(
                "load was lost during V9.3.0 MPC terminal alignment",
                observation,
            )

        target_pose = self._placement_vehicle_target(observation, pre_distance=0.0)
        command = self.controller.pose_command(
            target_pose,
            maximum_speed=p.placement_mpc_forward_max_speed,
            lift_target=p.transport_lift_target,
            stop_distance=0.0,
            steering_limit=p.placement_mpc_steering_limit,
            minimum_speed_override=0.0,
        )
        placement_error = self._load_to_placement_error(observation)
        filtered_error, filtered_command_longitudinal = self._placement_precision_update_filter(
            placement_error, command.error
        )
        now = float(observation.sim_time)
        elapsed = self._elapsed(observation)
        forward_speed = self._vehicle_forward_speed(observation)

        # V9.3.0 stop-first release latch.  V9.2.5 required the chassis-speed
        # gate *before* entering RELEASE_COMMIT, which left finals episodes
        # oscillating through otherwise release-worthy 5-10 cm poses.  Once
        # filtered geometry and RGB consensus enter the candidate envelope,
        # freeze MPC immediately and let the chassis settle while evidence is
        # accumulated.  This separates "reach the basin" from "stop to release".
        precommit_geometry = (
            filtered_error.distance
            <= p.placement_release_prebrake_position_tolerance
            and abs(filtered_error.yaw)
            <= p.placement_release_prebrake_yaw_tolerance
            and placement_vision_ready
        )
        if p.placement_release_supervisor_enabled > 0.5:
            supervised = self._placement_release_supervisor_step(
                observation,
                filtered_error=filtered_error,
                placement_vision_ready=placement_vision_ready,
                forward_speed=forward_speed,
                command_error=command.error,
                placement_error=placement_error,
            )
            if supervised is not None:
                return supervised
            # V9.3.4 supervisor owns every release attempt.  When it is idle or
            # cooling down, skip the legacy pre-brake/commit path and let MPC
            # continue correcting geometry.
            precommit_geometry = False
            if self._placement_precision_phase in ("RELEASE_SETTLE", "RELEASE_INTENT"):
                self._placement_precision_phase = "MPC"

        if self._placement_precision_phase != "RELEASE_COMMIT":
            if precommit_geometry:
                if self._placement_release_prebrake_since is None:
                    self._placement_release_prebrake_since = now
                    self._placement_release_prebrake_count += 1
                prebrake_elapsed = now - self._placement_release_prebrake_since
                # Stop first as soon as the broad basin is entered, but only
                # arm RELEASE_COMMIT after the geometry survives a short dwell.
                if prebrake_elapsed < p.placement_release_prebrake_hold_seconds:
                    self._placement_precision_set_direction(0)
                    self._placement_mpc_last_plan = None
                    self._placement_precision_hold_frame_count += 1
                    return self._decision(
                        action=ForkliftAction.stopped(lift_target=p.transport_lift_target),
                        observation=observation,
                        status=(
                            "V9.3.0 release pre-brake dwell "
                            f"({prebrake_elapsed:.2f}/{p.placement_release_prebrake_hold_seconds:.2f}s)"
                        ),
                        error=command.error,
                        progress_score=self._placement_precision_progress_score(filtered_error),
                        placement_error=placement_error,
                    )
                self._placement_precision_phase = "RELEASE_COMMIT"
                self._placement_release_commit_start_time = now
                self._placement_release_commit_count += 1
                self._placement_release_evidence_seconds = 0.0
                self._placement_release_last_update_time = now
                self._placement_release_hard_violation_since = None
                self._placement_mpc_last_plan = None
                self._placement_precision_set_direction(0)
            else:
                self._placement_release_prebrake_since = None

        if self._placement_precision_phase == "RELEASE_COMMIT":
            commit_start = now if self._placement_release_commit_start_time is None else self._placement_release_commit_start_time
            commit_elapsed = max(0.0, now - commit_start)
            evidence_ready = self._placement_release_update_evidence(
                observation,
                filtered_error=filtered_error,
                placement_vision_ready=placement_vision_ready,
                forward_speed=forward_speed,
            )
            hard_geometry_ok = (
                filtered_error.distance <= p.placement_release_abort_position_tolerance
                and abs(filtered_error.yaw) <= p.placement_release_abort_yaw_tolerance
            )
            violation_grace = max(
                0.20,
                2.0 * p.placement_mpc_update_period,
            )
            if hard_geometry_ok:
                self._placement_release_hard_violation_since = None
            elif self._placement_release_hard_violation_since is None:
                self._placement_release_hard_violation_since = now
            hard_violation_persistent = (
                self._placement_release_hard_violation_since is not None
                and now - self._placement_release_hard_violation_since
                >= violation_grace
            )
            if hard_violation_persistent or commit_elapsed >= p.placement_release_commit_max_seconds:
                self._placement_release_commit_abort_count += 1
                self._placement_release_prebrake_abort_count += 1
                self._placement_precision_phase = "MPC"
                self._placement_release_commit_start_time = None
                self._placement_release_prebrake_since = None
                self._placement_release_hard_violation_since = None
                self._placement_release_evidence_seconds = 0.0
                self._placement_mpc_last_plan = None
                return self._decision(
                    action=ForkliftAction.stopped(lift_target=p.transport_lift_target),
                    observation=observation,
                    status="V9.3.0 release commit aborted; returning control to MPC",
                    error=command.error,
                    progress_score=self._placement_precision_progress_score(filtered_error),
                    placement_error=placement_error,
                )

            commit_position_limit = max(
                0.01,
                p.placement_release_commit_position_tolerance
                - p.placement_release_uncertainty_position_gain
                * self._carried_load_pose_position_std_m,
            )
            commit_yaw_limit = max(
                math.radians(0.5),
                p.placement_release_commit_yaw_tolerance
                - p.placement_release_uncertainty_yaw_gain
                * math.radians(self._carried_load_pose_yaw_std_deg),
            )
            observer_consistent = (
                not self.placement_carried_observer_active
                or (
                    self._carried_load_observer_disagreement_position_m
                    <= p.placement_carried_observer_release_disagreement_position_m
                    and math.radians(self._carried_load_observer_disagreement_yaw_deg)
                    <= p.placement_carried_observer_release_disagreement_yaw_rad
                )
            )
            certification_error = self._load_to_strict_release_error(observation)
            strict_release_certified = self._strict_release_certified(
                certification_error=certification_error,
                now=now,
                placement_vision_ready=placement_vision_ready,
            )
            commit_ready = (
                evidence_ready
                and commit_elapsed >= p.placement_release_commit_min_seconds
                and filtered_error.distance <= commit_position_limit
                and abs(filtered_error.yaw) <= commit_yaw_limit
                and abs(forward_speed) <= p.placement_precision_release_max_speed
                and placement_vision_ready
                and observer_consistent
                and strict_release_certified
            )
            self._placement_precision_hold_frame_count += 1
            if commit_ready:
                self._transition(PickupState.LOWER_LOAD, observation)
                return self._decision(
                    action=ForkliftAction.stopped(lift_target=p.placement_lower_target),
                    observation=observation,
                    status="V9.3.0 release evidence committed; lowering pallet",
                    error=command.error,
                    progress_score=self._placement_precision_progress_score(filtered_error),
                    placement_error=placement_error,
                )
            return self._decision(
                action=ForkliftAction.stopped(lift_target=p.transport_lift_target),
                observation=observation,
                status=(
                    "V9.3.0 release pre-brake/evidence settling "
                    f"({commit_elapsed:.2f}/{p.placement_release_commit_min_seconds:.2f}s)"
                ),
                error=command.error,
                progress_score=self._placement_precision_progress_score(filtered_error),
                placement_error=placement_error,
            )

        # Preserve the filtered longitudinal command for first-action Schmitt
        # locking in the MPC scheduler below.
        command_longitudinal_for_mpc = float(filtered_command_longitudinal)

        if self._placement_precision_phase == "RECENTER_REVERSE":
            action, status, finished = self._placement_precision_recenter_action(
                observation, filtered_error
            )
            if finished:
                self._placement_mpc_last_plan = None
            timeout_failure = self._timeout_failure(observation, elapsed)
            if timeout_failure is not None:
                return timeout_failure
            return self._decision(
                action=action,
                observation=observation,
                status=status,
                error=command.error,
                progress_score=self._placement_precision_progress_score(filtered_error),
                placement_error=placement_error,
            )

        exit_position_limit = p.placement_precision_entry_position_tolerance + p.placement_precision_maximum_regression_m
        exit_lateral_limit = p.placement_precision_entry_lateral_tolerance + p.placement_precision_maximum_regression_m
        exit_yaw_limit = p.placement_precision_entry_yaw_tolerance + max(
            p.placement_yaw_tolerance, 2.0 * p.placement_release_yaw_hysteresis
        )
        if p.placement_terminal_ownership_enabled > 0.5:
            # V9.3.5 keeps MPC ownership across the same wide envelope that may
            # be used for a bounded forced takeover.  Tiny excursions must not
            # bounce the system back to the weaker forward-only ALIGN owner.
            exit_position_limit = max(
                exit_position_limit, p.placement_terminal_ownership_mpc_force_distance_m
            )
            exit_lateral_limit = max(
                exit_lateral_limit, p.placement_terminal_ownership_mpc_force_lateral_m
            )
            exit_yaw_limit = max(
                exit_yaw_limit, p.placement_terminal_ownership_mpc_force_yaw_rad
            )
        rejoin_active = self._placement_precision_phase == "MPC_REJOIN"
        if rejoin_active:
            if self._placement_precision_rejoin_start_time is None:
                self._placement_precision_rejoin_start_time = now
            rejoin_elapsed = max(
                0.0,
                now - self._placement_precision_rejoin_start_time,
            )
            rejoin_hard_distance = min(
                0.95 * p.placement_mpc_trust_radius,
                max(
                    exit_position_limit,
                    p.placement_precision_recenter_max_distance + 0.10,
                ),
            )
            # Once the bounded reverse stroke has rebuilt runway, keep MPC
            # ownership long enough to drive back into the normal precision
            # basin.  Only a genuine trust-region escape or a failed rejoin
            # returns to coarse alignment.
            if (
                filtered_error.distance > rejoin_hard_distance
                or rejoin_elapsed
                > max(6.0, p.placement_precision_recenter_max_seconds)
            ):
                self._placement_precision_reentry_count += 1
                self._placement_precision_rejoin_start_time = None
                rejoin_next = (
                    PickupState.PLACE_CORRIDOR
                    if p.placement_terminal_ownership_enabled > 0.5
                    else PickupState.PLACE_ALIGN
                )
                self._transition(rejoin_next, observation)
                return self._decision(
                    action=ForkliftAction.stopped(
                        lift_target=p.transport_lift_target
                    ),
                    observation=observation,
                    status=(
                        "V9.3.5 MPC rejoin left ownership envelope; rebuilding rolling approach"
                    ),
                    error=command.error,
                    placement_error=placement_error,
                )
            if (
                filtered_error.distance
                <= p.placement_precision_entry_position_tolerance
                and abs(filtered_error.lateral)
                <= p.placement_precision_entry_lateral_tolerance
                and abs(filtered_error.yaw)
                <= p.placement_precision_entry_yaw_tolerance
            ):
                self._placement_precision_phase = "MPC"
                self._placement_precision_rejoin_start_time = None
                rejoin_active = False

        soft_ownership_violation = (
            not rejoin_active
            and (
                filtered_error.distance > exit_position_limit
                or abs(filtered_error.lateral) > exit_lateral_limit
                or abs(filtered_error.yaw) > exit_yaw_limit
            )
        )
        if p.placement_terminal_ownership_enabled > 0.5 and not rejoin_active:
            if soft_ownership_violation:
                if self._terminal_ownership_precision_violation_since is None:
                    self._terminal_ownership_precision_violation_since = now
                violation_elapsed = max(
                    0.0, now - self._terminal_ownership_precision_violation_since
                )
                hard_distance = max(
                    p.placement_mpc_trust_radius,
                    1.25 * p.placement_terminal_ownership_mpc_force_distance_m,
                )
                hard_lateral = 1.60 * p.placement_terminal_ownership_mpc_force_lateral_m
                hard_yaw = 1.50 * p.placement_terminal_ownership_mpc_force_yaw_rad
                hard_escape = (
                    filtered_error.distance > hard_distance
                    or abs(filtered_error.lateral) > hard_lateral
                    or abs(filtered_error.yaw) > hard_yaw
                )
                if (
                    hard_escape
                    or violation_elapsed
                    >= p.placement_terminal_ownership_mpc_exit_persistence_seconds
                ):
                    self._placement_precision_reentry_count += 1
                    self._transition(PickupState.PLACE_CORRIDOR, observation)
                    return self._decision(
                        action=ForkliftAction.stopped(
                            lift_target=p.transport_lift_target
                        ),
                        observation=observation,
                        status=(
                            "V9.3.7 persistent MPC ownership envelope loss; "
                            "rebuilding rolling approach"
                        ),
                        error=command.error,
                        placement_error=placement_error,
                    )
            else:
                self._terminal_ownership_precision_violation_since = None
        elif soft_ownership_violation:
            self._placement_precision_reentry_count += 1
            self._transition(PickupState.PLACE_ALIGN, observation)
            return self._decision(
                action=ForkliftAction.stopped(lift_target=p.transport_lift_target),
                observation=observation,
                status="V9.3.0 precision capture lost; returning to placement alignment",
                error=command.error,
                placement_error=placement_error,
            )

        # Strong lateral/yaw error near longitudinal closure is a known
        # nonholonomic feasibility case.  Do not spend several seconds asking
        # the local MPC to discover an ever-wider manoeuvre: preserve the
        # physically validated bounded S-curve as a feasibility restoration
        # primitive, then return control to MPC for centimetre-level closure.
        recenter_needed = (
            not rejoin_active
            and self._placement_precision_recenter_needed(
                filtered_error, command_longitudinal_for_mpc
            )
        )
        if (
            recenter_needed
            and self._placement_precision_recenter_cycle_count
            < p.placement_precision_recenter_max_cycles
        ):
            self._placement_mpc_fallback_count += 1
            self._placement_precision_start_recenter(observation)
            self._placement_precision_hold_frame_count += 1
            return self._decision(
                action=ForkliftAction.stopped(lift_target=p.transport_lift_target),
                observation=observation,
                status=(
                    "V9.3.0 geometry outside local MPC closure basin; "
                    "starting bounded S-curve feasibility fallback"
                ),
                error=command.error,
                progress_score=self._placement_precision_progress_score(filtered_error),
                placement_error=placement_error,
            )

        stalled, _regressed, precision_score = self._placement_precision_stalled_or_regressed(
            observation, filtered_error
        )
        if (
            self._placement_precision_last_progress_time is not None
            and now - self._placement_precision_last_progress_time >= p.placement_mpc_stall_seconds
        ):
            stalled = True
        if stalled and recenter_needed:
            self._placement_mpc_fallback_count += 1
            self._placement_precision_start_recenter(observation)
            self._placement_precision_hold_frame_count += 1
            return self._decision(
                action=ForkliftAction.stopped(lift_target=p.transport_lift_target),
                observation=observation,
                status="V9.3.0 MPC stalled; starting bounded S-curve fallback",
                error=command.error,
                progress_score=precision_score,
                placement_error=placement_error,
            )
        if stalled:
            self._placement_precision_best_score = precision_score
            self._placement_precision_best_distance = filtered_error.distance
            self._placement_precision_last_progress_time = now

        action, status, mpc_ok = self._placement_mpc_action(
            observation,
            command_error=command.error,
            filtered_error=filtered_error,
            filtered_command_longitudinal=command_longitudinal_for_mpc,
            placement_vision_ready=placement_vision_ready,
        )
        if not mpc_ok:
            infeasible_recenter_ready = (
                p.placement_mpc_infeasible_recenter_solve_count > 0
                and self._placement_mpc_consecutive_infeasible_solve_count
                >= p.placement_mpc_infeasible_recenter_solve_count
                and self._placement_precision_recenter_cycle_count
                < p.placement_precision_recenter_max_cycles
            )
            if recenter_needed or infeasible_recenter_ready:
                self._placement_precision_start_recenter(observation)
                self._placement_mpc_consecutive_infeasible_solve_count = 0
                status = (
                    "V9.3.7 repeated MPC infeasibility; entering bounded "
                    "S-curve feasibility restore"
                    if infeasible_recenter_ready
                    else "V9.3.0 MPC infeasible; entering bounded S-curve fallback"
                )

        timeout_failure = self._timeout_failure(observation, elapsed)
        if timeout_failure is not None:
            return timeout_failure
        return self._decision(
            action=action,
            observation=observation,
            status=status,
            error=command.error,
            progress_score=self._placement_precision_progress_score(filtered_error),
            placement_error=placement_error,
        )

    def _step_place_precision_v924(
        self,
        observation: ForkliftObservation,
        *,
        placement_vision_ready: bool,
    ) -> PickupDecision:
        """V9.3.0 terminal controller.

        Two facts from the V9.2.3 smoke trace drive this design:
        1) release-worthy physical poses were rejected by noisy instantaneous
           geometry, so release uses a filtered task residual plus RGB consensus;
        2) lateral/yaw errors cannot be removed by zero-length forward/reverse
           dithering on an Ackermann chassis, so a bounded reverse S-curve
           creates steering authority before forward closure.
        """
        p = self.parameters
        if not observation.load_state.startswith("LIFTED"):
            return self._fail(
                "load was lost during V9.3.0 competition precision alignment",
                observation,
            )

        target_pose = self._placement_vehicle_target(
            observation, pre_distance=0.0
        )
        command = self.controller.pose_command(
            target_pose,
            maximum_speed=p.placement_precision_forward_max_speed,
            lift_target=p.transport_lift_target,
            stop_distance=0.0,
            steering_limit=p.place_steering_limit,
            minimum_speed_override=0.0,
        )
        placement_error = self._load_to_placement_error(observation)
        filtered_error, filtered_command_longitudinal = (
            self._placement_precision_update_filter(
                placement_error, command.error
            )
        )
        now = float(observation.sim_time)
        elapsed = self._elapsed(observation)
        forward_speed = self._vehicle_forward_speed(observation)

        # Release is based on the temporally consistent task residual.  The
        # independent RGB release consensus and chassis-speed gate remain hard
        # requirements.  No truth or fixed target compensation enters here.
        precision_geometry = (
            filtered_error.distance
            <= p.placement_precision_filtered_position_tolerance
            and abs(filtered_error.yaw)
            <= p.placement_precision_filtered_yaw_tolerance
        )
        release_speed_ready = (
            abs(forward_speed)
            <= p.placement_precision_release_max_speed
        )
        if precision_geometry:
            self._placement_precision_hold_frame_count += 1
            if not release_speed_ready:
                self._placement_condition_since = None
                return self._decision(
                    action=ForkliftAction.stopped(
                        lift_target=p.transport_lift_target
                    ),
                    observation=observation,
                    status=(
                        "V9.3.0 filtered precision reached; "
                        "settling chassis velocity before release"
                    ),
                    error=command.error,
                    progress_score=self._placement_precision_progress_score(
                        filtered_error
                    ),
                    placement_error=placement_error,
                )
            if not placement_vision_ready:
                self._placement_condition_since = None
                return self._decision(
                    action=ForkliftAction.stopped(
                        lift_target=p.transport_lift_target
                    ),
                    observation=observation,
                    status=(
                        "V9.3.0 filtered precision reached; waiting for "
                        "stable recent RGB release consensus"
                    ),
                    error=command.error,
                    progress_score=self._placement_precision_progress_score(
                        filtered_error
                    ),
                    placement_error=placement_error,
                )
            if self._placement_condition_since is None:
                self._placement_condition_since = now
            if (
                now - self._placement_condition_since
                >= p.placement_hold_seconds
            ):
                self._transition(PickupState.LOWER_LOAD, observation)
                return self._decision(
                    action=ForkliftAction.stopped(
                        lift_target=p.placement_lower_target
                    ),
                    observation=observation,
                    status=(
                        "V9.3.0 filtered competition precision and RGB "
                        "consensus held; lowering pallet"
                    ),
                    error=command.error,
                    progress_score=self._placement_precision_progress_score(
                        filtered_error
                    ),
                    placement_error=placement_error,
                )
            return self._decision(
                action=ForkliftAction.stopped(
                    lift_target=p.transport_lift_target
                ),
                observation=observation,
                status=(
                    "Holding V9.3.0 filtered competition precision pose "
                    f"({now - self._placement_condition_since:.2f}/"
                    f"{p.placement_hold_seconds:.2f}s)"
                ),
                error=command.error,
                progress_score=self._placement_precision_progress_score(
                    filtered_error
                ),
                placement_error=placement_error,
            )

        # Any excursion resets the continuous release dwell, but does not
        # discard the filtered state estimate.
        self._placement_condition_since = None

        # While recentering, the pallet is intentionally moved away from the
        # target by a few decimetres.  Do not interpret that planned motion as
        # a capture-basin regression.
        if self._placement_precision_phase == "RECENTER_REVERSE":
            action, status, _finished = (
                self._placement_precision_recenter_action(
                    observation, filtered_error
                )
            )
            timeout_failure = self._timeout_failure(observation, elapsed)
            if timeout_failure is not None:
                return timeout_failure
            return self._decision(
                action=action,
                observation=observation,
                status=status,
                error=command.error,
                progress_score=self._placement_precision_progress_score(
                    filtered_error
                ),
                placement_error=placement_error,
            )

        # Gross capture loss still returns to PLACE_ALIGN, but local stalls do
        # not.  This eliminates the V9.2.3 0.1 s ALIGN <-> PRECISION bounce.
        exit_position_limit = (
            p.placement_precision_entry_position_tolerance
            + p.placement_precision_maximum_regression_m
        )
        exit_lateral_limit = (
            p.placement_precision_entry_lateral_tolerance
            + p.placement_precision_maximum_regression_m
        )
        exit_yaw_limit = (
            p.placement_precision_entry_yaw_tolerance
            + max(
                p.placement_yaw_tolerance,
                2.0 * p.placement_release_yaw_hysteresis,
            )
        )
        if (
            filtered_error.distance > exit_position_limit
            or abs(filtered_error.lateral) > exit_lateral_limit
            or abs(filtered_error.yaw) > exit_yaw_limit
        ):
            self._placement_precision_reentry_count += 1
            capture_recovery_state = (
                PickupState.PLACE_CORRIDOR
                if p.placement_terminal_ownership_enabled > 0.5
                else PickupState.PLACE_ALIGN
            )
            self._transition(capture_recovery_state, observation)
            return self._decision(
                action=ForkliftAction.stopped(
                    lift_target=p.transport_lift_target
                ),
                observation=observation,
                status=(
                    "V9.3.7 gross terminal capture lost; returning ownership to rolling corridor"
                    if p.placement_terminal_ownership_enabled > 0.5
                    else "V9.3.0 gross terminal capture lost; rebuilding approach"
                ),
                error=command.error,
                placement_error=placement_error,
            )

        # Once longitudinal closure has little remaining authority, lateral or
        # yaw error needs path length rather than high-frequency direction
        # changes. Start one bounded reverse S-curve stroke.
        if self._placement_precision_recenter_needed(
            filtered_error, filtered_command_longitudinal
        ):
            self._placement_precision_start_recenter(observation)
            self._placement_precision_hold_frame_count += 1
            return self._decision(
                action=ForkliftAction.stopped(
                    lift_target=p.transport_lift_target
                ),
                observation=observation,
                status=(
                    "V9.3.0 starting bounded reverse S-curve recenter"
                ),
                error=command.error,
                progress_score=self._placement_precision_progress_score(
                    filtered_error
                ),
                placement_error=placement_error,
            )

        stalled, _regressed, precision_score = (
            self._placement_precision_stalled_or_regressed(
                observation, filtered_error
            )
        )
        if stalled:
            # Do not bounce back to PLACE_ALIGN.  If geometry is the blocking
            # axis, consume a bounded recenter cycle; otherwise reset the local
            # progress watchdog and keep the filtered close controller active.
            if self._placement_precision_recenter_needed(
                filtered_error, filtered_command_longitudinal
            ):
                self._placement_precision_start_recenter(observation)
                self._placement_precision_hold_frame_count += 1
                return self._decision(
                    action=ForkliftAction.stopped(
                        lift_target=p.transport_lift_target
                    ),
                    observation=observation,
                    status=(
                        "V9.3.0 local stall converted to bounded recenter"
                    ),
                    error=command.error,
                    progress_score=precision_score,
                    placement_error=placement_error,
                )
            self._placement_precision_best_score = precision_score
            self._placement_precision_best_distance = filtered_error.distance
            self._placement_precision_last_progress_time = now

        action, status = self._placement_precision_close_action(
            observation,
            command_longitudinal=filtered_command_longitudinal,
            filtered_error=filtered_error,
        )
        timeout_failure = self._timeout_failure(observation, elapsed)
        if timeout_failure is not None:
            return timeout_failure
        return self._decision(
            action=action,
            observation=observation,
            status=status,
            error=command.error,
            progress_score=self._placement_precision_progress_score(
                filtered_error
            ),
            placement_error=placement_error,
        )

    def _smooth_transport_enabled(self) -> bool:
        p = self.parameters
        return (
            self._placement_enabled()
            and p.transport_runway_distance > 0.0
            and p.transport_path_wheelbase > 0.0
            and p.transport_path_lookahead > 0.0
        )

    def _carried_load_observer_enabled(self) -> bool:
        return self.parameters.placement_carried_observer_enabled > 0.0

    def _load_belief_enabled(self) -> bool:
        return self.parameters.placement_load_belief_enabled > 0.5

    def _reset_load_belief_reference(
        self, observation: ForkliftObservation, *, mode: str
    ) -> None:
        """Refresh both translation and yaw evidence references."""
        self._carried_load_belief_mode = str(mode)
        self._carried_load_belief_last_vehicle_pose = observation.vehicle_pose_world
        self._carried_load_belief_last_motion_time = float(observation.sim_time)
        self._carried_load_belief_distance_since_visual_m = 0.0
        self._carried_load_belief_turn_since_visual_rad = 0.0
        self._carried_load_belief_reverse_since_visual_m = 0.0
        self._carried_load_belief_translation_distance_since_visual_m = 0.0
        self._carried_load_belief_translation_turn_since_visual_rad = 0.0
        self._carried_load_belief_translation_reverse_since_visual_m = 0.0
        self._carried_load_belief_extra_position_sigma_m = 0.0
        self._carried_load_belief_extra_yaw_sigma_rad = 0.0

    def _reset_translation_load_belief_reference(
        self, observation: ForkliftObservation
    ) -> None:
        """Refresh translation evidence without erasing yaw motion debt."""
        self._carried_load_belief_last_vehicle_pose = observation.vehicle_pose_world
        self._carried_load_belief_last_motion_time = float(observation.sim_time)
        self._carried_load_belief_translation_distance_since_visual_m = 0.0
        self._carried_load_belief_translation_turn_since_visual_rad = 0.0
        self._carried_load_belief_translation_reverse_since_visual_m = 0.0
        self._carried_load_belief_extra_position_sigma_m = 0.0

    def _update_load_belief_motion(self, observation: ForkliftObservation) -> None:
        rigid_monitor = self._rigid_load_constraint_controller()
        if rigid_monitor is not None:
            rigid_monitor.update(
                now=float(observation.sim_time),
                load_state=observation.load_state,
                fork_contact_count=observation.fork_contact_count,
                lift_velocity=observation.lift_velocity,
            )
        if not self._load_belief_enabled() or not observation.load_state.startswith("LIFTED"):
            return
        now = float(observation.sim_time)
        pose = observation.vehicle_pose_world
        previous = self._carried_load_belief_last_vehicle_pose
        if previous is None:
            self._carried_load_belief_last_vehicle_pose = pose
            self._carried_load_belief_last_motion_time = now
            return
        distance = math.hypot(float(pose.x) - float(previous.x), float(pose.y) - float(previous.y))
        turn = abs(wrap_angle(float(pose.yaw) - float(previous.yaw)))
        self._carried_load_belief_distance_since_visual_m += distance
        self._carried_load_belief_turn_since_visual_rad += turn
        self._carried_load_belief_translation_distance_since_visual_m += distance
        self._carried_load_belief_translation_turn_since_visual_rad += turn
        if self._vehicle_forward_speed(observation) < -1e-3:
            self._carried_load_belief_reverse_since_visual_m += distance
            self._carried_load_belief_translation_reverse_since_visual_m += distance
        self._carried_load_belief_last_vehicle_pose = pose
        self._carried_load_belief_last_motion_time = now

        p = self.parameters
        time_since_translation_rgb = (
            0.0
            if self._carried_load_visual_last_rgb_time is None
            else max(0.0, now - self._carried_load_visual_last_rgb_time)
        )
        if p.placement_carried_yaw_axis_evidence_enabled > 0.5:
            time_since_yaw_evidence = (
                0.0
                if self._carried_load_yaw_last_evidence_time is None
                else max(0.0, now - self._carried_load_yaw_last_evidence_time)
            )
        else:
            time_since_yaw_evidence = time_since_translation_rgb
        if (
            self._carried_load_visual_last_rgb_time is not None
            and time_since_translation_rgb <= p.placement_carried_visual_max_stale_seconds
            and self._pickup_pose_is_visual()
        ):
            # A genuine fresh RGB update is handled by _update_carried_load_pose;
            # retain TRACKED here and keep motion since that observation small.
            self._carried_load_belief_mode = "VISUAL_TRACKED"
        elif self._carried_load_visual_authority_locked:
            if (
                self._carried_load_belief_distance_since_visual_m <= 0.05
                and self._carried_load_belief_turn_since_visual_rad <= math.radians(2.0)
            ):
                self._carried_load_belief_mode = "VISUAL_SEEDED"
            else:
                self._carried_load_belief_mode = "RIGID_PREDICTED"
        elif self._carried_load_pose_in_base is not None:
            self._carried_load_belief_mode = "FUSED"

        pos_extra = (
            p.placement_load_belief_position_distance_gain_m_per_m
            * self._carried_load_belief_translation_distance_since_visual_m
            + p.placement_load_belief_position_turn_gain_m_per_rad
            * self._carried_load_belief_translation_turn_since_visual_rad
            + p.placement_load_belief_position_reverse_gain_m_per_m
            * self._carried_load_belief_translation_reverse_since_visual_m
            + p.placement_load_belief_position_time_gain_mps * time_since_translation_rgb
        )
        yaw_extra = (
            p.placement_load_belief_yaw_distance_gain_rad_per_m
            * self._carried_load_belief_distance_since_visual_m
            + p.placement_load_belief_yaw_turn_gain
            * self._carried_load_belief_turn_since_visual_rad
            + p.placement_load_belief_yaw_reverse_gain_rad_per_m
            * self._carried_load_belief_reverse_since_visual_m
            + p.placement_load_belief_yaw_time_gain_radps * time_since_yaw_evidence
        )
        if p.placement_load_belief_max_position_sigma_m > 0.0:
            pos_extra = min(pos_extra, p.placement_load_belief_max_position_sigma_m)
        if p.placement_load_belief_max_yaw_sigma_rad > 0.0:
            yaw_extra = min(yaw_extra, p.placement_load_belief_max_yaw_sigma_rad)
        self._carried_load_belief_extra_position_sigma_m = max(0.0, float(pos_extra))
        self._carried_load_belief_extra_yaw_sigma_rad = max(0.0, float(yaw_extra))

    def _effective_carried_load_position_sigma_m(self) -> float:
        base = max(0.0, float(self._carried_load_pose_position_std_m))
        extra = max(0.0, float(self._carried_load_belief_extra_position_sigma_m))
        sigma = math.hypot(base, extra)
        monitor = self._rigid_load_constraint_monitor
        trusted_required = (
            self.parameters.placement_carried_seed_provenance_enabled > 0.5
            and self.parameters.placement_carried_seed_require_trusted_for_rigid_position_cap > 0.5
        )
        rigid_cap_allowed = bool(
            monitor is not None
            and monitor.active
            and (
                not trusted_required
                or self._carried_load_seed_trusted_for_aggressive_risk
            )
        )
        if rigid_cap_allowed:
            sigma = min(sigma, self.parameters.placement_rigid_load_constraint_position_sigma_cap_m)
        return float(sigma)

    def _effective_carried_load_yaw_sigma_rad(self) -> float:
        # R3 safety audit: do not reduce yaw uncertainty from contact rigidity.
        # R2 traces contain early terminal frames where the estimated yaw mean
        # is optimistic by >2deg while truth is still outside the 5deg limit.
        base = math.radians(max(0.0, float(self._carried_load_pose_yaw_std_deg)))
        extra = max(0.0, float(self._carried_load_belief_extra_yaw_sigma_rad))
        return float(math.hypot(base, extra))

    def _belief_conditioned_action(
        self, action: ForkliftAction, observation: ForkliftObservation
    ) -> ForkliftAction:
        if not self._load_belief_enabled() or not observation.load_state.startswith("LIFTED"):
            return action
        if self.state not in (
            PickupState.RETREAT,
            PickupState.TRANSPORT_REPOSITION,
            PickupState.TRANSPORT_APPROACH,
            PickupState.PLACE_CORRIDOR,
        ):
            return action
        if abs(float(action.speed_target)) <= 1e-9:
            return action
        p = self.parameters
        if self._carried_load_belief_mode == "VISUAL_SEEDED":
            scale = p.placement_load_belief_seeded_transport_speed_scale
        elif self._carried_load_belief_mode == "RIGID_PREDICTED":
            scale = p.placement_load_belief_predicted_transport_speed_scale
        else:
            return action
        steering_limit = max(0.05, p.transport_steering_limit)
        steering_ratio = min(1.0, abs(float(action.steering_command)) / steering_limit)
        turn_scale = 1.0 - (1.0 - p.placement_load_belief_turn_speed_scale) * steering_ratio
        scale = max(0.2, min(1.0, float(scale) * float(turn_scale)))
        if scale >= 0.999:
            return action
        self._carried_load_belief_transport_scaled_frames += 1
        return ForkliftAction(
            speed_target=float(action.speed_target) * scale,
            steering_command=float(action.steering_command),
            lift_target=float(action.lift_target),
            emergency_stop=bool(getattr(action, "emergency_stop", False)),
        )

    def _carried_load_observer_controller(self) -> ProbabilisticCarriedLoadObserver:
        if self._carried_load_observer is None:
            p = self.parameters
            self._carried_load_observer = ProbabilisticCarriedLoadObserver(
                CarriedLoadObserverConfig(
                    initial_position_sigma_m=p.placement_carried_observer_initial_position_sigma_m,
                    initial_yaw_sigma_rad=p.placement_carried_observer_initial_yaw_sigma_rad,
                    measurement_position_sigma_m=p.placement_carried_observer_measurement_position_sigma_m,
                    measurement_yaw_sigma_rad=p.placement_carried_observer_measurement_yaw_sigma_rad,
                    process_position_sigma_m=p.placement_carried_observer_process_position_sigma_m,
                    process_yaw_sigma_rad=p.placement_carried_observer_process_yaw_sigma_rad,
                    minimum_position_sigma_m=p.placement_carried_observer_minimum_position_sigma_m,
                    minimum_yaw_sigma_rad=p.placement_carried_observer_minimum_yaw_sigma_rad,
                    position_innovation_gate_m=p.placement_carried_observer_position_innovation_gate_m,
                    yaw_innovation_gate_rad=p.placement_carried_observer_yaw_innovation_gate_rad,
                    fast_alpha=p.placement_carried_observer_fast_alpha,
                )
            )
        return self._carried_load_observer

    def _sync_carried_load_observer_telemetry(self) -> None:
        if self._carried_load_observer is None or not self._carried_load_observer.active:
            self._carried_load_pose_in_base = None
            self._carried_load_fast_pose_in_base = None
            return
        snapshot = self._carried_load_observer.snapshot()
        self._carried_load_pose_in_base = snapshot.pose
        self._carried_load_fast_pose_in_base = snapshot.fast_pose
        self._carried_load_pose_position_std_m = snapshot.position_sigma_m
        self._carried_load_pose_yaw_std_deg = math.degrees(snapshot.yaw_sigma_rad)
        self._carried_load_observer_update_count = snapshot.update_count
        self._carried_load_observer_rejection_count = snapshot.rejection_count
        self._carried_load_observer_disagreement_position_m = snapshot.disagreement_position_m
        self._carried_load_observer_disagreement_yaw_deg = math.degrees(snapshot.disagreement_yaw_rad)

    def _pickup_pose_is_visual(self) -> bool:
        source = str(self._pickup_visual_source).lower()
        return source.startswith("rgb_") or source.startswith("vision_")

    def _pickup_visual_measurement_time(self, observation: ForkliftObservation) -> float | None:
        stale = float(self._pickup_visual_stale_seconds)
        if not math.isfinite(stale) or stale < 0.0:
            return None
        return float(observation.sim_time) - stale

    @staticmethod
    def _v938_pose_base_to_world(vehicle: Pose3D, relative: Pose3D) -> Pose3D:
        c = math.cos(float(vehicle.yaw))
        sn = math.sin(float(vehicle.yaw))
        return Pose3D(
            x=float(vehicle.x) + c * float(relative.x) - sn * float(relative.y),
            y=float(vehicle.y) + sn * float(relative.x) + c * float(relative.y),
            z=float(vehicle.z) + float(relative.z),
            roll=float(relative.roll),
            pitch=float(relative.pitch),
            yaw=wrap_angle(float(vehicle.yaw) + float(relative.yaw)),
        )

    @staticmethod
    def _v938_pose_world_to_base(vehicle: Pose3D, world: Pose3D) -> Pose3D:
        dx = float(world.x) - float(vehicle.x)
        dy = float(world.y) - float(vehicle.y)
        c = math.cos(float(vehicle.yaw))
        sn = math.sin(float(vehicle.yaw))
        return Pose3D(
            x=c * dx + sn * dy,
            y=-sn * dx + c * dy,
            z=float(world.z) - float(vehicle.z),
            roll=float(world.roll),
            pitch=float(world.pitch),
            yaw=wrap_angle(float(world.yaw) - float(vehicle.yaw)),
        )

    def _carried_load_yaw_anchor_controller(self) -> LateInsertYawAnchor | None:
        p = self.parameters
        if p.placement_carried_visual_yaw_anchor_enabled <= 0.5:
            return None
        if self._carried_load_yaw_anchor is None:
            self._carried_load_yaw_anchor = LateInsertYawAnchor(
                LateInsertYawAnchorConfig(
                    window_seconds=p.placement_carried_visual_yaw_anchor_window_seconds,
                    minimum_samples=p.placement_carried_visual_yaw_anchor_min_samples,
                    minimum_confidence=p.placement_carried_visual_yaw_anchor_min_confidence,
                    maximum_reprojection_error_px=p.placement_carried_visual_yaw_anchor_max_reprojection_error_px,
                    maximum_spread_rad=p.placement_carried_visual_yaw_anchor_max_spread_rad,
                )
            )
        return self._carried_load_yaw_anchor

    def _cache_carried_load_visual_handoff(self, observation: ForkliftObservation) -> None:
        """Cache the last trustworthy pickup-RGB relative load pose.

        The pickup camera can lose the fork-pocket markers shortly after the
        pallet is lifted. V9.3.8 caches the visual seed in world coordinates so
        INSERT/LIFT vehicle motion cannot invalidate the later base-frame seed.
        It must *not* be treated as a fresh update once RETREAT starts.
        """
        p = self.parameters
        if p.placement_carried_visual_authority_enabled <= 0.5:
            return
        if p.placement_carried_visual_handoff_stale_seconds <= 0.0:
            return
        if self.state not in (PickupState.INSERT, PickupState.LIFT, PickupState.VERIFY_LIFT):
            return
        if not self._pickup_pose_is_visual():
            return
        if self._pickup_visual_authority not in ("VISUAL_LOCK", "VISUAL_TRACK"):
            return
        stale = float(self._pickup_visual_stale_seconds)
        if (
            not math.isfinite(stale)
            or stale < 0.0
            or stale > p.placement_carried_visual_handoff_stale_seconds
        ):
            return
        measurement_time = self._pickup_visual_measurement_time(observation)
        if measurement_time is None:
            return
        # V9.3.8: store the estimated load in world coordinates. Reusing an
        # old base-frame seed after INSERT/LIFT vehicle motion caused a
        # vehicle-motion-sized carried-load bias in fallback handoffs.
        latest_world_pose = self._v938_pose_base_to_world(
            observation.vehicle_pose_world, observation.pallet_pose_in_base
        )
        self._carried_load_visual_handoff_pose = latest_world_pose
        self._carried_load_visual_handoff_measurement_time = measurement_time
        yaw_anchor = self._carried_load_yaw_anchor_controller()
        if yaw_anchor is not None:
            self._carried_load_yaw_anchor_estimate = yaw_anchor.add(
                measurement_time=measurement_time,
                world_yaw_rad=latest_world_pose.yaw,
                confidence=self._pickup_visual_last_accepted_confidence,
                reprojection_error_px=self._pickup_visual_last_accepted_reprojection_error_px,
            )
        self._carried_load_visual_handoff_last_accepted_confidence = (
            self._pickup_visual_last_accepted_confidence
        )
        self._carried_load_visual_handoff_last_accepted_reprojection_error_px = (
            self._pickup_visual_last_accepted_reprojection_error_px
        )

    def _carried_load_seed_provenance_config(self) -> LoadSeedProvenanceConfig:
        p = self.parameters
        return LoadSeedProvenanceConfig(
            recent_max_age_seconds=p.placement_carried_seed_recent_max_age_seconds,
            recent_min_confidence=p.placement_carried_seed_recent_min_confidence,
            recent_max_reprojection_error_px=p.placement_carried_seed_recent_max_reprojection_error_px,
            high_confidence_threshold=p.placement_carried_seed_high_confidence_threshold,
            high_confidence_max_age_seconds=p.placement_carried_seed_high_confidence_max_age_seconds,
            high_confidence_max_reprojection_error_px=p.placement_carried_seed_high_confidence_max_reprojection_error_px,
        )

    def _assess_cached_carried_load_seed(self, observation: ForkliftObservation) -> None:
        p = self.parameters
        if self._carried_load_visual_handoff_measurement_time is None:
            self._carried_load_seed_provenance = LoadSeedProvenance.UNKNOWN.value
            self._carried_load_seed_trusted_for_aggressive_risk = False
            self._carried_load_seed_reason = "missing_handoff_measurement_time"
            return
        age = max(0.0, float(observation.sim_time) - self._carried_load_visual_handoff_measurement_time)
        self._carried_load_seed_age_seconds = age
        self._carried_load_seed_confidence = self._carried_load_visual_handoff_last_accepted_confidence
        self._carried_load_seed_reprojection_error_px = self._carried_load_visual_handoff_last_accepted_reprojection_error_px
        if p.placement_carried_seed_provenance_enabled <= 0.5:
            self._carried_load_seed_provenance = LoadSeedProvenance.RGB_PRELIFT_RECENT.value
            self._carried_load_seed_trusted_for_aggressive_risk = True
            self._carried_load_seed_reason = "legacy_provenance_disabled"
            return
        assessment = assess_prelift_rgb_seed(
            age_seconds=age,
            confidence=self._carried_load_seed_confidence,
            reprojection_error_px=self._carried_load_seed_reprojection_error_px,
            config=self._carried_load_seed_provenance_config(),
        )
        self._carried_load_seed_provenance = assessment.provenance.value
        self._carried_load_seed_trusted_for_aggressive_risk = bool(assessment.trusted_for_aggressive_risk)
        self._carried_load_seed_reason = assessment.reason

    def _carried_load_visual_handoff_available(
        self, observation: ForkliftObservation, *, allow_fallback: bool = False
    ) -> bool:
        p = self.parameters
        if self._carried_load_visual_handoff_pose is None:
            return False
        if self._carried_load_visual_handoff_measurement_time is None:
            return False
        age = float(observation.sim_time) - self._carried_load_visual_handoff_measurement_time
        limit = p.placement_carried_visual_handoff_stale_seconds
        if allow_fallback and p.placement_carried_visual_handoff_fallback_stale_seconds > 0.0:
            limit = max(limit, p.placement_carried_visual_handoff_fallback_stale_seconds)
        return 0.0 <= age <= limit

    def _update_carried_visual_authority(self, observation: ForkliftObservation) -> None:
        p = self.parameters
        if p.placement_carried_visual_authority_enabled <= 0.5:
            return
        if not observation.load_state.startswith("LIFTED"):
            return
        visual = self._pickup_pose_is_visual()
        fresh = self._pickup_visual_stale_seconds <= p.placement_carried_visual_max_stale_seconds
        if visual and fresh and self._pickup_visual_authority in ("VISUAL_LOCK", "VISUAL_TRACK"):
            if not self._carried_load_visual_authority_locked:
                self._carried_load_visual_authority_locked = True
                self._carried_load_visual_lock_count += 1
            measurement_time = self._pickup_visual_measurement_time(observation)
            if measurement_time is not None:
                self._carried_load_visual_last_rgb_time = measurement_time
                if self.parameters.placement_carried_yaw_axis_evidence_enabled > 0.5:
                    self._carried_load_yaw_last_evidence_time = measurement_time
                    self._carried_load_yaw_evidence_source = "PICKUP_RGB_LIVE"

    def _sample_carried_load_pose(self, observation: ForkliftObservation) -> None:
        if not self._carried_load_observer_enabled() or not observation.load_state.startswith("LIFTED"):
            return
        p = self.parameters
        if p.placement_carried_visual_authority_enabled > 0.5:
            self._update_carried_visual_authority(observation)
            if not self._pickup_pose_is_visual():
                if p.placement_carried_visual_require_lock_for_release > 0.5:
                    self._carried_load_visual_guide_reject_count += 1
                    return
                # Moderate/finals retain a safe initialization fallback so a
                # brief pickup-camera miss cannot disable the observer.  After
                # initialization, source-aware updates still reject coarse guide.
            elif self._pickup_visual_stale_seconds > p.placement_carried_visual_max_stale_seconds:
                if p.placement_carried_visual_require_lock_for_release > 0.5:
                    return
        now = float(observation.sim_time)
        last = self._carried_load_pose_last_sample_time
        if last is not None and now - last < p.placement_carried_observer_sample_period:
            return
        self._carried_load_pose_last_sample_time = now
        self._carried_load_pose_samples.append(observation.pallet_pose_in_base)
        if len(self._carried_load_pose_samples) > 24:
            self._carried_load_pose_samples = self._carried_load_pose_samples[-24:]

    def _finalize_carried_load_pose(self, observation: ForkliftObservation) -> None:
        if not self._carried_load_observer_enabled():
            return
        self._sample_carried_load_pose(observation)
        samples = list(self._carried_load_pose_samples)
        p = self.parameters
        observer = self._carried_load_observer_controller()

        # V9.3.3-R1: weak-guide carried-load authority is handed off from the
        # last trustworthy pickup-RGB pose.  One trusted visual seed is better
        # than four time-correlated coarse-guide frames, and it avoids waiting
        # for markers that are physically occluded after lifting.
        normal_handoff = self._carried_load_visual_handoff_available(observation)
        fallback_handoff = (
            not normal_handoff
            and self._carried_load_visual_handoff_available(
                observation, allow_fallback=True
            )
        )
        if (
            len(samples) < p.placement_carried_observer_min_samples
            and p.placement_carried_visual_require_lock_for_release > 0.5
            and (normal_handoff or fallback_handoff)
        ):
            cached_world_seed = self._carried_load_visual_handoff_pose
            assert cached_world_seed is not None
            self._carried_load_yaw_anchor_used = False
            self._carried_load_yaw_anchor_delta_from_latest_deg = None
            self._carried_load_yaw_anchor_seed_sigma_rad = None
            yaw_sigma_override: float | None = None
            anchor = self._carried_load_yaw_anchor_estimate
            if (
                self.parameters.placement_carried_visual_yaw_anchor_enabled > 0.5
                and anchor is not None
            ):
                self._carried_load_yaw_anchor_used = True
                self._carried_load_yaw_anchor_delta_from_latest_deg = math.degrees(
                    wrap_angle(float(anchor.world_yaw_rad) - float(cached_world_seed.yaw))
                )
                cached_world_seed = Pose3D(
                    x=float(cached_world_seed.x),
                    y=float(cached_world_seed.y),
                    z=float(cached_world_seed.z),
                    roll=float(cached_world_seed.roll),
                    pitch=float(cached_world_seed.pitch),
                    yaw=float(anchor.world_yaw_rad),
                )
                if self.parameters.placement_carried_yaw_axis_evidence_enabled > 0.5:
                    # F3: the anchor is a stable measurement cluster, not a
                    # blind one-frame seed. Carry a conservative covariance
                    # into the observer, but never below the historical 1deg
                    # floor. Release still adds the independent transport/slip
                    # risk overlay later.
                    yaw_sigma_override = max(
                        self.parameters.placement_carried_observer_minimum_yaw_sigma_rad,
                        float(anchor.spread_rad),
                    )
                    self._carried_load_yaw_anchor_seed_sigma_rad = float(yaw_sigma_override)
                    self._carried_load_yaw_last_evidence_time = float(anchor.newest_measurement_time)
                    self._carried_load_yaw_evidence_source = "LATE_INSERT_ANCHOR"
            elif self.parameters.placement_carried_yaw_axis_evidence_enabled > 0.5:
                self._carried_load_yaw_last_evidence_time = (
                    self._carried_load_visual_handoff_measurement_time
                )
                self._carried_load_yaw_evidence_source = "HANDOFF_RGB"
            self._assess_cached_carried_load_seed(observation)
            seed = self._v938_pose_world_to_base(
                observation.vehicle_pose_world, cached_world_seed
            )
            observer.reset()
            if observer.initialize(
                [seed],
                initial_yaw_sigma_override_rad=yaw_sigma_override,
            ):
                if not self._carried_load_visual_authority_locked:
                    self._carried_load_visual_authority_locked = True
                    self._carried_load_visual_lock_count += 1
                self._carried_load_visual_handoff_seed_count += 1
                if fallback_handoff:
                    self._carried_load_visual_handoff_fallback_seed_count += 1
                self._carried_load_visual_last_rgb_time = (
                    self._carried_load_visual_handoff_measurement_time
                )
                self._carried_load_pose_last_update_time = float(observation.sim_time)
                self._sync_carried_load_observer_telemetry()
                if self._load_belief_enabled():
                    self._reset_load_belief_reference(
                        observation, mode="VISUAL_SEEDED"
                    )
            return

        if len(samples) < p.placement_carried_observer_min_samples:
            return
        observer.reset()
        if observer.initialize(samples):
            self._carried_load_pose_last_update_time = float(observation.sim_time)
            self._sync_carried_load_observer_telemetry()
            if self.parameters.placement_carried_seed_provenance_enabled > 0.5:
                self._carried_load_seed_provenance = LoadSeedProvenance.FUSED_GUIDE.value
                self._carried_load_seed_trusted_for_aggressive_risk = False
                self._carried_load_seed_age_seconds = float("inf")
                self._carried_load_seed_confidence = None
                self._carried_load_seed_reprojection_error_px = None
                self._carried_load_seed_reason = "observer_initialized_from_nonvisual_samples"
            if self._load_belief_enabled():
                self._reset_load_belief_reference(observation, mode="FUSED")

    def _update_carried_load_pose(self, observation: ForkliftObservation) -> None:
        if not self._carried_load_observer_enabled() or not observation.load_state.startswith("LIFTED"):
            return
        observer = self._carried_load_observer
        if observer is None or not observer.active:
            return
        p = self.parameters
        now = float(observation.sim_time)
        last = self._carried_load_pose_last_update_time
        if last is not None and now - last < p.placement_carried_observer_update_period:
            return
        self._carried_load_pose_last_update_time = now

        if p.placement_carried_visual_authority_enabled > 0.5:
            self._update_carried_visual_authority(observation)
            visual = self._pickup_pose_is_visual()
            fresh = self._pickup_visual_stale_seconds <= p.placement_carried_visual_max_stale_seconds
            if visual and fresh:
                observer.update(observation.pallet_pose_in_base)
                self._carried_load_visual_rgb_update_count += 1
                if self.parameters.placement_carried_seed_provenance_enabled > 0.5:
                    self._carried_load_seed_provenance = LoadSeedProvenance.RGB_LIVE.value
                    self._carried_load_seed_trusted_for_aggressive_risk = True
                    self._carried_load_seed_age_seconds = max(0.0, float(self._pickup_visual_stale_seconds))
                    self._carried_load_seed_confidence = self._pickup_visual_last_accepted_confidence
                    self._carried_load_seed_reprojection_error_px = self._pickup_visual_last_accepted_reprojection_error_px
                    self._carried_load_seed_reason = "fresh_live_rgb_update"
                measurement_time = self._pickup_visual_measurement_time(observation)
                if measurement_time is not None:
                    self._carried_load_visual_last_rgb_time = measurement_time
                if self._load_belief_enabled():
                    self._reset_load_belief_reference(
                        observation, mode="VISUAL_TRACKED"
                    )
            elif p.placement_carried_visual_require_lock_for_release > 0.5:
                # Weak-guide: once the carried-load transform is visually
                # established, coarse guide must never mutate it.
                self._carried_load_visual_rigid_prediction_count += 1
                if not visual:
                    self._carried_load_visual_guide_reject_count += 1
            else:
                # Moderate/finals keep the V9.3.2 low-gain observer behaviour.
                # Their structured pose is not the 20cm/10deg weak guide, and
                # continuing innovation-gated updates lets covariance contract
                # instead of freezing at the conservative initial sigma.
                observer.update(observation.pallet_pose_in_base)
            self._sync_carried_load_observer_telemetry()
            return

        observer.update(observation.pallet_pose_in_base)
        self._sync_carried_load_observer_telemetry()

    def _apply_terminal_load_reacquisition(
        self,
        observation: ForkliftObservation,
        measurement: Pose3D | None,
        *,
        measurement_position_sigma_m: float | None = None,
        measurement_yaw_sigma_deg: float | None = None,
        position_innovation_gate_m: float | None = None,
        yaw_innovation_gate_deg: float | None = None,
    ) -> None:
        """Fuse a temporally-consistent terminal RGB load measurement.

        This is an estimator-only interface.  The measurement can contract and
        correct the carried-load belief, but it never certifies release itself.
        """
        if measurement is None or not observation.load_state.startswith("LIFTED"):
            return
        if self.state not in (
            PickupState.PLACE_CORRIDOR, PickupState.PLACE_ALIGN,
            PickupState.PLACE_PRECISION, PickupState.PLACE_RECOVER_REVERSE,
        ):
            return
        observer = self._carried_load_observer
        if observer is None or not observer.active or observer.pose is None:
            return
        prior = observer.pose
        position_innovation = math.hypot(
            float(measurement.x) - float(prior.x),
            float(measurement.y) - float(prior.y),
        )
        yaw_innovation = abs(wrap_angle(float(measurement.yaw) - float(prior.yaw)))
        self._terminal_load_reacquisition_last_position_innovation_m = float(position_innovation)
        self._terminal_load_reacquisition_last_yaw_innovation_deg = math.degrees(yaw_innovation)
        self._terminal_load_reacquisition_last_measurement_yaw_deg = math.degrees(
            float(measurement.yaw)
        )
        yaw_authority = bool(
            self.parameters.placement_terminal_load_reacquisition_yaw_authority_enabled > 0.5
        )
        if yaw_authority:
            accepted = observer.update(
                measurement,
                measurement_position_sigma_m=measurement_position_sigma_m,
                measurement_yaw_sigma_rad=(
                    None if measurement_yaw_sigma_deg is None
                    else math.radians(float(measurement_yaw_sigma_deg))
                ),
                position_innovation_gate_m=position_innovation_gate_m,
                yaw_innovation_gate_rad=(
                    None if yaw_innovation_gate_deg is None
                    else math.radians(float(yaw_innovation_gate_deg))
                ),
            )
        else:
            # R4-F2: D2's prior-guided silhouette fit is independently useful
            # for translation but not for yaw. Preserve the F1 late-INSERT
            # yaw seed/rigid hold and consume terminal RGB as x/y/z evidence
            # only. Never use prior-as-measurement to shrink yaw covariance.
            self._terminal_load_reacquisition_yaw_suppressed_count += 1
            accepted = observer.update_position_only(
                measurement,
                measurement_position_sigma_m=measurement_position_sigma_m,
                position_innovation_gate_m=position_innovation_gate_m,
            )
        if accepted:
            self._terminal_load_reacquisition_update_count += 1
            if not yaw_authority:
                self._terminal_load_reacquisition_position_only_update_count += 1
            self._carried_load_visual_rgb_update_count += 1
            self._carried_load_visual_last_rgb_time = float(observation.sim_time)
            if (
                yaw_authority
                and self.parameters.placement_carried_yaw_axis_evidence_enabled > 0.5
            ):
                self._carried_load_yaw_last_evidence_time = float(observation.sim_time)
                self._carried_load_yaw_evidence_source = "TERMINAL_RGB_FULL"
            if self.parameters.placement_carried_seed_provenance_enabled > 0.5:
                self._carried_load_seed_provenance = LoadSeedProvenance.TERMINAL_RGB.value
                self._carried_load_seed_trusted_for_aggressive_risk = True
                self._carried_load_seed_age_seconds = 0.0
                self._carried_load_seed_reason = (
                    "terminal_rgb_reacquisition"
                    if yaw_authority else "terminal_rgb_reacquisition_position_only"
                )
            if yaw_authority and self._load_belief_enabled():
                self._reset_load_belief_reference(
                    observation, mode="TERMINAL_RGB_REACQUIRED"
                )
            elif (
                self._load_belief_enabled()
                and self.parameters.placement_carried_yaw_axis_evidence_enabled > 0.5
            ):
                self._reset_translation_load_belief_reference(observation)
        else:
            self._terminal_load_reacquisition_rejection_count += 1
        self._sync_carried_load_observer_telemetry()
        if observer.pose is not None:
            self._terminal_load_reacquisition_last_posterior_yaw_deg = math.degrees(
                float(observer.pose.yaw)
            )

    def _effective_pallet_pose_in_base(self, observation: ForkliftObservation) -> Pose3D:
        if (self._carried_load_observer_enabled() and self._carried_load_pose_in_base is not None and observation.load_state.startswith("LIFTED")):
            return self._carried_load_pose_in_base
        return observation.pallet_pose_in_base

    def _fast_pallet_pose_in_base(self, observation: ForkliftObservation) -> Pose3D:
        if (self._carried_load_observer_enabled() and self._carried_load_fast_pose_in_base is not None and observation.load_state.startswith("LIFTED")):
            return self._carried_load_fast_pose_in_base
        return observation.pallet_pose_in_base

    @staticmethod
    def _load_to_target_error_for_pose(load: Pose3D, target: Pose3D) -> DockingError:
        dx = float(target.x) - float(load.x)
        dy = float(target.y) - float(load.y)
        cosine = math.cos(float(target.yaw))
        sine = math.sin(float(target.yaw))
        longitudinal = cosine * dx + sine * dy
        lateral = -sine * dx + cosine * dy
        distance = math.hypot(longitudinal, lateral)
        heading = math.atan2(lateral, longitudinal) if distance > 1e-9 else 0.0
        return DockingError(
            longitudinal=float(longitudinal), lateral=float(lateral), distance=float(distance),
            heading=wrap_angle(heading), yaw=wrap_angle(float(target.yaw) - float(load.yaw)),
        )

    @classmethod
    def _load_to_placement_error_for_pose(cls, observation: ForkliftObservation, load: Pose3D) -> DockingError:
        return cls._load_to_target_error_for_pose(load, observation.placement_pose_in_base)

    def _load_to_placement_error(self, observation: ForkliftObservation) -> DockingError:
        return self._load_to_placement_error_for_pose(observation, self._effective_pallet_pose_in_base(observation))

    def _certification_target_pose_in_base(self, observation: ForkliftObservation) -> Pose3D:
        """Return the legacy MULTIVIEW/FAST certification target.

        V9.3.12-R4-E5 deliberately exposes this pose to the recenter planners so
        their full-pose model propagates the same world-fixed target used by the
        pre-F4 certification/control geometry.  R4-F4 must not alter this helper:
        its centre-PnP yaw anchor has release authority only and is applied by
        ``_strict_release_target_pose_in_base`` downstream of motion planning.
        No truth state is involved.
        """
        return (
            self._placement_certification_target_pose_in_base
            if self._placement_target_multiview_ready
            and self._placement_certification_target_pose_in_base is not None
            else observation.placement_pose_in_base
        )

    def _strict_release_target_pose_in_base(self, observation: ForkliftObservation) -> Pose3D:
        """Return the release-only target, preserving legacy x/y/z.

        R4-F4 may replace only target yaw with the short-lived centre-PnP world
        anchor. This helper is intentionally used only by strict release /
        Supervisor / Witness-adjacent assessment paths, never by MPC, E2/E3/E6
        search, or the full-pose recenter model.
        """
        base = self._certification_target_pose_in_base(observation)
        if (
            self.parameters.placement_strict_release_center_yaw_anchor_enabled > 0.5
            and self._placement_release_center_yaw_target_pose_in_base is not None
            and not self._strict_release_center_yaw_conflict_active
        ):
            center = self._placement_release_center_yaw_target_pose_in_base
            return Pose3D(
                x=float(base.x), y=float(base.y), z=float(base.z),
                roll=float(base.roll), pitch=float(base.pitch),
                yaw=float(center.yaw),
            )
        return base

    def _load_to_certification_error(self, observation: ForkliftObservation) -> DockingError:
        """Legacy certification-space error retained for motion/search logic."""
        return self._load_to_target_error_for_pose(
            self._effective_pallet_pose_in_base(observation),
            self._certification_target_pose_in_base(observation),
        )

    def _load_to_strict_release_error(self, observation: ForkliftObservation) -> DockingError:
        """Release-only error that may consume the guarded F4 centre-yaw anchor."""
        return self._load_to_target_error_for_pose(
            self._effective_pallet_pose_in_base(observation),
            self._strict_release_target_pose_in_base(observation),
        )

    def _fast_load_to_placement_error(self, observation: ForkliftObservation) -> DockingError:
        return self._load_to_placement_error_for_pose(observation, self._fast_pallet_pose_in_base(observation))

    def _placement_vehicle_target(
        self,
        observation: ForkliftObservation,
        *,
        pre_distance: float,
    ):
        target_load_pose = shift_pose_along_local_x(
            observation.placement_pose_in_base,
            -float(pre_distance),
        )
        return desired_vehicle_pose_for_load_target(
            target_load_pose,
            self._effective_pallet_pose_in_base(observation),
        )

    def _placement_release_envelope_enabled(self) -> bool:
        p = self.parameters
        return (
            p.placement_release_position_tolerance > 0.0
            and p.placement_release_yaw_tolerance > 0.0
            and p.placement_release_after_seconds > 0.0
            and p.placement_release_hold_seconds > 0.0
        )

    def _placement_post_release_limits(self) -> tuple[float, float]:
        p = self.parameters
        if self._placement_release_envelope_enabled():
            return (
                p.placement_post_release_position_tolerance,
                p.placement_post_release_yaw_tolerance,
            )
        return (
            1.8 * p.placement_position_tolerance,
            1.5 * p.placement_yaw_tolerance,
        )

    def _placement_recovery_enabled(self) -> bool:
        p = self.parameters
        return (
            self._placement_enabled()
            and p.placement_maximum_recoveries > 0
            and p.placement_recovery_minimum_distance > 0.0
            and p.placement_recovery_maximum_distance > 0.0
        )

    @staticmethod
    def _placement_progress_score(error: DockingError) -> float:
        return float(error.distance + 0.35 * abs(error.yaw))

    def _placement_progress_stalled(
        self, observation: ForkliftObservation, error: DockingError
    ) -> bool:
        p = self.parameters
        if p.placement_progress_timeout <= 0.0:
            return False
        now = float(observation.sim_time)
        score = self._placement_progress_score(error)
        if (self._placement_best_progress_score is None
                or score <= self._placement_best_progress_score
                - p.placement_progress_improvement):
            self._placement_best_progress_score = score
            self._placement_last_progress_time = now
            return False
        return now - self._placement_last_progress_time >= p.placement_progress_timeout

    def _placement_reentry_max_speed(self) -> float:
        p = self.parameters
        if self._placement_recovery_count <= 0:
            return p.place_align_max_speed
        if p.placement_recovery_runway_distance <= 0.0:
            return p.place_align_max_speed
        scale = p.placement_recovery_reentry_speed_scale ** (
            self._placement_recovery_count
        )
        scale = max(
            p.placement_recovery_reentry_minimum_speed_scale,
            scale,
        )
        return max(
            p.place_align_minimum_speed,
            p.place_align_max_speed * scale,
        )

    def _placement_recovery_distance(
        self, placement_error: DockingError, command_error: DockingError
    ) -> float:
        p = self.parameters
        legacy_requested = (
            p.placement_recovery_minimum_distance
            + p.placement_recovery_lateral_gain * abs(placement_error.lateral)
            + p.placement_recovery_yaw_gain * abs(placement_error.yaw)
        )
        if p.placement_recovery_runway_distance <= 0.0:
            self._placement_recovery_required_runway = 0.0
            return min(
                p.placement_recovery_maximum_distance,
                max(p.placement_recovery_minimum_distance, legacy_requested),
            )
        overshoot = max(0.0, -float(command_error.longitudinal))
        attempt_extra = (
            p.placement_recovery_attempt_distance_gain
            * max(0, self._placement_recovery_count - 1)
        )
        required_runway = (
            p.placement_recovery_runway_distance
            + p.placement_recovery_longitudinal_gain * overshoot
            + p.placement_recovery_lateral_gain * abs(command_error.lateral)
            + p.placement_recovery_yaw_gain * abs(command_error.yaw)
            + attempt_extra
        )
        required_runway = min(
            p.placement_recovery_maximum_distance,
            max(p.placement_recovery_runway_distance, required_runway),
        )
        self._placement_recovery_required_runway = required_runway
        additional_for_runway = max(
            0.0,
            required_runway - max(0.0, float(command_error.longitudinal)),
        )
        requested = max(legacy_requested, additional_for_runway)
        return min(
            p.placement_recovery_maximum_distance,
            max(p.placement_recovery_minimum_distance, requested),
        )

    def _placement_recovery_reentry_error(
        self, observation: ForkliftObservation
    ) -> DockingError:
        target_pose = self._placement_vehicle_target(
            observation, pre_distance=0.0
        )
        command = self.controller.pose_command(
            target_pose,
            maximum_speed=max(
                self.parameters.place_align_minimum_speed,
                self._placement_reentry_max_speed(),
            ),
            lift_target=self.parameters.transport_lift_target,
            stop_distance=0.0,
            steering_limit=self.parameters.place_steering_limit,
            minimum_speed_override=min(
                self.parameters.place_align_minimum_speed,
                self._placement_reentry_max_speed(),
            ),
        )
        return command.error

    def _placement_recovery_reentry_ready_now(
        self, observation: ForkliftObservation
    ) -> tuple[bool, DockingError]:
        p = self.parameters
        error = self._placement_recovery_reentry_error(observation)
        if p.placement_recovery_runway_distance <= 0.0:
            return True, error
        ready = (
            error.longitudinal >= p.placement_recovery_runway_distance
            and abs(error.heading) <= p.placement_recovery_reentry_heading_tolerance
            and abs(error.yaw) <= p.placement_recovery_reentry_yaw_tolerance
        )
        return bool(ready), error

    def _placement_recovery_reverse_steering(
        self, error: DockingError
    ) -> float:
        """Closed-loop steering while reversing to rebuild a usable runway.

        Lateral and yaw error need opposite steering signs in reverse:
        positive lateral error is corrected with positive reverse steering,
        while positive yaw error is corrected with negative reverse steering.
        No fixed target offset or learned geometry bias is used.
        """
        p = self.parameters
        if (
            p.placement_recovery_reverse_steering_limit <= 0.0
            or p.placement_recovery_reverse_lateral_gain <= 0.0
            or p.placement_recovery_reverse_yaw_gain <= 0.0
        ):
            return 0.0
        runway = max(
            0.35,
            abs(float(error.longitudinal)),
            0.5 * max(0.0, p.placement_recovery_runway_distance),
        )
        lateral_angle = math.atan2(float(error.lateral), runway)
        steering = (
            p.placement_recovery_reverse_lateral_gain * lateral_angle
            - p.placement_recovery_reverse_yaw_gain * float(error.yaw)
        )
        limit = p.placement_recovery_reverse_steering_limit
        return max(-limit, min(limit, float(steering)))

    def _begin_placement_recovery(
        self, *, reason: str, observation: ForkliftObservation,
        placement_error: DockingError, command_error: DockingError
    ) -> PickupDecision:
        p = self.parameters
        if (not self._placement_recovery_enabled()
                or self._placement_recovery_count >= p.placement_maximum_recoveries):
            return self._fail(
                f"{reason}; terminal placement recovery exhausted", observation
            )
        self._placement_recovery_count += 1
        self._placement_recovery_reason = reason
        self._placement_recovery_target_distance = self._placement_recovery_distance(
            placement_error, command_error
        )
        self._transition(PickupState.PLACE_RECOVER_REVERSE, observation)
        return self._decision(
            action=ForkliftAction(
                speed_target=p.placement_recovery_unwind_speed,
                steering_command=0.0,
                lift_target=p.transport_lift_target,
            ),
            observation=observation,
            status=(f"Starting terminal reverse recovery "
                    f"{self._placement_recovery_count}/"
                    f"{p.placement_maximum_recoveries}: {reason}"),
            error=command_error, placement_error=placement_error,
        )

    @staticmethod
    def _vehicle_forward_speed(observation: ForkliftObservation) -> float:
        vx, vy, _ = observation.vehicle_linear_velocity
        yaw = float(observation.vehicle_pose_world.yaw)
        return float(vx) * math.cos(yaw) + float(vy) * math.sin(yaw)

    def _placement_predictive_guard_enabled(self) -> bool:
        p = self.parameters
        return (
            p.placement_guard_minimum_forward_speed > 0.0
            and p.placement_guard_reaction_seconds > 0.0
            and p.placement_guard_deceleration_mps2 > 0.0
            and p.placement_guard_brake_hold_seconds > 0.0
        )

    def _placement_guard_geometry_misaligned(
        self, error: DockingError
    ) -> bool:
        p = self.parameters
        return (
            abs(error.lateral) > p.placement_guard_lateral_tolerance
            or abs(error.heading) > p.placement_guard_heading_tolerance
            or abs(error.yaw) > p.placement_guard_yaw_tolerance
        )

    def _placement_guard_stopping_distance(
        self, observation: ForkliftObservation
    ) -> float:
        p = self.parameters
        speed = max(0.0, self._vehicle_forward_speed(observation))
        return float(
            speed * p.placement_guard_reaction_seconds
            + speed * speed / (2.0 * p.placement_guard_deceleration_mps2)
            + p.placement_guard_stopping_margin_m
        )

    def _placement_predictive_guard_triggered(
        self, error: DockingError, observation: ForkliftObservation
    ) -> bool:
        p = self.parameters
        if not self._placement_predictive_guard_enabled():
            return False
        if self._placement_guard_brake_used:
            return False
        speed = max(0.0, self._vehicle_forward_speed(observation))
        if speed < p.placement_guard_minimum_forward_speed:
            return False
        if not self._placement_guard_geometry_misaligned(error):
            return False
        return (
            0.0 < error.longitudinal
            <= self._placement_guard_stopping_distance(observation)
        )

    def _placement_settle_progressing(
        self, observation: ForkliftObservation, placement_error: DockingError
    ) -> bool:
        p = self.parameters
        now = float(observation.sim_time)
        score = float(placement_error.distance)
        if self._placement_precision_settle_best is None:
            self._placement_precision_settle_best = score
            self._placement_precision_settle_last_improve_time = now
            return True
        if score <= (
            self._placement_precision_settle_best
            - p.placement_precision_settle_improvement_m
        ):
            self._placement_precision_settle_best = score
            self._placement_precision_settle_last_improve_time = now
            return True
        if self._placement_precision_settle_last_improve_time is None:
            self._placement_precision_settle_last_improve_time = now
            return True
        return (
            now - self._placement_precision_settle_last_improve_time
            < p.placement_precision_settle_progress_timeout
        )

    def _timeout_for_state(self) -> float | None:
        p = self.parameters
        return {
            PickupState.LOWER_FORK: p.lower_timeout,
            PickupState.APPROACH: p.approach_timeout,
            PickupState.ALIGN: p.align_timeout,
            PickupState.INSERT: p.insert_timeout,
            PickupState.LIFT: p.lift_timeout,
            PickupState.VERIFY_LIFT: p.lift_timeout,
            PickupState.RETREAT: p.retreat_timeout,
            PickupState.TRANSPORT_REPOSITION: p.transport_reposition_timeout,
            PickupState.TRANSPORT_APPROACH: p.transport_timeout,
            PickupState.PLACE_CORRIDOR: p.terminal_approach_corridor_timeout,
            PickupState.PLACE_ALIGN: p.place_align_timeout,
            PickupState.PLACE_PRECISION: p.place_align_timeout,
            PickupState.PLACE_RECOVER_REVERSE: p.placement_recovery_timeout,
            PickupState.LOWER_LOAD: p.placement_lower_timeout,
            PickupState.RELEASE_VERIFY: p.placement_lower_timeout,
            PickupState.PLACE_RETREAT: p.placement_retreat_timeout,
        }.get(self.state)

    def _recovery_steering_error(
        self,
        observation: ForkliftObservation,
    ) -> float:
        return max(
            abs(float(observation.steering_left)),
            abs(float(observation.steering_right)),
        )

    def _start_recovery_motion(
        self,
        observation: ForkliftObservation,
    ) -> None:
        pose = observation.vehicle_pose_world
        self._recovery_start_xy = (pose.x, pose.y)
        self._recovery_motion_start_time = float(observation.sim_time)

    def _recovery_reverse_action(self) -> ForkliftAction:
        return ForkliftAction(
            speed_target=self.parameters.recovery_speed,
            steering_command=0.0,
            lift_target=self.parameters.insertion_lift_target,
        )

    def _moving_unwind_enabled(self) -> bool:
        p = self.parameters
        return (
            p.recovery_unwind_speed < 0.0
            and p.recovery_unwind_distance > 0.0
        )

    def _recovery_unwind_action(self) -> ForkliftAction:
        return ForkliftAction(
            speed_target=self.parameters.recovery_unwind_speed,
            steering_command=0.0,
            lift_target=self.parameters.insertion_lift_target,
        )

    def _begin_recovery(
        self,
        reason: str,
        observation: ForkliftObservation,
    ) -> PickupDecision:
        p = self.parameters
        if (
            self.state not in self._RECOVERABLE_STATES
            or self._recovery_count >= p.maximum_recoveries
            or p.recovery_distance <= 0.0
        ):
            return self._fail(reason, observation)

        self._recovery_count += 1
        self._recovery_reason = reason
        self._transition(PickupState.RECOVER_REVERSE, observation)

        steering_error = self._recovery_steering_error(observation)
        steering_centered = steering_error <= p.recovery_steering_tolerance

        if self._moving_unwind_enabled():
            # A rolling tyre cannot reliably steer at standstill because of
            # lateral scrub. Creep backwards while commanding zero steering
            # to unload the contact patch and let the real joints unwind.
            self._start_recovery_motion(observation)
            if steering_centered:
                self._recovery_centered_since = float(observation.sim_time)
            action = self._recovery_unwind_action()
            status = (
                f"Recovery {self._recovery_count}/{p.maximum_recoveries}: "
                f"creeping reverse to unwind steering "
                f"({math.degrees(steering_error):.1f} deg)"
            )
        elif steering_centered and p.recovery_center_hold_seconds <= 0.0:
            self._start_recovery_motion(observation)
            action = self._recovery_reverse_action()
            status = (
                f"Recovery {self._recovery_count}/{p.maximum_recoveries}: "
                "reversing to rebuild approach geometry"
            )
        else:
            if steering_centered:
                self._recovery_centered_since = float(observation.sim_time)
            action = ForkliftAction.stopped(
                lift_target=p.insertion_lift_target
            )
            status = (
                f"Recovery {self._recovery_count}/{p.maximum_recoveries}: "
                f"centering steering ({math.degrees(steering_error):.1f} deg)"
            )

        return self._decision(
            action=action,
            observation=observation,
            status=status,
        )

    def _timeout_failure(
        self,
        observation: ForkliftObservation,
        elapsed: float,
    ) -> PickupDecision | None:
        """Check timeout after a state's completion condition has run."""
        timeout = self._timeout_for_state()
        if timeout is None or elapsed <= timeout:
            return None
        reason = f"state {self.state.value} timed out after {timeout:.1f}s"
        if self.state in self._RECOVERABLE_STATES:
            return self._begin_recovery(reason, observation)
        return self._fail(reason, observation)

    @staticmethod
    def _progress_score(state: PickupState, error: DockingError) -> float:
        """Return a stage-specific scalar; lower is better."""
        if state == PickupState.APPROACH:
            return (
                error.distance
                + 0.35 * abs(error.lateral)
                + 0.20 * abs(error.yaw)
            )
        if state == PickupState.ALIGN:
            return (
                0.25 * error.distance
                + abs(error.lateral)
                + 0.65 * abs(error.yaw)
            )
        return (
            error.distance
            + 0.75 * abs(error.lateral)
            + 0.35 * abs(error.yaw)
        )

    def _stalled_score(
        self,
        observation: ForkliftObservation,
        score: float,
    ) -> tuple[bool, float]:
        """Update progress memory for an arbitrary lower-is-better score."""
        p = self.parameters
        score = float(score)
        now = float(observation.sim_time)

        if p.progress_timeout <= 0.0:
            return False, score

        if self._progress_state != self.state or self._best_progress_score is None:
            self._progress_state = self.state
            self._best_progress_score = score
            self._last_progress_time = now
            return False, score

        if score <= self._best_progress_score - p.progress_improvement:
            self._best_progress_score = score
            self._last_progress_time = now
            return False, score

        stalled = now - self._last_progress_time >= p.progress_timeout
        return stalled, score

    def _stalled(
        self,
        observation: ForkliftObservation,
        error: DockingError,
    ) -> tuple[bool, float]:
        """Update progress memory and report a no-improvement interval."""
        return self._stalled_score(
            observation,
            self._progress_score(self.state, error),
        )

    def _overshot(self, error: DockingError) -> bool:
        tolerance = self.parameters.overshoot_longitudinal_tolerance
        return tolerance > 0.0 and error.longitudinal < -tolerance

    def _legacy_terminal_corridor_step(
        self, observation: ForkliftObservation, elapsed: float
    ) -> PickupDecision:
        """Preserve V9.3.0-H1 single-corridor behavior for old configs."""
        p = self.parameters
        # Build a curvature-feasible final approach to a live vehicle pose
        # derived from the current carried-load transform and placement
        # target.  This preserves the good 1-1.5 m geometry instead of
        # handing the last metre to a direct endpoint pose controller.
        corridor_target = self._placement_vehicle_target(
            observation,
            pre_distance=p.terminal_approach_corridor_standoff_distance,
        )
        live_goal_world = relative_pose_to_world(
            observation.vehicle_pose_world, corridor_target
        )
        needs_replan = self._transport_path is None
        if (
            not needs_replan
            and self._transport_goal_world is not None
            and self._terminal_corridor_last_replan_time is not None
            and float(observation.sim_time) - self._terminal_corridor_last_replan_time
            >= p.terminal_approach_corridor_replan_min_seconds
        ):
            goal_shift = math.hypot(
                live_goal_world.x - self._transport_goal_world.x,
                live_goal_world.y - self._transport_goal_world.y,
            )
            goal_yaw_shift = abs(wrap_angle(
                live_goal_world.yaw - self._transport_goal_world.yaw
            ))
            needs_replan = (
                goal_shift >= p.terminal_approach_corridor_replan_position_m
                or goal_yaw_shift >= p.terminal_approach_corridor_replan_yaw_rad
            )
        if needs_replan:
            corridor_chord = math.hypot(
                float(corridor_target.x),
                float(corridor_target.y),
            )
            corridor_yaw_error = abs(wrap_angle(float(corridor_target.yaw)))

            # V9.3.0-H1: the historical transport-path builder is a
            # long-runway primitive and intentionally rejects chords <=
            # 0.5 m.  PLACE_CORRIDOR, however, can legitimately be
            # entered inside that distance after TRANSPORT_APPROACH.
            # Do not weaken the long-path invariant.  Use a bounded local
            # bridge for the short final segment and hand off to the
            # existing bidirectional precision chain once the corridor is
            # already captured or slightly overshot.
            corridor_already_captured = (
                corridor_chord <= p.terminal_approach_corridor_capture_distance
                and corridor_yaw_error <= p.terminal_approach_corridor_yaw_tolerance
            )
            if corridor_already_captured or corridor_target.x <= 0.08:
                self._transport_path = None
                self._transport_goal_world = None
                self._transport_path_progress_index = 0
                self._transition(PickupState.PLACE_ALIGN, observation)
                return self._decision(
                    action=ForkliftAction.stopped(lift_target=p.transport_lift_target),
                    observation=observation,
                    status=(
                        "Terminal corridor already captured; entering "
                        "placement alignment"
                    ),
                    error=DockingError(
                        longitudinal=float(corridor_target.x),
                        lateral=float(corridor_target.y),
                        distance=float(corridor_chord),
                        heading=math.atan2(corridor_target.y, corridor_target.x),
                        yaw=wrap_angle(corridor_target.yaw),
                    ),
                    placement_error=self._load_to_placement_error(observation),
                )

            if corridor_chord <= 0.5:
                # The local bridge is deliberately forward-only and slow.
                # If the desired corridor pose moves behind the vehicle,
                # the x<=0.08 handoff above gives ownership to PLACE_ALIGN
                # / PLACE_PRECISION, where bounded reverse motion already
                # has physical validation.
                self._transport_path = None
                self._transport_goal_world = live_goal_world
                self._transport_path_progress_index = 0
                self._terminal_corridor_last_replan_time = float(
                    observation.sim_time
                )
                bridge_command = self.controller.pose_command(
                    corridor_target,
                    maximum_speed=p.terminal_approach_corridor_max_speed,
                    lift_target=p.transport_lift_target,
                    stop_distance=0.0,
                    steering_limit=p.transport_steering_limit,
                    minimum_speed_override=(
                        p.terminal_approach_corridor_minimum_speed
                    ),
                )
                timeout_failure = self._timeout_failure(observation, elapsed)
                if timeout_failure is not None:
                    return timeout_failure
                return self._decision(
                    action=bridge_command.action,
                    observation=observation,
                    status=(
                        "Following short terminal corridor bridge "
                        f"({corridor_chord:.2f}m to standoff)"
                    ),
                    error=bridge_command.error,
                    placement_error=self._load_to_placement_error(observation),
                )

            self._transport_goal_world = live_goal_world
            self._transport_path = build_cubic_transport_path(
                observation.vehicle_pose_world,
                self._transport_goal_world,
                handle_scale=p.terminal_approach_corridor_handle_scale,
                sample_count=p.terminal_approach_corridor_samples,
            )
            self._transport_path_progress_index = 0
            self._terminal_corridor_last_replan_time = float(observation.sim_time)

        assert self._transport_path is not None
        path_command = track_transport_path(
            self._transport_path,
            observation.vehicle_pose_world,
            previous_index=self._transport_path_progress_index,
            wheelbase=p.transport_path_wheelbase,
            lookahead_distance=p.terminal_approach_corridor_lookahead,
            maximum_speed=p.terminal_approach_corridor_max_speed,
            minimum_speed=p.terminal_approach_corridor_minimum_speed,
            steering_limit=p.transport_steering_limit,
            lift_target=p.transport_lift_target,
            capture_distance=p.terminal_approach_corridor_capture_distance,
            goal_yaw_tolerance=p.terminal_approach_corridor_yaw_tolerance,
            speed_gain=p.transport_path_speed_gain,
            steering_speed_floor=p.transport_path_steering_speed_floor,
            steering_slowdown_gain=p.transport_path_steering_slowdown_gain,
        )
        self._transport_path_progress_index = path_command.progress_index
        captured = (
            path_command.goal_distance <= p.terminal_approach_corridor_capture_distance
            and abs(path_command.goal_yaw_error) <= p.terminal_approach_corridor_yaw_tolerance
        )
        if captured:
            self._transition(PickupState.PLACE_ALIGN, observation)
            return self._decision(
                action=ForkliftAction.stopped(lift_target=p.transport_lift_target),
                observation=observation,
                status="Terminal approach corridor captured; handing off to precision alignment",
                error=path_command.error,
                placement_error=self._load_to_placement_error(observation),
            )
        timeout_failure = self._timeout_failure(observation, elapsed)
        if timeout_failure is not None:
            return timeout_failure
        return self._decision(
            action=path_command.action,
            observation=observation,
            status=(
                "Following carried-load-aware terminal approach corridor "
                f"({100.0 * path_command.path_progress:.0f}%, "
                f"{path_command.remaining_length:.2f}m remaining)"
            ),
            error=path_command.error,
            placement_error=self._load_to_placement_error(observation),
        )


    def step(
        self,
        observation: ForkliftObservation,
        *,
        pickup_vision_ready: bool = True,
        placement_vision_ready: bool = True,
        placement_vision_authority: str | None = None,
        placement_vision_stale_seconds: float | None = None,
        placement_vision_raw_position_spread_m: float | None = None,
        placement_vision_raw_yaw_spread_deg: float | None = None,
        placement_certification_target_pose_in_base: Pose3D | None = None,
        placement_release_center_yaw_target_pose_in_base: Pose3D | None = None,
        placement_vision_multiview_ready: bool | None = None,
        placement_vision_multiview_samples: int | None = None,
        placement_vision_multiview_position_spread_m: float | None = None,
        placement_vision_multiview_yaw_spread_deg: float | None = None,
        placement_vision_fast_slow_position_disagreement_m: float | None = None,
        placement_vision_fast_slow_yaw_disagreement_deg: float | None = None,
        pickup_vision_authority: str | None = None,
        pickup_vision_source: str | None = None,
        pickup_vision_stale_seconds: float | None = None,
        pickup_vision_last_accepted_confidence: float | None = None,
        pickup_vision_last_accepted_reprojection_error_px: float | None = None,
        terminal_load_reacquisition_pose_in_base: Pose3D | None = None,
        terminal_load_reacquisition_position_sigma_m: float | None = None,
        terminal_load_reacquisition_yaw_sigma_deg: float | None = None,
        terminal_load_reacquisition_position_gate_m: float | None = None,
        terminal_load_reacquisition_yaw_gate_deg: float | None = None,
    ) -> PickupDecision:
        p = self.parameters
        elapsed = self._elapsed(observation)
        if placement_vision_authority is not None:
            self._terminal_visual_authority = str(placement_vision_authority)
        if placement_vision_raw_position_spread_m is not None:
            raw_pos = float(placement_vision_raw_position_spread_m)
            self._placement_target_raw_position_spread_m = (
                raw_pos if math.isfinite(raw_pos) and raw_pos >= 0.0 else None
            )
        if placement_vision_raw_yaw_spread_deg is not None:
            raw_yaw_deg = float(placement_vision_raw_yaw_spread_deg)
            self._placement_target_raw_yaw_spread_rad = (
                math.radians(raw_yaw_deg)
                if math.isfinite(raw_yaw_deg) and raw_yaw_deg >= 0.0
                else None
            )
        self._placement_certification_target_pose_in_base = placement_certification_target_pose_in_base
        self._placement_release_center_yaw_target_pose_in_base = (
            placement_release_center_yaw_target_pose_in_base
        )
        self._update_release_center_yaw_continuity_guard(observation)
        if self._strict_release_center_yaw_conflict_active:
            self._strict_release_center_yaw_conflict_fallback_frame_count += 1
        if placement_vision_multiview_ready is not None:
            self._placement_target_multiview_ready = bool(placement_vision_multiview_ready)
        if placement_vision_multiview_samples is not None:
            self._placement_target_multiview_samples = max(0, int(placement_vision_multiview_samples))
        if placement_vision_multiview_position_spread_m is not None:
            value = float(placement_vision_multiview_position_spread_m)
            self._placement_target_multiview_position_spread_m = (
                value if math.isfinite(value) and value >= 0.0 else None
            )
        if placement_vision_multiview_yaw_spread_deg is not None:
            value = float(placement_vision_multiview_yaw_spread_deg)
            self._placement_target_multiview_yaw_spread_rad = (
                math.radians(value) if math.isfinite(value) and value >= 0.0 else None
            )
        if placement_vision_fast_slow_position_disagreement_m is not None:
            value = float(placement_vision_fast_slow_position_disagreement_m)
            self._placement_target_fast_slow_position_disagreement_m = (
                value if math.isfinite(value) and value >= 0.0 else None
            )
        if placement_vision_fast_slow_yaw_disagreement_deg is not None:
            value = float(placement_vision_fast_slow_yaw_disagreement_deg)
            self._placement_target_fast_slow_yaw_disagreement_rad = (
                math.radians(value) if math.isfinite(value) and value >= 0.0 else None
            )
        if pickup_vision_authority is not None:
            self._pickup_visual_authority = str(pickup_vision_authority)
        if pickup_vision_source is not None:
            self._pickup_visual_source = str(pickup_vision_source)
        if pickup_vision_stale_seconds is not None:
            self._pickup_visual_stale_seconds = float(pickup_vision_stale_seconds)
        if pickup_vision_last_accepted_confidence is not None:
            value = float(pickup_vision_last_accepted_confidence)
            self._pickup_visual_last_accepted_confidence = value if math.isfinite(value) else None
        if pickup_vision_last_accepted_reprojection_error_px is not None:
            value = float(pickup_vision_last_accepted_reprojection_error_px)
            self._pickup_visual_last_accepted_reprojection_error_px = value if math.isfinite(value) else None
        self._cache_carried_load_visual_handoff(observation)
        visual_stale_seconds = (
            float(placement_vision_stale_seconds)
            if placement_vision_stale_seconds is not None
            else float("inf")
        )

        load_tilt = max(
            abs(float(observation.pallet_pose_world.roll)),
            abs(float(observation.pallet_pose_world.pitch)),
        )
        if load_tilt > p.maximum_load_tilt:
            return self._fail(
                f"load tilt exceeded {math.degrees(p.maximum_load_tilt):.1f} deg",
                observation,
            )

        # V9.3.0: after VERIFY_LIFT has initialized the observer, keep the
        # rigid load state alive with low-gain innovation-gated updates.
        if self.state != PickupState.VERIFY_LIFT:
            self._update_carried_load_pose(observation)
        self._apply_terminal_load_reacquisition(
            observation, terminal_load_reacquisition_pose_in_base,
            measurement_position_sigma_m=terminal_load_reacquisition_position_sigma_m,
            measurement_yaw_sigma_deg=terminal_load_reacquisition_yaw_sigma_deg,
            position_innovation_gate_m=terminal_load_reacquisition_position_gate_m,
            yaw_innovation_gate_deg=terminal_load_reacquisition_yaw_gate_deg,
        )
        self._update_load_belief_motion(observation)

        terminal_budget_failure = self._placement_terminal_budget_failure(
            observation
        )
        if terminal_budget_failure is not None:
            return terminal_budget_failure

        if self.state == PickupState.LOWER_FORK:
            action = ForkliftAction.stopped(
                lift_target=p.insertion_lift_target
            )
            settled = (
                abs(observation.lift_position - p.insertion_lift_target)
                <= p.lift_position_tolerance
                and abs(observation.lift_velocity) <= p.lift_velocity_tolerance
            )
            if settled and elapsed >= 0.20:
                self._transition(PickupState.APPROACH, observation)
            else:
                timeout_failure = self._timeout_failure(observation, elapsed)
                if timeout_failure is not None:
                    return timeout_failure
            return self._decision(
                action=action,
                observation=observation,
                status="Setting fork height for pallet pockets",
            )

        if self.state == PickupState.APPROACH:
            if self._axis_docking_enabled():
                approach_corridor: AxisCorridorError | None = None
                if self._fork_corridor_enabled():
                    approach_corridor = self._fork_corridor_error(
                        observation,
                        object_center_distance=p.insertion_distance,
                    )
                command = self.controller.axis_command(
                    observation.pallet_pose_in_base,
                    target_distance=p.approach_line_distance,
                    maximum_speed=p.approach_max_speed,
                    lift_target=p.insertion_lift_target,
                    stop_longitudinal_tolerance=0.0,
                    **self._corridor_command_overrides(
                        approach_corridor
                    ),
                )
                captured = (
                    command.error.longitudinal
                    <= p.pre_position_tolerance
                )
                if captured:
                    self._transition(PickupState.ALIGN, observation)
                    return self._decision(
                        action=ForkliftAction.stopped(
                            lift_target=p.insertion_lift_target
                        ),
                        observation=observation,
                        status=(
                            "Object-axis approach gate reached; "
                            "braking before line alignment"
                        ),
                        error=command.error,
                        corridor_error=approach_corridor,
                    )

                stalled, score = self._stalled(
                    observation,
                    command.error,
                )
                if stalled:
                    return self._begin_recovery(
                        "axis APPROACH made no progress for "
                        f"{p.progress_timeout:.1f}s",
                        observation,
                    )

                timeout_failure = self._timeout_failure(
                    observation,
                    elapsed,
                )
                if timeout_failure is not None:
                    return timeout_failure
                return self._decision(
                    action=command.action,
                    observation=observation,
                    status=(
                        "Following projected fork corridor to approach gate"
                        if approach_corridor is not None
                        else "Following pallet centreline to approach gate"
                    ),
                    error=command.error,
                    progress_score=score,
                    corridor_error=approach_corridor,
                )

            else:
                command = self.controller.command(
                    observation.pallet_pose_in_base,
                    standoff_distance=p.pre_approach_distance,
                    maximum_speed=p.approach_max_speed,
                    lift_target=p.insertion_lift_target,
                    stop_distance=0.04,
                )
                if command.error.distance <= p.approach_capture_distance:
                    self._transition(PickupState.ALIGN, observation)
                    return self._decision(
                        action=ForkliftAction.stopped(
                            lift_target=p.insertion_lift_target
                        ),
                        observation=observation,
                        status=(
                            "Pre-approach captured; braking before "
                            "rolling alignment"
                        ),
                        error=command.error,
                    )
    
                if self._overshot(command.error):
                    return self._begin_recovery(
                        "pre-approach pose was overshot",
                        observation,
                    )
    
                stalled, score = self._stalled(observation, command.error)
                if stalled:
                    return self._begin_recovery(
                        f"APPROACH made no progress for {p.progress_timeout:.1f}s",
                        observation,
                    )
    
                timeout_failure = self._timeout_failure(observation, elapsed)
                if timeout_failure is not None:
                    return timeout_failure
                return self._decision(
                    action=command.action,
                    observation=observation,
                    status="Driving to planned pallet pre-approach pose",
                    error=command.error,
                    progress_score=score,
                )
    
        if self.state == PickupState.ALIGN:
            if self._axis_docking_enabled():
                # Continue toward the last safe correction boundary. In
                # corridor mode, handoff depends on the fork segment's
                # projected pocket clearance at the planned lift distance,
                # not on lateral/yaw errors at the vehicle origin.
                corridor_error: AxisCorridorError | None = None
                if self._fork_corridor_enabled():
                    corridor_error = self._fork_corridor_error(
                        observation,
                        object_center_distance=p.insertion_distance,
                    )
                command = self.controller.axis_command(
                    observation.pallet_pose_in_base,
                    target_distance=p.alignment_abort_distance,
                    maximum_speed=p.align_max_speed,
                    lift_target=p.insertion_lift_target,
                    stop_longitudinal_tolerance=0.0,
                    minimum_speed_override=(
                        p.align_minimum_speed
                        if p.align_minimum_speed > 0.0
                        else None
                    ),
                    **self._corridor_command_overrides(
                        corridor_error
                    ),
                )
                gate_error = object_axis_error(
                    observation.pallet_pose_in_base,
                    target_distance=p.alignment_line_distance,
                )

                if corridor_error is not None:
                    aligned = (
                        gate_error.longitudinal
                        <= p.pre_position_tolerance
                        and corridor_error.maximum_abs_lateral
                        <= p.alignment_preview_tolerance
                        and abs(gate_error.yaw)
                        <= p.pre_yaw_tolerance
                    )
                    progress_value = (
                        0.20 * max(command.error.longitudinal, 0.0)
                        + corridor_error.maximum_abs_lateral
                        + 0.10 * abs(gate_error.yaw)
                    )
                    stalled, score = self._stalled_score(
                        observation,
                        progress_value,
                    )
                else:
                    aligned = (
                        gate_error.longitudinal
                        <= p.pre_position_tolerance
                        and abs(gate_error.lateral)
                        <= p.pre_lateral_tolerance
                        and abs(gate_error.yaw)
                        <= p.pre_yaw_tolerance
                    )
                    stalled, score = self._stalled(
                        observation,
                        command.error,
                    )

                if aligned:
                    if self._alignment_condition_since is None:
                        self._alignment_condition_since = float(
                            observation.sim_time
                        )
                    held = (
                        float(observation.sim_time)
                        - self._alignment_condition_since
                        >= p.alignment_hold_seconds
                    )
                    if held:
                        if not pickup_vision_ready:
                            timeout_failure = self._timeout_failure(
                                observation,
                                elapsed,
                            )
                            if timeout_failure is not None:
                                return timeout_failure
                            return self._decision(
                                action=ForkliftAction.stopped(
                                    lift_target=p.insertion_lift_target
                                ),
                                observation=observation,
                                status=(
                                    "Alignment held; waiting for "
                                    "pre-insert RGB pocket acquisition"
                                ),
                                error=gate_error,
                                corridor_error=corridor_error,
                            )
                        self._transition(
                            PickupState.INSERT,
                            observation,
                        )
                        return self._decision(
                            action=ForkliftAction.stopped(
                                lift_target=p.insertion_lift_target
                            ),
                            observation=observation,
                            status=(
                                "Projected fork corridor held; "
                                "starting insertion"
                                if corridor_error is not None
                                else (
                                    "Pallet-axis entry gate held; "
                                    "starting straight insertion"
                                )
                            ),
                            error=gate_error,
                            corridor_error=corridor_error,
                        )
                    action = ForkliftAction.stopped(
                        lift_target=p.insertion_lift_target
                    )
                else:
                    self._alignment_condition_since = None
                    action = command.action

                if (
                    not aligned
                    and command.error.longitudinal <= 0.0
                ):
                    detail = (
                        ""
                        if corridor_error is None
                        else (
                            " "
                            f"(projected clearance="
                            f"{corridor_error.maximum_abs_lateral:.3f}m)"
                        )
                    )
                    return self._begin_recovery(
                        "alignment gate was missed before the safe "
                        f"insertion corridor{detail}",
                        observation,
                    )

                if stalled:
                    return self._begin_recovery(
                        "axis ALIGN made no progress for "
                        f"{p.progress_timeout:.1f}s",
                        observation,
                    )

                timeout_failure = self._timeout_failure(
                    observation,
                    elapsed,
                )
                if timeout_failure is not None:
                    return timeout_failure
                return self._decision(
                    action=action,
                    observation=observation,
                    status=(
                        "Holding projected fork corridor"
                        if aligned and corridor_error is not None
                        else (
                            "Holding pallet-axis entry gate"
                            if aligned
                            else (
                                "Aligning projected fork corridor"
                                if corridor_error is not None
                                else "Acquiring pallet centreline at low speed"
                            )
                        )
                    ),
                    error=gate_error,
                    progress_score=score,
                    corridor_error=corridor_error,
                )

            else:
                command = self.controller.command(
                    observation.pallet_pose_in_base,
                    standoff_distance=p.pre_approach_distance,
                    maximum_speed=p.align_max_speed,
                    lift_target=p.insertion_lift_target,
                    stop_distance=0.0,
                    minimum_speed_override=(
                        p.align_minimum_speed
                        if p.align_minimum_speed > 0.0
                        else None
                    ),
                )
                exact_alignment = (
                    command.error.distance <= p.pre_position_tolerance
                    and abs(command.error.lateral) <= p.pre_lateral_tolerance
                    and abs(command.error.yaw) <= p.pre_yaw_tolerance
                )
                corridor_handoff = (
                    p.align_handoff_longitudinal_tolerance > 0.0
                    and abs(command.error.longitudinal)
                    <= p.align_handoff_longitudinal_tolerance
                    and abs(command.error.lateral)
                    <= p.align_handoff_lateral_tolerance
                    and abs(command.error.yaw)
                    <= p.align_handoff_yaw_tolerance
                )
                aligned = exact_alignment or corridor_handoff
    
                if aligned:
                    if self._alignment_condition_since is None:
                        self._alignment_condition_since = float(observation.sim_time)
                    held = (
                        float(observation.sim_time) - self._alignment_condition_since
                        >= p.alignment_hold_seconds
                    )
                    if held:
                        if not pickup_vision_ready:
                            timeout_failure = self._timeout_failure(
                                observation,
                                elapsed,
                            )
                            if timeout_failure is not None:
                                return timeout_failure
                            return self._decision(
                                action=ForkliftAction.stopped(
                                    lift_target=p.insertion_lift_target
                                ),
                                observation=observation,
                                status=(
                                    "Alignment held; waiting for "
                                    "pre-insert RGB pocket acquisition"
                                ),
                                error=command.error,
                            )
                        self._transition(PickupState.INSERT, observation)
                        return self._decision(
                            action=ForkliftAction.stopped(
                                lift_target=p.insertion_lift_target
                            ),
                            observation=observation,
                            status=(
                                "Alignment corridor held; "
                                "starting fork insertion"
                            ),
                            error=command.error,
                        )
                    action = ForkliftAction.stopped(
                        lift_target=p.insertion_lift_target
                    )
                else:
                    self._alignment_condition_since = None
                    action = command.action
    
                if not aligned and self._overshot(command.error):
                    return self._begin_recovery(
                        "rolling ALIGN overshot the usable handoff corridor",
                        observation,
                    )
    
                stalled, score = self._stalled(observation, command.error)
                if stalled:
                    return self._begin_recovery(
                        f"ALIGN made no progress for {p.progress_timeout:.1f}s",
                        observation,
                    )
    
                timeout_failure = self._timeout_failure(observation, elapsed)
                if timeout_failure is not None:
                    return timeout_failure
                return self._decision(
                    action=action,
                    observation=observation,
                    status=(
                        "Holding usable alignment corridor before insertion"
                        if aligned
                        else "Rolling low-speed alignment with pallet fork pockets"
                    ),
                    error=command.error,
                    progress_score=score,
                )
    
        if self.state == PickupState.INSERT:
            if self._axis_docking_enabled():
                # The lift decision is based on fork/pocket overlap geometry.
                # Origin lateral error and yaw can be individually non-zero
                # while cancelling along the actual fork segment.
                minimum_insert_speed = (
                    p.insertion_minimum_speed
                    if p.insertion_minimum_speed > 0.0
                    else p.align_minimum_speed
                )
                corridor_error: AxisCorridorError | None = None
                if self._fork_corridor_enabled():
                    # Before the nominal lift depth, preview the overlap at
                    # insertion_distance. Once deeper, use the actual overlap.
                    corridor_center_distance = min(
                        float(observation.pallet_pose_in_base.x),
                        p.insertion_distance,
                    )
                    corridor_error = self._fork_corridor_error(
                        observation,
                        object_center_distance=corridor_center_distance,
                    )
                command = self.controller.axis_command(
                    observation.pallet_pose_in_base,
                    target_distance=p.insertion_abort_distance,
                    maximum_speed=p.insertion_max_speed,
                    lift_target=p.insertion_lift_target,
                    stop_longitudinal_tolerance=0.0,
                    steering_limit=p.insertion_steering_limit,
                    minimum_speed_override=min(
                        minimum_insert_speed,
                        p.insertion_max_speed,
                    )
                    if minimum_insert_speed > 0.0
                    else None,
                    **self._corridor_command_overrides(
                        corridor_error
                    ),
                )
                insertion_gate_error = object_axis_error(
                    observation.pallet_pose_in_base,
                    target_distance=p.insertion_distance,
                )

                if corridor_error is not None:
                    corridor_ready = (
                        corridor_error.maximum_abs_lateral
                        <= p.insertion_corridor_tolerance
                    )
                    inserted = (
                        insertion_gate_error.longitudinal
                        <= p.insertion_position_tolerance
                        and corridor_ready
                        and abs(insertion_gate_error.yaw)
                        <= p.insertion_yaw_tolerance
                    )
                else:
                    corridor_ready = False
                    inserted = (
                        insertion_gate_error.longitudinal
                        <= p.insertion_position_tolerance
                        and abs(insertion_gate_error.lateral)
                        <= p.insertion_lateral_tolerance
                        and abs(insertion_gate_error.yaw)
                        <= p.insertion_yaw_tolerance
                    )

                if inserted:
                    self._transition(PickupState.LIFT, observation)
                    return self._decision(
                        action=ForkliftAction.stopped(
                            lift_target=p.transport_lift_target
                        ),
                        observation=observation,
                        status=(
                            "Fork segment is inside the pocket corridor; "
                            "lifting pallet"
                            if corridor_error is not None
                            else (
                                "Longitudinal insertion gate reached; "
                                "lifting pallet"
                            )
                        ),
                        error=insertion_gate_error,
                        corridor_error=corridor_error,
                    )

                if corridor_error is not None:
                    unsafe_line_error = (
                        corridor_error.maximum_abs_lateral
                        > p.insertion_abort_lateral
                        or abs(insertion_gate_error.yaw)
                        > p.insertion_abort_yaw
                    )
                    progress_value = (
                        max(insertion_gate_error.longitudinal, 0.0)
                        + 2.0 * corridor_error.maximum_abs_lateral
                        + 0.10 * abs(insertion_gate_error.yaw)
                    )
                    stalled, score = self._stalled_score(
                        observation,
                        progress_value,
                    )
                else:
                    unsafe_line_error = (
                        abs(command.error.lateral)
                        > p.insertion_abort_lateral
                        or abs(command.error.yaw)
                        > p.insertion_abort_yaw
                    )
                    stalled, score = self._stalled(
                        observation,
                        command.error,
                    )

                too_close_to_realign = (
                    command.error.longitudinal <= 0.0
                )
                close_enough_for_corridor_abort = (
                    insertion_gate_error.longitudinal <= 0.35
                )
                contact_blocked = (
                    observation.fork_contact_count > 0
                    and insertion_gate_error.longitudinal
                    > p.insertion_position_tolerance
                )
                should_recover = (
                    (
                        unsafe_line_error
                        or too_close_to_realign
                    )
                    if corridor_error is None
                    else (
                        too_close_to_realign
                        or contact_blocked
                        or (
                            unsafe_line_error
                            and close_enough_for_corridor_abort
                        )
                    )
                )
                if elapsed >= 0.50 and should_recover:
                    detail = (
                        ""
                        if corridor_error is None
                        else (
                            " "
                            f"(fork clearance="
                            f"{corridor_error.maximum_abs_lateral:.3f}m)"
                        )
                    )
                    reason = (
                        "fork contact blocked insertion before lift position"
                        if contact_blocked
                        else (
                            "insertion corridor was lost before lift "
                            f"position{detail}"
                        )
                    )
                    return self._begin_recovery(
                        reason,
                        observation,
                    )

                if stalled:
                    return self._begin_recovery(
                        "axis INSERT made no progress for "
                        f"{p.progress_timeout:.1f}s",
                        observation,
                    )

                timeout_failure = self._timeout_failure(
                    observation,
                    elapsed,
                )
                if timeout_failure is not None:
                    return timeout_failure
                return self._decision(
                    action=command.action,
                    observation=observation,
                    status=(
                        "Following fork-pocket overlap corridor"
                        if corridor_error is not None
                        else "Following pallet axis through fork pockets"
                    ),
                    error=insertion_gate_error,
                    progress_score=score,
                    corridor_error=corridor_error,
                )

            else:
                command = self.controller.command(
                    observation.pallet_pose_in_base,
                    standoff_distance=p.insertion_distance,
                    maximum_speed=p.insertion_max_speed,
                    lift_target=p.insertion_lift_target,
                    stop_distance=0.02,
                    steering_limit=0.14,
                )
                inserted = (
                    command.error.distance <= p.insertion_position_tolerance
                    and abs(command.error.lateral) <= p.insertion_lateral_tolerance
                    and abs(command.error.yaw) <= p.insertion_yaw_tolerance
                )
                if inserted:
                    self._transition(PickupState.LIFT, observation)
                    return self._decision(
                        action=ForkliftAction.stopped(
                            lift_target=p.transport_lift_target
                        ),
                        observation=observation,
                        status="Fork insertion complete; lifting pallet",
                        error=command.error,
                    )
    
                if self._overshot(command.error):
                    return self._begin_recovery(
                        "fork insertion target was overshot",
                        observation,
                    )
    
                stalled, score = self._stalled(observation, command.error)
                if stalled:
                    return self._begin_recovery(
                        f"INSERT made no progress for {p.progress_timeout:.1f}s",
                        observation,
                    )
    
                timeout_failure = self._timeout_failure(observation, elapsed)
                if timeout_failure is not None:
                    return timeout_failure
                return self._decision(
                    action=command.action,
                    observation=observation,
                    status="Low-speed fork insertion",
                    error=command.error,
                    progress_score=score,
                )
    
        if self.state == PickupState.RECOVER_REVERSE:
            now = float(observation.sim_time)

            if self._moving_unwind_enabled():
                # V5.1.3 mode: reverse motion starts immediately at a small
                # creep speed. This releases tyre scrub so the actual rear
                # steering joints can follow the zero-angle command.
                if (
                    self._recovery_motion_start_time is None
                    or self._recovery_start_xy is None
                ):
                    self._start_recovery_motion(observation)

                pose = observation.vehicle_pose_world
                reverse_distance = math.hypot(
                    pose.x - self._recovery_start_xy[0],
                    pose.y - self._recovery_start_xy[1],
                )
                reset_ready = (
                    p.recovery_reset_distance > 0.0
                    and reverse_distance
                    >= p.recovery_reset_minimum_distance
                    and float(observation.pallet_pose_in_base.x)
                    >= p.recovery_reset_distance
                )
                distance_ready = (
                    reverse_distance >= p.recovery_distance
                )
                if reset_ready or distance_ready:
                    self._transition(PickupState.APPROACH, observation)
                    return self._decision(
                        action=ForkliftAction.stopped(
                            lift_target=p.insertion_lift_target
                        ),
                        observation=observation,
                        status=(
                            "Recovery runway rebuilt; "
                            "replanning corridor approach"
                            if reset_ready
                            else (
                                "Maximum recovery distance reached; "
                                "replanning corridor approach"
                            )
                        ),
                    )

                motion_elapsed = now - self._recovery_motion_start_time
                steering_error = self._recovery_steering_error(observation)
                steering_centered = (
                    steering_error <= p.recovery_steering_tolerance
                )

                if steering_centered:
                    if self._recovery_centered_since is None:
                        self._recovery_centered_since = now
                else:
                    self._recovery_centered_since = None

                centered_long_enough = (
                    self._recovery_centered_since is not None
                    and now - self._recovery_centered_since
                    >= p.recovery_center_hold_seconds
                )
                unwind_time_exhausted = (
                    p.recovery_center_timeout > 0.0
                    and motion_elapsed >= p.recovery_center_timeout
                )
                unwind_distance_reached = (
                    reverse_distance >= p.recovery_unwind_distance
                )

                # Never fail merely because the steering did not centre.
                # After the bounded unwind phase, continue the main reverse
                # while still commanding zero steering.
                if (
                    centered_long_enough
                    or unwind_time_exhausted
                    or unwind_distance_reached
                ):
                    action = self._recovery_reverse_action()
                    phase = "main reverse"
                else:
                    action = self._recovery_unwind_action()
                    phase = "moving steering unwind"

                if motion_elapsed > p.recovery_timeout:
                    if (
                        p.recovery_minimum_distance > 0.0
                        and reverse_distance
                        >= p.recovery_minimum_distance
                    ):
                        self._transition(
                            PickupState.APPROACH,
                            observation,
                        )
                        return self._decision(
                            action=ForkliftAction.stopped(
                                lift_target=p.insertion_lift_target
                            ),
                            observation=observation,
                            status=(
                                "Partial recovery accepted after timeout "
                                f"({reverse_distance:.2f}m); "
                                "replanning pre-approach"
                            ),
                        )
                    return self._fail(
                        "recovery reverse moved only "
                        f"{reverse_distance:.2f}/"
                        f"{p.recovery_distance:.2f}m in "
                        f"{p.recovery_timeout:.1f}s "
                        f"(steering error="
                        f"{math.degrees(steering_error):.1f}deg)",
                        observation,
                    )

                return self._decision(
                    action=action,
                    observation=observation,
                    status=(
                        f"Recovery {self._recovery_count}/"
                        f"{p.maximum_recoveries}: {phase} "
                        f"{reverse_distance:.2f}/"
                        f"{p.recovery_distance:.2f}m, "
                        f"steer={math.degrees(steering_error):.1f}deg"
                    ),
                )

            # Legacy V5.1.1 mode: remain stopped until the steering joints are
            # centred. Kept for backward compatibility when unwind speed is 0.
            if self._recovery_motion_start_time is None:
                steering_error = self._recovery_steering_error(observation)
                steering_centered = (
                    steering_error <= p.recovery_steering_tolerance
                )

                if steering_centered:
                    if self._recovery_centered_since is None:
                        self._recovery_centered_since = now
                    centered_duration = now - self._recovery_centered_since
                    if centered_duration >= p.recovery_center_hold_seconds:
                        self._start_recovery_motion(observation)
                        return self._decision(
                            action=self._recovery_reverse_action(),
                            observation=observation,
                            status=(
                                f"Recovery {self._recovery_count}/"
                                f"{p.maximum_recoveries}: steering centred; "
                                "starting reverse"
                            ),
                        )
                else:
                    self._recovery_centered_since = None

                if (
                    not steering_centered
                    and p.recovery_center_timeout > 0.0
                    and elapsed > p.recovery_center_timeout
                ):
                    return self._fail(
                        "recovery steering failed to centre "
                        f"within {p.recovery_center_timeout:.1f}s "
                        f"(error={math.degrees(steering_error):.1f}deg)",
                        observation,
                    )

                return self._decision(
                    action=ForkliftAction.stopped(
                        lift_target=p.insertion_lift_target
                    ),
                    observation=observation,
                    status=(
                        f"Recovery {self._recovery_count}/"
                        f"{p.maximum_recoveries}: centering steering "
                        f"({math.degrees(steering_error):.1f} deg)"
                    ),
                )

            if self._recovery_start_xy is None:
                self._start_recovery_motion(observation)

            pose = observation.vehicle_pose_world
            reverse_distance = math.hypot(
                pose.x - self._recovery_start_xy[0],
                pose.y - self._recovery_start_xy[1],
            )
            reset_ready = (
                p.recovery_reset_distance > 0.0
                and reverse_distance
                >= p.recovery_reset_minimum_distance
                and float(observation.pallet_pose_in_base.x)
                >= p.recovery_reset_distance
            )
            distance_ready = reverse_distance >= p.recovery_distance
            if reset_ready or distance_ready:
                self._transition(PickupState.APPROACH, observation)
                return self._decision(
                    action=ForkliftAction.stopped(
                        lift_target=p.insertion_lift_target
                    ),
                    observation=observation,
                    status=(
                        "Recovery runway rebuilt; replanning corridor approach"
                        if reset_ready
                        else (
                            "Maximum recovery distance reached; "
                            "replanning corridor approach"
                        )
                    ),
                )

            motion_elapsed = now - self._recovery_motion_start_time
            if motion_elapsed > p.recovery_timeout:
                return self._fail(
                    "recovery reverse moved only "
                    f"{reverse_distance:.2f}/{p.recovery_distance:.2f}m "
                    f"in {p.recovery_timeout:.1f}s",
                    observation,
                )

            return self._decision(
                action=self._recovery_reverse_action(),
                observation=observation,
                status=(
                    f"Recovery {self._recovery_count}/{p.maximum_recoveries}: "
                    f"straight reverse {reverse_distance:.2f}/"
                    f"{p.recovery_distance:.2f}m "
                    f"({motion_elapsed:.1f}/{p.recovery_timeout:.1f}s)"
                ),
            )

        if self.state == PickupState.LIFT:
            action = ForkliftAction.stopped(
                lift_target=p.transport_lift_target
            )
            lifted = (
                observation.load_state.startswith("LIFTED")
                and observation.lift_position >= p.lifted_minimum_fork_height
            )
            if lifted:
                self._transition(PickupState.VERIFY_LIFT, observation)
            else:
                timeout_failure = self._timeout_failure(observation, elapsed)
                if timeout_failure is not None:
                    return timeout_failure
            return self._decision(
                action=action,
                observation=observation,
                status="Lifting pallet to transport height",
            )

        if self.state == PickupState.VERIFY_LIFT:
            action = ForkliftAction.stopped(
                lift_target=p.transport_lift_target
            )
            if not observation.load_state.startswith("LIFTED"):
                return self._fail("load was not retained after lifting", observation)
            self._sample_carried_load_pose(observation)
            if elapsed >= p.verify_lift_seconds:
                self._finalize_carried_load_pose(observation)
                load_visual_ready = (
                    p.placement_carried_visual_require_lock_for_release <= 0.5
                    or (
                        self._carried_load_visual_authority_locked
                        and self.placement_carried_observer_active
                    )
                )
                if load_visual_ready:
                    self._transition(PickupState.RETREAT, observation)
                else:
                    timeout_failure = self._timeout_failure(observation, elapsed)
                    if timeout_failure is not None:
                        return timeout_failure
                    return self._decision(
                        action=action,
                        observation=observation,
                        status=(
                            "V9.3.3-R1 waiting for carried-load visual handoff seed "
                            f"(samples={len(self._carried_load_pose_samples)}, "
                            f"seed={'yes' if self._carried_load_visual_handoff_available(observation) else 'no'})"
                        ),
                    )
            else:
                timeout_failure = self._timeout_failure(observation, elapsed)
                if timeout_failure is not None:
                    return timeout_failure
            return self._decision(
                action=action,
                observation=observation,
                status="Verifying stable pallet support",
            )

        if self.state == PickupState.RETREAT:
            if not observation.load_state.startswith("LIFTED"):
                return self._fail("load was lost during retreat", observation)
            if self._retreat_start_xy is None:
                pose = observation.vehicle_pose_world
                self._retreat_start_xy = (pose.x, pose.y)
            pose = observation.vehicle_pose_world
            retreat_distance = math.hypot(
                pose.x - self._retreat_start_xy[0],
                pose.y - self._retreat_start_xy[1],
            )
            if retreat_distance >= p.retreat_distance:
                if self._placement_enabled():
                    next_state = (
                        PickupState.TRANSPORT_REPOSITION
                        if self._smooth_transport_enabled()
                        else PickupState.TRANSPORT_APPROACH
                    )
                else:
                    next_state = PickupState.DONE
                self._transition(next_state, observation)
                action = ForkliftAction.stopped(
                    lift_target=p.transport_lift_target
                )
            else:
                timeout_failure = self._timeout_failure(observation, elapsed)
                if timeout_failure is not None:
                    return timeout_failure
                action = ForkliftAction(
                    speed_target=p.retreat_speed,
                    steering_command=0.0,
                    lift_target=p.transport_lift_target,
                )
            return self._decision(
                action=action,
                observation=observation,
                status=(
                    f"Retreating with load ({retreat_distance:.2f}m)"
                    if retreat_distance < p.retreat_distance
                    else (
                        "Pickup clear; starting loaded transport"
                        if self._placement_enabled()
                        else "Pickup retreat completed"
                    )
                ),
            )

        if self.state == PickupState.TRANSPORT_REPOSITION:
            if not observation.load_state.startswith("LIFTED"):
                return self._fail(
                    "load was lost during transport reposition",
                    observation,
                )
            if self._transport_reposition_start_xy is None:
                pose = observation.vehicle_pose_world
                self._transport_reposition_start_xy = (pose.x, pose.y)

            pose = observation.vehicle_pose_world
            reverse_distance = math.hypot(
                pose.x - self._transport_reposition_start_xy[0],
                pose.y - self._transport_reposition_start_xy[1],
            )
            target_pose = self._placement_vehicle_target(
                observation,
                pre_distance=p.placement_pre_distance,
            )
            runway_ready = (
                reverse_distance
                >= p.transport_reposition_minimum_distance
                and target_pose.x >= p.transport_runway_distance
            )
            if runway_ready:
                self._transition(PickupState.TRANSPORT_APPROACH, observation)
                return self._decision(
                    action=ForkliftAction.stopped(
                        lift_target=p.transport_lift_target
                    ),
                    observation=observation,
                    status=(
                        "Loaded transport runway established; "
                        "building smooth lane-change path"
                    ),
                    error=DockingError(
                        longitudinal=float(target_pose.x),
                        lateral=float(target_pose.y),
                        distance=math.hypot(target_pose.x, target_pose.y),
                        heading=math.atan2(target_pose.y, target_pose.x),
                        yaw=wrap_angle(target_pose.yaw),
                    ),
                    placement_error=self._load_to_placement_error(observation),
                )

            if reverse_distance >= p.transport_reposition_maximum_distance:
                return self._fail(
                    "unable to establish loaded transport runway "
                    f"({target_pose.x:.2f}/{p.transport_runway_distance:.2f}m)",
                    observation,
                )

            timeout_failure = self._timeout_failure(observation, elapsed)
            if timeout_failure is not None:
                return timeout_failure

            steering_error = self._recovery_steering_error(observation)
            unwind = steering_error > max(
                p.recovery_steering_tolerance,
                0.10,
            )
            reverse_speed = (
                p.transport_reposition_unwind_speed
                if unwind
                else p.transport_reposition_speed
            )
            return self._decision(
                action=ForkliftAction(
                    speed_target=reverse_speed,
                    steering_command=0.0,
                    lift_target=p.transport_lift_target,
                ),
                observation=observation,
                status=(
                    "Moving reverse to release steering scrub and "
                    f"create transport runway "
                    f"({reverse_distance:.2f}m, target x={target_pose.x:.2f}m)"
                    if unwind
                    else (
                        "Creating loaded transport runway "
                        f"({reverse_distance:.2f}/"
                        f"{p.transport_reposition_maximum_distance:.2f}m, "
                        f"target x={target_pose.x:.2f}/"
                        f"{p.transport_runway_distance:.2f}m)"
                    )
                ),
                error=DockingError(
                    longitudinal=float(target_pose.x),
                    lateral=float(target_pose.y),
                    distance=math.hypot(target_pose.x, target_pose.y),
                    heading=math.atan2(target_pose.y, target_pose.x),
                    yaw=wrap_angle(target_pose.yaw),
                ),
                placement_error=self._load_to_placement_error(observation),
            )

        if self.state == PickupState.TRANSPORT_APPROACH:
            if not observation.load_state.startswith("LIFTED"):
                return self._fail("load was lost during transport", observation)

            if self._smooth_transport_enabled():
                if self._transport_path is None:
                    target_pose = self._placement_vehicle_target(
                        observation,
                        pre_distance=p.placement_pre_distance,
                    )
                    if target_pose.x <= 0.50:
                        # V9.3.7: after terminal reacquisition / corridor recovery,
                        # the dynamically carried-load-aware vehicle target can
                        # legitimately move behind the current base pose even
                        # though the pallet itself is already inside the terminal
                        # region.  Do not send that short/behind target back into
                        # the long-range smooth transport planner (which requires
                        # a forward chord).  Hand ownership to the rolling terminal
                        # corridor when the task geometry is already local.
                        placement_error = self._load_to_placement_error(observation)
                        local_terminal_limit = max(
                            1.25,
                            p.terminal_approach_corridor_rolling_timeout_handoff_distance
                            + 0.50,
                        )
                        if (
                            p.terminal_approach_corridor_enabled > 0.0
                            and p.terminal_approach_corridor_rolling_enabled > 0.5
                            and placement_error.distance <= local_terminal_limit
                        ):
                            self._transport_path = None
                            self._transport_goal_world = None
                            self._transport_path_progress_index = 0
                            self._transition(PickupState.PLACE_CORRIDOR, observation)
                            return self._decision(
                                action=ForkliftAction.stopped(
                                    lift_target=p.transport_lift_target
                                ),
                                observation=observation,
                                status=(
                                    "V9.3.7 near-target smooth transport target "
                                    "not forward; handing directly to rolling corridor"
                                ),
                                error=placement_error,
                                placement_error=placement_error,
                            )
                        return self._fail(
                            "smooth transport target is not forward of vehicle",
                            observation,
                        )
                    self._transport_goal_world = relative_pose_to_world(
                        observation.vehicle_pose_world,
                        target_pose,
                    )
                    self._transport_path = build_cubic_transport_path(
                        observation.vehicle_pose_world,
                        self._transport_goal_world,
                        handle_scale=p.transport_path_handle_scale,
                        sample_count=p.transport_path_samples,
                    )
                    self._transport_path_progress_index = 0

                assert self._transport_path is not None
                path_command = track_transport_path(
                    self._transport_path,
                    observation.vehicle_pose_world,
                    previous_index=self._transport_path_progress_index,
                    wheelbase=p.transport_path_wheelbase,
                    lookahead_distance=p.transport_path_lookahead,
                    maximum_speed=p.transport_max_speed,
                    minimum_speed=p.transport_path_minimum_speed,
                    steering_limit=p.transport_steering_limit,
                    lift_target=p.transport_lift_target,
                    capture_distance=p.transport_capture_distance,
                    goal_yaw_tolerance=p.transport_path_goal_yaw_tolerance,
                    speed_gain=p.transport_path_speed_gain,
                    steering_speed_floor=(
                        p.transport_path_steering_speed_floor
                    ),
                    steering_slowdown_gain=(
                        p.transport_path_steering_slowdown_gain
                    ),
                )
                self._transport_path_progress_index = (
                    path_command.progress_index
                )
                captured = (
                    path_command.goal_distance
                    <= p.transport_capture_distance
                    and abs(path_command.goal_yaw_error)
                    <= p.transport_path_goal_yaw_tolerance
                )
                if captured:
                    next_state = (
                        PickupState.PLACE_CORRIDOR
                        if p.terminal_approach_corridor_enabled > 0.0
                        else PickupState.PLACE_ALIGN
                    )
                    self._transition(next_state, observation)
                    return self._decision(
                        action=ForkliftAction.stopped(
                            lift_target=p.transport_lift_target
                        ),
                        observation=observation,
                        status=(
                            "Smooth transport path captured; "
                            + (
                                "starting terminal approach corridor"
                                if next_state == PickupState.PLACE_CORRIDOR
                                else "starting final placement alignment"
                            )
                        ),
                        error=path_command.error,
                        placement_error=self._load_to_placement_error(
                            observation
                        ),
                    )

                timeout_failure = self._timeout_failure(observation, elapsed)
                if timeout_failure is not None:
                    return timeout_failure
                return self._decision(
                    action=path_command.action,
                    observation=observation,
                    status=(
                        "Following smooth loaded lane-change path "
                        f"({100.0 * path_command.path_progress:.0f}%, "
                        f"{path_command.remaining_length:.2f}m remaining)"
                    ),
                    error=path_command.error,
                    placement_error=self._load_to_placement_error(observation),
                )

            target_pose = self._placement_vehicle_target(
                observation,
                pre_distance=p.placement_pre_distance,
            )
            command = self.controller.pose_command(
                target_pose,
                maximum_speed=p.transport_max_speed,
                lift_target=p.transport_lift_target,
                stop_distance=0.0,
                steering_limit=p.transport_steering_limit,
                minimum_speed_override=min(0.06, p.transport_max_speed),
            )
            if command.error.distance <= p.transport_capture_distance:
                next_state = (
                    PickupState.PLACE_CORRIDOR
                    if p.terminal_approach_corridor_enabled > 0.0
                    else PickupState.PLACE_ALIGN
                )
                self._transition(next_state, observation)
                return self._decision(
                    action=ForkliftAction.stopped(
                        lift_target=p.transport_lift_target
                    ),
                    observation=observation,
                    status=(
                        "Placement pre-approach captured; entering terminal approach corridor"
                        if next_state == PickupState.PLACE_CORRIDOR
                        else "Placement pre-approach captured; braking"
                    ),
                    error=command.error,
                    placement_error=self._load_to_placement_error(observation),
                )
            if command.error.longitudinal <= -0.20:
                return self._fail("loaded transport target was overshot", observation)
            timeout_failure = self._timeout_failure(observation, elapsed)
            if timeout_failure is not None:
                return timeout_failure
            return self._decision(
                action=command.action,
                observation=observation,
                status="Transporting pallet to placement pre-approach",
                error=command.error,
                placement_error=self._load_to_placement_error(observation),
            )

        if self.state == PickupState.PLACE_CORRIDOR:
            if not observation.load_state.startswith("LIFTED"):
                return self._fail("load was lost during terminal approach corridor", observation)

            if (
                p.terminal_approach_corridor_entry_distance
                <= p.terminal_approach_corridor_standoff_distance + 1e-6
                and p.terminal_approach_corridor_rolling_enabled <= 0.5
            ):
                return self._legacy_terminal_corridor_step(observation, elapsed)

            placement_error = self._load_to_placement_error(observation)

            # V9.3.2: rolling corridor.  There is intentionally no fixed
            # entry-point capture: an Ackermann vehicle needs forward path
            # length to reduce lateral/yaw error.  This stage therefore shapes
            # geometry while rolling and hands off early to the bidirectional
            # local precision controller instead of timing out at a docking
            # pose that cannot be corrected at standstill.
            if p.terminal_approach_corridor_rolling_enabled > 0.5:
                final_target = self._placement_vehicle_target(
                    observation,
                    pre_distance=p.terminal_approach_corridor_standoff_distance,
                )
                target_distance = math.hypot(
                    float(final_target.x), float(final_target.y)
                )
                target_yaw = wrap_angle(float(final_target.yaw))
                task_distance = float(placement_error.distance)
                task_lateral = float(placement_error.lateral)
                task_yaw = float(placement_error.yaw)

                ownership_enabled = p.placement_terminal_ownership_enabled > 0.5
                ownership_acquire_ok = (
                    self._terminal_ownership_acquire_ready(placement_error)
                    if ownership_enabled else True
                )
                ownership_force_ok = (
                    self._terminal_ownership_force_ready(placement_error)
                    if ownership_enabled else True
                )
                normal_handoff = (
                    task_distance
                    <= p.terminal_approach_corridor_rolling_handoff_distance
                    and ownership_acquire_ok
                )
                # If the standoff has effectively been reached with geometry
                # still outside the direct envelope, hand control to the
                # bidirectional controller only inside the wider force envelope.
                # Do not keep driving forward through the target simply because
                # the direct acquisition gate was missed.
                # V9.3.7: the wider force envelope is a fallback, not an
                # eager trigger. Keep rolling until the actual handoff distance
                # is reached; only then may the force envelope own the chassis.
                force_handoff = (
                    ownership_enabled
                    and task_distance
                    <= p.terminal_approach_corridor_rolling_handoff_distance
                    and ownership_force_ok
                )
                timeout_geometry_ok = (
                    (p.terminal_approach_corridor_timeout_handoff_lateral_limit <= 0.0
                     or abs(task_lateral) <= p.terminal_approach_corridor_timeout_handoff_lateral_limit)
                    and (p.terminal_approach_corridor_timeout_handoff_yaw_limit <= 0.0
                         or abs(task_yaw) <= p.terminal_approach_corridor_timeout_handoff_yaw_limit)
                )
                timeout_handoff = (
                    p.terminal_approach_corridor_rolling_handoff_seconds > 0.0
                    and elapsed >= p.terminal_approach_corridor_rolling_handoff_seconds
                    and task_distance
                    <= p.terminal_approach_corridor_rolling_timeout_handoff_distance
                    and timeout_geometry_ok
                    and (not ownership_enabled or ownership_force_ok)
                )
                if (
                    p.terminal_approach_corridor_rolling_handoff_seconds > 0.0
                    and elapsed >= p.terminal_approach_corridor_rolling_handoff_seconds
                    and task_distance <= p.terminal_approach_corridor_rolling_timeout_handoff_distance
                    and not timeout_geometry_ok
                ):
                    self._terminal_corridor_timeout_handoff_guard_reject_count += 1
                if normal_handoff or timeout_handoff or force_handoff:
                    self._terminal_corridor_handoff_count += 1
                    if timeout_handoff and not normal_handoff:
                        self._terminal_corridor_timeout_handoff_count += 1
                    self._terminal_corridor_last_handoff_distance = task_distance
                    self._terminal_corridor_last_handoff_lateral = task_lateral
                    self._terminal_corridor_last_handoff_yaw_deg = math.degrees(task_yaw)
                    next_state = (
                        PickupState.PLACE_PRECISION
                        if ownership_enabled
                        else PickupState.PLACE_ALIGN
                    )
                    if ownership_enabled:
                        if normal_handoff:
                            self._terminal_ownership_direct_mpc_count += 1
                        else:
                            self._terminal_ownership_forced_mpc_count += 1
                    self._transition(next_state, observation)
                    return self._decision(
                        action=ForkliftAction.stopped(
                            lift_target=p.transport_lift_target
                        ),
                        observation=observation,
                        status=(
                            "V9.3.7 rolling corridor ownership handoff "
                            f"(d={task_distance:.2f}m, lat={task_lateral:.3f}m, "
                            f"yaw={math.degrees(task_yaw):.1f}deg"
                            + (", timeout escape" if timeout_handoff and not normal_handoff else "")
                            + ")"
                        ),
                        error=DockingError(
                            longitudinal=float(final_target.x),
                            lateral=float(final_target.y),
                            distance=float(target_distance),
                            heading=math.atan2(final_target.y, final_target.x),
                            yaw=target_yaw,
                        ),
                        placement_error=placement_error,
                    )

                if (
                    p.terminal_approach_corridor_timeout > 0.0
                    and elapsed >= p.terminal_approach_corridor_timeout
                    and not timeout_handoff
                ):
                    # Do not fail the mission because a corridor timer expired.
                    # A far target means the coarse transport capture was not
                    # strong enough; return once to TRANSPORT_APPROACH. If that
                    # has already happened, force ownership to the bidirectional
                    # terminal controller rather than permitting a corridor loop.
                    if self._terminal_corridor_reacquire_count <= 0:
                        self._terminal_corridor_reacquire_count += 1
                        self._transition(PickupState.TRANSPORT_APPROACH, observation)
                        return self._decision(
                            action=ForkliftAction.stopped(
                                lift_target=p.transport_lift_target
                            ),
                            observation=observation,
                            status=(
                                "V9.3.2 rolling corridor far-timeout; "
                                "returning once to transport reacquire"
                            ),
                            placement_error=placement_error,
                        )
                    self._terminal_corridor_handoff_count += 1
                    self._terminal_corridor_timeout_handoff_count += 1
                    self._terminal_corridor_last_handoff_distance = task_distance
                    self._terminal_corridor_last_handoff_lateral = task_lateral
                    self._terminal_corridor_last_handoff_yaw_deg = math.degrees(task_yaw)
                    repeated_next_state = (
                        PickupState.PLACE_PRECISION
                        if ownership_enabled and ownership_force_ok
                        else PickupState.PLACE_ALIGN
                    )
                    if repeated_next_state == PickupState.PLACE_PRECISION:
                        self._terminal_ownership_forced_mpc_count += 1
                    self._transition(repeated_next_state, observation)
                    return self._decision(
                        action=ForkliftAction.stopped(
                            lift_target=p.transport_lift_target
                        ),
                        observation=observation,
                        status=(
                            "V9.3.2 rolling corridor repeated far-timeout; "
                            "forcing bidirectional terminal handoff"
                        ),
                        placement_error=placement_error,
                    )

                lateral_angle = math.atan2(
                    p.terminal_approach_corridor_rolling_lateral_gain
                    * task_lateral,
                    max(1e-6, p.terminal_approach_corridor_rolling_lookahead),
                )
                steering = (
                    lateral_angle
                    + p.terminal_approach_corridor_rolling_yaw_gain * task_yaw
                )
                steer_limit = min(
                    p.transport_steering_limit,
                    p.terminal_approach_corridor_rolling_steering_limit,
                )
                steering = max(-steer_limit, min(steer_limit, steering))

                remaining = max(0.0, float(final_target.x))
                speed = min(
                    p.terminal_approach_corridor_max_speed,
                    max(
                        p.terminal_approach_corridor_minimum_speed,
                        p.terminal_approach_corridor_rolling_speed_gain * remaining,
                    ),
                )
                lateral_ratio = min(
                    1.0,
                    abs(task_lateral)
                    / max(1e-6, p.terminal_approach_corridor_rolling_lateral_band),
                )
                yaw_ratio = min(
                    1.0,
                    abs(task_yaw)
                    / max(1e-6, p.terminal_approach_corridor_rolling_yaw_band),
                )
                geometry_scale = max(
                    p.terminal_approach_corridor_rolling_min_geometry_scale,
                    1.0 - 0.45 * lateral_ratio - 0.35 * yaw_ratio,
                )

                # Deep visual/decision binding is intentionally profile-gated.
                # In weak-guide mode, lack of a visual lock reduces approach
                # authority instead of letting a quantized 20 cm / 10 deg guide
                # drive the vehicle aggressively into the precision workspace.
                visual_scale = 1.0
                if (
                    p.terminal_visual_binding_enabled > 0.5
                    and task_distance <= p.terminal_visual_required_distance
                ):
                    if self._terminal_visual_authority != "VISUAL_LOCK":
                        visual_scale *= p.terminal_visual_unlocked_speed_scale
                        self._terminal_corridor_visual_coarse_frame_count += 1
                    if (
                        p.terminal_visual_stale_seconds > 0.0
                        and visual_stale_seconds > p.terminal_visual_stale_seconds
                    ):
                        visual_scale *= p.terminal_visual_stale_speed_scale
                        self._terminal_corridor_visual_stale_frame_count += 1

                self._terminal_corridor_rolling_frame_count += 1
                # PLACE_CORRIDOR timeout is no longer an immediate mission
                # failure in rolling mode.  If the normal rolling window is
                # exceeded before the configured timeout-handoff envelope is
                # reached, keep bounded low-speed ownership; the global state
                # timeout is deliberately bypassed here so an arbitrary timer
                # cannot kill an otherwise controllable terminal approach.
                return self._decision(
                    action=ForkliftAction(
                        speed_target=float(speed * geometry_scale * visual_scale),
                        steering_command=float(steering),
                        lift_target=p.transport_lift_target,
                    ),
                    observation=observation,
                    status=(
                        "V9.3.2 rolling task-space corridor "
                        f"(remain={remaining:.2f}m, task={task_distance:.2f}m, "
                        f"lat={task_lateral:.3f}m, yaw={math.degrees(task_yaw):.1f}deg, "
                        f"vision={self._terminal_visual_authority})"
                    ),
                    error=DockingError(
                        longitudinal=float(final_target.x),
                        lateral=float(final_target.y),
                        distance=float(target_distance),
                        heading=math.atan2(final_target.y, final_target.x),
                        yaw=target_yaw,
                    ),
                    placement_error=placement_error,
                )

            # V9.3.1: the terminal approach is deliberately split into two
            # geometric jobs. ENTRY uses available runway to capture a pose on
            # the placement axis. AXIS then advances to the final standoff with
            # task-space pallet feedback. This prevents the single Bezier path
            # from creating the 0.5 m lateral/yaw bulge seen in V9.3.0-H1.
            if self._terminal_corridor_phase == "ENTRY":
                corridor_target = self._placement_vehicle_target(
                    observation,
                    pre_distance=p.terminal_approach_corridor_entry_distance,
                )
                live_goal_world = relative_pose_to_world(
                    observation.vehicle_pose_world, corridor_target
                )
                needs_replan = self._transport_path is None
                if (
                    not needs_replan
                    and self._transport_goal_world is not None
                    and self._terminal_corridor_last_replan_time is not None
                    and float(observation.sim_time) - self._terminal_corridor_last_replan_time
                    >= p.terminal_approach_corridor_replan_min_seconds
                ):
                    goal_shift = math.hypot(
                        live_goal_world.x - self._transport_goal_world.x,
                        live_goal_world.y - self._transport_goal_world.y,
                    )
                    goal_yaw_shift = abs(wrap_angle(
                        live_goal_world.yaw - self._transport_goal_world.yaw
                    ))
                    needs_replan = (
                        goal_shift >= p.terminal_approach_corridor_replan_position_m
                        or goal_yaw_shift >= p.terminal_approach_corridor_replan_yaw_rad
                    )

                entry_geometry_ready = (
                    abs(float(placement_error.lateral))
                    <= p.terminal_approach_corridor_entry_lateral_tolerance
                    and abs(float(placement_error.yaw))
                    <= p.terminal_approach_corridor_entry_yaw_tolerance
                )
                corridor_chord = math.hypot(
                    float(corridor_target.x), float(corridor_target.y)
                )
                target_close = (
                    corridor_chord
                    <= p.terminal_approach_corridor_entry_capture_distance
                )
                if target_close and entry_geometry_ready:
                    if self._terminal_corridor_entry_since is None:
                        self._terminal_corridor_entry_since = float(observation.sim_time)
                    held = (
                        float(observation.sim_time) - self._terminal_corridor_entry_since
                        >= p.terminal_approach_corridor_entry_hold_seconds
                    )
                    if held:
                        self._transport_path = None
                        self._transport_goal_world = None
                        self._transport_path_progress_index = 0
                        self._terminal_corridor_phase = "AXIS"
                        self._terminal_corridor_entry_since = None
                        return self._decision(
                            action=ForkliftAction.stopped(lift_target=p.transport_lift_target),
                            observation=observation,
                            status=(
                                "V9.3.1 terminal corridor axis-entry captured; "
                                "starting straight task-space approach"
                            ),
                            error=DockingError(
                                longitudinal=float(corridor_target.x),
                                lateral=float(corridor_target.y),
                                distance=float(corridor_chord),
                                heading=math.atan2(corridor_target.y, corridor_target.x),
                                yaw=wrap_angle(corridor_target.yaw),
                            ),
                            placement_error=placement_error,
                        )
                else:
                    self._terminal_corridor_entry_since = None

                if target_close and not entry_geometry_ready:
                    # The path endpoint may be reached before the carried load
                    # is actually aligned with the placement axis. Keep
                    # refining the explicit entry pose instead of letting the
                    # path tracker declare geometric victory on distance only.
                    entry_command = self.controller.pose_command(
                        corridor_target,
                        maximum_speed=min(
                            p.terminal_approach_corridor_max_speed, 0.06
                        ),
                        lift_target=p.transport_lift_target,
                        stop_distance=0.0,
                        steering_limit=min(
                            p.transport_steering_limit,
                            p.terminal_approach_corridor_axis_steering_limit,
                        ),
                        minimum_speed_override=min(
                            p.terminal_approach_corridor_minimum_speed, 0.02
                        ),
                    )
                    timeout_failure = self._timeout_failure(observation, elapsed)
                    if timeout_failure is not None:
                        return timeout_failure
                    return self._decision(
                        action=entry_command.action,
                        observation=observation,
                        status=(
                            "V9.3.1 refining axis-entry geometry after path capture "
                            f"(lat={placement_error.lateral:.3f}m, "
                            f"yaw={math.degrees(placement_error.yaw):.1f}deg)"
                        ),
                        error=entry_command.error,
                        placement_error=placement_error,
                    )

                if needs_replan:
                    self._terminal_corridor_entry_replan_count += 1
                    self._transport_goal_world = live_goal_world
                    self._transport_path_progress_index = 0
                    self._terminal_corridor_last_replan_time = float(observation.sim_time)
                    if corridor_chord > 0.5:
                        self._transport_path = build_cubic_transport_path(
                            observation.vehicle_pose_world,
                            self._transport_goal_world,
                            handle_scale=p.terminal_approach_corridor_handle_scale,
                            sample_count=p.terminal_approach_corridor_samples,
                        )
                    else:
                        self._transport_path = None

                if self._transport_path is None:
                    # H1 short bridge retained, but now it terminates at the
                    # runway-rich ENTRY pose rather than the 0.22 m standoff.
                    bridge_command = self.controller.pose_command(
                        corridor_target,
                        maximum_speed=p.terminal_approach_corridor_max_speed,
                        lift_target=p.transport_lift_target,
                        stop_distance=0.0,
                        steering_limit=min(
                            p.transport_steering_limit,
                            p.terminal_approach_corridor_axis_steering_limit,
                        ),
                        minimum_speed_override=(
                            p.terminal_approach_corridor_minimum_speed
                        ),
                    )
                    timeout_failure = self._timeout_failure(observation, elapsed)
                    if timeout_failure is not None:
                        return timeout_failure
                    return self._decision(
                        action=bridge_command.action,
                        observation=observation,
                        status=(
                            "V9.3.1 refining short corridor axis-entry "
                            f"({corridor_chord:.2f}m)"
                        ),
                        error=bridge_command.error,
                        placement_error=placement_error,
                    )

                path_command = track_transport_path(
                    self._transport_path,
                    observation.vehicle_pose_world,
                    previous_index=self._transport_path_progress_index,
                    wheelbase=p.transport_path_wheelbase,
                    lookahead_distance=p.terminal_approach_corridor_lookahead,
                    maximum_speed=p.terminal_approach_corridor_max_speed,
                    minimum_speed=p.terminal_approach_corridor_minimum_speed,
                    steering_limit=min(
                        p.transport_steering_limit,
                        p.terminal_approach_corridor_axis_steering_limit,
                    ),
                    lift_target=p.transport_lift_target,
                    capture_distance=p.terminal_approach_corridor_entry_capture_distance,
                    goal_yaw_tolerance=p.terminal_approach_corridor_entry_yaw_tolerance,
                    speed_gain=p.transport_path_speed_gain,
                    steering_speed_floor=p.transport_path_steering_speed_floor,
                    steering_slowdown_gain=p.transport_path_steering_slowdown_gain,
                )
                self._transport_path_progress_index = path_command.progress_index
                timeout_failure = self._timeout_failure(observation, elapsed)
                if timeout_failure is not None:
                    return timeout_failure
                return self._decision(
                    action=path_command.action,
                    observation=observation,
                    status=(
                        "V9.3.1 capturing terminal axis-entry "
                        f"({100.0 * path_command.path_progress:.0f}%, "
                        f"lat={placement_error.lateral:.3f}m, "
                        f"yaw={math.degrees(placement_error.yaw):.1f}deg)"
                    ),
                    error=path_command.error,
                    placement_error=placement_error,
                )

            # AXIS phase. Do not construct another Bezier curve. The vehicle is
            # already aligned with the placement axis; use the carried pallet
            # residual directly to keep cross-track/yaw error from regrowing.
            final_target = self._placement_vehicle_target(
                observation,
                pre_distance=p.terminal_approach_corridor_standoff_distance,
            )
            final_distance = math.hypot(float(final_target.x), float(final_target.y))
            final_yaw = abs(wrap_angle(float(final_target.yaw)))
            final_geometry_ready = (
                abs(float(placement_error.lateral))
                <= p.terminal_approach_corridor_entry_lateral_tolerance
                and abs(float(placement_error.yaw))
                <= p.terminal_approach_corridor_yaw_tolerance
            )
            if (
                final_distance <= p.terminal_approach_corridor_capture_distance
                and final_yaw <= p.terminal_approach_corridor_yaw_tolerance
                and final_geometry_ready
            ) or float(final_target.x) <= 0.05:
                self._transition(PickupState.PLACE_ALIGN, observation)
                return self._decision(
                    action=ForkliftAction.stopped(lift_target=p.transport_lift_target),
                    observation=observation,
                    status="V9.3.1 axis corridor captured; handing off to MPC alignment",
                    error=DockingError(
                        longitudinal=float(final_target.x),
                        lateral=float(final_target.y),
                        distance=float(final_distance),
                        heading=math.atan2(final_target.y, final_target.x),
                        yaw=wrap_angle(final_target.yaw),
                    ),
                    placement_error=placement_error,
                )

            if (
                abs(float(placement_error.lateral))
                >= p.terminal_approach_corridor_axis_abort_lateral
                or abs(float(placement_error.yaw))
                >= p.terminal_approach_corridor_axis_abort_yaw
            ):
                self._terminal_corridor_axis_reset_count += 1
                if float(placement_error.distance) <= 0.45:
                    # Once the vehicle is already close, recovering the distant
                    # entry pose would require a large reverse excursion. Hand
                    # ownership to the physically validated bidirectional MPC /
                    # bounded-recenter chain instead.
                    self._transition(PickupState.PLACE_ALIGN, observation)
                    return self._decision(
                        action=ForkliftAction.stopped(lift_target=p.transport_lift_target),
                        observation=observation,
                        status=(
                            "V9.3.1 close-range corridor geometry degraded; "
                            "handing off to bidirectional precision controller"
                        ),
                        placement_error=placement_error,
                    )
                # A target jump while runway remains can be repaired by
                # reacquiring the explicit entry pose.
                self._terminal_corridor_phase = "ENTRY"
                self._transport_path = None
                self._transport_goal_world = None
                self._transport_path_progress_index = 0
                self._terminal_corridor_entry_since = None
                return self._decision(
                    action=ForkliftAction.stopped(lift_target=p.transport_lift_target),
                    observation=observation,
                    status="V9.3.1 axis corridor geometry degraded; reacquiring entry",
                    placement_error=placement_error,
                )

            lateral_angle = math.atan2(
                p.terminal_approach_corridor_axis_lateral_gain
                * float(placement_error.lateral),
                p.terminal_approach_corridor_axis_lookahead,
            )
            steering = (
                lateral_angle
                + p.terminal_approach_corridor_axis_yaw_gain
                * float(placement_error.yaw)
            )
            steering = max(
                -p.terminal_approach_corridor_axis_steering_limit,
                min(p.terminal_approach_corridor_axis_steering_limit, steering),
            )
            remaining = max(0.0, float(final_target.x))
            speed = min(
                p.terminal_approach_corridor_max_speed,
                max(
                    p.terminal_approach_corridor_minimum_speed,
                    p.terminal_approach_corridor_axis_speed_gain * remaining,
                ),
            )
            # Slow down when geometry is not yet tight; the point of this phase
            # is preserving the axis, not reaching standoff as fast as possible.
            geometry_scale = max(
                0.35,
                1.0
                - 0.55
                * min(
                    1.0,
                    abs(float(placement_error.lateral))
                    / max(1e-6, p.terminal_approach_corridor_axis_abort_lateral),
                )
                - 0.35
                * min(
                    1.0,
                    abs(float(placement_error.yaw))
                    / max(1e-6, p.terminal_approach_corridor_axis_abort_yaw),
                ),
            )
            self._terminal_corridor_axis_frame_count += 1
            timeout_failure = self._timeout_failure(observation, elapsed)
            if timeout_failure is not None:
                return timeout_failure
            return self._decision(
                action=ForkliftAction(
                    speed_target=float(speed * geometry_scale),
                    steering_command=float(steering),
                    lift_target=p.transport_lift_target,
                ),
                observation=observation,
                status=(
                    "V9.3.1 straight terminal axis approach "
                    f"(remain={remaining:.2f}m, lat={placement_error.lateral:.3f}m, "
                    f"yaw={math.degrees(placement_error.yaw):.1f}deg)"
                ),
                error=DockingError(
                    longitudinal=float(final_target.x),
                    lateral=float(final_target.y),
                    distance=float(final_distance),
                    heading=math.atan2(final_target.y, final_target.x),
                    yaw=wrap_angle(final_target.yaw),
                ),
                placement_error=placement_error,
            )

        if self.state == PickupState.PLACE_ALIGN:
            if not observation.load_state.startswith("LIFTED"):
                return self._fail("load was lost before placement", observation)

            target_pose = self._placement_vehicle_target(
                observation, pre_distance=0.0
            )
            max_speed = self._placement_reentry_max_speed()
            command = self.controller.pose_command(
                target_pose, maximum_speed=max_speed,
                lift_target=p.transport_lift_target, stop_distance=0.0,
                steering_limit=p.place_steering_limit,
                minimum_speed_override=min(
                    p.place_align_minimum_speed, max_speed
                ),
            )
            placement_error = self._load_to_placement_error(observation)
            now = float(observation.sim_time)

            # V9.3.5 terminal ownership: PLACE_ALIGN is a bounded conditioner,
            # not a terminal controller of last resort.  Directly enter the
            # bidirectional MPC as soon as its explicit acquisition envelope is
            # reached.  If ALIGN loses progress or exhausts its short ownership
            # window, either force MPC inside a wider safe envelope or return to
            # the rolling corridor/recovery rather than holding for tens of
            # seconds.
            ownership = self._terminal_ownership_controller()
            if ownership is not None:
                ownership_update = ownership.update(
                    now,
                    distance=float(placement_error.distance),
                    lateral=float(placement_error.lateral),
                    yaw=float(placement_error.yaw),
                    progress_score=self._terminal_ownership_progress_score(placement_error),
                )
                if ownership_update.action in (
                    TerminalOwnershipSupervisor.DIRECT_MPC,
                    TerminalOwnershipSupervisor.FORCE_MPC,
                ):
                    if ownership_update.action == TerminalOwnershipSupervisor.DIRECT_MPC:
                        self._terminal_ownership_direct_mpc_count += 1
                        ownership_status = "direct"
                    else:
                        self._terminal_ownership_forced_mpc_count += 1
                        self._terminal_ownership_align_timeout_count += 1
                        ownership_status = "forced after bounded ALIGN"
                    self._transition(PickupState.PLACE_PRECISION, observation)
                    return self._decision(
                        action=ForkliftAction.stopped(lift_target=p.transport_lift_target),
                        observation=observation,
                        status=(
                            "V9.3.5 terminal ownership -> MPC " + ownership_status
                            + f" (align={ownership_update.align_elapsed_seconds:.2f}s, "
                            + f"d={placement_error.distance:.2f}m, "
                            + f"lat={placement_error.lateral:.3f}m, "
                            + f"yaw={math.degrees(placement_error.yaw):.1f}deg)"
                        ),
                        error=command.error,
                        placement_error=placement_error,
                    )
                if ownership_update.action == TerminalOwnershipSupervisor.REACQUIRE:
                    self._terminal_ownership_align_timeout_count += 1
                    if (
                        self._terminal_ownership_reacquire_count
                        < p.placement_terminal_ownership_max_reacquire_count
                    ):
                        self._terminal_ownership_reacquire_count += 1
                        self._transition(PickupState.PLACE_CORRIDOR, observation)
                        return self._decision(
                            action=ForkliftAction.stopped(lift_target=p.transport_lift_target),
                            observation=observation,
                            status=(
                                "V9.3.5 PLACE_ALIGN ownership expired; "
                                "returning to rolling corridor for geometry reacquire"
                            ),
                            error=command.error,
                            placement_error=placement_error,
                        )
                    if self._placement_recovery_enabled():
                        return self._begin_placement_recovery(
                            reason=(
                                "V9.3.5 PLACE_ALIGN ownership expired outside MPC force envelope"
                            ),
                            observation=observation,
                            placement_error=placement_error,
                            command_error=command.error,
                        )

            precise_enter = (
                placement_error.distance <= p.placement_position_tolerance
                and abs(placement_error.yaw) <= p.placement_yaw_tolerance
            )
            operational_geometry = (
                self._placement_release_envelope_enabled()
                and placement_error.distance
                <= p.placement_release_position_tolerance
                and abs(placement_error.yaw)
                <= p.placement_release_yaw_tolerance
            )

            # Backward-compatibility path for an explicitly V9.2.2-style
            # configuration.  Current V9.2.3 formal profiles never enter this
            # branch because their precision entry basin is wider than the
            # legacy operational release envelope.
            legacy_narrow_precision_handoff = (
                self._competition_precision_enabled()
                and p.placement_precision_entry_position_tolerance
                < p.placement_release_position_tolerance
            )
            if legacy_narrow_precision_handoff and operational_geometry:
                precision_entry_legacy = self._placement_precision_entry_ready(
                    placement_error
                )
                if precision_entry_legacy:
                    if self._placement_precision_entry_since is None:
                        self._placement_precision_entry_since = now
                    handoff_elapsed = now - self._placement_precision_entry_since
                    if handoff_elapsed >= p.placement_precision_entry_hold_seconds:
                        self._transition(PickupState.PLACE_PRECISION, observation)
                        return self._decision(
                            action=ForkliftAction.stopped(
                                lift_target=p.transport_lift_target
                            ),
                            observation=observation,
                            status=(
                                "Stable controllable precision basin captured; "
                                "entering competition precision closure"
                            ),
                            error=command.error,
                            placement_error=placement_error,
                        )
                    return self._decision(
                        action=ForkliftAction.stopped(
                            lift_target=p.transport_lift_target
                        ),
                        observation=observation,
                        status=(
                            "Holding precision handoff basin "
                            f"({handoff_elapsed:.2f}/"
                            f"{p.placement_precision_entry_hold_seconds:.2f}s)"
                        ),
                        error=command.error,
                        placement_error=placement_error,
                    )

                self._placement_precision_entry_since = None
                capture_command = self.controller.pose_command(
                    target_pose,
                    maximum_speed=min(
                        max_speed, p.placement_precision_entry_max_speed
                    ),
                    lift_target=p.transport_lift_target,
                    stop_distance=0.0,
                    steering_limit=p.place_steering_limit,
                    minimum_speed_override=0.0,
                )
                return self._decision(
                    action=capture_command.action,
                    observation=observation,
                    status="Conditioning terminal geometry before precision handoff",
                    error=capture_command.error,
                    progress_score=self._placement_progress_score(placement_error),
                    placement_error=placement_error,
                )

            # V9.2.3: precision takeover starts from a deliberately *wider*
            # controllable capture basin.  The V9.2.2 smoke test showed that
            # forcing PLACE_ALIGN to achieve a 5 cm lateral / 0.085 rad handoff
            # with a forward-only pose controller caused full runway recovery
            # from an otherwise useful 0.16-0.22 m terminal capture.
            #
            # The handoff is therefore governed by a bounded local basin plus
            # chassis-speed dwell, not by the legacy release envelope.  Once
            # inside this basin, PLACE_PRECISION owns both forward and reverse
            # micro-motion and no large recovery is started merely to satisfy a
            # tighter lateral handoff gate.
            precision_entry = (
                self._competition_precision_enabled()
                and self._placement_precision_entry_ready(placement_error)
            )
            if precision_entry:
                entry_speed_ready = (
                    abs(self._vehicle_forward_speed(observation))
                    <= p.placement_precision_entry_max_speed
                )
                if not entry_speed_ready:
                    self._placement_precision_entry_since = None
                    return self._decision(
                        action=ForkliftAction.stopped(
                            lift_target=p.transport_lift_target
                        ),
                        observation=observation,
                        status=(
                            "Precision capture basin reached; braking chassis "
                            "before local bidirectional closure"
                        ),
                        error=command.error,
                        placement_error=placement_error,
                    )
                if self._placement_precision_entry_since is None:
                    self._placement_precision_entry_since = now
                handoff_elapsed = now - self._placement_precision_entry_since
                if handoff_elapsed >= p.placement_precision_entry_hold_seconds:
                    self._transition(PickupState.PLACE_PRECISION, observation)
                    return self._decision(
                        action=ForkliftAction.stopped(
                            lift_target=p.transport_lift_target
                        ),
                        observation=observation,
                        status=(
                            "Stable terminal capture; entering bidirectional "
                            "competition precision closure"
                        ),
                        error=command.error,
                        placement_error=placement_error,
                    )
                return self._decision(
                    action=ForkliftAction.stopped(
                        lift_target=p.transport_lift_target
                    ),
                    observation=observation,
                    status=(
                        "Holding terminal precision capture "
                        f"({handoff_elapsed:.2f}/"
                        f"{p.placement_precision_entry_hold_seconds:.2f}s)"
                    ),
                    error=command.error,
                    placement_error=placement_error,
                )
            self._placement_precision_entry_since = None

            if operational_geometry and self._placement_operational_enter_time is None:
                self._placement_operational_enter_time = now
                self._placement_precision_settle_best = placement_error.distance
                self._placement_precision_settle_last_improve_time = now

            settle_elapsed = (
                0.0 if self._placement_operational_enter_time is None
                else max(0.0, now - self._placement_operational_enter_time)
            )
            settle_enabled = (
                p.placement_precision_settle_seconds > 0.0
                and p.placement_precision_settle_max_speed > 0.0
            )
            settle_window = (
                operational_geometry
                and not precise_enter
                and settle_enabled
                and settle_elapsed < p.placement_precision_settle_seconds
            )
            settle_progressing = False
            if settle_window:
                settle_progressing = self._placement_settle_progressing(
                    observation, placement_error
                )
                if not settle_progressing:
                    self._placement_precision_settle_exit_count += 1
                    settle_window = False

            release_enter = (
                operational_geometry
                and elapsed >= p.placement_release_after_seconds
                and not settle_window
            )
            candidate_mode: str | None = (
                "precise" if precise_enter
                else ("operational" if release_enter else None)
            )

            if self._placement_condition_mode is not None:
                if self._placement_condition_mode == "precise":
                    pos_limit = (p.placement_position_tolerance
                                 + p.placement_release_position_hysteresis)
                    yaw_limit = (p.placement_yaw_tolerance
                                 + p.placement_release_yaw_hysteresis)
                else:
                    pos_limit = (p.placement_release_position_tolerance
                                 + p.placement_release_position_hysteresis)
                    yaw_limit = (p.placement_release_yaw_tolerance
                                 + p.placement_release_yaw_hysteresis)
                if (placement_error.distance <= pos_limit
                        and abs(placement_error.yaw) <= yaw_limit):
                    candidate_mode = self._placement_condition_mode

            if candidate_mode is not None:
                if self._placement_condition_mode != candidate_mode:
                    self._placement_condition_mode = candidate_mode
                    self._placement_condition_since = now
                elif self._placement_condition_since is None:
                    self._placement_condition_since = now
                hold_seconds = (
                    p.placement_hold_seconds
                    if candidate_mode == "precise"
                    else p.placement_release_hold_seconds
                )
                if now - self._placement_condition_since >= hold_seconds:
                    if not placement_vision_ready:
                        return self._decision(
                            action=ForkliftAction.stopped(
                                lift_target=p.transport_lift_target
                            ),
                            observation=observation,
                            status=(
                                "Placement envelope held; waiting for stable "
                                "recent RGB target consensus"
                            ),
                            error=command.error,
                            placement_error=placement_error,
                        )
                    self._transition(PickupState.LOWER_LOAD, observation)
                    return self._decision(
                        action=ForkliftAction.stopped(
                            lift_target=p.placement_lower_target
                        ),
                        observation=observation,
                        status=(
                            "Precise placement pose held; lowering pallet"
                            if candidate_mode == "precise"
                            else "Stable operational placement envelope held; "
                                 "lowering pallet"
                        ),
                        error=command.error, placement_error=placement_error,
                    )
                action = ForkliftAction.stopped(
                    lift_target=p.transport_lift_target
                )
            else:
                self._placement_condition_since = None
                self._placement_condition_mode = None

                # V9.2.0: a strictly bounded settle is allowed only while the
                # pallet already lies inside the operational envelope.  It cannot
                # trigger recovery and cannot run beyond the fixed budget.
                if settle_window and settle_progressing:
                    self._placement_precision_settle_frame_count += 1
                    settle_speed = min(
                        max_speed, p.placement_precision_settle_max_speed
                    )
                    settle_command = self.controller.pose_command(
                        target_pose, maximum_speed=settle_speed,
                        lift_target=p.transport_lift_target, stop_distance=0.0,
                        steering_limit=p.place_steering_limit,
                        minimum_speed_override=0.0,
                    )
                    # Never push through a predicted stopping boundary during the
                    # settle.  Stop and wait for operational fallback instead.
                    stopping_distance = (
                        self._placement_guard_stopping_distance(observation)
                        if self._placement_predictive_guard_enabled()
                        else 0.0
                    )
                    if (
                        settle_command.error.longitudinal <= 0.0
                        or (stopping_distance > 0.0
                            and settle_command.error.longitudinal
                            <= stopping_distance)
                    ):
                        self._placement_precision_settle_exit_count += 1
                        action = ForkliftAction.stopped(
                            lift_target=p.transport_lift_target
                        )
                    else:
                        action = settle_command.action
                elif operational_geometry:
                    # Key rollback from V9.1.1: after the bounded settle, hold.
                    # Do not enter prolonged precision creep or terminal recovery.
                    action = ForkliftAction.stopped(
                        lift_target=p.transport_lift_target
                    )
                else:
                    # Predictive guard is brake-only.  One brake per PLACE_ALIGN
                    # attempt; actual overshoot/stall still controls recovery.
                    if self._placement_guard_hold_since is not None:
                        if (now - self._placement_guard_hold_since
                                < p.placement_guard_brake_hold_seconds):
                            return self._decision(
                                action=ForkliftAction.stopped(
                                    lift_target=p.transport_lift_target
                                ),
                                observation=observation,
                                status="Predictive terminal brake hold",
                                error=command.error,
                                placement_error=placement_error,
                            )
                        self._placement_guard_hold_since = None
                    if self._placement_predictive_guard_triggered(
                        command.error, observation
                    ):
                        self._placement_guard_brake_used = True
                        self._placement_guard_brake_count += 1
                        self._placement_guard_hold_since = now
                        return self._decision(
                            action=ForkliftAction.stopped(
                                lift_target=p.transport_lift_target
                            ),
                            observation=observation,
                            status=(
                                "Predictive terminal guard braking without "
                                "reverse recovery"
                            ),
                            error=command.error,
                            placement_error=placement_error,
                        )
                    action = command.action

            # Recovery is deliberately disabled while already inside the safe
            # operational envelope.  This is the main anti-loop invariant from
            # the V9.1.1 failure data.
            if (
                candidate_mode is None
                and not operational_geometry
                and self._placement_recovery_enabled()
            ):
                overshot = (
                    command.error.longitudinal
                    <= -p.placement_overshoot_longitudinal_tolerance
                )
                stalled = self._placement_progress_stalled(
                    observation, placement_error
                )
                if overshot or stalled:
                    return self._begin_placement_recovery(
                        reason=(
                            "placement target moved behind the forward-only controller"
                            if overshot
                            else "terminal placement made no progress"
                        ),
                        observation=observation,
                        placement_error=placement_error,
                        command_error=command.error,
                    )

            if (not self._placement_recovery_enabled()
                    and command.error.longitudinal <= -0.12
                    and candidate_mode is None):
                return self._fail(
                    "placement alignment pose was overshot", observation
                )

            timeout_failure = self._timeout_failure(observation, elapsed)
            if timeout_failure is not None:
                return timeout_failure

            if candidate_mode is not None:
                status = (
                    "Holding precise placement pose before lowering"
                    if candidate_mode == "precise"
                    else "Holding stable operational placement envelope"
                )
            elif settle_window and settle_progressing:
                status = (
                    "Bounded precision settle inside operational envelope "
                    f"({settle_elapsed:.2f}/{p.placement_precision_settle_seconds:.2f}s)"
                )
            elif operational_geometry:
                status = "Stable operational capture; waiting for release gate"
            else:
                status = "Fine-aligning carried pallet with placement target"

            return self._decision(
                action=action, observation=observation,
                status=status,
                error=command.error,
                progress_score=self._placement_progress_score(placement_error),
                placement_error=placement_error,
            )

        if self.state == PickupState.PLACE_PRECISION:
            if self._v925_mpc_enabled():
                return self._step_place_precision_v925(
                    observation,
                    placement_vision_ready=placement_vision_ready,
                )
            if self._v924_precision_enabled():
                return self._step_place_precision_v924(
                    observation,
                    placement_vision_ready=placement_vision_ready,
                )
            if not observation.load_state.startswith("LIFTED"):
                return self._fail(
                    "load was lost during competition precision alignment",
                    observation,
                )

            target_pose = self._placement_vehicle_target(
                observation, pre_distance=0.0
            )
            command = self.controller.pose_command(
                target_pose,
                maximum_speed=p.placement_precision_forward_max_speed,
                lift_target=p.transport_lift_target,
                stop_distance=0.0,
                steering_limit=p.place_steering_limit,
                minimum_speed_override=0.0,
            )
            placement_error = self._load_to_placement_error(observation)
            now = float(observation.sim_time)
            forward_speed = self._vehicle_forward_speed(observation)

            # V9.2.3 release gate: geometry alone is not enough.  The vehicle
            # must first settle to a low longitudinal speed so a transient
            # crossing of the 7-7.5 cm window cannot immediately start lowering.
            precision_geometry = (
                placement_error.distance <= p.placement_position_tolerance
                and abs(placement_error.yaw) <= p.placement_yaw_tolerance
            )
            release_speed_ready = (
                abs(forward_speed) <= p.placement_precision_release_max_speed
            )
            if precision_geometry:
                self._placement_precision_hold_frame_count += 1
                if not release_speed_ready:
                    self._placement_condition_since = None
                    return self._decision(
                        action=ForkliftAction.stopped(
                            lift_target=p.transport_lift_target
                        ),
                        observation=observation,
                        status=(
                            "Competition precision geometry reached; "
                            "settling chassis velocity before release"
                        ),
                        error=command.error,
                        progress_score=self._placement_precision_progress_score(
                            placement_error
                        ),
                        placement_error=placement_error,
                    )
                if self._placement_condition_since is None:
                    self._placement_condition_since = now
                if (
                    now - self._placement_condition_since
                    >= p.placement_hold_seconds
                ):
                    if not placement_vision_ready:
                        return self._decision(
                            action=ForkliftAction.stopped(
                                lift_target=p.transport_lift_target
                            ),
                            observation=observation,
                            status=(
                                "Competition precision held; waiting for "
                                "stable recent RGB target consensus"
                            ),
                            error=command.error,
                            progress_score=(
                                self._placement_precision_progress_score(
                                    placement_error
                                )
                            ),
                            placement_error=placement_error,
                        )
                    self._transition(PickupState.LOWER_LOAD, observation)
                    return self._decision(
                        action=ForkliftAction.stopped(
                            lift_target=p.placement_lower_target
                        ),
                        observation=observation,
                        status=(
                            "Competition precision pose and velocity held; "
                            "lowering pallet"
                        ),
                        error=command.error,
                        progress_score=(
                            self._placement_precision_progress_score(
                                placement_error
                            )
                        ),
                        placement_error=placement_error,
                    )
                return self._decision(
                    action=ForkliftAction.stopped(
                        lift_target=p.transport_lift_target
                    ),
                    observation=observation,
                    status=(
                        "Holding competition precision pose "
                        f"({now - self._placement_condition_since:.2f}/"
                        f"{p.placement_hold_seconds:.2f}s)"
                    ),
                    error=command.error,
                    progress_score=self._placement_precision_progress_score(
                        placement_error
                    ),
                    placement_error=placement_error,
                )

            # Release dwell must be continuous; any excursion resets it.
            self._placement_condition_since = None

            # V9.2.3 trust region: keep local closure alive across the entire
            # capture basin.  V9.2.2 used the narrow handoff tolerances again
            # as an exit condition and consequently bounced back to PLACE_ALIGN
            # after sub-second excursions.
            exit_position_limit = (
                p.placement_precision_entry_position_tolerance
                + p.placement_precision_maximum_regression_m
            )
            exit_lateral_limit = (
                p.placement_precision_entry_lateral_tolerance
                + p.placement_precision_maximum_regression_m
            )
            exit_yaw_limit = (
                p.placement_precision_entry_yaw_tolerance
                + max(
                    p.placement_yaw_tolerance,
                    2.0 * p.placement_release_yaw_hysteresis,
                )
            )
            if (
                placement_error.distance > exit_position_limit
                or abs(placement_error.lateral) > exit_lateral_limit
                or abs(placement_error.yaw) > exit_yaw_limit
            ):
                self._placement_precision_reentry_count += 1
                self._transition(PickupState.PLACE_ALIGN, observation)
                return self._decision(
                    action=ForkliftAction.stopped(
                        lift_target=p.transport_lift_target
                    ),
                    observation=observation,
                    status=(
                        "Precision capture basin exited; rebuilding terminal "
                        "approach without forced recovery"
                    ),
                    error=command.error,
                    placement_error=placement_error,
                )

            stalled, _regressed, precision_score = (
                self._placement_precision_stalled_or_regressed(
                    observation, placement_error
                )
            )
            if stalled:
                # A local stall is not equivalent to a gross overshoot.  Stop
                # and let PLACE_ALIGN re-observe/re-enter; do not immediately
                # spend 0.45-1.55 m of runway recovery while the pallet is still
                # inside the terminal capture basin.
                self._placement_precision_reentry_count += 1
                self._transition(PickupState.PLACE_ALIGN, observation)
                return self._decision(
                    action=ForkliftAction.stopped(
                        lift_target=p.transport_lift_target
                    ),
                    observation=observation,
                    status=(
                        "Precision closure paused after local no-progress; "
                        "re-observing terminal capture"
                    ),
                    error=command.error,
                    progress_score=precision_score,
                    placement_error=placement_error,
                )

            # Vehicle throttle direction must follow the desired-vehicle pose
            # residual.  The pallet-to-placement longitudinal value is expressed
            # in the placement-target frame and is not a vehicle-forward sign.
            # The V9.2.2 smoke matrix proved this distinction: useful terminal
            # captures were sent into large reverse runway recovery.
            longitudinal = float(command.error.longitudinal)
            deadband = p.placement_precision_longitudinal_deadband
            if longitudinal > deadband:
                desired_action = self._placement_precision_forward_action(
                    command
                )
                desired_status = (
                    "Desired-vehicle competition precision forward closure"
                )
            elif longitudinal < -deadband:
                reverse_action = self._placement_precision_reverse_action(
                    observation, command.error
                )
                if reverse_action is None:
                    self._placement_precision_reentry_count += 1
                    self._transition(PickupState.PLACE_ALIGN, observation)
                    return self._decision(
                        action=ForkliftAction.stopped(
                            lift_target=p.transport_lift_target
                        ),
                        observation=observation,
                        status=(
                            "Desired reverse pose left local precision basin; "
                            "rebuilding terminal approach"
                        ),
                        error=command.error,
                        progress_score=precision_score,
                        placement_error=placement_error,
                    )
                desired_action = reverse_action
                desired_status = (
                    "Desired-vehicle competition precision reverse closure"
                )
            else:
                desired_action = self._placement_precision_geometry_action(
                    observation, command
                )
                desired_status = (
                    "Competition precision near-zero Ackermann shunt"
                )

            desired_speed = float(desired_action.speed_target)
            direction_epsilon = (
                p.placement_precision_direction_change_speed_epsilon
            )
            if (
                desired_speed > 0.0 and forward_speed < -direction_epsilon
            ) or (
                desired_speed < 0.0 and forward_speed > direction_epsilon
            ):
                action = ForkliftAction.stopped(
                    lift_target=p.transport_lift_target
                )
                self._placement_precision_hold_frame_count += 1
                status = "Competition precision direction-change brake hold"
            else:
                action = desired_action
                status = desired_status
                if desired_speed > 1e-6:
                    self._placement_precision_forward_frame_count += 1
                elif desired_speed < -1e-6:
                    self._placement_precision_reverse_frame_count += 1
                else:
                    self._placement_precision_hold_frame_count += 1

            timeout_failure = self._timeout_failure(observation, elapsed)
            if timeout_failure is not None:
                return timeout_failure
            return self._decision(
                action=action,
                observation=observation,
                status=status,
                error=command.error,
                progress_score=precision_score,
                placement_error=placement_error,
            )

        if self.state == PickupState.PLACE_RECOVER_REVERSE:
            if not observation.load_state.startswith("LIFTED"):
                return self._fail(
                    "load was lost during terminal reverse recovery", observation
                )
            if self._placement_recovery_start_xy is None:
                vehicle = observation.vehicle_pose_world
                self._placement_recovery_start_xy = (vehicle.x, vehicle.y)
            vehicle = observation.vehicle_pose_world
            travelled = math.hypot(
                vehicle.x - self._placement_recovery_start_xy[0],
                vehicle.y - self._placement_recovery_start_xy[1],
            )
            steering_error = max(
                abs(float(observation.steering_left)),
                abs(float(observation.steering_right)),
            )
            centred = steering_error <= p.placement_recovery_steering_tolerance
            reentry_ready, reentry_error = (
                self._placement_recovery_reentry_ready_now(observation)
            )
            self._placement_recovery_live_runway = float(reentry_error.longitudinal)
            self._placement_recovery_reentry_ready = bool(reentry_ready)
            distance_ready = (
                travelled >= self._placement_recovery_target_distance
            )
            if distance_ready and reentry_ready and centred:
                self._transition(PickupState.PLACE_ALIGN, observation)
                return self._decision(
                    action=ForkliftAction.stopped(
                        lift_target=p.transport_lift_target
                    ),
                    observation=observation,
                    status=(
                        "Steered terminal runway rebuilt; "
                        "restarting placement alignment"
                    ),
                    placement_error=self._load_to_placement_error(observation),
                )
            timeout_failure = self._timeout_failure(observation, elapsed)
            if timeout_failure is not None:
                return timeout_failure

            # V9.2.0: unlike the straight reverse used by V9.1.2, use the live
            # lateral/yaw error to shape the reverse path. Once both the
            # requested distance and re-entry geometry are satisfied, unwind
            # the wheels before returning to the forward-only PLACE_ALIGN.
            if distance_ready and reentry_ready:
                speed = (
                    p.placement_recovery_unwind_speed
                    if p.placement_recovery_unwind_speed < 0.0
                    else p.placement_recovery_speed
                )
                steering_command = 0.0
                phase = "centering"
            else:
                speed = (
                    p.placement_recovery_unwind_speed
                    if distance_ready and p.placement_recovery_unwind_speed < 0.0
                    else p.placement_recovery_speed
                )
                steering_command = self._placement_recovery_reverse_steering(
                    reentry_error
                )
                phase = "steered-reverse"

            return self._decision(
                action=ForkliftAction(
                    speed_target=speed,
                    steering_command=steering_command,
                    lift_target=p.transport_lift_target,
                ),
                observation=observation,
                status=(
                    f"Rebuilding terminal runway [{phase}] "
                    f"({travelled:.2f}/{self._placement_recovery_target_distance:.2f}m, "
                    f"live={reentry_error.longitudinal:.2f}/"
                    f"{p.placement_recovery_runway_distance:.2f}m, "
                    f"steer={steering_command:.3f})"
                ),
                placement_error=self._load_to_placement_error(observation),
            )

        if self.state == PickupState.LOWER_LOAD:
            action = ForkliftAction.stopped(
                lift_target=p.placement_lower_target
            )
            placement_error = (
                self._release_snapshot_error
                if p.placement_release_snapshot_enabled > 0.5
                and self._release_snapshot_error is not None
                else self._load_to_placement_error(observation)
            )
            if self._placement_lower_start_world_xy is not None:
                pallet = observation.pallet_pose_world
                lower_motion = math.hypot(
                    pallet.x - self._placement_lower_start_world_xy[0],
                    pallet.y - self._placement_lower_start_world_xy[1],
                )
                if lower_motion > p.placement_load_motion_tolerance:
                    return self._fail(
                        f"pallet moved {lower_motion:.2f}m while lowering", observation
                    )
            if p.placement_release_snapshot_enabled <= 0.5:
                post_position_limit, _ = self._placement_post_release_limits()
                if placement_error.distance > post_position_limit:
                    return self._fail(
                        "pallet drifted outside placement target while lowering",
                        observation,
                    )
            grounded = (
                not observation.load_state.startswith("LIFTED")
                and observation.lift_position
                <= p.placement_lower_target + p.lift_position_tolerance
                and abs(observation.lift_velocity) <= p.lift_velocity_tolerance
            )
            if grounded:
                self._transition(PickupState.RELEASE_VERIFY, observation)
            else:
                timeout_failure = self._timeout_failure(observation, elapsed)
                if timeout_failure is not None:
                    return timeout_failure
            return self._decision(
                action=action,
                observation=observation,
                status="Lowering pallet onto placement zone",
                placement_error=placement_error,
            )

        if self.state == PickupState.RELEASE_VERIFY:
            action = ForkliftAction.stopped(
                lift_target=p.placement_lower_target
            )
            placement_error = (
                self._release_snapshot_error
                if p.placement_release_snapshot_enabled > 0.5
                and self._release_snapshot_error is not None
                else self._load_to_placement_error(observation)
            )
            if observation.load_state.startswith("LIFTED"):
                return self._fail("pallet remained lifted during release verification", observation)
            post_position_limit, post_yaw_limit = (
                self._placement_post_release_limits()
            )
            if p.placement_release_snapshot_enabled <= 0.5 and (
                placement_error.distance > post_position_limit
                or abs(placement_error.yaw) > post_yaw_limit
            ):
                return self._fail(
                    "pallet settled outside placement tolerance",
                    observation,
                )
            if elapsed >= p.release_verify_seconds:
                self._transition(PickupState.PLACE_RETREAT, observation)
            else:
                timeout_failure = self._timeout_failure(observation, elapsed)
                if timeout_failure is not None:
                    return timeout_failure
            return self._decision(
                action=action,
                observation=observation,
                status="Verifying pallet is supported by the floor",
                placement_error=placement_error,
            )

        if self.state == PickupState.PLACE_RETREAT:
            if observation.load_state.startswith("LIFTED"):
                return self._fail("pallet was lifted again during release retreat", observation)
            if self._placement_retreat_start_xy is None:
                vehicle = observation.vehicle_pose_world
                self._placement_retreat_start_xy = (vehicle.x, vehicle.y)
            if self._placed_pallet_world_pose is None:
                pallet = observation.pallet_pose_world
                self._placed_pallet_world_pose = (pallet.x, pallet.y, pallet.yaw)
            vehicle = observation.vehicle_pose_world
            pallet = observation.pallet_pose_world
            retreat_distance = math.hypot(
                vehicle.x - self._placement_retreat_start_xy[0],
                vehicle.y - self._placement_retreat_start_xy[1],
            )
            pallet_motion = math.hypot(
                pallet.x - self._placed_pallet_world_pose[0],
                pallet.y - self._placed_pallet_world_pose[1],
            )
            if pallet_motion > p.placement_load_motion_tolerance:
                return self._fail(
                    f"placed pallet moved {pallet_motion:.2f}m during fork withdrawal",
                    observation,
                )
            placement_error = (
                self._release_snapshot_error
                if p.placement_release_snapshot_enabled > 0.5
                and self._release_snapshot_error is not None
                else self._load_to_placement_error(observation)
            )
            released = (
                retreat_distance >= p.placement_retreat_distance
                and observation.fork_contact_count == 0
            )
            if released:
                post_position_limit, post_yaw_limit = (
                    self._placement_post_release_limits()
                )
                if p.placement_release_snapshot_enabled <= 0.5 and (
                    placement_error.distance > post_position_limit
                    or abs(placement_error.yaw) > post_yaw_limit
                ):
                    return self._fail(
                        "final pallet placement is outside tolerance",
                        observation,
                    )
                self._transition(PickupState.DONE, observation)
                action = ForkliftAction.stopped(
                    lift_target=p.placement_lower_target
                )
            else:
                timeout_failure = self._timeout_failure(observation, elapsed)
                if timeout_failure is not None:
                    return timeout_failure
                action = ForkliftAction(
                    speed_target=p.placement_retreat_speed,
                    steering_command=0.0,
                    lift_target=p.placement_lower_target,
                )
            return self._decision(
                action=action,
                observation=observation,
                status=(
                    "Placement completed; forks clear"
                    if released
                    else (
                        f"Withdrawing forks ({retreat_distance:.2f}/"
                        f"{p.placement_retreat_distance:.2f}m, "
                        f"pallet motion={pallet_motion:.2f}m)"
                    )
                ),
                placement_error=placement_error,
            )

        if self.state == PickupState.DONE:
            return self._decision(
                action=ForkliftAction.stopped(
                    lift_target=(
                        p.placement_lower_target
                        if self._placement_enabled()
                        else p.transport_lift_target
                    )
                ),
                observation=observation,
                status=(
                    "Autonomous pickup-transport-placement completed"
                    if self._placement_enabled()
                    else "Autonomous pickup completed"
                ),
                placement_error=(
                    self._load_to_placement_error(observation)
                    if self._placement_enabled()
                    else None
                ),
            )

        return PickupDecision(
            action=ForkliftAction.stopped(
                lift_target=observation.lift_position
            ),
            state=PickupState.FAILED,
            state_elapsed=elapsed,
            status="Autonomous pickup failed",
            failure_reason=self.failure_reason or "unknown failure",
            recovery_count=self._recovery_count,
            recovery_reason=self._recovery_reason,
            placement_recovery_count=self._placement_recovery_count,
            placement_recovery_reason=self._placement_recovery_reason,
        )
