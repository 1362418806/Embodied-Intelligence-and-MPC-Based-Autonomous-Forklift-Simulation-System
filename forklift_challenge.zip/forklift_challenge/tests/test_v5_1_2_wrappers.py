"""Smoke tests for v5.1.2 wrapper imports."""

from __future__ import annotations

import importlib.util
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def load_wrapper(filename: str):
    path = PROJECT_ROOT / "scripts" / filename
    spec = importlib.util.spec_from_file_location(f"_test_{path.stem}", path)
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_interactive_wrapper_resolves_local_base_script() -> None:
    module = load_wrapper("run_forklift_v5_1_1.py")
    assert module.PROJECT_ROOT == PROJECT_ROOT
    assert module.BASE_SCRIPT == PROJECT_ROOT / "scripts" / "run_forklift_v5_1.py"
    assert module.DEFAULT_CONFIG == PROJECT_ROOT / "configs" / "vehicle_v5_1_1.yaml"


def test_batch_wrapper_resolves_local_base_script() -> None:
    module = load_wrapper("run_v5_1_1_batch.py")
    assert module.PROJECT_ROOT == PROJECT_ROOT
    assert module.BASE_SCRIPT == PROJECT_ROOT / "scripts" / "run_v5_1_batch.py"
    assert module.DEFAULT_CONFIG == PROJECT_ROOT / "configs" / "vehicle_v5_1_1.yaml"
