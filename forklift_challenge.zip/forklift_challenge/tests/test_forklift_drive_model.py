"""Structural and controller checks for forklift_v1.xml."""

from __future__ import annotations

import math
from pathlib import Path

import mujoco
import numpy as np

from control.ackermann import (
    front_drive_angular_speeds,
    rear_ackermann_angles,
)


PROJECT_ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = PROJECT_ROOT / "assets" / "forklift" / "forklift_v1.xml"


def load_model() -> tuple[mujoco.MjModel, mujoco.MjData]:
    model = mujoco.MjModel.from_xml_path(str(MODEL_PATH))
    return model, mujoco.MjData(model)


def named_id(model: mujoco.MjModel, object_type: mujoco.mjtObj, name: str) -> int:
    object_id = mujoco.mj_name2id(model, object_type, name)
    assert object_id >= 0, f"Missing MuJoCo object: {name}"
    return object_id


def test_model_compiles_and_contains_drive_objects() -> None:
    model, _ = load_model()

    required_joints = (
        "forklift_free",
        "front_left_wheel_joint",
        "front_right_wheel_joint",
        "rear_left_steer_joint",
        "rear_right_steer_joint",
        "rear_left_wheel_joint",
        "rear_right_wheel_joint",
        "lift_joint",
    )
    required_actuators = (
        "front_left_drive_velocity",
        "front_right_drive_velocity",
        "rear_left_steer_position",
        "rear_right_steer_position",
        "lift_position",
    )

    for name in required_joints:
        named_id(model, mujoco.mjtObj.mjOBJ_JOINT, name)
    for name in required_actuators:
        named_id(model, mujoco.mjtObj.mjOBJ_ACTUATOR, name)


def test_rear_ackermann_geometry_has_correct_sign_and_inner_angle() -> None:
    left_turn = rear_ackermann_angles(0.30, wheelbase=0.93, rear_track=1.16)
    assert left_turn.left < 0.0
    assert left_turn.right < 0.0
    assert abs(left_turn.left) > abs(left_turn.right)

    right_turn = rear_ackermann_angles(-0.30, wheelbase=0.93, rear_track=1.16)
    assert right_turn.left > 0.0
    assert right_turn.right > 0.0
    assert abs(right_turn.right) > abs(right_turn.left)


def test_front_drive_differential_speeds_match_turn_direction() -> None:
    left, right = front_drive_angular_speeds(
        vehicle_speed=1.0,
        steering_command=0.25,
        wheelbase=0.93,
        front_track=1.16,
        wheel_radius=0.28,
    )
    assert left > 0.0
    assert right > left

    straight_left, straight_right = front_drive_angular_speeds(
        vehicle_speed=1.0,
        steering_command=0.0,
        wheelbase=0.93,
        front_track=1.16,
        wheel_radius=0.28,
    )
    assert math.isclose(straight_left, straight_right)


def test_steering_actuators_reach_ackermann_targets() -> None:
    model, data = load_model()

    # Isolate steering-joint tracking from gravity and tire scrub.
    model.opt.gravity[:] = 0.0
    model.geom_contype[:] = 0
    model.geom_conaffinity[:] = 0
    mujoco.mj_forward(model, data)

    left_joint = named_id(
        model, mujoco.mjtObj.mjOBJ_JOINT, "rear_left_steer_joint"
    )
    right_joint = named_id(
        model, mujoco.mjtObj.mjOBJ_JOINT, "rear_right_steer_joint"
    )
    left_act = named_id(
        model, mujoco.mjtObj.mjOBJ_ACTUATOR, "rear_left_steer_position"
    )
    right_act = named_id(
        model, mujoco.mjtObj.mjOBJ_ACTUATOR, "rear_right_steer_position"
    )

    target = rear_ackermann_angles(0.25, wheelbase=0.93, rear_track=1.16)
    data.ctrl[left_act] = target.left
    data.ctrl[right_act] = target.right

    for _ in range(1500):
        mujoco.mj_step(model, data)

    left_qpos = float(data.qpos[int(model.jnt_qposadr[left_joint])])
    right_qpos = float(data.qpos[int(model.jnt_qposadr[right_joint])])

    assert abs(left_qpos - target.left) < 0.03
    assert abs(right_qpos - target.right) < 0.03
    assert np.isfinite(data.qpos).all()
    assert np.isfinite(data.qvel).all()


def test_drive_actuators_spin_front_wheels_without_nan() -> None:
    model, data = load_model()

    # Isolate wheel velocity actuators from ground contact.
    model.opt.gravity[:] = 0.0
    model.geom_contype[:] = 0
    model.geom_conaffinity[:] = 0
    mujoco.mj_forward(model, data)

    left_joint = named_id(
        model, mujoco.mjtObj.mjOBJ_JOINT, "front_left_wheel_joint"
    )
    right_joint = named_id(
        model, mujoco.mjtObj.mjOBJ_JOINT, "front_right_wheel_joint"
    )
    left_act = named_id(
        model, mujoco.mjtObj.mjOBJ_ACTUATOR, "front_left_drive_velocity"
    )
    right_act = named_id(
        model, mujoco.mjtObj.mjOBJ_ACTUATOR, "front_right_drive_velocity"
    )

    data.ctrl[left_act] = 3.0
    data.ctrl[right_act] = 3.0
    for _ in range(1000):
        mujoco.mj_step(model, data)

    left_dof = int(model.jnt_dofadr[left_joint])
    right_dof = int(model.jnt_dofadr[right_joint])
    assert float(data.qvel[left_dof]) > 1.0
    assert float(data.qvel[right_dof]) > 1.0
    assert np.isfinite(data.qpos).all()
    assert np.isfinite(data.qvel).all()


def test_vehicle_remains_stationary_after_settling() -> None:
    """Zero drive commands should not cause continuing vehicle drift."""
    model, data = load_model()

    forklift_joint = named_id(
        model, mujoco.mjtObj.mjOBJ_JOINT, "forklift_free"
    )
    qpos_address = int(model.jnt_qposadr[forklift_joint])

    actuator_names = (
        "front_left_drive_velocity",
        "front_right_drive_velocity",
        "rear_left_steer_position",
        "rear_right_steer_position",
        "lift_position",
    )
    actuator_ids = {
        name: named_id(model, mujoco.mjtObj.mjOBJ_ACTUATOR, name)
        for name in actuator_names
    }

    for actuator_id in actuator_ids.values():
        data.ctrl[actuator_id] = 0.0

    settle_steps = int(1.0 / model.opt.timestep)
    for _ in range(settle_steps):
        mujoco.mj_step(model, data)

    initial_x = float(data.qpos[qpos_address])
    initial_y = float(data.qpos[qpos_address + 1])

    observation_steps = int(3.0 / model.opt.timestep)
    for _ in range(observation_steps):
        mujoco.mj_step(model, data)

    final_x = float(data.qpos[qpos_address])
    final_y = float(data.qpos[qpos_address + 1])
    displacement = math.hypot(final_x - initial_x, final_y - initial_y)

    assert displacement < 0.05
    assert np.isfinite(data.qpos).all()
    assert np.isfinite(data.qvel).all()
