"""Summarize V9.3.12-R4-D2 terminal-load image association evidence."""
from __future__ import annotations
import argparse, json, statistics
from pathlib import Path
from collections import Counter


def median(values):
    vals=[float(v) for v in values if v is not None]
    return None if not vals else statistics.median(vals)


def main() -> int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("association_jsonl", type=Path)
    args=ap.parse_args()
    rows=[json.loads(line) for line in args.association_jsonl.read_text(encoding="utf-8").splitlines() if line.strip()]
    requested=[r for r in rows if r.get("requested")]
    supports=[r for r in requested if r.get("support_ranks")]
    raw=[r for r in requested if r.get("raw_accepted")]
    status=Counter(str(r.get("final_status", r.get("status"))) for r in requested)
    print(f"records: {len(rows)} requested: {len(requested)}")
    print(f"support-group frames: {len(supports)} ({len(supports)/max(1,len(requested)):.1%})")
    print(f"raw accepted: {len(raw)} ({len(raw)/max(1,len(requested)):.1%})")
    print(f"status: {dict(status)}")
    print(f"support observed recall median: {median(r.get('support_observed_recall') for r in supports)}")
    print(f"support horizontal IoU median: {median(r.get('support_horizontal_iou') for r in supports)}")
    print(f"support top-edge error median px: {median(r.get('support_top_edge_error_px') for r in supports)}")
    print(f"fitted observed recall median: {median(r.get('fitted_observed_recall') for r in requested)}")
    print(f"fitted horizontal IoU median: {median(r.get('fitted_horizontal_iou') for r in requested)}")
    print(f"fitted center error median px: {median(r.get('fitted_center_error_px') for r in requested)}")
    z_deltas=[]
    for r in requested:
        a=r.get("observer_prior_pose_in_base")
        b=r.get("projection_prior_pose_in_base")
        if a and b:
            z_deltas.append(float(b["z"])-float(a["z"]))
    print(f"projection z correction median m: {median(z_deltas)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
