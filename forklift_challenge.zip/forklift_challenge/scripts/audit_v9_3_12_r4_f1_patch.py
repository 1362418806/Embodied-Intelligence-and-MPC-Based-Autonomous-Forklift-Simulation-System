"""Static/invariant audit for V9.3.12-R4-F1 yaw-anchor patch."""
from __future__ import annotations

import math
from pathlib import Path
import py_compile
import sys

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from control.carried_load_yaw_anchor import LateInsertYawAnchorConfig


def check(name: str, ok: bool) -> None:
    print(f"{'PASS' if ok else 'FAIL'} {name}")
    if not ok:
        raise AssertionError(name)


def main() -> int:
    for rel in (
        "control/carried_load_yaw_anchor.py",
        "task/pickup_state_machine.py",
        "evaluation/dual_vision_metrics.py",
        "simulator/dual_vision_mission_episode.py",
        "scripts/analyze_v9_3_12_r4_f1_yaw_attribution.py",
        "scripts/run_v9_3_12_r4_f1_batch.py",
        "scripts/evaluate_v9_3_12_r4_f1_precision_closure.py",
    ):
        py_compile.compile(str(ROOT / rel), doraise=True)
        check(f"compile:{rel}", True)

    cfg = yaml.safe_load((ROOT / "configs" / "vehicle_v9_3_12_r4_f1.yaml").read_text(encoding="utf-8"))
    base = cfg["autonomy"]
    weak = cfg["perception"]["terminal_autonomy_overrides"]["weak_guide"]

    check("anchor globally disabled", base["placement_carried_visual_yaw_anchor_enabled"] == 0.0)
    check("anchor weak-guide enabled", weak["placement_carried_visual_yaw_anchor_enabled"] == 1.0)
    LateInsertYawAnchorConfig(
        window_seconds=float(weak["placement_carried_visual_yaw_anchor_window_seconds"]),
        minimum_samples=int(weak["placement_carried_visual_yaw_anchor_min_samples"]),
        minimum_confidence=float(weak["placement_carried_visual_yaw_anchor_min_confidence"]),
        maximum_reprojection_error_px=float(weak["placement_carried_visual_yaw_anchor_max_reprojection_error_px"]),
        maximum_spread_rad=float(weak["placement_carried_visual_yaw_anchor_max_spread_rad"]),
    ).validate()
    check("anchor config validates", True)
    check("anchor confidence >= 0.80", float(weak["placement_carried_visual_yaw_anchor_min_confidence"]) >= 0.80)
    check("anchor reprojection <= 2px", float(weak["placement_carried_visual_yaw_anchor_max_reprojection_error_px"]) <= 2.0)
    check("anchor spread <= 0.5deg", float(weak["placement_carried_visual_yaw_anchor_max_spread_rad"]) <= math.radians(0.5) + 1e-12)

    # Frozen safety/release contract from E7.
    check("strict position remains 9.5cm", math.isclose(float(weak["placement_strict_release_position_limit_m"]), 0.095, abs_tol=1e-12))
    check("strict yaw remains 4.6deg", math.isclose(float(weak["placement_strict_release_yaw_limit_rad"]), math.radians(4.6), abs_tol=1e-12))
    check("yaw sigma gain unchanged", math.isclose(float(weak["placement_strict_release_yaw_sigma_gain"]), 0.22, abs_tol=1e-12))
    check("execution yaw reserve unchanged", math.isclose(float(weak["placement_strict_release_execution_yaw_reserve_rad"]), math.radians(0.4), abs_tol=1e-12))
    check("target yaw floor unchanged", math.isclose(float(weak["placement_strict_release_target_yaw_margin_floor_rad"]), math.radians(0.35), abs_tol=1e-12))
    check("consensus release authority remains off", float(weak["placement_certified_basin_consensus_release_authority"]) == 0.0)
    check("terminal budget remains 90s", math.isclose(float(weak["placement_terminal_budget_seconds"]), 90.0, abs_tol=1e-12))
    check("observer minimum yaw sigma not relaxed", math.isclose(float(weak["placement_carried_observer_minimum_yaw_sigma_rad"]), math.radians(1.0), abs_tol=1e-12))

    source = (ROOT / "task" / "pickup_state_machine.py").read_text(encoding="utf-8")
    check("anchor replaces yaw only", "yaw=float(anchor.world_yaw_rad)" in source and "x=float(cached_world_seed.x)" in source)
    check("latest world handoff retained", "latest_world_pose = self._v938_pose_base_to_world" in source)
    check("no truth dependency in anchor module", "ground_truth" not in (ROOT / "control" / "carried_load_yaw_anchor.py").read_text(encoding="utf-8"))
    print("V9.3.12-R4-F1 static audit: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
