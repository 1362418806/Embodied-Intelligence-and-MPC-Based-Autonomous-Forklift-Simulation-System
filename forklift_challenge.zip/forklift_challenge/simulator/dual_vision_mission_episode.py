"""Headless V8.2.1 terminal-consensus dual-RGB mission execution."""

from __future__ import annotations

import json
import math
from dataclasses import replace
from pathlib import Path
from typing import Any, Iterable

import cv2
import mujoco
import numpy as np

from control.ackermann import front_drive_angular_speeds, rear_ackermann_angles
from control.docking_controller import DockingController
from control.safety import LiftDriveInterlock
from evaluation.dual_vision_metrics import DualVisionMissionResult
from evaluation.precision_diagnostics import (
    PrecisionDiagnosticsRecorder,
    placement_error_components,
)
from evaluation.pickup_vision_quality import PickupVisionQualityAccumulator
from evaluation.terminal_validation import validate_terminal_mission
from perception.appearance_stress import AppearanceStressPipeline
from perception.pose_pipeline import PosePipeline, wrap_angle
from perception.terminal_fusion import apply_terminal_autonomy_overrides
from perception.terminal_load_reacquisition import TerminalLoadReacquisitionPipeline
from perception.vision_placement import VisionPlacementPipeline
from perception.vision_pickup import VisionPickupPipeline
from scenarios.randomization import Scenario, apply_scenario
from simulator.camera_renderer import MultiCameraRenderer
from simulator.observation_builder import ObservationBuilder
from simulator.render_health import RenderHealthTracker
from control.weak_guide import quantize_weak_guide_observation
from task.pickup_state_machine import PickupParameters, PickupState, PickupStateMachine


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _require_id(model: mujoco.MjModel, object_type: mujoco.mjtObj, name: str) -> int:
    object_id = mujoco.mj_name2id(model, object_type, name)
    if object_id < 0:
        raise RuntimeError(f"required MuJoCo object was not found: {name}")
    return int(object_id)


def _rpy(data: mujoco.MjData, qpos_address: int) -> tuple[float, float, float]:
    w, x, y, z = data.qpos[qpos_address + 3 : qpos_address + 7]
    sinr_cosp = 2.0 * (w * x + y * z)
    cosr_cosp = 1.0 - 2.0 * (x * x + y * y)
    roll = math.atan2(sinr_cosp, cosr_cosp)
    sinp = 2.0 * (w * y - z * x)
    pitch = math.copysign(math.pi / 2.0, sinp) if abs(sinp) >= 1.0 else math.asin(sinp)
    siny_cosp = 2.0 * (w * z + x * y)
    cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
    return roll, pitch, math.atan2(siny_cosp, cosy_cosp)


def _contacts(
    data: mujoco.MjData,
    first: Iterable[int],
    second: Iterable[int],
) -> int:
    a = set(first)
    b = set(second)
    count = 0
    for index in range(data.ncon):
        geom1 = int(data.contact[index].geom1)
        geom2 = int(data.contact[index].geom2)
        count += int(
            (geom1 in a and geom2 in b) or (geom2 in a and geom1 in b)
        )
    return count


def _controller(values: dict[str, Any]) -> DockingController:
    return DockingController(
        distance_gain=float(values["distance_gain"]),
        heading_gain=float(values["heading_gain"]),
        yaw_gain=float(values["yaw_gain"]),
        lateral_gain=float(values.get("lateral_gain", 0.0)),
        lookahead_distance=float(values.get("lookahead_distance", 0.75)),
        maximum_steering=float(values["maximum_steering"]),
        minimum_creep_speed=float(values["minimum_creep_speed"]),
        heading_slowdown_angle=float(values["heading_slowdown_angle"]),
        yaw_slowdown_angle=float(
            values.get("yaw_slowdown_angle", values["heading_slowdown_angle"])
        ),
        minimum_alignment_scale=float(values.get("minimum_alignment_scale", 0.2)),
    )


def _placement_error(observation) -> tuple[float, float]:
    dx = observation.placement_pose_in_base.x - observation.pallet_pose_in_base.x
    dy = observation.placement_pose_in_base.y - observation.pallet_pose_in_base.y
    yaw = wrap_angle(
        observation.placement_pose_in_base.yaw
        - observation.pallet_pose_in_base.yaw
    )
    return math.hypot(dx, dy), abs(math.degrees(yaw))


class _ErrorAccumulator:
    def __init__(self) -> None:
        self.frames = 0
        self.pallet_position_sq = 0.0
        self.pallet_yaw_sq = 0.0
        self.placement_position_sq = 0.0
        self.placement_yaw_sq = 0.0
        self.maximum_stale = 0.0

    def add(self, frame) -> None:
        self.frames += 1
        self.pallet_position_sq += frame.pallet.filtered_position_error_m**2
        self.pallet_yaw_sq += frame.pallet.filtered_yaw_error_deg**2
        self.placement_position_sq += frame.placement.filtered_position_error_m**2
        self.placement_yaw_sq += frame.placement.filtered_yaw_error_deg**2
        self.maximum_stale = max(
            self.maximum_stale,
            frame.pallet.stale_seconds,
            frame.placement.stale_seconds,
        )

    def rmse(self) -> tuple[float, float, float, float]:
        denominator = max(1, self.frames)
        return (
            math.sqrt(self.pallet_position_sq / denominator),
            math.sqrt(self.pallet_yaw_sq / denominator),
            math.sqrt(self.placement_position_sq / denominator),
            math.sqrt(self.placement_yaw_sq / denominator),
        )


class _VisionErrorAccumulator:
    def __init__(self) -> None:
        self.frames = 0
        self.position_sq = 0.0
        self.yaw_sq = 0.0
        self.confidences: list[float] = []
        self.reprojection_errors: list[float] = []

    def add(self, frame, truth) -> None:
        pose = frame.detection_pose_in_base
        if pose is None:
            return
        self.frames += 1
        dx = float(pose.x) - float(truth.placement_pose_in_base.x)
        dy = float(pose.y) - float(truth.placement_pose_in_base.y)
        yaw = wrap_angle(
            float(pose.yaw) - float(truth.placement_pose_in_base.yaw)
        )
        self.position_sq += dx * dx + dy * dy
        self.yaw_sq += math.degrees(yaw) ** 2
        detection = frame.detection
        if detection is not None:
            self.confidences.append(float(detection.confidence))
            if detection.reprojection_error_px is not None:
                self.reprojection_errors.append(
                    float(detection.reprojection_error_px)
                )

    def metrics(self) -> dict[str, float | None]:
        if self.frames <= 0:
            return {
                "position_rmse_m": None,
                "yaw_rmse_deg": None,
                "average_confidence": None,
                "maximum_reprojection_error_px": None,
            }
        return {
            "position_rmse_m": math.sqrt(self.position_sq / self.frames),
            "yaw_rmse_deg": math.sqrt(self.yaw_sq / self.frames),
            "average_confidence": (
                sum(self.confidences) / len(self.confidences)
                if self.confidences
                else None
            ),
            "maximum_reprojection_error_px": (
                max(self.reprojection_errors)
                if self.reprojection_errors
                else None
            ),
        }


def run_vision_mission_episode(
    config: dict[str, Any],
    scenario: Scenario,
    *,
    profile_name: str | None = None,
    appearance_profile_name: str | None = None,
    max_episode_seconds: float | None = None,
    trace_path: Path | None = None,
    terminal_oracle_geometry: bool = False,
    terminal_reacquisition_audit_path: Path | None = None,
    terminal_reacquisition_debug_dir: Path | None = None,
    terminal_reacquisition_debug_image_stride: int = 50,
    terminal_reacquisition_debug_max_images: int = 60,
) -> DualVisionMissionResult:
    model_path = (PROJECT_ROOT / config["model"]["xml_path"]).resolve()
    if not model_path.is_file():
        raise FileNotFoundError(f"MJCF model does not exist: {model_path}")

    model = mujoco.MjModel.from_xml_path(str(model_path))
    data = mujoco.MjData(model)
    mujoco.mj_resetData(model, data)
    apply_scenario(model, data, scenario)

    drive = config["drive"]
    lift = config["lift"]
    pickup = config["pickup"]
    safety = config["safety"]
    autonomy = config["autonomy"]
    batch = config.get("batch", {})
    perception_config = config["perception"]
    vision_config = config["vision"]
    pickup_vision_config = config["pickup_vision"]
    terminal_load_reacquisition_config = config.get("terminal_load_reacquisition")
    terminal_load_projection_config = (
        {}
        if terminal_load_reacquisition_config is None
        else dict(terminal_load_reacquisition_config.get("projection", {}))
    )
    terminal_load_projection_mode = str(
        terminal_load_projection_config.get("mode", "observer")
    )
    terminal_load_projection_z_offset_m = float(
        terminal_load_projection_config.get("pallet_body_z_from_lift_offset_m", 0.0)
    )
    camera_config = config["camera"]
    appearance_config = config.get("appearance_stress", {})
    selected_appearance_profile = str(
        appearance_profile_name
        if appearance_profile_name is not None
        else appearance_config.get("default_profile", "clean")
    )
    appearance = AppearanceStressPipeline.from_config(
        appearance_config,
        profile_name=selected_appearance_profile,
        seed=scenario.seed,
        image_width=int(camera_config["width"]),
        image_height=int(camera_config["height"]),
    )
    appearance.apply_camera_extrinsics(
        model,
        mujoco,
        (
            str(pickup_vision_config.get("camera_name", "fork_rgb")),
            str(vision_config.get("camera_name", "front_rgb")),
        ),
    )

    actuator_ids = {
        name: _require_id(model, mujoco.mjtObj.mjOBJ_ACTUATOR, name)
        for name in (
            "front_left_drive_velocity",
            "front_right_drive_velocity",
            "rear_left_steer_position",
            "rear_right_steer_position",
            "lift_position",
        )
    }
    joint_ids = {
        name: _require_id(model, mujoco.mjtObj.mjOBJ_JOINT, name)
        for name in ("forklift_free", "pallet_load_free", "lift_joint")
    }
    forklift_qpos = int(model.jnt_qposadr[joint_ids["forklift_free"]])
    pallet_qpos = int(model.jnt_qposadr[joint_ids["pallet_load_free"]])
    lift_dof = int(model.jnt_dofadr[joint_ids["lift_joint"]])
    fork_geoms = {
        _require_id(model, mujoco.mjtObj.mjOBJ_GEOM, name)
        for name in ("left_fork", "right_fork")
    }
    pallet_geoms = {
        _require_id(model, mujoco.mjtObj.mjOBJ_GEOM, name)
        for name in (
            "pallet_center_runner",
            "pallet_left_runner",
            "pallet_right_runner",
            "pallet_deck",
            "cargo_box",
        )
    }

    initial_lift = float(lift["initial_target"])
    data.ctrl[actuator_ids["lift_position"]] = initial_lift
    settle_steps = int(
        round(float(batch.get("settle_seconds", 0.5)) / model.opt.timestep)
    )
    for _ in range(settle_steps):
        mujoco.mj_step(model, data)

    ground_load_z = float(data.qpos[pallet_qpos + 2])
    builder = ObservationBuilder(model)
    selected_profile = str(
        profile_name
        if profile_name is not None
        else perception_config["default_profile"]
    )
    pipeline = PosePipeline.from_config(
        perception_config,
        profile_name=selected_profile,
        seed=scenario.seed,
    )
    pickup_vision = VisionPickupPipeline.from_config(
        pickup_vision_config,
        profile_name=selected_profile,
        image_width=int(camera_config["width"]),
        image_height=int(camera_config["height"]),
    )
    vision = VisionPlacementPipeline.from_config(
        vision_config,
        profile_name=selected_profile,
        image_width=int(camera_config["width"]),
        image_height=int(camera_config["height"]),
    )
    # V9.3.12-R4-D2: terminal load RGB plumbing remains active. D2 additionally
    # separates the carried-load observer prior from the projection-only height
    # used by the front-camera model; x/y/yaw still come from the observer.
    terminal_load_reacquisition = (
        None
        if terminal_load_reacquisition_config is None
        else TerminalLoadReacquisitionPipeline.from_config(
            terminal_load_reacquisition_config,
            profile_name=selected_profile,
            image_width=int(camera_config["width"]),
            image_height=int(camera_config["height"]),
        )
    )
    renderer = MultiCameraRenderer(
        model,
        width=int(camera_config["width"]),
        height=int(camera_config["height"]),
    )
    effective_autonomy = apply_terminal_autonomy_overrides(
        autonomy,
        perception_config,
        profile_name=selected_profile,
    )
    machine = PickupStateMachine(
        parameters=PickupParameters.from_mapping(effective_autonomy),
        docking_controller=_controller(config["controller"]),
    )
    machine.reset(float(data.time))
    interlock = LiftDriveInterlock(
        enabled=bool(safety["stop_drive_during_lift"]),
        velocity_threshold=float(safety["lift_velocity_threshold"]),
        settle_time=float(safety["lift_settle_time_seconds"]),
    )
    interlock.reset(lift_target=initial_lift, sim_time=float(data.time))

    def load_status() -> tuple[int, str, float]:
        load_z = float(data.qpos[pallet_qpos + 2])
        roll, pitch, _ = _rpy(data, pallet_qpos)
        tilt = max(abs(math.degrees(roll)), abs(math.degrees(pitch)))
        contacts = _contacts(data, fork_geoms, pallet_geoms)
        lifted = load_z - ground_load_z >= float(pickup["lifted_height_threshold"])
        state = "LIFTED" if lifted else ("ENGAGED" if contacts else "GROUND")
        return contacts, state, tilt

    start = float(data.time)
    time_limit = float(
        max_episode_seconds
        if max_episode_seconds is not None
        else batch.get("max_episode_seconds", 260.0)
    )
    trace_hz = float(batch.get("trace_hz", 10.0))
    next_trace = start
    trace_period = 1.0 / trace_hz
    stream = None
    if trace_path is not None:
        trace_path.parent.mkdir(parents=True, exist_ok=True)
        stream = trace_path.open("w", encoding="utf-8")

    # R4-D1 passive association audit. This stream intentionally contains no
    # ground-truth geometry and has no path back into the controller.
    reacq_audit_stream = None
    if terminal_reacquisition_audit_path is not None:
        terminal_reacquisition_audit_path.parent.mkdir(parents=True, exist_ok=True)
        reacq_audit_stream = terminal_reacquisition_audit_path.open("w", encoding="utf-8")
    reacq_debug_image_count = 0
    reacq_debug_stride = max(1, int(terminal_reacquisition_debug_image_stride))
    reacq_debug_limit = max(0, int(terminal_reacquisition_debug_max_images))
    if terminal_reacquisition_debug_dir is not None:
        terminal_reacquisition_debug_dir.mkdir(parents=True, exist_ok=True)

    current_state = machine.state.value
    state_enter = start
    state_durations: dict[str, float] = {}
    previous_xy = (
        float(data.qpos[forklift_qpos]),
        float(data.qpos[forklift_qpos + 1]),
    )
    path_length = 0.0
    max_steering = 0.0
    max_tilt = 0.0
    final_state = PickupState.FAILED.value
    failure_reason: str | None = None
    episode_timed_out = False
    release_start: tuple[float, float] | None = None
    release_motion = 0.0
    controller_certified_release: bool | None = None
    controller_certified_release_truth_pass: bool | None = None
    controller_certified_release_false_positive = False
    controller_truth_ready_uncertified = False
    controller_truth_ready_uncertified_since: float | None = None
    # V9.3.9 witness semantics: evaluate the state actually certified when
    # INTENT is latched, and separately evaluate the eventual execution.
    last_release_witness_capture_count = 0
    release_witness_time: float | None = None
    release_witness_truth_pass: bool | None = None
    release_witness_false_positive = False
    release_witness_estimated_position_error_m: float | None = None
    release_witness_estimated_yaw_error_deg: float | None = None
    release_execution_truth_pass: bool | None = None
    release_execution_false_positive = False
    release_witness_to_execute_seconds: float | None = None
    controller_release_estimated_position_error_m: float | None = None
    controller_release_estimated_yaw_error_deg: float | None = None
    controller_release_target_raw_position_spread_m: float | None = None
    controller_release_target_raw_yaw_spread_deg: float | None = None
    controller_release_target_position_margin_m: float | None = None
    controller_release_target_yaw_margin_deg: float | None = None
    controller_release_seed_provenance: str | None = None
    controller_release_seed_trusted_for_aggressive_risk: bool | None = None
    controller_release_seed_age_seconds: float | None = None
    controller_release_risk_budget_mode: str | None = None
    controller_release_yaw_risk_budget_mode: str | None = None
    controller_release_target_source: str | None = None
    release_center_yaw_anchor_seen = False
    release_center_yaw_anchor_active_frame_count = 0
    strict_release_center_yaw_rss_frame_count = 0
    accumulator = _ErrorAccumulator()
    vision_accumulator = _VisionErrorAccumulator()
    pickup_vision_quality = PickupVisionQualityAccumulator.from_mapping(
        config.get("pickup_vision_evaluation", {}),
        update_hz=pickup_vision.profile.update_hz,
    )
    render_health = RenderHealthTracker.from_mapping(
        config.get("render_health", {})
    )
    precision_diagnostics = PrecisionDiagnosticsRecorder.from_mapping(
        config.get("precision_diagnostics", {})
    )
    terminal_control_states = {
        PickupState.PLACE_CORRIDOR,
        PickupState.PLACE_ALIGN,
        PickupState.PLACE_PRECISION,
        PickupState.PLACE_RECOVER_REVERSE,
    }
    last_frame = None
    last_pickup_vision_frame = None
    last_vision_frame = None
    last_terminal_load_reacquisition_frame = None

    try:
        while float(data.time) - start <= time_limit:
            contacts, load_state, tilt = load_status()
            truth = builder.build(
                data,
                fork_contact_count=contacts,
                load_state=load_state,
            )
            frame = pipeline.step(truth)
            if selected_profile == "weak_guide":
                weak_cfg = perception_config.get("weak_guide_quantization", {})
                coarse_observation = quantize_weak_guide_observation(
                    frame.observation,
                    position_resolution_m=float(weak_cfg.get("position_resolution_m", 0.20)),
                    yaw_resolution_deg=float(weak_cfg.get("yaw_resolution_deg", 10.0)),
                )
                frame = replace(frame, observation=coarse_observation)
            pickup_visibility = (
                pickup_vision.detector.visibility_opportunity(
                    truth.pallet_pose_in_base,
                    minimum_marker_width_px=float(
                        config["pickup_vision_evaluation"][
                            "minimum_marker_width_px"
                        ]
                    ),
                    minimum_marker_height_px=float(
                        config["pickup_vision_evaluation"][
                            "minimum_marker_height_px"
                        ]
                    ),
                    image_margin_px=float(
                        config["pickup_vision_evaluation"][
                            "image_margin_px"
                        ]
                    ),
                    maximum_distance_m=float(
                        config["pickup_vision_evaluation"][
                            "maximum_opportunity_distance_m"
                        ]
                    ),
                )
            )
            pickup_rgb = None
            if pickup_vision.wants_image(
                sim_time=truth.sim_time,
                controller_state=machine.state.value,
                observation=frame.observation,
            ):
                pickup_rgb = render_health.render(
                    renderer,
                    data,
                    pickup_vision.camera_name,
                    channel="pickup",
                )
                pickup_rgb = appearance.apply(
                    pickup_rgb,
                    channel="pickup",
                ).image
            pickup_vision_frame = pickup_vision.step(
                frame=frame,
                rgb=pickup_rgb,
                controller_state=machine.state.value,
            )
            fused_frame = replace(frame, observation=pickup_vision_frame.observation)
            placement_wants_rgb = vision.wants_image(
                sim_time=truth.sim_time,
                controller_state=machine.state.value,
            )
            load_prior = machine.carried_load_pose_in_base
            # R4-D2 projection-height repair.
            #
            # D1 proved the propagated load's planar pose is already good, but
            # its z remains the pre-lift visual seed. ObservationBuilder exposes
            # lift_position as proprioception, so use the analytic rigid support
            # geometry only for the camera projection / terminal RGB measurement:
            #
            #   pallet_body_z = lift_position - 0.605 m
            #
            # This is model kinematics, not GT and not a learned bias/offset.
            load_projection_prior = load_prior
            if (
                load_prior is not None
                and terminal_load_projection_mode == "lift_kinematic"
            ):
                load_projection_prior = replace(
                    load_prior,
                    z=float(frame.observation.lift_position)
                    + terminal_load_projection_z_offset_m,
                )
            load_wants_rgb = bool(
                terminal_load_reacquisition is not None
                and terminal_load_reacquisition.wants_image(
                    sim_time=truth.sim_time,
                    controller_state=machine.state.value,
                    prior_pose_in_base=load_projection_prior,
                )
            )
            rgb = None
            if placement_wants_rgb or (
                load_wants_rgb
                and terminal_load_reacquisition is not None
                and terminal_load_reacquisition.camera_name == vision.camera_name
            ):
                rgb = render_health.render(
                    renderer, data, vision.camera_name, channel="placement"
                )
                rgb = appearance.apply(rgb, channel="placement").image
            vision_frame = vision.step(
                frame=fused_frame,
                rgb=rgb if placement_wants_rgb else None,
                controller_state=machine.state.value,
            )
            terminal_load_rgb = None
            if load_wants_rgb and terminal_load_reacquisition is not None:
                if terminal_load_reacquisition.camera_name == vision.camera_name:
                    terminal_load_rgb = rgb
                else:
                    terminal_load_rgb = render_health.render(
                        renderer, data, terminal_load_reacquisition.camera_name,
                        channel="placement",
                    )
                    terminal_load_rgb = appearance.apply(
                        terminal_load_rgb, channel="placement"
                    ).image
                terminal_load_reacquisition_frame = terminal_load_reacquisition.step(
                    rgb=terminal_load_rgb,
                    sim_time=truth.sim_time,
                    controller_state=machine.state.value,
                    prior_pose_in_base=load_projection_prior,
                )
            elif terminal_load_reacquisition is not None:
                terminal_load_reacquisition_frame = terminal_load_reacquisition.step(
                    rgb=None,
                    sim_time=truth.sim_time,
                    controller_state=machine.state.value,
                    prior_pose_in_base=load_projection_prior,
                )
            else:
                terminal_load_reacquisition_frame = None
            last_frame = frame
            last_pickup_vision_frame = pickup_vision_frame
            last_vision_frame = vision_frame
            last_terminal_load_reacquisition_frame = terminal_load_reacquisition_frame

            if (
                terminal_load_reacquisition is not None
                and terminal_load_reacquisition_frame is not None
                and terminal_load_reacquisition_frame.diagnostics.requested
            ):
                audit_record = terminal_load_reacquisition.association_audit_snapshot()
                audit_record.update({
                    "episode_id": str(scenario.scenario_id),
                    "sim_time": float(truth.sim_time),
                    "controller_state": str(machine.state.value),
                    "projection_mode": terminal_load_projection_mode,
                    "lift_position": float(frame.observation.lift_position),
                    "observer_prior_pose_in_base": (
                        None if load_prior is None else {
                            "x": float(load_prior.x), "y": float(load_prior.y),
                            "z": float(load_prior.z), "roll": float(load_prior.roll),
                            "pitch": float(load_prior.pitch), "yaw": float(load_prior.yaw),
                        }
                    ),
                    "projection_prior_pose_in_base": (
                        None if load_projection_prior is None else {
                            "x": float(load_projection_prior.x),
                            "y": float(load_projection_prior.y),
                            "z": float(load_projection_prior.z),
                            "roll": float(load_projection_prior.roll),
                            "pitch": float(load_projection_prior.pitch),
                            "yaw": float(load_projection_prior.yaw),
                        }
                    ),
                })
                if reacq_audit_stream is not None:
                    reacq_audit_stream.write(json.dumps(audit_record, ensure_ascii=False) + "\n")

                # Save sparse visual evidence across the terminal interval.
                # The first few frames are kept, then every Nth RGB sample.
                sample_index = int(terminal_load_reacquisition.sample_count)
                save_debug = bool(
                    terminal_reacquisition_debug_dir is not None
                    and terminal_load_rgb is not None
                    and reacq_debug_image_count < reacq_debug_limit
                    and (sample_index <= 5 or sample_index % reacq_debug_stride == 0
                         or terminal_load_reacquisition_frame.diagnostics.raw_accepted
                         or terminal_load_reacquisition_frame.diagnostics.consensus_ready)
                )
                if save_debug:
                    overlay = terminal_load_reacquisition.debug_overlay_bgr(terminal_load_rgb)
                    safe_status = str(terminal_load_reacquisition_frame.diagnostics.status).replace("/", "_")
                    image_path = terminal_reacquisition_debug_dir / (
                        f"sample_{sample_index:05d}_t_{truth.sim_time:08.3f}_{safe_status}.png"
                    )
                    cv2.imwrite(str(image_path), overlay)
                    reacq_debug_image_count += 1

            accumulator.add(frame)
            pickup_vision_quality.add(
                pickup_vision_frame,
                truth,
                visibility=pickup_visibility,
            )
            vision_accumulator.add(vision_frame, truth)
            perceived = vision_frame.observation
            estimated = perceived
            if terminal_oracle_geometry and machine.state in terminal_control_states:
                # Diagnostic-only oracle: isolate terminal controller/physics by
                # replacing only the relative pallet/placement geometry consumed
                # by PLACE_ALIGN/PLACE_PRECISION/PLACE_RECOVER_REVERSE.  This never affects normal
                # release qualification and is explicitly recorded in the result.
                estimated = replace(
                    perceived,
                    pallet_pose_in_base=truth.pallet_pose_in_base,
                    placement_pose_in_base=truth.placement_pose_in_base,
                )

            if machine.state in (
                PickupState.TRANSPORT_APPROACH,
                PickupState.PLACE_CORRIDOR,
                PickupState.PLACE_ALIGN,
                PickupState.PLACE_PRECISION,
            ):
                truth_approach_error = placement_error_components(truth)
                for stage_name, threshold in (
                    ("approach_1p5m", 1.5),
                    ("approach_1p0m", 1.0),
                    ("approach_0p5m", 0.5),
                    ("approach_0p2m", 0.2),
                ):
                    if truth_approach_error["position_error_m"] <= threshold:
                        precision_diagnostics.capture(
                            stage_name, sim_time=truth.sim_time, truth=truth, estimated=perceived
                        )

            if machine.state in (
                PickupState.PLACE_ALIGN, PickupState.PLACE_PRECISION
            ):
                perceived_error = placement_error_components(perceived)
                if (
                    perceived_error["position_error_m"]
                    <= float(effective_autonomy["placement_release_position_tolerance"])
                    and abs(perceived_error["yaw_error_deg"])
                    <= math.degrees(float(effective_autonomy["placement_release_yaw_tolerance"]))
                ):
                    precision_diagnostics.capture(
                        "operational_capture", sim_time=truth.sim_time,
                        truth=truth, estimated=perceived,
                    )
                if (
                    perceived_error["position_error_m"] < 0.10
                    and abs(perceived_error["yaw_error_deg"]) < 5.0
                ):
                    precision_diagnostics.capture(
                        "competition_capture", sim_time=truth.sim_time,
                        truth=truth, estimated=perceived,
                    )

            decision = machine.step(
                estimated,
                pickup_vision_ready=pickup_vision.ready_for_insert(),
                placement_vision_ready=vision.release_ready(),
                placement_vision_authority=getattr(
                    vision_frame.diagnostics, "visual_authority", None
                ),
                placement_vision_stale_seconds=getattr(
                    vision_frame.diagnostics, "stale_seconds", None
                ),
                placement_vision_raw_position_spread_m=getattr(
                    vision_frame.diagnostics, "raw_release_position_spread_m", None
                ),
                placement_vision_raw_yaw_spread_deg=getattr(
                    vision_frame.diagnostics, "raw_release_yaw_spread_deg", None
                ),
                placement_certification_target_pose_in_base=getattr(
                    vision_frame, "certification_target_pose_in_base", None
                ),
                placement_release_center_yaw_target_pose_in_base=getattr(
                    vision_frame, "release_center_yaw_target_pose_in_base", None
                ),
                placement_vision_multiview_ready=getattr(
                    vision_frame.diagnostics, "certification_multiview_ready", False
                ),
                placement_vision_multiview_samples=getattr(
                    vision_frame.diagnostics, "certification_multiview_samples", 0
                ),
                placement_vision_multiview_position_spread_m=getattr(
                    vision_frame.diagnostics, "certification_multiview_position_spread_m", None
                ),
                placement_vision_multiview_yaw_spread_deg=getattr(
                    vision_frame.diagnostics, "certification_multiview_yaw_spread_deg", None
                ),
                placement_vision_fast_slow_position_disagreement_m=getattr(
                    vision_frame.diagnostics, "certification_fast_slow_position_disagreement_m", None
                ),
                placement_vision_fast_slow_yaw_disagreement_deg=getattr(
                    vision_frame.diagnostics, "certification_fast_slow_yaw_disagreement_deg", None
                ),
                pickup_vision_authority=getattr(
                    pickup_vision_frame.diagnostics, "visual_authority", None
                ),
                pickup_vision_source=getattr(
                    pickup_vision_frame.diagnostics, "pose_source", None
                ),
                pickup_vision_stale_seconds=getattr(
                    pickup_vision_frame.diagnostics, "stale_seconds", None
                ),
                pickup_vision_last_accepted_confidence=getattr(
                    pickup_vision_frame.diagnostics, "last_accepted_confidence", None
                ),
                pickup_vision_last_accepted_reprojection_error_px=getattr(
                    pickup_vision_frame.diagnostics, "last_accepted_reprojection_error_px", None
                ),
                terminal_load_reacquisition_pose_in_base=(
                    None if terminal_load_reacquisition_frame is None
                    else terminal_load_reacquisition_frame.pose_in_base
                ),
                terminal_load_reacquisition_position_sigma_m=(
                    None if terminal_load_reacquisition is None
                    else terminal_load_reacquisition.profile.measurement_position_sigma_m
                ),
                terminal_load_reacquisition_yaw_sigma_deg=(
                    None if terminal_load_reacquisition is None
                    else math.degrees(terminal_load_reacquisition.profile.measurement_yaw_sigma_rad)
                ),
                terminal_load_reacquisition_position_gate_m=(
                    None if terminal_load_reacquisition is None
                    else terminal_load_reacquisition.profile.maximum_position_innovation_m
                ),
                terminal_load_reacquisition_yaw_gate_deg=(
                    None if terminal_load_reacquisition is None
                    else math.degrees(terminal_load_reacquisition.profile.maximum_yaw_innovation_rad)
                ),
            )
            max_tilt = max(max_tilt, tilt)
            # R4-F4 visibility: count release-only centre-yaw and guarded RSS
            # activity without exposing evaluator truth to runtime control.
            if bool(getattr(decision, "strict_release_center_yaw_anchor_active", False)):
                release_center_yaw_anchor_seen = True
                release_center_yaw_anchor_active_frame_count += 1
            if str(getattr(decision, "strict_release_yaw_risk_budget_mode", "ADDITIVE")) == "CENTER_YAW_RSS":
                strict_release_center_yaw_rss_frame_count += 1

            # V9.3.8 evaluation-side certification diagnostics. Truth is used
            # only here for diagnosis and is never passed back into control.
            truth_release_error = placement_error_components(truth)
            truth_strict_ready = bool(
                truth_release_error["position_error_m"] < 0.10
                and abs(truth_release_error["yaw_error_deg"]) < 5.0
            )
            if decision.release_witness_capture_count > last_release_witness_capture_count:
                last_release_witness_capture_count = int(decision.release_witness_capture_count)
                release_witness_time = float(truth.sim_time)
                release_witness_truth_pass = bool(truth_strict_ready)
                release_witness_false_positive = bool(not truth_strict_ready)
                release_witness_estimated_position_error_m = (
                    decision.strict_release_certification_position_error_m
                )
                release_witness_estimated_yaw_error_deg = (
                    decision.strict_release_certification_yaw_error_deg
                )

            if (
                current_state == PickupState.PLACE_PRECISION.value
                and truth_strict_ready
                and not bool(decision.strict_release_certified)
            ):
                if controller_truth_ready_uncertified_since is None:
                    controller_truth_ready_uncertified_since = float(truth.sim_time)
                elif (
                    float(truth.sim_time) - controller_truth_ready_uncertified_since
                    >= 0.35
                ):
                    controller_truth_ready_uncertified = True
            else:
                controller_truth_ready_uncertified_since = None

            if decision.state.value != current_state:
                state_durations[current_state] = state_durations.get(
                    current_state, 0.0
                ) + float(data.time) - state_enter
                current_state = decision.state.value
                state_enter = float(data.time)
                if current_state == PickupState.PLACE_ALIGN.value:
                    precision_diagnostics.capture(
                        "terminal_entry", sim_time=truth.sim_time,
                        truth=truth, estimated=perceived,
                    )
                elif current_state == PickupState.LOWER_LOAD.value:
                    precision_diagnostics.capture(
                        "release_command", sim_time=truth.sim_time,
                        truth=truth, estimated=perceived,
                    )
                    controller_certified_release = bool(decision.strict_release_certified)
                    controller_certified_release_truth_pass = truth_strict_ready
                    controller_certified_release_false_positive = bool(
                        controller_certified_release and not truth_strict_ready
                    )
                    release_execution_truth_pass = bool(truth_strict_ready)
                    release_execution_false_positive = bool(not truth_strict_ready)
                    if release_witness_time is not None:
                        release_witness_to_execute_seconds = max(
                            0.0, float(truth.sim_time) - release_witness_time
                        )
                    if decision.placement_error is not None:
                        controller_release_estimated_position_error_m = float(
                            decision.placement_error.distance
                        )
                        controller_release_estimated_yaw_error_deg = math.degrees(
                            abs(float(decision.placement_error.yaw))
                        )
                    controller_release_target_raw_position_spread_m = (
                        decision.placement_target_raw_position_spread_m
                    )
                    controller_release_target_raw_yaw_spread_deg = (
                        decision.placement_target_raw_yaw_spread_deg
                    )
                    controller_release_target_position_margin_m = (
                        decision.strict_release_target_position_margin_m
                    )
                    controller_release_target_yaw_margin_deg = (
                        decision.strict_release_target_yaw_margin_deg
                    )
                    controller_release_seed_provenance = decision.carried_load_seed_provenance
                    controller_release_seed_trusted_for_aggressive_risk = bool(
                        decision.carried_load_seed_trusted_for_aggressive_risk
                    )
                    controller_release_seed_age_seconds = decision.carried_load_seed_age_seconds
                    controller_release_risk_budget_mode = decision.strict_release_risk_budget_mode
                    controller_release_yaw_risk_budget_mode = decision.strict_release_yaw_risk_budget_mode
                    controller_release_target_source = decision.strict_release_certification_target_source
                elif current_state == PickupState.RELEASE_VERIFY.value:
                    precision_diagnostics.capture(
                        "grounded", sim_time=truth.sim_time,
                        truth=truth, estimated=perceived,
                    )
                elif current_state == PickupState.PLACE_RETREAT.value:
                    precision_diagnostics.capture(
                        "retreat_start", sim_time=truth.sim_time,
                        truth=truth, estimated=perceived,
                    )
                    release_start = (
                        truth.pallet_pose_world.x,
                        truth.pallet_pose_world.y,
                    )

            if release_start is not None:
                release_motion = max(
                    release_motion,
                    math.hypot(
                        truth.pallet_pose_world.x - release_start[0],
                        truth.pallet_pose_world.y - release_start[1],
                    ),
                )

            action = decision.action
            requested_speed = 0.0 if action.emergency_stop else action.speed_target
            resolved = interlock.resolve(
                requested_speed=requested_speed,
                lift_velocity=float(data.qvel[lift_dof]),
                lift_target=action.lift_target,
                sim_time=float(data.time),
            )
            steering = max(
                -float(drive["maximum_steering_command"]),
                min(
                    float(drive["maximum_steering_command"]),
                    action.steering_command,
                ),
            )
            angles = rear_ackermann_angles(
                steering,
                float(drive["wheelbase"]),
                float(drive["rear_track"]),
            )
            left_omega, right_omega = front_drive_angular_speeds(
                resolved.applied_speed,
                steering,
                float(drive["wheelbase"]),
                float(drive["front_track"]),
                float(drive["front_wheel_radius"]),
            )
            data.ctrl[actuator_ids["front_left_drive_velocity"]] = left_omega
            data.ctrl[actuator_ids["front_right_drive_velocity"]] = right_omega
            data.ctrl[actuator_ids["rear_left_steer_position"]] = angles.left
            data.ctrl[actuator_ids["rear_right_steer_position"]] = angles.right
            data.ctrl[actuator_ids["lift_position"]] = max(
                float(lift["minimum_height"]),
                min(float(lift["maximum_height"]), action.lift_target),
            )
            max_steering = max(max_steering, abs(math.degrees(steering)))

            if stream is not None and float(data.time) + 1e-12 >= next_trace:
                stream.write(
                    json.dumps(
                        {
                            "ground_truth_observation": truth.to_dict(),
                            "estimated_observation": estimated.to_dict(),
                            "perception": frame.to_dict(),
                            "pickup_vision": pickup_vision_frame.diagnostics.to_dict(),
                            "pickup_visibility": pickup_visibility.to_dict(),
                            "vision_marker": vision_frame.diagnostics.to_dict(),
                            "terminal_load_reacquisition": (
                                None if terminal_load_reacquisition_frame is None
                                else terminal_load_reacquisition_frame.diagnostics.to_dict()
                            ),
                            "render_health": render_health.to_dict(),
                            "appearance_stress": appearance.trace_snapshot(),
                            "decision": decision.to_dict(),
                            "applied_speed": resolved.applied_speed,
                            "interlock_reason": resolved.reason,
                        },
                        ensure_ascii=False,
                    )
                    + "\n"
                )
                while next_trace <= float(data.time):
                    next_trace += trace_period

            if decision.state in (PickupState.DONE, PickupState.FAILED):
                final_state = decision.state.value
                failure_reason = decision.failure_reason
                break

            mujoco.mj_step(model, data)
            current_xy = (
                float(data.qpos[forklift_qpos]),
                float(data.qpos[forklift_qpos + 1]),
            )
            path_length += math.hypot(
                current_xy[0] - previous_xy[0],
                current_xy[1] - previous_xy[1],
            )
            previous_xy = current_xy
            if not np.isfinite(data.qpos).all() or not np.isfinite(data.qvel).all():
                failure_reason = "non-finite MuJoCo state"
                break
        else:
            episode_timed_out = True
            failure_reason = f"episode exceeded {time_limit:.1f}s"
    finally:
        if stream is not None:
            stream.close()
        if reacq_audit_stream is not None:
            reacq_audit_stream.close()
        renderer.close()

    end = float(data.time)
    state_durations[current_state] = state_durations.get(current_state, 0.0) + max(
        0.0, end - state_enter
    )
    contacts, load_state, tilt = load_status()
    final_truth = builder.build(
        data,
        fork_contact_count=contacts,
        load_state=load_state,
    )
    final_estimated = (
        last_vision_frame.observation
        if last_vision_frame is not None
        else final_truth
    )
    precision_diagnostics.capture(
        "final", sim_time=final_truth.sim_time,
        truth=final_truth, estimated=final_estimated,
    )
    placement_error, placement_yaw_error = _placement_error(final_truth)
    mission_done = final_state == PickupState.DONE.value
    validation = validate_terminal_mission(
        mission_done=mission_done,
        placement_error_m=placement_error,
        placement_yaw_error_rad=math.radians(placement_yaw_error),
        release_motion_m=release_motion,
        load_state=load_state,
        position_tolerance_m=float(
            effective_autonomy["placement_post_release_position_tolerance"]
        ),
        yaw_tolerance_rad=float(
            effective_autonomy["placement_post_release_yaw_tolerance"]
        ),
        release_motion_tolerance_m=float(
            effective_autonomy["placement_load_motion_tolerance"]
        ),
    )
    success = mission_done and validation.passed
    if mission_done and not validation.passed:
        final_state = PickupState.FAILED.value
        failure_reason = validation.failure_reason
    if success and not vision.meets_success_requirement():
        success = False
        final_state = PickupState.FAILED.value
        failure_reason = (
            "RGB placement marker was not acquired often enough "
            f"({vision.detection_count}/"
            f"{vision.profile.minimum_detections_for_success})"
        )
    if success and not pickup_vision.meets_success_requirement():
        success = False
        final_state = PickupState.FAILED.value
        failure_reason = (
            "RGB pallet pockets did not satisfy pickup acquisition "
            f"(total={pickup_vision.detection_count}/"
            f"{pickup_vision.profile.minimum_detections_for_success}, "
            f"before_insert="
            f"{pickup_vision.detection_count_before_insert}/"
            f"{pickup_vision.profile.minimum_detections_before_insert})"
        )
    pallet_rmse, pallet_yaw_rmse, placement_rmse, placement_yaw_rmse = (
        accumulator.rmse()
    )

    if last_frame is None:
        dropout_rate = 0.0
        rejection_rate = 0.0
        selected_profile = profile_name or str(perception_config["default_profile"])
    else:
        samples = max(
            1,
            last_frame.pallet.sample_count + last_frame.placement.sample_count,
        )
        dropout_rate = (
            last_frame.pallet.dropout_count + last_frame.placement.dropout_count
        ) / samples
        rejection_rate = (
            last_frame.pallet.rejected_count + last_frame.placement.rejected_count
        ) / samples
        selected_profile = last_frame.profile_name

    vision_metrics = vision_accumulator.metrics()
    vision_stale = vision.maximum_stale_seconds_observed
    pickup_quality_metrics = pickup_vision_quality.metrics()
    pickup_vision_stale = pickup_vision.maximum_stale_seconds_observed
    render_metrics = render_health.metrics()
    appearance_metrics = appearance.metrics()
    precision_metrics = precision_diagnostics.finalize()
    terminal_entry_stage = precision_metrics.get("stages", {}).get("terminal_entry")
    release_stage = precision_metrics.get("stages", {}).get("release_command")
    if isinstance(terminal_entry_stage, dict) and isinstance(release_stage, dict):
        terminal_alignment_seconds = max(
            0.0,
            float(release_stage["sim_time"])
            - float(terminal_entry_stage["sim_time"]),
        )
    else:
        terminal_alignment_seconds = float(
            machine.placement_terminal_elapsed(end)
        )

    return DualVisionMissionResult(
        scenario_id=scenario.scenario_id,
        difficulty=scenario.difficulty,
        seed=scenario.seed,
        perception_profile=selected_profile,
        success=success,
        final_state=final_state,
        failure_reason=None if success else (failure_reason or "unknown failure"),
        duration_seconds=max(0.0, end - start),
        path_length_m=path_length,
        max_abs_steering_deg=max_steering,
        max_load_tilt_deg=max(max_tilt, tilt),
        final_placement_error_m=placement_error,
        final_placement_yaw_error_deg=placement_yaw_error,
        release_pallet_motion_m=release_motion,
        steering_exercised=max_steering
        >= float(batch.get("steering_exercised_degrees", 1.0)),
        recovery_count=machine.recovery_count,
        pickup_vision_sample_count=pickup_vision.sample_count,
        pickup_vision_detection_count=pickup_vision.detection_count,
        pickup_vision_rejection_count=pickup_vision.rejection_count,
        pickup_vision_detection_rate=pickup_vision.detection_count / max(1, pickup_vision.sample_count),
        pickup_vision_position_rmse_m=(
            pickup_quality_metrics.raw_position_rmse_m
        ),
        pickup_vision_yaw_rmse_deg=(
            pickup_quality_metrics.raw_yaw_rmse_deg
        ),
        pickup_vision_average_confidence=(
            pickup_quality_metrics.average_confidence
        ),
        pickup_vision_maximum_reprojection_error_px=(
            pickup_quality_metrics.maximum_reprojection_error_px
        ),
        pickup_vision_maximum_stale_seconds=pickup_vision_stale,
        pickup_vision_used_for_pickup=pickup_vision.ever_applied,
        pallet_position_rmse_m=pallet_rmse,
        pallet_yaw_rmse_deg=pallet_yaw_rmse,
        placement_position_rmse_m=placement_rmse,
        placement_yaw_rmse_deg=placement_yaw_rmse,
        maximum_stale_seconds=accumulator.maximum_stale,
        measurement_dropout_rate=dropout_rate,
        measurement_rejection_rate=rejection_rate,
        vision_sample_count=vision.sample_count,
        vision_detection_count=vision.detection_count,
        vision_rejection_count=vision.rejection_count,
        vision_detection_rate=vision.detection_count / max(1, vision.sample_count),
        vision_position_rmse_m=vision_metrics["position_rmse_m"],
        vision_yaw_rmse_deg=vision_metrics["yaw_rmse_deg"],
        vision_average_confidence=vision_metrics["average_confidence"],
        vision_maximum_reprojection_error_px=vision_metrics[
            "maximum_reprojection_error_px"
        ],
        vision_maximum_stale_seconds=vision_stale,
        vision_used_for_terminal=vision.ever_applied,
        pickup_vision_raw_detection_count=(
            pickup_quality_metrics.raw_detection_count
        ),
        pickup_vision_raw_position_p95_m=(
            pickup_quality_metrics.raw_position_p95_m
        ),
        pickup_vision_raw_yaw_p95_deg=(
            pickup_quality_metrics.raw_yaw_p95_deg
        ),
        pickup_vision_fused_frame_count=(
            pickup_quality_metrics.fused_frame_count
        ),
        pickup_vision_fused_position_rmse_m=(
            pickup_quality_metrics.fused_position_rmse_m
        ),
        pickup_vision_fused_yaw_rmse_deg=(
            pickup_quality_metrics.fused_yaw_rmse_deg
        ),
        pickup_vision_visible_sample_count=(
            pickup_quality_metrics.visible_sample_count
        ),
        pickup_vision_visible_detection_count=(
            pickup_quality_metrics.visible_detection_count
        ),
        pickup_vision_visible_detection_rate=(
            pickup_quality_metrics.visible_detection_rate
        ),
        pickup_vision_detection_rate_approach=(
            pickup_quality_metrics.detection_rate_approach
        ),
        pickup_vision_detection_rate_align=(
            pickup_quality_metrics.detection_rate_align
        ),
        pickup_vision_detection_rate_insert=(
            pickup_quality_metrics.detection_rate_insert
        ),
        pickup_vision_detection_rate_recovery=(
            pickup_quality_metrics.detection_rate_recovery
        ),
        pickup_vision_detection_acquired=(
            pickup_quality_metrics.detection_acquired
        ),
        pickup_vision_first_detection_seconds=(
            pickup_quality_metrics.first_detection_seconds
        ),
        pickup_vision_longest_detection_streak_seconds=(
            pickup_quality_metrics.longest_detection_streak_seconds
        ),
        pickup_vision_last_detection_distance_m=(
            pickup_quality_metrics.last_detection_distance_m
        ),
        pickup_vision_accepted_outlier_count=(
            pickup_quality_metrics.accepted_outlier_count
        ),
        pickup_vision_sample_count_by_state=(
            pickup_quality_metrics.sample_count_by_state
        ),
        pickup_vision_detection_count_by_state=(
            pickup_quality_metrics.detection_count_by_state
        ),
        render_attempt_count=render_metrics.attempt_count,
        render_retry_count=render_metrics.retry_count,
        render_failure_count=render_metrics.failure_count,
        render_invalid_frame_count=render_metrics.invalid_frame_count,
        render_context_warning_count=render_metrics.context_warning_count,
        render_exception_count=render_metrics.exception_count,
        render_channel_failures=render_metrics.channel_failures,
        pickup_vision_fused_position_p95_m=(
            pickup_quality_metrics.fused_position_p95_m
        ),
        pickup_vision_fused_yaw_p95_deg=(
            pickup_quality_metrics.fused_yaw_p95_deg
        ),
        pickup_vision_opportunity_count=(
            pickup_quality_metrics.opportunity_count
        ),
        pickup_vision_opportunity_detection_count=(
            pickup_quality_metrics.opportunity_raw_detection_count
        ),
        pickup_vision_opportunity_detection_rate=(
            pickup_quality_metrics.opportunity_detection_rate
        ),
        pickup_vision_first_detection_state=(
            pickup_quality_metrics.first_detection_state
        ),
        pickup_vision_detections_before_insert=(
            pickup_quality_metrics.detections_before_insert
        ),
        pickup_vision_ready_before_insert=(
            pickup_quality_metrics.ready_before_insert
        ),
        pickup_vision_raw_outlier_count=(
            pickup_quality_metrics.raw_outlier_count
        ),
        pickup_vision_innovation_rejected_count=(
            pickup_quality_metrics.innovation_rejected_count
        ),
        pickup_vision_measurement_guide_rejected_count=(
            pickup_quality_metrics.measurement_guide_rejected_count
        ),
        pickup_vision_control_accepted_outlier_count=(
            pickup_quality_metrics.control_accepted_outlier_count
        ),
        pickup_detector_raw_detection_count=(
            pickup_quality_metrics.detector_raw_detection_count
        ),
        pickup_detector_raw_position_rmse_m=(
            pickup_quality_metrics.detector_raw_position_rmse_m
        ),
        pickup_detector_raw_yaw_rmse_deg=(
            pickup_quality_metrics.detector_raw_yaw_rmse_deg
        ),
        pickup_detector_raw_position_p95_m=(
            pickup_quality_metrics.detector_raw_position_p95_m
        ),
        pickup_detector_raw_yaw_p95_deg=(
            pickup_quality_metrics.detector_raw_yaw_p95_deg
        ),
        pickup_vision_control_accepted_measurement_count=(
            pickup_quality_metrics.control_accepted_measurement_count
        ),
        pickup_vision_control_accepted_outlier_rate=(
            pickup_quality_metrics.control_accepted_outlier_rate
        ),
        pickup_vision_control_accepted_severe_outlier_count=(
            pickup_quality_metrics.control_accepted_severe_outlier_count
        ),
        pickup_vision_control_accepted_severe_outlier_rate=(
            pickup_quality_metrics.control_accepted_severe_outlier_rate
        ),
        pickup_vision_opportunity_count_by_state=(
            pickup_quality_metrics.opportunity_count_by_state
        ),
        pickup_vision_opportunity_detection_count_by_state=(
            pickup_quality_metrics.opportunity_detection_count_by_state
        ),
        pickup_vision_raw_detection_rate_by_state=(
            pickup_quality_metrics.raw_detection_rate_by_state
        ),
        pickup_vision_control_detection_rate_by_state=(
            pickup_quality_metrics.control_detection_rate_by_state
        ),
        appearance_profile=selected_appearance_profile,
        appearance_frame_count=int(
            appearance_metrics["frame_count"]
        ),
        appearance_dropout_count=int(
            appearance_metrics["dropout_count"]
        ),
        appearance_blur_count=int(
            appearance_metrics["blur_count"]
        ),
        appearance_occlusion_count=int(
            appearance_metrics["occlusion_count"]
        ),
        appearance_noise_frame_count=int(
            appearance_metrics["noise_frame_count"]
        ),
        appearance_affine_frame_count=int(
            appearance_metrics["affine_frame_count"]
        ),
        appearance_maximum_camera_translation_m=float(
            appearance_metrics["maximum_camera_translation_m"]
        ),
        appearance_maximum_camera_rotation_deg=float(
            appearance_metrics["maximum_camera_rotation_deg"]
        ),
        pickup_vision_high_confidence_count=(
            pickup_vision.high_confidence_count
        ),
        pickup_vision_medium_confidence_count=(
            pickup_vision.medium_confidence_count
        ),
        pickup_vision_confidence_rejection_count=(
            pickup_vision.confidence_rejection_count
        ),
        pickup_vision_reacquire_required_at_end=(
            pickup_vision.reacquire_required
        ),
        vision_high_confidence_count=vision.high_confidence_count,
        vision_medium_confidence_count=vision.medium_confidence_count,
        vision_confidence_rejection_count=(
            vision.confidence_rejection_count
        ),
        vision_guide_rejection_count=vision.guide_rejection_count,
        vision_innovation_rejection_count=(
            vision.innovation_rejection_count
        ),
        state_durations={key: round(value, 6) for key, value in state_durations.items()},
        scenario=scenario.to_dict(),
        placement_recovery_count=machine.placement_recovery_count,
        placement_guard_brake_count=machine.placement_guard_brake_count,
        placement_precision_settle_frame_count=(machine.placement_precision_settle_frame_count),
        placement_precision_settle_exit_count=(machine.placement_precision_settle_exit_count),
        placement_precision_forward_frame_count=(machine.placement_precision_forward_frame_count),
        placement_precision_reverse_frame_count=(machine.placement_precision_reverse_frame_count),
        placement_precision_hold_frame_count=(machine.placement_precision_hold_frame_count),
        placement_precision_reentry_count=(machine.placement_precision_reentry_count),
        placement_precision_recenter_cycle_count=(
            machine.placement_precision_recenter_cycle_count
        ),
        placement_precision_recenter_frame_count=(
            machine.placement_precision_recenter_frame_count
        ),
        placement_precision_direction_switch_count=(
            machine.placement_precision_direction_switch_count
        ),
        placement_mpc_solve_count=machine.placement_mpc_solve_count,
        placement_mpc_fallback_count=machine.placement_mpc_fallback_count,
        placement_mpc_infeasible_solve_count=(
            machine.placement_mpc_infeasible_solve_count
        ),
        placement_mpc_regression_reject_solve_count=(
            machine.placement_mpc_regression_reject_solve_count
        ),
        placement_release_candidate_count=(
            machine.placement_release_candidate_count
        ),
        placement_release_commit_count=machine.placement_release_commit_count,
        placement_release_commit_abort_count=(
            machine.placement_release_commit_abort_count
        ),
        placement_release_prebrake_count=(
            machine.placement_release_prebrake_count
        ),
        placement_release_prebrake_abort_count=(
            machine.placement_release_prebrake_abort_count
        ),
        placement_release_block_position_frames=(
            machine.placement_release_block_position_frames
        ),
        placement_release_block_yaw_frames=(
            machine.placement_release_block_yaw_frames
        ),
        placement_release_block_speed_frames=(
            machine.placement_release_block_speed_frames
        ),
        placement_release_block_vision_frames=(
            machine.placement_release_block_vision_frames
        ),
        placement_release_block_observer_frames=(
            machine.placement_release_block_observer_frames
        ),
        placement_carried_observer_active=(
            machine.placement_carried_observer_active
        ),
        placement_carried_observer_sample_count=(
            machine.placement_carried_observer_sample_count
        ),
        placement_carried_observer_position_std_m=(
            machine.placement_carried_observer_position_std_m
        ),
        placement_carried_observer_yaw_std_deg=(
            machine.placement_carried_observer_yaw_std_deg
        ),
        placement_carried_observer_update_count=(
            machine.placement_carried_observer_update_count
        ),
        placement_carried_observer_rejection_count=(
            machine.placement_carried_observer_rejection_count
        ),
        placement_carried_observer_disagreement_position_m=(
            machine.placement_carried_observer_disagreement_position_m
        ),
        placement_carried_observer_disagreement_yaw_deg=(
            machine.placement_carried_observer_disagreement_yaw_deg
        ),
        placement_mpc_model_id_sample_count=(
            machine.placement_mpc_model_id_sample_count
        ),
        placement_mpc_model_id_longitudinal_rmse_m=(
            machine.placement_mpc_model_id_longitudinal_rmse_m
        ),
        placement_mpc_model_id_lateral_rmse_m=(
            machine.placement_mpc_model_id_lateral_rmse_m
        ),
        placement_mpc_model_id_yaw_rmse_deg=(
            machine.placement_mpc_model_id_yaw_rmse_deg
        ),
        terminal_corridor_entry_replan_count=(
            machine.terminal_corridor_entry_replan_count
        ),
        terminal_corridor_axis_frame_count=(
            machine.terminal_corridor_axis_frame_count
        ),
        terminal_corridor_axis_reset_count=(
            machine.terminal_corridor_axis_reset_count
        ),
        terminal_corridor_rolling_frame_count=(
            machine.terminal_corridor_rolling_frame_count
        ),
        terminal_corridor_handoff_count=(
            machine.terminal_corridor_handoff_count
        ),
        terminal_corridor_timeout_handoff_count=(
            machine.terminal_corridor_timeout_handoff_count
        ),
        terminal_corridor_reacquire_count=(
            machine.terminal_corridor_reacquire_count
        ),
        terminal_corridor_visual_coarse_frame_count=(
            machine.terminal_corridor_visual_coarse_frame_count
        ),
        terminal_corridor_visual_stale_frame_count=(
            machine.terminal_corridor_visual_stale_frame_count
        ),
        terminal_corridor_last_handoff_distance_m=(
            machine.terminal_corridor_last_handoff_distance
        ),
        terminal_corridor_last_handoff_lateral_m=(
            machine.terminal_corridor_last_handoff_lateral
        ),
        terminal_corridor_last_handoff_yaw_deg=(
            machine.terminal_corridor_last_handoff_yaw_deg
        ),
        vision_visual_takeover_count=int(
            getattr(vision, "visual_takeover_count", 0)
        ),
        pickup_vision_visual_takeover_count=int(
            getattr(pickup_vision, "visual_takeover_count", 0)
        ),
        vision_authority_lock_count=int(
            getattr(vision, "visual_authority_lock_count", 0)
        ),
        vision_authority_unlock_count=int(
            getattr(vision, "visual_authority_unlock_count", 0)
        ),
        pickup_vision_authority_lock_count=int(
            getattr(pickup_vision, "visual_authority_lock_count", 0)
        ),
        pickup_vision_authority_unlock_count=int(
            getattr(pickup_vision, "visual_authority_unlock_count", 0)
        ),
        carried_load_visual_authority_locked=bool(
            machine.carried_load_visual_authority_locked
        ),
        carried_load_visual_lock_count=machine.carried_load_visual_lock_count,
        carried_load_visual_rgb_update_count=machine.carried_load_visual_rgb_update_count,
        carried_load_visual_guide_reject_count=machine.carried_load_visual_guide_reject_count,
        carried_load_visual_rigid_prediction_count=machine.carried_load_visual_rigid_prediction_count,
        carried_load_visual_handoff_seed_count=machine.carried_load_visual_handoff_seed_count,
        carried_load_yaw_anchor_used=machine.carried_load_yaw_anchor_used,
        carried_load_yaw_anchor_sample_count=machine.carried_load_yaw_anchor_sample_count,
        carried_load_yaw_anchor_spread_deg=machine.carried_load_yaw_anchor_spread_deg,
        carried_load_yaw_anchor_delta_from_latest_deg=machine.carried_load_yaw_anchor_delta_from_latest_deg,
        carried_load_seed_provenance=machine.carried_load_seed_provenance,
        carried_load_seed_trusted_for_aggressive_risk=machine.carried_load_seed_trusted_for_aggressive_risk,
        carried_load_seed_age_seconds=machine.carried_load_seed_age_seconds,
        carried_load_seed_confidence=machine.carried_load_seed_confidence,
        carried_load_seed_reprojection_error_px=machine.carried_load_seed_reprojection_error_px,
        controller_release_seed_provenance=controller_release_seed_provenance,
        controller_release_seed_trusted_for_aggressive_risk=controller_release_seed_trusted_for_aggressive_risk,
        controller_release_seed_age_seconds=controller_release_seed_age_seconds,
        controller_release_risk_budget_mode=controller_release_risk_budget_mode,
        controller_release_yaw_risk_budget_mode=controller_release_yaw_risk_budget_mode,
        controller_release_target_source=controller_release_target_source,
        release_center_yaw_anchor_seen=release_center_yaw_anchor_seen,
        release_center_yaw_anchor_active_frame_count=release_center_yaw_anchor_active_frame_count,
        strict_release_center_yaw_rss_frame_count=strict_release_center_yaw_rss_frame_count,
        strict_release_center_yaw_conflict_count=machine.strict_release_center_yaw_conflict_count,
        strict_release_center_yaw_revalidation_count=machine.strict_release_center_yaw_revalidation_count,
        strict_release_center_yaw_conflict_fallback_frame_count=(
            machine.strict_release_center_yaw_conflict_fallback_frame_count
        ),
        strict_release_center_yaw_conflict_last_jump_deg=(
            machine.strict_release_center_yaw_conflict_last_jump_deg
        ),
        strict_release_center_yaw_conflict_last_load_stale_seconds=(
            machine.strict_release_center_yaw_conflict_last_load_stale_seconds
        ),
        strict_release_certification_pass_count=machine.strict_release_certification_pass_count,
        strict_release_certification_reject_count=machine.strict_release_certification_reject_count,
        terminal_corridor_timeout_handoff_guard_reject_count=(
            machine.terminal_corridor_timeout_handoff_guard_reject_count
        ),
        carried_load_visual_handoff_fallback_seed_count=(
            machine.carried_load_visual_handoff_fallback_seed_count
        ),
        release_supervisor_settle_count=machine.release_supervisor_settle_count,
        release_supervisor_intent_count=machine.release_supervisor_intent_count,
        release_supervisor_intent_abort_count=machine.release_supervisor_intent_abort_count,
        release_supervisor_settle_timeout_count=machine.release_supervisor_settle_timeout_count,
        release_supervisor_mpc_resume_count=machine.release_supervisor_mpc_resume_count,
        release_supervisor_hold_seconds=machine.release_supervisor_hold_seconds,
        release_supervisor_certified_hold_seconds=machine.release_supervisor_certified_hold_seconds,
        release_supervisor_certification_to_release_seconds=(
            machine.release_supervisor_certification_to_release_seconds
        ),
        terminal_ownership_mpc_entered=machine.terminal_ownership_mpc_entered,
        terminal_ownership_direct_mpc_count=machine.terminal_ownership_direct_mpc_count,
        terminal_ownership_forced_mpc_count=machine.terminal_ownership_forced_mpc_count,
        terminal_ownership_align_timeout_count=machine.terminal_ownership_align_timeout_count,
        terminal_ownership_reacquire_count=machine.terminal_ownership_reacquire_count,
        terminal_ownership_total_align_seconds=machine.terminal_ownership_total_align_seconds,
        terminal_ownership_max_align_seconds=machine.terminal_ownership_max_align_seconds,
        carried_load_belief_mode=machine.carried_load_belief_mode,
        carried_load_belief_position_sigma_m=machine.carried_load_belief_position_sigma_m,
        carried_load_belief_yaw_sigma_deg=machine.carried_load_belief_yaw_sigma_deg,
        carried_load_motion_yaw_sigma_deg=machine.carried_load_motion_yaw_sigma_deg,
        carried_load_release_yaw_sigma_deg=machine.carried_load_release_yaw_sigma_deg,
        carried_load_yaw_anchor_seed_sigma_deg=machine.carried_load_yaw_anchor_seed_sigma_deg,
        carried_load_yaw_evidence_source=machine.carried_load_yaw_evidence_source,
        carried_load_belief_distance_since_visual_m=machine.carried_load_belief_distance_since_visual_m,
        carried_load_belief_turn_since_visual_deg=machine.carried_load_belief_turn_since_visual_deg,
        carried_load_belief_transport_scaled_frames=machine.carried_load_belief_transport_scaled_frames,
        controller_certified_release=controller_certified_release,
        controller_certified_release_truth_pass=controller_certified_release_truth_pass,
        controller_certified_release_false_positive=controller_certified_release_false_positive,
        controller_truth_ready_uncertified=controller_truth_ready_uncertified,
        controller_release_estimated_position_error_m=controller_release_estimated_position_error_m,
        controller_release_estimated_yaw_error_deg=controller_release_estimated_yaw_error_deg,
        controller_release_target_raw_position_spread_m=controller_release_target_raw_position_spread_m,
        controller_release_target_raw_yaw_spread_deg=controller_release_target_raw_yaw_spread_deg,
        controller_release_target_position_margin_m=controller_release_target_position_margin_m,
        controller_release_target_yaw_margin_deg=controller_release_target_yaw_margin_deg,
        placement_mpc_yaw_escrow_activation_count=machine.placement_mpc_yaw_escrow_activation_count,
        # V9.3.12-R4-B: restore the V9.3.11/V9.3.12 diagnostic fields
        # that were dropped by the R4-A package merge. These are telemetry
        # only and do not alter the runtime controller.
        certified_basin_enter_count=machine.certified_basin_enter_count,
        certified_basin_exit_count=machine.certified_basin_exit_count,
        certified_basin_strict_enter_count=machine.certified_basin_strict_enter_count,
        certified_basin_consensus_enter_count=machine.certified_basin_consensus_enter_count,
        certified_basin_persisted_pass_count=machine.certified_basin_persisted_pass_count,
        certified_basin_longest_active_seconds=machine.certified_basin_longest_active_seconds,
        strict_release_certification_blocker_counts=machine.strict_release_certification_blocker_counts,
        placement_mpc_near_basin_escrow_activation_count=machine.placement_mpc_near_basin_escrow_activation_count,
        placement_mpc_near_basin_escrow_accepted_plan_count=machine.placement_mpc_near_basin_escrow_accepted_plan_count,
        placement_mpc_near_basin_last_deficit_improvement=machine.placement_mpc_near_basin_last_deficit_improvement,
        terminal_load_reacquisition_sample_count=(
            0 if terminal_load_reacquisition is None else terminal_load_reacquisition.sample_count
        ),
        terminal_load_reacquisition_raw_detection_count=(
            0 if terminal_load_reacquisition is None else terminal_load_reacquisition.raw_detection_count
        ),
        terminal_load_reacquisition_consensus_update_count=(
            0 if terminal_load_reacquisition is None else terminal_load_reacquisition.accepted_update_count
        ),
        terminal_load_reacquisition_observer_update_count=machine.terminal_load_reacquisition_update_count,
        terminal_load_reacquisition_observer_rejection_count=machine.terminal_load_reacquisition_rejection_count,
        terminal_load_reacquisition_position_only_update_count=machine.terminal_load_reacquisition_position_only_update_count,
        terminal_load_reacquisition_yaw_suppressed_count=machine.terminal_load_reacquisition_yaw_suppressed_count,
        terminal_load_reacquisition_yaw_authority_enabled=machine.terminal_load_reacquisition_yaw_authority_enabled,
        terminal_load_reacquisition_last_measurement_yaw_deg=machine.terminal_load_reacquisition_last_measurement_yaw_deg,
        terminal_load_reacquisition_last_posterior_yaw_deg=machine.terminal_load_reacquisition_last_posterior_yaw_deg,
        terminal_load_reacquisition_rejected_innovation_count=(
            0 if terminal_load_reacquisition is None else terminal_load_reacquisition.rejected_innovation_count
        ),
        terminal_load_reacquisition_rejected_spread_count=(
            0 if terminal_load_reacquisition is None else terminal_load_reacquisition.rejected_spread_count
        ),
        terminal_load_reacquisition_maximum_stale_seconds=(
            0.0 if terminal_load_reacquisition is None else terminal_load_reacquisition.maximum_stale_seconds_observed
        ),
        terminal_load_reacquisition_last_position_spread_m=(
            None if terminal_load_reacquisition is None else terminal_load_reacquisition.last_consensus_position_spread_m
        ),
        terminal_load_reacquisition_last_yaw_spread_deg=(
            None
            if terminal_load_reacquisition is None or terminal_load_reacquisition.last_consensus_yaw_spread_rad is None
            else math.degrees(terminal_load_reacquisition.last_consensus_yaw_spread_rad)
        ),
        terminal_load_reacquisition_last_position_innovation_m=machine.terminal_load_reacquisition_last_position_innovation_m,
        terminal_load_reacquisition_last_yaw_innovation_deg=machine.terminal_load_reacquisition_last_yaw_innovation_deg,
        placement_micro_primitive_search_count=machine.placement_micro_primitive_search_count,
        placement_micro_primitive_activation_count=machine.placement_micro_primitive_activation_count,
        placement_micro_primitive_accepted_count=machine.placement_micro_primitive_accepted_count,
        placement_micro_primitive_candidate_count=machine.placement_micro_primitive_candidate_count,
        placement_micro_primitive_last_deficit_improvement=machine.placement_micro_primitive_last_deficit_improvement,
        placement_strict_recovery_retention_search_count=machine.placement_strict_recovery_retention_search_count,
        placement_strict_recovery_retention_activation_count=machine.placement_strict_recovery_retention_activation_count,
        placement_strict_recovery_retention_candidate_count=machine.placement_strict_recovery_retention_candidate_count,
        placement_strict_recovery_retention_last_deficit_improvement=machine.placement_strict_recovery_retention_last_deficit_improvement,
        placement_strict_recovery_final_settle_count=machine.placement_strict_recovery_final_settle_count,
        placement_fresh_rgb_yaw_closure_search_count=machine.placement_fresh_rgb_yaw_closure_search_count,
        placement_fresh_rgb_yaw_closure_activation_count=machine.placement_fresh_rgb_yaw_closure_activation_count,
        placement_fresh_rgb_yaw_closure_candidate_count=machine.placement_fresh_rgb_yaw_closure_candidate_count,
        placement_fresh_rgb_yaw_closure_feedback_reject_count=machine.placement_fresh_rgb_yaw_closure_feedback_reject_count,
        placement_fresh_rgb_yaw_closure_last_predicted_yaw_improvement_deg=machine.placement_fresh_rgb_yaw_closure_last_predicted_yaw_improvement_deg,
        placement_fresh_rgb_yaw_closure_last_measured_yaw_improvement_deg=machine.placement_fresh_rgb_yaw_closure_last_measured_yaw_improvement_deg,
        placement_fresh_rgb_yaw_closure_total_candidate_count=machine.placement_fresh_rgb_yaw_closure_total_candidate_count,
        placement_fresh_rgb_yaw_closure_no_candidate_search_count=machine.placement_fresh_rgb_yaw_closure_no_candidate_search_count,
        placement_post_closure_basin_ownership_entry_count=machine.placement_post_closure_basin_ownership_entry_count,
        placement_post_closure_mpc_veto_count=machine.placement_post_closure_mpc_veto_count,
        placement_post_closure_mpc_safe_allow_count=machine.placement_post_closure_mpc_safe_allow_count,
        placement_post_closure_certification_handoff_count=machine.placement_post_closure_certification_handoff_count,
        placement_post_closure_continuation_search_count=machine.placement_post_closure_continuation_search_count,
        placement_post_closure_continuation_activation_count=machine.placement_post_closure_continuation_activation_count,
        placement_post_closure_last_certification_position_m=machine.placement_post_closure_last_certification_position_m,
        placement_post_closure_last_certification_yaw_deg=machine.placement_post_closure_last_certification_yaw_deg,
        placement_post_closure_gray_zone_hold_count=machine.placement_post_closure_gray_zone_hold_count,
        placement_certification_basin_closure_search_count=machine.placement_certification_basin_closure_search_count,
        placement_certification_basin_closure_activation_count=machine.placement_certification_basin_closure_activation_count,
        placement_certification_basin_closure_candidate_count=machine.placement_certification_basin_closure_candidate_count,
        placement_certification_basin_closure_total_candidate_count=machine.placement_certification_basin_closure_total_candidate_count,
        placement_certification_basin_closure_no_candidate_search_count=machine.placement_certification_basin_closure_no_candidate_search_count,
        placement_certification_basin_closure_feedback_reject_count=machine.placement_certification_basin_closure_feedback_reject_count,
        placement_certification_basin_closure_last_predicted_deficit_improvement=machine._certification_basin_closure_last_predicted_deficit_improvement,
        placement_certification_basin_closure_last_measured_deficit_improvement=machine._certification_basin_closure_last_measured_deficit_improvement,
        placement_certification_basin_closure_last_current_deficit=machine._certification_basin_closure_last_current_deficit,
        placement_certification_basin_closure_last_predicted_deficit=machine._certification_basin_closure_last_predicted_deficit,
        placement_certification_basin_closure_post_motion_rgb_updates=machine._certification_basin_closure_post_motion_rgb_updates,
        placement_certification_basin_closure_supervisor_retry_suppressed_count=machine.placement_certification_basin_closure_supervisor_retry_suppressed_count,
        placement_certification_basin_closure_full_pose_search_count=machine.placement_certification_basin_closure_full_pose_search_count,
        placement_certification_basin_closure_legacy_error_space_search_count=machine.placement_certification_basin_closure_legacy_error_space_search_count,
        placement_certification_basin_closure_last_certification_longitudinal_m=machine._certification_basin_closure_last_certification_longitudinal_m,
        placement_certification_basin_closure_last_certification_lateral_m=machine._certification_basin_closure_last_certification_lateral_m,
        placement_position_blocker_recenter_search_count=machine.placement_position_blocker_recenter_search_count,
        placement_position_blocker_recenter_activation_count=machine.placement_position_blocker_recenter_activation_count,
        placement_position_blocker_recenter_candidate_count=machine.placement_position_blocker_recenter_candidate_count,
        placement_position_blocker_recenter_total_candidate_count=machine.placement_position_blocker_recenter_total_candidate_count,
        placement_position_blocker_recenter_return_replan_count=machine.placement_position_blocker_recenter_return_replan_count,
        placement_position_blocker_recenter_return_candidate_count=machine.placement_position_blocker_recenter_return_candidate_count,
        placement_position_blocker_recenter_feedback_reject_count=machine.placement_position_blocker_recenter_feedback_reject_count,
        placement_position_blocker_recenter_abort_count=machine.placement_position_blocker_recenter_abort_count,
        placement_position_blocker_recenter_midpoint_replan_fail_count=machine.placement_position_blocker_recenter_midpoint_replan_fail_count,
        placement_position_blocker_recenter_mid_rgb_updates=machine._position_blocker_recenter_mid_rgb_updates,
        placement_position_blocker_recenter_final_rgb_updates=machine._position_blocker_recenter_final_rgb_updates,
        placement_position_blocker_recenter_last_predicted_effective_position_m=machine._position_blocker_recenter_last_predicted_effective_position_m,
        placement_position_blocker_recenter_last_predicted_effective_yaw_deg=math.degrees(machine._position_blocker_recenter_last_predicted_effective_yaw_rad),
        placement_position_blocker_recenter_last_measured_effective_position_m=machine._position_blocker_recenter_last_measured_effective_position_m,
        placement_position_blocker_recenter_last_measured_effective_yaw_deg=math.degrees(machine._position_blocker_recenter_last_measured_effective_yaw_rad),
        placement_position_blocker_recenter_last_measured_position_improvement_m=machine._position_blocker_recenter_last_measured_position_improvement_m,
        placement_position_blocker_recenter_presteer_timeout_count=machine.placement_position_blocker_recenter_presteer_timeout_count,
        placement_position_blocker_recenter_last_effective_steering_deg=math.degrees(machine._position_blocker_recenter_last_effective_steering_rad),
        placement_position_blocker_recenter_last_departure_odometry_m=machine._position_blocker_recenter_last_departure_odometry_m,
        placement_position_blocker_recenter_last_return_odometry_m=machine._position_blocker_recenter_last_return_odometry_m,
        placement_position_blocker_recenter_midpoint_position_deviation_m=machine._position_blocker_recenter_midpoint_position_deviation_m,
        placement_position_blocker_recenter_midpoint_yaw_deviation_deg=math.degrees(machine._position_blocker_recenter_midpoint_yaw_deviation_rad),
        placement_position_blocker_recenter_full_pose_search_count=machine.placement_position_blocker_recenter_full_pose_search_count,
        placement_position_blocker_recenter_full_pose_return_replan_count=machine.placement_position_blocker_recenter_full_pose_return_replan_count,
        placement_position_blocker_recenter_legacy_error_space_search_count=machine.placement_position_blocker_recenter_legacy_error_space_search_count,
        placement_position_blocker_recenter_rollback_count=machine._position_blocker_recenter_rollback_count,
        placement_position_blocker_recenter_rollback_success_count=machine._position_blocker_recenter_rollback_success_count,
        placement_position_blocker_recenter_rollback_failure_count=machine._position_blocker_recenter_rollback_failure_count,
        placement_position_blocker_recenter_rollback_target_odometry_m=machine._position_blocker_recenter_rollback_target_odometry_m,
        placement_position_blocker_recenter_last_rollback_odometry_m=machine._position_blocker_recenter_last_rollback_odometry_m,
        placement_position_blocker_recenter_last_return_unwind_odometry_m=machine._position_blocker_recenter_last_return_unwind_odometry_m,
        placement_position_blocker_recenter_rollback_rgb_updates=machine._position_blocker_recenter_rollback_rgb_updates,
        placement_position_blocker_recenter_rollback_reason=machine._position_blocker_recenter_rollback_reason,
        placement_position_blocker_recenter_yaw_handoff_count=machine._position_blocker_recenter_yaw_handoff_count,
        placement_position_blocker_recenter_retrace_candidate_reject_count=(
            0 if machine._position_blocker_recenter_planner is None
            else machine._position_blocker_recenter_planner.retrace_candidate_reject_count
        ),
        placement_position_blocker_recenter_topology_candidate_count=(
            0 if machine._position_blocker_recenter_planner is None
            else machine._position_blocker_recenter_planner.topology_candidate_count
        ),
        placement_position_blocker_recenter_final_evidence_consistent_rgb_updates=(
            machine._position_blocker_recenter_final_evidence_consistent_rgb_updates
        ),
        placement_position_blocker_recenter_final_live_strict_attempt_count=(
            machine._position_blocker_recenter_final_live_strict_attempt_count
        ),
        placement_position_blocker_recenter_final_evidence_timeout_count=(
            machine._position_blocker_recenter_final_evidence_timeout_count
        ),
        placement_target_multiview_ready=bool(
            getattr(vision, "certification_multiview_ready", lambda: False)()
        ),
        placement_target_multiview_samples=len(
            getattr(vision, "certification_multiview_history", [])
        ),
        placement_target_multiview_position_spread_m=getattr(
            vision, "certification_multiview_position_spread_m", None
        ),
        placement_target_multiview_yaw_spread_deg=(
            None
            if getattr(vision, "certification_multiview_yaw_spread_rad", None) is None
            else math.degrees(float(vision.certification_multiview_yaw_spread_rad))
        ),
        placement_target_fast_slow_position_disagreement_m=getattr(
            vision, "certification_fast_slow_position_disagreement_m", None
        ),
        placement_target_fast_slow_yaw_disagreement_deg=(
            None
            if getattr(vision, "certification_fast_slow_yaw_disagreement_rad", None) is None
            else math.degrees(float(vision.certification_fast_slow_yaw_disagreement_rad))
        ),
        release_witness_capture_count=machine.release_witness_capture_count,
        release_witness_drift_abort_count=machine.release_witness_drift_abort_count,
        release_witness_instant_strict_gate_block_count=machine.release_witness_instant_strict_gate_block_count,
        release_witness_truth_pass=release_witness_truth_pass,
        release_witness_false_positive=release_witness_false_positive,
        release_execution_truth_pass=release_execution_truth_pass,
        release_execution_false_positive=release_execution_false_positive,
        release_witness_to_execute_seconds=release_witness_to_execute_seconds,
        release_witness_estimated_position_error_m=release_witness_estimated_position_error_m,
        release_witness_estimated_yaw_error_deg=release_witness_estimated_yaw_error_deg,
        terminal_oracle_geometry=bool(terminal_oracle_geometry),
        episode_timed_out=bool(episode_timed_out),
        long_episode=bool(
            max(0.0, end - start) >= float(batch.get("long_episode_seconds", 180.0))
        ),
        terminal_budget_exhausted=bool(
            machine.placement_terminal_budget_exhausted
        ),
        terminal_alignment_seconds=terminal_alignment_seconds,
        precision_diagnostics=precision_metrics,
    )
