"""Deterministic noisy-pose sensor simulation and temporal filtering.

The simulator still produces exact physical state. This module sits between
that ground-truth observation and the autonomous controller, replacing only
``pallet_pose_in_base`` and ``placement_pose_in_base`` with delayed, noisy,
filtered estimates. Vehicle proprioception, contacts, lift state and physical
safety signals remain unchanged.
"""

from __future__ import annotations

from collections import deque
from dataclasses import asdict, dataclass, replace
import math
import random
from typing import Any, Deque, Mapping

from interfaces.observation import ForkliftObservation, Pose3D


def wrap_angle(angle: float) -> float:
    return (float(angle) + math.pi) % (2.0 * math.pi) - math.pi


def _clamp_radial(x: float, y: float, maximum: float) -> tuple[float, float]:
    if maximum <= 0.0:
        return 0.0, 0.0
    radius = math.hypot(x, y)
    if radius <= maximum or radius <= 1e-12:
        return x, y
    scale = maximum / radius
    return x * scale, y * scale


def _relative_to_world(vehicle: Pose3D, relative: Pose3D) -> Pose3D:
    c = math.cos(vehicle.yaw)
    s = math.sin(vehicle.yaw)
    return Pose3D(
        x=vehicle.x + c * relative.x - s * relative.y,
        y=vehicle.y + s * relative.x + c * relative.y,
        z=vehicle.z + relative.z,
        roll=relative.roll,
        pitch=relative.pitch,
        yaw=wrap_angle(vehicle.yaw + relative.yaw),
    )


def _world_to_relative(vehicle: Pose3D, world: Pose3D) -> Pose3D:
    dx = world.x - vehicle.x
    dy = world.y - vehicle.y
    c = math.cos(vehicle.yaw)
    s = math.sin(vehicle.yaw)
    return Pose3D(
        x=c * dx + s * dy,
        y=-s * dx + c * dy,
        z=world.z - vehicle.z,
        roll=world.roll,
        pitch=world.pitch,
        yaw=wrap_angle(world.yaw - vehicle.yaw),
    )


@dataclass(frozen=True)
class PerceptionProfile:
    """Configuration for one simulated guide-pose sensor profile."""

    update_hz: float
    latency_seconds: float
    latency_jitter_seconds: float
    dropout_probability: float
    position_sigma_m: float
    position_clip_m: float
    yaw_sigma_rad: float
    yaw_clip_rad: float
    bias_position_sigma_m: float
    bias_position_clip_m: float
    bias_yaw_sigma_rad: float
    bias_yaw_clip_rad: float
    filter_alpha: float
    filter_beta: float
    maximum_position_innovation_m: float
    maximum_yaw_innovation_rad: float
    maximum_prediction_seconds: float

    @classmethod
    def from_mapping(cls, values: Mapping[str, Any]) -> "PerceptionProfile":
        def rad(name_deg: str) -> float:
            return math.radians(float(values[name_deg]))

        profile = cls(
            update_hz=float(values["update_hz"]),
            latency_seconds=float(values.get("latency_seconds", 0.0)),
            latency_jitter_seconds=float(values.get("latency_jitter_seconds", 0.0)),
            dropout_probability=float(values.get("dropout_probability", 0.0)),
            position_sigma_m=float(values.get("position_sigma_m", 0.0)),
            position_clip_m=float(values.get("position_clip_m", 0.0)),
            yaw_sigma_rad=rad("yaw_sigma_deg"),
            yaw_clip_rad=rad("yaw_clip_deg"),
            bias_position_sigma_m=float(values.get("bias_position_sigma_m", 0.0)),
            bias_position_clip_m=float(values.get("bias_position_clip_m", 0.0)),
            bias_yaw_sigma_rad=rad("bias_yaw_sigma_deg"),
            bias_yaw_clip_rad=rad("bias_yaw_clip_deg"),
            filter_alpha=float(values.get("filter_alpha", 1.0)),
            filter_beta=float(values.get("filter_beta", 0.0)),
            maximum_position_innovation_m=float(
                values.get("maximum_position_innovation_m", 1.0)
            ),
            maximum_yaw_innovation_rad=rad("maximum_yaw_innovation_deg"),
            maximum_prediction_seconds=float(
                values.get("maximum_prediction_seconds", 1.0)
            ),
        )
        profile.validate()
        return profile

    def validate(self) -> None:
        if self.update_hz <= 0.0:
            raise ValueError("update_hz must be positive")
        non_negative = (
            self.latency_seconds,
            self.latency_jitter_seconds,
            self.position_sigma_m,
            self.position_clip_m,
            self.yaw_sigma_rad,
            self.yaw_clip_rad,
            self.bias_position_sigma_m,
            self.bias_position_clip_m,
            self.bias_yaw_sigma_rad,
            self.bias_yaw_clip_rad,
            self.filter_beta,
            self.maximum_prediction_seconds,
        )
        if any(value < 0.0 for value in non_negative):
            raise ValueError("perception profile values must be non-negative")
        if not 0.0 <= self.dropout_probability <= 1.0:
            raise ValueError("dropout_probability must be in [0, 1]")
        if not 0.0 < self.filter_alpha <= 1.0:
            raise ValueError("filter_alpha must be in (0, 1]")
        if self.maximum_position_innovation_m <= 0.0:
            raise ValueError("maximum_position_innovation_m must be positive")
        if self.maximum_yaw_innovation_rad <= 0.0:
            raise ValueError("maximum_yaw_innovation_deg must be positive")


@dataclass(frozen=True)
class TargetDiagnostics:
    status: str
    sample_count: int
    accepted_count: int
    dropout_count: int
    rejected_count: int
    stale_seconds: float
    raw_position_error_m: float | None
    raw_yaw_error_deg: float | None
    filtered_position_error_m: float
    filtered_yaw_error_deg: float

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class PerceptionFrame:
    observation: ForkliftObservation
    pallet: TargetDiagnostics
    placement: TargetDiagnostics
    profile_name: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "profile_name": self.profile_name,
            "pallet": self.pallet.to_dict(),
            "placement": self.placement.to_dict(),
        }


@dataclass(frozen=True)
class _QueuedMeasurement:
    delivery_time: float
    sample_time: float
    world_pose: Pose3D
    truth_world_pose: Pose3D


@dataclass
class _FilterState:
    pose: Pose3D
    vx: float = 0.0
    vy: float = 0.0
    yaw_rate: float = 0.0
    time: float = 0.0
    last_measurement_time: float = 0.0


class _TargetEstimator:
    def __init__(self, profile: PerceptionProfile, *, seed: int) -> None:
        self.profile = profile
        self.rng = random.Random(int(seed))
        self.queue: Deque[_QueuedMeasurement] = deque()
        self.state: _FilterState | None = None
        self.next_sample_time: float | None = None
        self.sample_count = 0
        self.accepted_count = 0
        self.dropout_count = 0
        self.rejected_count = 0
        self.last_status = "uninitialized"
        self.last_raw_position_error_m: float | None = None
        self.last_raw_yaw_error_deg: float | None = None
        self.bias_x, self.bias_y = _clamp_radial(
            self.rng.gauss(0.0, profile.bias_position_sigma_m),
            self.rng.gauss(0.0, profile.bias_position_sigma_m),
            profile.bias_position_clip_m,
        )
        self.bias_yaw = max(
            -profile.bias_yaw_clip_rad,
            min(
                profile.bias_yaw_clip_rad,
                self.rng.gauss(0.0, profile.bias_yaw_sigma_rad),
            ),
        )

    def reset(self) -> None:
        self.queue.clear()
        self.state = None
        self.next_sample_time = None
        self.sample_count = 0
        self.accepted_count = 0
        self.dropout_count = 0
        self.rejected_count = 0
        self.last_status = "uninitialized"
        self.last_raw_position_error_m = None
        self.last_raw_yaw_error_deg = None

    def _noisy_relative(self, truth: Pose3D) -> Pose3D:
        dx, dy = _clamp_radial(
            self.rng.gauss(0.0, self.profile.position_sigma_m),
            self.rng.gauss(0.0, self.profile.position_sigma_m),
            self.profile.position_clip_m,
        )
        dyaw = max(
            -self.profile.yaw_clip_rad,
            min(
                self.profile.yaw_clip_rad,
                self.rng.gauss(0.0, self.profile.yaw_sigma_rad),
            ),
        )
        return Pose3D(
            x=truth.x + dx + self.bias_x,
            y=truth.y + dy + self.bias_y,
            z=truth.z,
            roll=truth.roll,
            pitch=truth.pitch,
            yaw=wrap_angle(truth.yaw + dyaw + self.bias_yaw),
        )

    def _predict_to(self, now: float) -> None:
        if self.state is None:
            return
        dt = max(0.0, float(now) - self.state.time)
        if dt <= 0.0:
            return
        bounded = min(dt, self.profile.maximum_prediction_seconds)
        self.state.pose = replace(
            self.state.pose,
            x=self.state.pose.x + self.state.vx * bounded,
            y=self.state.pose.y + self.state.vy * bounded,
            yaw=wrap_angle(self.state.pose.yaw + self.state.yaw_rate * bounded),
        )
        self.state.time = float(now)

    def _accept(self, measurement: _QueuedMeasurement, now: float) -> None:
        measurement_pose = measurement.world_pose
        if self.state is None:
            self.state = _FilterState(
                pose=measurement_pose,
                time=float(now),
                last_measurement_time=measurement.sample_time,
            )
            self.accepted_count += 1
            self.last_status = "initialized"
            return

        self._predict_to(now)
        latency = max(0.0, float(now) - measurement.sample_time)
        projected = replace(
            measurement_pose,
            x=measurement_pose.x + self.state.vx * latency,
            y=measurement_pose.y + self.state.vy * latency,
            yaw=wrap_angle(measurement_pose.yaw + self.state.yaw_rate * latency),
        )
        innovation_x = projected.x - self.state.pose.x
        innovation_y = projected.y - self.state.pose.y
        innovation_yaw = wrap_angle(projected.yaw - self.state.pose.yaw)
        if (
            math.hypot(innovation_x, innovation_y)
            > self.profile.maximum_position_innovation_m
            or abs(innovation_yaw) > self.profile.maximum_yaw_innovation_rad
        ):
            self.rejected_count += 1
            self.last_status = "rejected"
            return

        dt = max(1e-3, float(now) - self.state.last_measurement_time)
        alpha = self.profile.filter_alpha
        beta = self.profile.filter_beta
        self.state.pose = replace(
            self.state.pose,
            x=self.state.pose.x + alpha * innovation_x,
            y=self.state.pose.y + alpha * innovation_y,
            yaw=wrap_angle(self.state.pose.yaw + alpha * innovation_yaw),
            z=projected.z,
            roll=projected.roll,
            pitch=projected.pitch,
        )
        self.state.vx += beta * innovation_x / dt
        self.state.vy += beta * innovation_y / dt
        self.state.yaw_rate += beta * innovation_yaw / dt
        self.state.last_measurement_time = measurement.sample_time
        self.accepted_count += 1
        self.last_status = "accepted"

    def step(
        self,
        *,
        now: float,
        vehicle_pose_world: Pose3D,
        truth_relative: Pose3D,
        force_initial: bool,
    ) -> tuple[Pose3D, TargetDiagnostics]:
        now = float(now)
        if self.next_sample_time is None:
            self.next_sample_time = now

        period = 1.0 / self.profile.update_hz
        while self.next_sample_time <= now + 1e-12:
            sample_time = self.next_sample_time
            self.next_sample_time += period
            self.sample_count += 1
            dropped = self.rng.random() < self.profile.dropout_probability
            if force_initial and self.state is None:
                dropped = False
            if dropped:
                self.dropout_count += 1
                self.last_status = "dropout"
                continue
            noisy_relative = self._noisy_relative(truth_relative)
            noisy_world = _relative_to_world(vehicle_pose_world, noisy_relative)
            truth_world = _relative_to_world(vehicle_pose_world, truth_relative)
            jitter = self.rng.uniform(
                -self.profile.latency_jitter_seconds,
                self.profile.latency_jitter_seconds,
            )
            delivery = sample_time + max(0.0, self.profile.latency_seconds + jitter)
            self.queue.append(
                _QueuedMeasurement(
                    delivery_time=delivery,
                    sample_time=sample_time,
                    world_pose=noisy_world,
                    truth_world_pose=truth_world,
                )
            )
            self.last_raw_position_error_m = math.hypot(
                noisy_world.x - truth_world.x,
                noisy_world.y - truth_world.y,
            )
            self.last_raw_yaw_error_deg = math.degrees(
                abs(wrap_angle(noisy_world.yaw - truth_world.yaw))
            )

        delivered = False
        while self.queue and self.queue[0].delivery_time <= now + 1e-12:
            delivered = True
            self._accept(self.queue.popleft(), now)

        if self.state is None:
            # Latency on the first frame must not deprive the controller of a
            # pose. Initialize from the first queued sample while retaining its
            # scheduled delivery for later normal filtering.
            if self.queue:
                first = self.queue[0]
                self.state = _FilterState(
                    pose=first.world_pose,
                    time=now,
                    last_measurement_time=first.sample_time,
                )
                self.accepted_count += 1
                self.last_status = "bootstrap"
            else:
                truth_world = _relative_to_world(vehicle_pose_world, truth_relative)
                self.state = _FilterState(
                    pose=truth_world,
                    time=now,
                    last_measurement_time=now,
                )
                self.last_status = "truth_bootstrap"
        else:
            self._predict_to(now)
            if not delivered and self.last_status not in ("dropout", "rejected"):
                self.last_status = "predicted"

        estimate_relative = _world_to_relative(vehicle_pose_world, self.state.pose)
        position_error = math.hypot(
            estimate_relative.x - truth_relative.x,
            estimate_relative.y - truth_relative.y,
        )
        yaw_error = math.degrees(
            abs(wrap_angle(estimate_relative.yaw - truth_relative.yaw))
        )
        stale = max(0.0, now - self.state.last_measurement_time)
        diagnostics = TargetDiagnostics(
            status=self.last_status,
            sample_count=self.sample_count,
            accepted_count=self.accepted_count,
            dropout_count=self.dropout_count,
            rejected_count=self.rejected_count,
            stale_seconds=stale,
            raw_position_error_m=self.last_raw_position_error_m,
            raw_yaw_error_deg=self.last_raw_yaw_error_deg,
            filtered_position_error_m=position_error,
            filtered_yaw_error_deg=yaw_error,
        )
        return estimate_relative, diagnostics


class PosePipeline:
    """Apply a selected noisy-pose profile to synchronized observations."""

    def __init__(
        self,
        *,
        profile_name: str,
        profile: PerceptionProfile,
        seed: int,
    ) -> None:
        self.profile_name = str(profile_name)
        self.profile = profile
        self.seed = int(seed)
        self.pallet = _TargetEstimator(profile, seed=self.seed ^ 0xA511E9B3)
        self.placement = _TargetEstimator(profile, seed=self.seed ^ 0x63D83595)
        self._last_time: float | None = None

    @classmethod
    def from_config(
        cls,
        perception_config: Mapping[str, Any],
        *,
        profile_name: str | None,
        seed: int,
    ) -> "PosePipeline":
        profiles = perception_config.get("profiles")
        if not isinstance(profiles, Mapping):
            raise KeyError("perception.profiles")
        selected = str(
            profile_name
            if profile_name is not None
            else perception_config.get("default_profile", "clean")
        )
        if selected not in profiles:
            options = ", ".join(sorted(str(key) for key in profiles))
            raise ValueError(
                f"unknown perception profile {selected!r}; choose from: {options}"
            )
        return cls(
            profile_name=selected,
            profile=PerceptionProfile.from_mapping(profiles[selected]),
            seed=int(seed) + int(perception_config.get("seed_offset", 0)),
        )

    def reset(self) -> None:
        self.pallet.reset()
        self.placement.reset()
        self._last_time = None

    def step(self, truth: ForkliftObservation) -> PerceptionFrame:
        now = float(truth.sim_time)
        if self._last_time is not None and now + 1e-9 < self._last_time:
            self.reset()
        self._last_time = now
        pallet_pose, pallet_diag = self.pallet.step(
            now=now,
            vehicle_pose_world=truth.vehicle_pose_world,
            truth_relative=truth.pallet_pose_in_base,
            force_initial=True,
        )
        placement_pose, placement_diag = self.placement.step(
            now=now,
            vehicle_pose_world=truth.vehicle_pose_world,
            truth_relative=truth.placement_pose_in_base,
            force_initial=True,
        )
        estimated = replace(
            truth,
            pallet_pose_in_base=pallet_pose,
            placement_pose_in_base=placement_pose,
        )
        return PerceptionFrame(
            observation=estimated,
            pallet=pallet_diag,
            placement=placement_diag,
            profile_name=self.profile_name,
        )
