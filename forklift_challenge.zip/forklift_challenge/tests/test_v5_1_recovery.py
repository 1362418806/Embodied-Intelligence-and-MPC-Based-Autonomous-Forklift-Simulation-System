"""V5.1 state-machine tests for progress, rolling ALIGN and recovery."""

from __future__ import annotations

from dataclasses import replace
import math

from control.docking_controller import DockingController
from interfaces.observation import ForkliftObservation, Pose3D
from task.pickup_state_machine import (
    PickupParameters,
    PickupState,
    PickupStateMachine,
)


def make_pose(
    x: float = 0.0,
    y: float = 0.0,
    z: float = 0.0,
    roll: float = 0.0,
    pitch: float = 0.0,
    yaw: float = 0.0,
) -> Pose3D:
    return Pose3D(x=x, y=y, z=z, roll=roll, pitch=pitch, yaw=yaw)


def observation(
    *,
    sim_time: float,
    pallet_x: float,
    pallet_y: float = 0.0,
    pallet_yaw: float = 0.0,
    vehicle_x: float = 0.0,
    vehicle_y: float = 0.0,
    lift_position: float = 0.04,
    lift_velocity: float = 0.0,
    load_state: str = "GROUND",
) -> ForkliftObservation:
    return ForkliftObservation(
        sim_time=sim_time,
        vehicle_pose_world=make_pose(vehicle_x, vehicle_y, z=0.58),
        vehicle_linear_velocity=(0.0, 0.0, 0.0),
        vehicle_angular_velocity=(0.0, 0.0, 0.0),
        steering_left=0.0,
        steering_right=0.0,
        front_wheel_speed_left=0.0,
        front_wheel_speed_right=0.0,
        lift_position=lift_position,
        lift_velocity=lift_velocity,
        pallet_pose_world=make_pose(3.2, 0.0),
        pallet_pose_in_base=make_pose(
            pallet_x,
            pallet_y,
            yaw=pallet_yaw,
        ),
        placement_pose_in_base=make_pose(5.2, -1.5),
        fork_contact_count=0,
        load_state=load_state,
    )


def parameters() -> PickupParameters:
    return PickupParameters(
        insertion_lift_target=0.04,
        transport_lift_target=0.30,
        pre_approach_distance=2.85,
        insertion_distance=1.60,
        approach_max_speed=0.32,
        align_max_speed=0.13,
        insertion_max_speed=0.09,
        retreat_speed=-0.18,
        retreat_distance=0.75,
        approach_capture_distance=0.42,
        pre_position_tolerance=0.085,
        pre_lateral_tolerance=0.060,
        pre_yaw_tolerance=0.075,
        insertion_position_tolerance=0.055,
        insertion_lateral_tolerance=0.045,
        insertion_yaw_tolerance=0.060,
        lift_position_tolerance=0.055,
        lift_velocity_tolerance=0.015,
        lifted_minimum_fork_height=0.12,
        verify_lift_seconds=0.60,
        maximum_load_tilt=0.175,
        lower_timeout=4.0,
        approach_timeout=35.0,
        align_timeout=20.0,
        insert_timeout=18.0,
        lift_timeout=8.0,
        retreat_timeout=10.0,
        align_minimum_speed=0.075,
        alignment_hold_seconds=0.35,
        progress_timeout=1.0,
        progress_improvement=0.018,
        recovery_speed=-0.16,
        recovery_distance=0.48,
        recovery_timeout=6.0,
        maximum_recoveries=2,
        overshoot_longitudinal_tolerance=0.10,
    )


def machine(params: PickupParameters | None = None) -> PickupStateMachine:
    return PickupStateMachine(
        parameters=params or parameters(),
        docking_controller=DockingController(
            distance_gain=0.78,
            heading_gain=1.45,
            yaw_gain=0.72,
            lateral_gain=0.82,
            lookahead_distance=0.95,
            maximum_steering=0.36,
            minimum_creep_speed=0.055,
            heading_slowdown_angle=0.75,
            yaw_slowdown_angle=0.52,
            minimum_alignment_scale=0.32,
        ),
    )


def enter_approach(state_machine: PickupStateMachine) -> None:
    state_machine.reset(0.0)
    decision = state_machine.step(
        observation(sim_time=0.30, pallet_x=4.0)
    )
    assert decision.state == PickupState.APPROACH


def test_stalled_approach_enters_bounded_reverse_recovery() -> None:
    state_machine = machine()
    enter_approach(state_machine)

    state_machine.step(observation(sim_time=0.40, pallet_x=4.0, pallet_y=0.2))
    decision = state_machine.step(
        observation(sim_time=1.41, pallet_x=4.0, pallet_y=0.2)
    )

    assert decision.state == PickupState.RECOVER_REVERSE
    assert decision.action.speed_target < 0.0
    assert decision.action.steering_command == 0.0
    assert decision.recovery_count == 1
    assert decision.recovery_reason is not None
    assert "no progress" in decision.recovery_reason


def test_recovery_distance_returns_to_replanned_approach() -> None:
    state_machine = machine()
    enter_approach(state_machine)
    state_machine.step(observation(sim_time=0.40, pallet_x=4.0, pallet_y=0.2))
    decision = state_machine.step(
        observation(sim_time=1.41, pallet_x=4.0, pallet_y=0.2)
    )
    assert decision.state == PickupState.RECOVER_REVERSE

    decision = state_machine.step(
        observation(
            sim_time=2.0,
            pallet_x=4.5,
            pallet_y=0.2,
            vehicle_x=-0.50,
        )
    )
    assert decision.state == PickupState.APPROACH
    assert decision.action.speed_target == 0.0


def test_rolling_align_keeps_creep_speed_until_tolerances_hold() -> None:
    state_machine = machine()
    enter_approach(state_machine)

    decision = state_machine.step(
        observation(sim_time=0.50, pallet_x=3.10, pallet_y=0.10)
    )
    assert decision.state == PickupState.ALIGN

    decision = state_machine.step(
        observation(
            sim_time=0.60,
            pallet_x=2.92,
            pallet_y=0.075,
            pallet_yaw=math.radians(5.0),
        )
    )
    assert decision.state == PickupState.ALIGN
    assert decision.action.speed_target >= 0.075
    assert abs(decision.action.steering_command) > 0.0


def test_alignment_must_hold_before_insert() -> None:
    state_machine = machine()
    enter_approach(state_machine)
    assert state_machine.step(
        observation(sim_time=0.50, pallet_x=2.90)
    ).state == PickupState.ALIGN

    first = state_machine.step(
        observation(sim_time=0.60, pallet_x=2.85)
    )
    assert first.state == PickupState.ALIGN
    assert first.action.speed_target == 0.0

    held = state_machine.step(
        observation(sim_time=0.96, pallet_x=2.85)
    )
    assert held.state == PickupState.INSERT


def test_recovery_limit_fails_instead_of_looping_forever() -> None:
    params = replace(
        parameters(),
        maximum_recoveries=0,
    )
    state_machine = machine(params)
    enter_approach(state_machine)
    state_machine.step(observation(sim_time=0.40, pallet_x=4.0))
    decision = state_machine.step(observation(sim_time=1.41, pallet_x=4.0))

    assert decision.state == PickupState.FAILED
    assert decision.failure_reason is not None
    assert "no progress" in decision.failure_reason
