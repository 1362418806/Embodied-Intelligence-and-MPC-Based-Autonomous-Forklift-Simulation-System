"""Tests for V6.1 runway creation and smooth loaded path tracking."""

from __future__ import annotations

import math
from pathlib import Path

import yaml

from control.docking_controller import DockingController, wrap_angle
from control.transport_path import (
    build_cubic_transport_path,
    relative_pose_in_frame,
    relative_pose_to_world,
    track_transport_path,
)
from interfaces.observation import ForkliftObservation, Pose3D
from task.pickup_state_machine import (
    PickupParameters,
    PickupState,
    PickupStateMachine,
)


def pose(x: float = 0.0, y: float = 0.0, yaw: float = 0.0) -> Pose3D:
    return Pose3D(x=x, y=y, z=0.0, roll=0.0, pitch=0.0, yaw=yaw)


def observation(
    sim_time: float,
    *,
    vehicle_x: float = 0.0,
    vehicle_y: float = 0.0,
    vehicle_yaw: float = 0.0,
    pallet_base: Pose3D | None = None,
    placement_base: Pose3D | None = None,
    steering_left: float = 0.0,
    steering_right: float = 0.0,
) -> ForkliftObservation:
    return ForkliftObservation(
        sim_time=sim_time,
        vehicle_pose_world=pose(vehicle_x, vehicle_y, vehicle_yaw),
        vehicle_linear_velocity=(0.0, 0.0, 0.0),
        vehicle_angular_velocity=(0.0, 0.0, 0.0),
        steering_left=steering_left,
        steering_right=steering_right,
        front_wheel_speed_left=0.0,
        front_wheel_speed_right=0.0,
        lift_position=0.30,
        lift_velocity=0.0,
        pallet_pose_world=pose(2.5, 0.0),
        pallet_pose_in_base=pallet_base or pose(1.60, 0.0),
        placement_pose_in_base=placement_base or pose(5.20, -1.50),
        fork_contact_count=4,
        load_state="LIFTED",
    )


def machine() -> PickupStateMachine:
    root = Path(__file__).resolve().parents[1]
    config = yaml.safe_load(
        (root / "configs" / "vehicle_v6_1.yaml").read_text(encoding="utf-8")
    )
    values = config["controller"]
    return PickupStateMachine(
        parameters=PickupParameters.from_mapping(config["autonomy"]),
        docking_controller=DockingController(
            distance_gain=values["distance_gain"],
            heading_gain=values["heading_gain"],
            yaw_gain=values["yaw_gain"],
            lateral_gain=values["lateral_gain"],
            lookahead_distance=values["lookahead_distance"],
            maximum_steering=values["maximum_steering"],
            minimum_creep_speed=values["minimum_creep_speed"],
            heading_slowdown_angle=values["heading_slowdown_angle"],
            yaw_slowdown_angle=values["yaw_slowdown_angle"],
            minimum_alignment_scale=values["minimum_alignment_scale"],
        ),
    )


def test_relative_pose_composition_round_trip() -> None:
    frame = pose(1.2, -0.7, 0.4)
    relative = pose(3.0, -1.1, -0.2)
    world = relative_pose_to_world(frame, relative)
    recovered = relative_pose_in_frame(world, frame)
    assert math.isclose(recovered.x, relative.x, abs_tol=1e-9)
    assert math.isclose(recovered.y, relative.y, abs_tol=1e-9)
    assert math.isclose(recovered.yaw, relative.yaw, abs_tol=1e-9)


def test_bezier_path_has_exact_endpoints() -> None:
    start = pose(-3.5, 0.1, 0.03)
    goal = pose(2.7, -1.5, 0.15)
    path = build_cubic_transport_path(
        start,
        goal,
        handle_scale=0.40,
        sample_count=221,
    )
    assert path.points[0] == (start.x, start.y)
    assert path.points[-1] == (goal.x, goal.y)
    assert path.total_length > math.hypot(goal.x - start.x, goal.y - start.y)


def test_pure_pursuit_tracks_representative_loaded_lane_change() -> None:
    path = build_cubic_transport_path(
        pose(),
        pose(6.2, -1.5, 0.20),
        handle_scale=0.40,
        sample_count=221,
    )
    x = y = yaw = 0.0
    progress = 0
    captured = False
    maximum_steering = 0.0
    timestep = 0.02
    for _ in range(int(100.0 / timestep)):
        command = track_transport_path(
            path,
            pose(x, y, yaw),
            previous_index=progress,
            wheelbase=0.93,
            lookahead_distance=0.90,
            maximum_speed=0.32,
            minimum_speed=0.10,
            steering_limit=0.24,
            lift_target=0.30,
            capture_distance=0.30,
            goal_yaw_tolerance=0.20,
        )
        progress = command.progress_index
        steering = command.action.steering_command
        maximum_steering = max(maximum_steering, abs(steering))

        # Approximate the measured loaded-vehicle speed loss at large steering.
        if abs(steering) <= 0.15:
            traction_scale = 1.0
        else:
            ratio = (abs(steering) - 0.15) / (0.28 - 0.15)
            traction_scale = max(0.08, 1.0 - 0.92 * ratio**1.3)
        speed = command.action.speed_target * traction_scale
        x += speed * math.cos(yaw) * timestep
        y += speed * math.sin(yaw) * timestep
        yaw = wrap_angle(
            yaw + speed * math.tan(steering) / 0.93 * timestep
        )

        if (
            command.goal_distance <= 0.30
            and abs(command.goal_yaw_error) <= 0.20
        ):
            captured = True
            break

    assert captured
    assert maximum_steering <= 0.24 + 1e-12
    assert math.hypot(6.2 - x, -1.5 - y) <= 0.32
    assert abs(wrap_angle(0.20 - yaw)) <= 0.20


def test_retreat_transitions_to_transport_reposition() -> None:
    state_machine = machine()
    state_machine.state = PickupState.RETREAT
    state_machine._state_enter_time = 0.0
    state_machine._retreat_start_xy = (0.0, 0.0)
    decision = state_machine.step(observation(1.0, vehicle_x=-0.80))
    assert decision.state == PickupState.TRANSPORT_REPOSITION
    assert decision.action.speed_target == 0.0


def test_reposition_establishes_runway_before_building_path() -> None:
    state_machine = machine()
    state_machine.state = PickupState.TRANSPORT_REPOSITION
    state_machine._state_enter_time = 0.0
    state_machine._transport_reposition_start_xy = (0.0, 0.0)

    # target_load pre-position: 8.65 - 0.85 = 7.80m; subtract the
    # carried-pallet offset 1.60m to obtain a 6.20m vehicle target.
    ready = observation(
        15.0,
        vehicle_x=-3.30,
        pallet_base=pose(1.60, 0.0),
        placement_base=pose(8.65, -1.50),
    )
    decision = state_machine.step(ready)
    assert decision.state == PickupState.TRANSPORT_APPROACH
    assert decision.action.speed_target == 0.0

    following = state_machine.step(ready)
    assert following.state == PickupState.TRANSPORT_APPROACH
    assert following.action.speed_target > 0.0
    assert "smooth loaded lane-change path" in following.status
