# V9.2.1 Integration Guide

## 1. Create the controller once per mission controller instance

```python
from forklift_v9_2_1_terminal_precision import Pose2D, TerminalPrecisionController

self.terminal_precision = TerminalPrecisionController()
```

## 2. Initialize carried-pallet pose after stable pickup/lift

Use the last trusted measured/fused pallet pose in the forklift base frame. Do not use MuJoCo truth.

```python
self.terminal_precision.reset(
    Pose2D(
        x=fused_pallet_pose_in_base.x,
        y=fused_pallet_pose_in_base.y,
        yaw=fused_pallet_pose_in_base.yaw,
    )
)
```

If a trusted post-pickup carried-pallet measurement is available later, refresh it:

```python
self.terminal_precision.update_carried_pallet_pose(
    Pose2D(
        x=fused_carried_pallet_pose_in_base.x,
        y=fused_carried_pallet_pose_in_base.y,
        yaw=fused_carried_pallet_pose_in_base.yaw,
    )
)
```

## 3. Call the controller in terminal alignment

`actual_speed_mps` must be **signed longitudinal chassis speed**. If the existing signal is only an unsigned speed magnitude, do not pass it until a signed signal is available.

```python
decision = self.terminal_precision.step(
    target_pose_in_base=Pose2D(
        x=placement_pose_in_base.x,
        y=placement_pose_in_base.y,
        yaw=placement_pose_in_base.yaw,
    ),
    dt_s=dt,
    max_curvature_1pm=vehicle_max_curvature,
    measurement_valid=placement_measurement_is_valid,
    measurement_age_s=placement_measurement_age_s,
    actual_speed_mps=signed_longitudinal_speed_mps,
)
```

When `decision.authoritative` is false, keep the existing V9.2 outer terminal approach. When true, convert `decision.curvature_1pm` through the existing Ackermann steering layer and use `decision.speed_mps` as the local speed command.

## 4. Preserve the existing downstream safety chain

The new precision command must pass through the existing collision guard / guard-brake / actuator limiting code. Do not bypass it.

## 5. Re-entry

When `decision.request_reentry` is true, transition to the existing terminal re-entry/recovery state. Call:

```python
self.terminal_precision.mark_reentry_started()
```

when re-entry starts.

## 6. Release

On the precision path, begin lowering only when:

```python
decision.release_ready
```

is true. The default release gate is `< 0.070 m`, `< 3 deg`, continuously for `0.70 s`.

Keep the existing V9.2 75/90 s hard terminal budget as the final watchdog.

## 7. Required diagnostics

Add estimated-control diagnostics:

```text
terminal_precision_mode
terminal_precision_position_error_m
terminal_precision_yaw_error_deg
terminal_precision_goal_x_m
terminal_precision_goal_y_m
terminal_precision_goal_yaw_deg
terminal_precision_command_speed_mps
terminal_precision_command_curvature_1pm
terminal_precision_progress_cost
terminal_precision_best_progress_cost
terminal_precision_stagnation_s
terminal_precision_release_ready
terminal_precision_reentry_request_count
```

Add evaluator-only truth diagnostics:

```text
release_truth_error_x_m
release_truth_error_y_m
release_truth_error_yaw_deg
grounded_truth_error_x_m
grounded_truth_error_y_m
final_truth_error_x_m
final_truth_error_y_m
carried_pallet_relative_drift_position_m
carried_pallet_relative_drift_yaw_deg
```

Never feed these truth values back into the controller.

## 8. Validation order

```powershell
python scripts\verify_v9_2_1_patch.py
```

Then run the existing V9.2 failing seeds first, followed by the full release matrix. Do not change pickup, perception, physics, or competition thresholds during this validation cycle.
