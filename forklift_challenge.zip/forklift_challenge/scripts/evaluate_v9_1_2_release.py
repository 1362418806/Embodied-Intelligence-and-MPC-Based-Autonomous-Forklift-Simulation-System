"""Evaluate V9.1.2 stable-settle release candidate."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys
PROJECT_ROOT=Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path: sys.path.insert(0,str(PROJECT_ROOT))
from evaluation.release_qualification import (
    COMBINED_INFORMATIONAL, FORMAL_THRESHOLDS, ReleaseThresholds,
    overall_pass, qualify_summary_file,
)
PROMOTION={
    "moderate_easy": ReleaseThresholds(minimum_success_rate=0.90),
    "moderate_nominal": ReleaseThresholds(minimum_success_rate=0.85),
    "finals_easy": ReleaseThresholds(minimum_success_rate=0.70),
}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--moderate-easy',type=Path,required=True)
    p.add_argument('--moderate-nominal',type=Path,required=True)
    p.add_argument('--finals-easy',type=Path,required=True)
    p.add_argument('--combined',type=Path)
    p.add_argument('--output',type=Path,default=PROJECT_ROOT/'outputs'/'v9_1_2_release_report')
    a=p.parse_args()
    paths={'moderate_easy':a.moderate_easy,'moderate_nominal':a.moderate_nominal,'finals_easy':a.finals_easy}
    historical=[qualify_summary_file(paths[k],label=k,thresholds=FORMAL_THRESHOLDS[k]) for k in paths]
    promotion=[qualify_summary_file(paths[k],label=k,thresholds=PROMOTION[k]) for k in paths]
    combined=None
    if a.combined:
        combined=qualify_summary_file(a.combined,label='finals_combined',thresholds=COMBINED_INFORMATIONAL,hard_gate=False)
    historical_pass=overall_pass(historical)
    promotion_pass=overall_pass(promotion)
    precision={}
    for k,path in paths.items():
        s=json.loads(path.read_text(encoding='utf-8'))
        precision[k]={
            'rate':s.get('competition_precision_success_rate',0.0),
            'count':s.get('competition_precision_success_count',0),
            'episodes':s.get('episode_count',0),
            'position_rate':s.get('competition_position_pass_rate',0.0),
            'yaw_rate':s.get('competition_yaw_pass_rate',0.0),
        }
    a.output.mkdir(parents=True,exist_ok=True)
    payload={
        'schema':'forklift_v9_1_2_release_qualification_v1',
        'generated_at_utc':datetime.now(timezone.utc).isoformat(),
        'historical_pass':historical_pass,
        'promotion_pass':promotion_pass,
        'historical_results':[r.to_dict() for r in historical],
        'promotion_results':[r.to_dict() for r in promotion],
        'combined_result':None if combined is None else combined.to_dict(),
        'competition_precision':precision,
        'policy':{
            'geometry_compensation_used':False,
            'competition_position_limit_m':0.10,
            'competition_yaw_limit_deg':5.0,
        },
    }
    (a.output/'qualification.json').write_text(json.dumps(payload,indent=2),encoding='utf-8')
    lines=['# V9.1.2 Release Qualification','',f"Historical 80/70/50: **{'PASS' if historical_pass else 'FAIL'}**",f"Promotion 90/85/70: **{'PASS' if promotion_pass else 'FAIL'}**",'', '## Competition precision']
    for k,v in precision.items(): lines.append(f"- {k}: {v['count']}/{v['episodes']} = {v['rate']:.1%} (position={v['position_rate']:.1%}, yaw={v['yaw_rate']:.1%})")
    lines += ['', 'No terminal geometric compensation/offset is used in V9.1.2.']
    (a.output/'qualification.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(f"V9.1.2 historical 80/70/50 baseline: {'PASS' if historical_pass else 'FAIL'}")
    print(f"V9.1.2 promotion 90/85/70: {'PASS' if promotion_pass else 'FAIL'}")
    for k,v in precision.items(): print(f"  {k} competition <0.10m/<5deg: {v['count']}/{v['episodes']} = {v['rate']:.1%}")
    if combined is not None: print(f"  finals_combined: {'PASS' if combined.passed else 'FAIL'} [informational]")
    print(f"report: {a.output.resolve()}")
    return 0 if promotion_pass else 2
if __name__=='__main__': raise SystemExit(main())
