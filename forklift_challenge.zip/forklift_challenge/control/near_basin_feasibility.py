"""V9.3.11 bounded task-space feasibility escrow for Ackermann terminal tails."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class NearBasinFeasibilityConfig:
    activation_distance_m: float
    activation_yaw_rad: float
    maximum_predicted_distance_m: float
    position_scale_m: float
    yaw_scale_rad: float
    required_deficit_improvement: float
    allowed_active_regression: float
    max_seconds: float
    max_activations: int

    def validate(self) -> None:
        if self.activation_distance_m <= 0.0:
            raise ValueError("near-basin activation distance must be positive")
        if self.activation_yaw_rad <= 0.0:
            raise ValueError("near-basin activation yaw must be positive")
        if self.maximum_predicted_distance_m < self.activation_distance_m:
            raise ValueError("near-basin predicted distance must cover activation distance")
        if self.position_scale_m <= 0.0 or self.yaw_scale_rad <= 0.0:
            raise ValueError("near-basin deficit scales must be positive")
        if self.required_deficit_improvement <= 0.0:
            raise ValueError("near-basin required improvement must be positive")
        if self.allowed_active_regression < 0.0:
            raise ValueError("near-basin allowed regression must be non-negative")
        if self.max_seconds <= 0.0:
            raise ValueError("near-basin max_seconds must be positive")
        if self.max_activations <= 0:
            raise ValueError("near-basin max_activations must be positive")


class NearBasinFeasibilityEscrow:
    """Allows one bounded nonholonomic arc when competition deficit improves.

    The escrow never commands motion. It only answers whether an MPC plan that
    would otherwise be rejected by the generic progress corridor is justified
    by a reduction in normalized competition-boundary deficit.
    """

    def __init__(self, config: NearBasinFeasibilityConfig) -> None:
        config.validate()
        self.config = config
        self.reset()

    def reset(self) -> None:
        self.active_until: float | None = None
        self.activation_count = 0
        self.accepted_plan_count = 0
        self.last_current_deficit = 0.0
        self.last_predicted_deficit = 0.0
        self.last_improvement = 0.0

    def deficit(
        self,
        *,
        distance_m: float,
        abs_yaw_rad: float,
        position_limit_m: float,
        yaw_limit_rad: float,
    ) -> float:
        c = self.config
        position_overrun = max(0.0, float(distance_m) - float(position_limit_m))
        yaw_overrun = max(0.0, float(abs_yaw_rad) - float(yaw_limit_rad))
        return position_overrun / c.position_scale_m + yaw_overrun / c.yaw_scale_rad

    def allow(
        self,
        now: float,
        *,
        current_distance_m: float,
        current_abs_yaw_rad: float,
        predicted_distance_m: float,
        predicted_abs_yaw_rad: float,
        position_limit_m: float,
        yaw_limit_rad: float,
    ) -> bool:
        now = float(now)
        c = self.config
        current = self.deficit(
            distance_m=current_distance_m,
            abs_yaw_rad=current_abs_yaw_rad,
            position_limit_m=position_limit_m,
            yaw_limit_rad=yaw_limit_rad,
        )
        predicted = self.deficit(
            distance_m=predicted_distance_m,
            abs_yaw_rad=predicted_abs_yaw_rad,
            position_limit_m=position_limit_m,
            yaw_limit_rad=yaw_limit_rad,
        )
        improvement = current - predicted
        self.last_current_deficit = float(current)
        self.last_predicted_deficit = float(predicted)
        self.last_improvement = float(improvement)

        active = self.active_until is not None and now <= self.active_until
        candidate = bool(
            current > 0.0
            and current_distance_m <= c.activation_distance_m
            and current_abs_yaw_rad <= c.activation_yaw_rad
            and predicted_distance_m <= c.maximum_predicted_distance_m
            and predicted_abs_yaw_rad <= current_abs_yaw_rad + 0.017453292519943295
            and improvement >= c.required_deficit_improvement
            and self.activation_count < c.max_activations
        )
        if candidate and not active:
            self.activation_count += 1
            self.active_until = now + c.max_seconds
            active = True

        safe_while_active = bool(
            active
            and predicted_distance_m <= c.maximum_predicted_distance_m
            and predicted <= current + c.allowed_active_regression
        )
        allowed = bool(candidate or safe_while_active)
        if allowed:
            self.accepted_plan_count += 1
        return allowed
