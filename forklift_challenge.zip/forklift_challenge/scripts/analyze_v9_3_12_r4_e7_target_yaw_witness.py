"""Analyze V9.3.12-R4-E7 dual-PnP target-yaw witness behavior.

Primary diagnosis uses controller-visible trace fields only. Ground-truth yaw
comparisons are explicitly reported under a diagnostic_* prefix and are offline
evaluation only; they never feed runtime control.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from statistics import median
from typing import Any


def wrap_deg(value: float) -> float:
    return (float(value) + 180.0) % 360.0 - 180.0


def _safe_last(rows: list[dict[str, Any]], path: tuple[str, ...], default: Any = None) -> Any:
    for row in reversed(rows):
        value: Any = row
        ok = True
        for key in path:
            if not isinstance(value, dict) or key not in value:
                ok = False
                break
            value = value[key]
        if ok and value is not None:
            return value
    return default


def analyze(path: Path) -> dict[str, Any]:
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    witness_samples: list[dict[str, float]] = []
    previous_sample_count = -1
    first_applied_time = None

    for row in rows:
        marker = row.get("vision_marker") or {}
        gt = row.get("ground_truth_observation") or {}
        est = row.get("estimated_observation") or {}
        sample_count = int(marker.get("sample_count") or 0)
        applied = int(marker.get("center_yaw_witness_applied_count") or 0)
        sim_time = gt.get("sim_time")

        if first_applied_time is None and applied > 0 and sim_time is not None:
            first_applied_time = float(sim_time)

        # Deduplicate the persisted diagnostics: only take newly sampled RGB.
        if sample_count <= previous_sample_count:
            continue
        previous_sample_count = sample_count

        corner = marker.get("center_yaw_witness_last_corner_yaw_deg")
        center = marker.get("center_yaw_witness_last_center_yaw_deg")
        gt_target = (gt.get("placement_pose_in_base") or {}).get("yaw")
        est_target = (est.get("placement_pose_in_base") or {}).get("yaw")
        if corner is None or center is None:
            continue

        item: dict[str, float] = {
            "time_s": float(sim_time or 0.0),
            "corner_yaw_deg": float(corner),
            "center_yaw_deg": float(center),
            "delta_deg": wrap_deg(float(center) - float(corner)),
            "consensus_samples": float(marker.get("center_yaw_witness_consensus_samples") or 0),
            "consensus_delta_deg": float(marker.get("center_yaw_witness_consensus_delta_deg") or 0.0),
            "delta_spread_deg": float(marker.get("center_yaw_witness_delta_spread_deg") or 0.0),
        }
        if gt_target is not None:
            gt_deg = math.degrees(float(gt_target))
            item["truth_target_yaw_deg"] = gt_deg
            item["corner_abs_error_deg"] = abs(wrap_deg(float(corner) - gt_deg))
            item["center_abs_error_deg"] = abs(wrap_deg(float(center) - gt_deg))
        if est_target is not None and gt_target is not None:
            item["fused_target_abs_error_deg"] = abs(
                wrap_deg(math.degrees(float(est_target)) - math.degrees(float(gt_target)))
            )
        witness_samples.append(item)

    marker_last = _safe_last(rows, ("vision_marker",), {}) or {}
    decision_last = _safe_last(rows, ("decision",), {}) or {}

    corner_errors = [s["corner_abs_error_deg"] for s in witness_samples if "corner_abs_error_deg" in s]
    center_errors = [s["center_abs_error_deg"] for s in witness_samples if "center_abs_error_deg" in s]
    fused_errors = [s["fused_target_abs_error_deg"] for s in witness_samples if "fused_target_abs_error_deg" in s]
    deltas = [abs(s["delta_deg"]) for s in witness_samples]

    release_commit = int(decision_last.get("placement_release_commit_count") or 0)
    strict = bool(decision_last.get("strict_release_certified", False))
    final_blocker = decision_last.get("strict_release_certification_blocker")
    applied_count = int(marker_last.get("center_yaw_witness_applied_count") or 0)

    if release_commit > 0:
        diagnosis = "RELEASED_TARGET_YAW_CLUSTER_CLOSED"
    elif applied_count <= 0:
        diagnosis = "CENTER_YAW_WITNESS_NOT_ACTIVE"
    elif corner_errors and center_errors:
        corner_med = median(corner_errors)
        center_med = median(center_errors)
        if center_med + 0.20 < corner_med:
            diagnosis = "CENTER_YAW_WITNESS_IMPROVES_TARGET_YAW_RELEASE_STILL_OPEN"
        elif center_med > corner_med + 0.20:
            diagnosis = "CENTER_YAW_WITNESS_REGRESSION_REVERT_TO_LEGACY"
        else:
            diagnosis = "CENTER_YAW_WITNESS_AMBIGUOUS"
    else:
        diagnosis = "CENTER_YAW_WITNESS_ACTIVE_NO_GT_DIAGNOSTIC"

    # E6 recenter/liveness telemetry remains important to detect regressions.
    result = {
        "trace": str(path),
        "samples": len(rows),
        "diagnosis": diagnosis,
        "witness_applied_count": applied_count,
        "witness_rejected_count": int(marker_last.get("center_yaw_witness_rejected_count") or 0),
        "witness_consensus_samples_final": int(marker_last.get("center_yaw_witness_consensus_samples") or 0),
        "witness_consensus_delta_deg_final": marker_last.get("center_yaw_witness_consensus_delta_deg"),
        "witness_delta_spread_deg_final": marker_last.get("center_yaw_witness_delta_spread_deg"),
        "first_witness_applied_time_s": first_applied_time,
        "sampled_center_corner_pair_count": len(witness_samples),
        "median_abs_center_corner_delta_deg": median(deltas) if deltas else None,
        "position_recenter_activation_count": int(decision_last.get("placement_position_blocker_recenter_activation_count") or 0),
        "position_recenter_measured_effective_position_m": decision_last.get("placement_position_blocker_recenter_last_measured_effective_position_m"),
        "position_recenter_measured_effective_yaw_deg": decision_last.get("placement_position_blocker_recenter_last_measured_effective_yaw_deg"),
        "position_to_yaw_handoff_count": int(decision_last.get("placement_position_blocker_recenter_yaw_handoff_count") or 0),
        "strict_certified": strict,
        "strict_blocker": final_blocker,
        "release_commit_count": release_commit,
        "release_witness_capture_count": int(decision_last.get("release_witness_capture_count") or 0),
        "terminal_reacq_updates": int(decision_last.get("terminal_load_reacquisition_update_count") or 0),
        "diagnostic_corner_target_yaw_median_abs_error_deg": median(corner_errors) if corner_errors else None,
        "diagnostic_center_target_yaw_median_abs_error_deg": median(center_errors) if center_errors else None,
        "diagnostic_fused_target_yaw_median_abs_error_deg": median(fused_errors) if fused_errors else None,
        "diagnostic_center_minus_corner_median_abs_error_improvement_deg": (
            median(corner_errors) - median(center_errors)
            if corner_errors and center_errors else None
        ),
    }
    return result


def render_md(result: dict[str, Any]) -> str:
    lines = [
        "# V9.3.12-R4-E7 target-yaw witness analysis",
        "",
        f"- Diagnosis: **{result['diagnosis']}**",
        f"- Trace samples: {result['samples']}",
        f"- Witness applied/rejected: {result['witness_applied_count']} / {result['witness_rejected_count']}",
        f"- Witness final consensus samples: {result['witness_consensus_samples_final']}",
        f"- Witness final consensus delta: {result['witness_consensus_delta_deg_final']} deg",
        f"- Witness final delta spread: {result['witness_delta_spread_deg_final']} deg",
        f"- First witness applied: {result['first_witness_applied_time_s']} s",
        f"- Median |center-corner| yaw delta: {result['median_abs_center_corner_delta_deg']} deg",
        "",
        "## Controller-visible closure",
        f"- POSITION recenter activations: {result['position_recenter_activation_count']}",
        f"- POSITION recenter measured effective position: {result['position_recenter_measured_effective_position_m']} m",
        f"- POSITION recenter measured effective yaw: {result['position_recenter_measured_effective_yaw_deg']} deg",
        f"- POSITION->YAW handoffs: {result['position_to_yaw_handoff_count']}",
        f"- Strict certified: {result['strict_certified']}",
        f"- Final strict blocker: {result['strict_blocker']}",
        f"- Release commits: {result['release_commit_count']}",
        f"- Witness captures: {result['release_witness_capture_count']}",
        "",
        "## Offline GT diagnostic only",
        f"- Legacy corner-PnP target-yaw median abs error: {result['diagnostic_corner_target_yaw_median_abs_error_deg']} deg",
        f"- Centre-PnP target-yaw median abs error: {result['diagnostic_center_target_yaw_median_abs_error_deg']} deg",
        f"- Fused target-yaw median abs error: {result['diagnostic_fused_target_yaw_median_abs_error_deg']} deg",
        f"- Centre minus corner median-error improvement: {result['diagnostic_center_minus_corner_median_abs_error_improvement_deg']} deg",
        "",
        "> Ground truth in this section is analyzer-only and is not consumed by runtime control.",
        "",
    ]
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("trace", type=Path)
    parser.add_argument("--output-json", type=Path)
    parser.add_argument("--output-md", type=Path)
    args = parser.parse_args()
    result = analyze(args.trace)

    print("V9.3.12-R4-E7 target-yaw witness analysis")
    for key, value in result.items():
        print(f"  {key}: {value}")

    if args.output_json:
        args.output_json.parent.mkdir(parents=True, exist_ok=True)
        args.output_json.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    if args.output_md:
        args.output_md.parent.mkdir(parents=True, exist_ok=True)
        args.output_md.write_text(render_md(result), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
