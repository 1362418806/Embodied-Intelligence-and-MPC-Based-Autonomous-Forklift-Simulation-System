"""V9.3.12 bounded SE(2) micro-primitive search for the final Ackermann tail."""

from __future__ import annotations

from dataclasses import dataclass
import math

from control.terminal_mpc import TerminalKinematicMPC


@dataclass(frozen=True)
class TerminalMicroPrimitiveConfig:
    wheelbase_m: float
    steering_limit_rad: float
    speed_mps: float
    activation_distance_m: float
    activation_yaw_rad: float
    maximum_predicted_distance_m: float
    position_limit_m: float
    yaw_limit_rad: float
    position_scale_m: float
    yaw_scale_rad: float
    required_deficit_improvement: float
    duration_options_s: tuple[float, ...]
    steering_fractions: tuple[float, ...]
    max_activations: int
    cooldown_seconds: float
    maximum_total_execution_seconds: float
    reverse_penalty: float
    direction_switch_penalty: float

    def validate(self) -> None:
        if self.wheelbase_m <= 0.0 or self.steering_limit_rad <= 0.0 or self.speed_mps <= 0.0:
            raise ValueError("micro-primitive vehicle limits must be positive")
        if self.activation_distance_m <= 0.0 or self.activation_yaw_rad <= 0.0:
            raise ValueError("micro-primitive activation limits must be positive")
        if self.maximum_predicted_distance_m < self.activation_distance_m:
            raise ValueError("micro-primitive predicted envelope must contain activation envelope")
        if self.position_limit_m <= 0.0 or self.yaw_limit_rad <= 0.0:
            raise ValueError("micro-primitive strict limits must be positive")
        if self.position_scale_m <= 0.0 or self.yaw_scale_rad <= 0.0:
            raise ValueError("micro-primitive deficit scales must be positive")
        if self.required_deficit_improvement <= 0.0:
            raise ValueError("micro-primitive improvement threshold must be positive")
        if not self.duration_options_s or any(item <= 0.0 for item in self.duration_options_s):
            raise ValueError("micro-primitive durations must be positive")
        if not self.steering_fractions or any(abs(item) > 1.0 for item in self.steering_fractions):
            raise ValueError("micro-primitive steering fractions must be within [-1,1]")
        if self.max_activations <= 0 or self.cooldown_seconds < 0.0 or self.maximum_total_execution_seconds <= 0.0:
            raise ValueError("invalid micro-primitive activation budget")


@dataclass(frozen=True)
class TerminalMicroPrimitive:
    speed_mps: float
    steering_rad: float
    duration_seconds: float
    predicted_x_m: float
    predicted_y_m: float
    predicted_yaw_rad: float
    current_deficit: float
    predicted_deficit: float
    deficit_improvement: float
    cost: float


class TerminalMicroPrimitivePlanner:
    """Enumerate 2x5x3 short Ackermann motions and choose a strict-basin improving arc."""

    def __init__(self, config: TerminalMicroPrimitiveConfig) -> None:
        config.validate()
        self.config = config
        self.reset()

    def reset(self) -> None:
        self.activation_count = 0
        self.accepted_count = 0
        self.search_count = 0
        self.executed_seconds = 0.0
        self.last_activation_time: float | None = None
        self.last_selected: TerminalMicroPrimitive | None = None
        self.last_candidate_count = 0

    def deficit(self, x: float, y: float, yaw: float) -> float:
        c = self.config
        position = math.hypot(float(x), float(y))
        position_over = max(0.0, position - c.position_limit_m)
        yaw_over = max(0.0, abs(float(yaw)) - c.yaw_limit_rad)
        return position_over / c.position_scale_m + yaw_over / c.yaw_scale_rad

    def _simulate(self, x: float, y: float, yaw: float, *, speed: float, steering: float, duration: float) -> tuple[float, float, float]:
        remaining = float(duration)
        state = (float(x), float(y), float(yaw))
        while remaining > 1e-9:
            dt = min(0.05, remaining)
            state = TerminalKinematicMPC.predict_target_pose(
                *state,
                speed=float(speed),
                steering=float(steering),
                wheelbase=self.config.wheelbase_m,
                dt=dt,
            )
            remaining -= dt
        return state

    def search(
        self,
        *,
        now: float,
        target_x_m: float,
        target_y_m: float,
        target_yaw_rad: float,
        current_direction: int = 0,
    ) -> TerminalMicroPrimitive | None:
        c = self.config
        self.search_count += 1
        distance = math.hypot(float(target_x_m), float(target_y_m))
        abs_yaw = abs(float(target_yaw_rad))
        current_deficit = self.deficit(target_x_m, target_y_m, target_yaw_rad)
        if (
            current_deficit <= 0.0
            or distance > c.activation_distance_m
            or abs_yaw > c.activation_yaw_rad
            or self.activation_count >= c.max_activations
            or self.executed_seconds >= c.maximum_total_execution_seconds
            or (
                self.last_activation_time is not None
                and float(now) - self.last_activation_time < c.cooldown_seconds
            )
        ):
            self.last_candidate_count = 0
            return None

        candidates: list[TerminalMicroPrimitive] = []
        for direction in (1, -1):
            speed = float(direction) * c.speed_mps
            for fraction in c.steering_fractions:
                steering = float(fraction) * c.steering_limit_rad
                for duration in c.duration_options_s:
                    if self.executed_seconds + duration > c.maximum_total_execution_seconds + 1e-9:
                        continue
                    px, py, pyaw = self._simulate(
                        target_x_m, target_y_m, target_yaw_rad,
                        speed=speed, steering=steering, duration=duration,
                    )
                    predicted_distance = math.hypot(px, py)
                    if predicted_distance > c.maximum_predicted_distance_m:
                        continue
                    predicted_deficit = self.deficit(px, py, pyaw)
                    improvement = current_deficit - predicted_deficit
                    if improvement < c.required_deficit_improvement:
                        continue
                    path_penalty = 0.10 * abs(speed) * duration
                    reverse = c.reverse_penalty if direction < 0 else 0.0
                    switch = c.direction_switch_penalty if current_direction and direction != current_direction else 0.0
                    cost = (
                        3.0 * predicted_deficit
                        + 1.6 * predicted_distance
                        + 0.30 * abs(pyaw)
                        + path_penalty + reverse + switch
                    )
                    candidates.append(
                        TerminalMicroPrimitive(
                            speed_mps=speed,
                            steering_rad=steering,
                            duration_seconds=float(duration),
                            predicted_x_m=px,
                            predicted_y_m=py,
                            predicted_yaw_rad=pyaw,
                            current_deficit=float(current_deficit),
                            predicted_deficit=float(predicted_deficit),
                            deficit_improvement=float(improvement),
                            cost=float(cost),
                        )
                    )
        self.last_candidate_count = len(candidates)
        if not candidates:
            return None
        best = min(candidates, key=lambda item: (item.cost, -item.deficit_improvement, item.duration_seconds))
        self.activation_count += 1
        self.accepted_count += 1
        self.executed_seconds += best.duration_seconds
        self.last_activation_time = float(now)
        self.last_selected = best
        return best


@dataclass(frozen=True)
class YawTailReserveConfig:
    """One-shot reserve for a position-in-basin but yaw-outside Ackermann tail."""

    wheelbase_m: float
    steering_limit_rad: float
    speed_mps: float
    position_gate_m: float
    yaw_min_rad: float
    yaw_max_rad: float
    predicted_position_guard_m: float
    required_yaw_improvement_rad: float
    duration_options_s: tuple[float, ...]
    steering_fractions: tuple[float, ...]
    maximum_speed_for_activation_mps: float
    max_activations: int
    maximum_total_execution_seconds: float

    def validate(self) -> None:
        if self.wheelbase_m <= 0.0 or self.steering_limit_rad <= 0.0 or self.speed_mps <= 0.0:
            raise ValueError("yaw-tail vehicle limits must be positive")
        if not (0.0 < self.position_gate_m <= self.predicted_position_guard_m):
            raise ValueError("yaw-tail position guard must contain activation gate")
        if not (0.0 < self.yaw_min_rad < self.yaw_max_rad):
            raise ValueError("yaw-tail yaw interval is invalid")
        if self.required_yaw_improvement_rad <= 0.0:
            raise ValueError("yaw-tail requires positive yaw improvement")
        if self.maximum_speed_for_activation_mps < 0.0:
            raise ValueError("yaw-tail activation speed must be non-negative")
        if self.max_activations <= 0 or self.maximum_total_execution_seconds <= 0.0:
            raise ValueError("yaw-tail reserve budget must be positive")
        if not self.duration_options_s or any(item <= 0.0 for item in self.duration_options_s):
            raise ValueError("yaw-tail durations must be positive")
        if not self.steering_fractions or any(abs(item) > 1.0 for item in self.steering_fractions):
            raise ValueError("yaw-tail steering fractions must be within [-1,1]")


class TerminalYawTailReservePlanner:
    """Search a tiny one-shot Ackermann lattice prioritizing yaw correction."""

    def __init__(self, config: YawTailReserveConfig) -> None:
        config.validate()
        self.config = config
        self.reset()

    def reset(self) -> None:
        self.search_count = 0
        self.activation_count = 0
        self.accepted_count = 0
        self.executed_seconds = 0.0
        self.last_selected: TerminalMicroPrimitive | None = None
        self.last_candidate_count = 0

    def _simulate(self, x: float, y: float, yaw: float, *, speed: float, steering: float, duration: float) -> tuple[float, float, float]:
        remaining = float(duration)
        state = (float(x), float(y), float(yaw))
        while remaining > 1e-9:
            dt = min(0.05, remaining)
            state = TerminalKinematicMPC.predict_target_pose(
                *state, speed=float(speed), steering=float(steering),
                wheelbase=self.config.wheelbase_m, dt=dt,
            )
            remaining -= dt
        return state

    def search(
        self,
        *,
        target_x_m: float,
        target_y_m: float,
        target_yaw_rad: float,
        current_speed_mps: float,
        current_direction: int = 0,
    ) -> TerminalMicroPrimitive | None:
        c = self.config
        self.search_count += 1
        distance = math.hypot(float(target_x_m), float(target_y_m))
        abs_yaw = abs(float(target_yaw_rad))
        if (
            distance > c.position_gate_m
            or abs_yaw < c.yaw_min_rad
            or abs_yaw > c.yaw_max_rad
            or abs(float(current_speed_mps)) > c.maximum_speed_for_activation_mps
            or self.activation_count >= c.max_activations
            or self.executed_seconds >= c.maximum_total_execution_seconds
        ):
            self.last_candidate_count = 0
            return None

        candidates: list[TerminalMicroPrimitive] = []
        current_deficit = max(0.0, abs_yaw - c.yaw_min_rad)
        for direction in (1, -1):
            speed = direction * c.speed_mps
            for fraction in c.steering_fractions:
                steering = float(fraction) * c.steering_limit_rad
                if abs(steering) <= 1e-9:
                    continue
                for duration in c.duration_options_s:
                    if self.executed_seconds + duration > c.maximum_total_execution_seconds + 1e-9:
                        continue
                    px, py, pyaw = self._simulate(
                        target_x_m, target_y_m, target_yaw_rad,
                        speed=speed, steering=steering, duration=duration,
                    )
                    predicted_distance = math.hypot(px, py)
                    yaw_improvement = abs_yaw - abs(float(pyaw))
                    if predicted_distance > c.predicted_position_guard_m:
                        continue
                    if yaw_improvement < c.required_yaw_improvement_rad:
                        continue
                    switch_penalty = 0.015 if current_direction and direction != current_direction else 0.0
                    reverse_penalty = 0.01 if direction < 0 else 0.0
                    cost = (
                        4.0 * abs(float(pyaw))
                        + 2.0 * predicted_distance
                        + 0.10 * abs(speed) * duration
                        + switch_penalty + reverse_penalty
                    )
                    candidates.append(TerminalMicroPrimitive(
                        speed_mps=float(speed), steering_rad=float(steering), duration_seconds=float(duration),
                        predicted_x_m=float(px), predicted_y_m=float(py), predicted_yaw_rad=float(pyaw),
                        current_deficit=float(current_deficit),
                        predicted_deficit=max(0.0, abs(float(pyaw)) - c.yaw_min_rad),
                        deficit_improvement=float(yaw_improvement), cost=float(cost),
                    ))
        self.last_candidate_count = len(candidates)
        if not candidates:
            return None
        best = min(candidates, key=lambda item: (item.cost, -item.deficit_improvement, item.duration_seconds))
        self.activation_count += 1
        self.accepted_count += 1
        self.executed_seconds += best.duration_seconds
        self.last_selected = best
        return best



@dataclass(frozen=True)
class FreshRGBYawClosureConfig:
    """Fresh-terminal-RGB gated paired Ackermann yaw closure.

    The sequence uses two opposite-direction/opposite-steering strokes.  Both
    strokes rotate the target-frame yaw in the same direction while their
    translations largely cancel.  It is deliberately a liveness primitive,
    never a release/certification authority.
    """

    wheelbase_m: float
    steering_limit_rad: float
    speed_mps: float
    position_gate_m: float
    yaw_min_rad: float
    yaw_max_rad: float
    target_yaw_rad: float
    midpoint_position_guard_m: float
    final_position_guard_m: float
    required_yaw_improvement_rad: float
    duration_options_s: tuple[float, ...]
    steering_fractions: tuple[float, ...]
    maximum_speed_for_activation_mps: float
    max_activations: int
    maximum_total_execution_seconds: float

    def validate(self) -> None:
        if self.wheelbase_m <= 0.0 or self.steering_limit_rad <= 0.0 or self.speed_mps <= 0.0:
            raise ValueError("fresh-RGB yaw closure vehicle limits must be positive")
        if not (0.0 < self.position_gate_m <= self.final_position_guard_m <= self.midpoint_position_guard_m):
            raise ValueError("fresh-RGB yaw closure position envelopes are invalid")
        if not (0.0 < self.target_yaw_rad < self.yaw_min_rad < self.yaw_max_rad):
            raise ValueError("fresh-RGB yaw closure yaw envelopes are invalid")
        if self.required_yaw_improvement_rad <= 0.0:
            raise ValueError("fresh-RGB yaw closure requires positive predicted improvement")
        if self.maximum_speed_for_activation_mps < 0.0:
            raise ValueError("fresh-RGB yaw closure activation speed must be non-negative")
        if self.max_activations <= 0 or self.maximum_total_execution_seconds <= 0.0:
            raise ValueError("fresh-RGB yaw closure budget must be positive")
        if not self.duration_options_s or any(item <= 0.0 for item in self.duration_options_s):
            raise ValueError("fresh-RGB yaw closure durations must be positive")
        if not self.steering_fractions or any(not (0.0 < abs(item) <= 1.0) for item in self.steering_fractions):
            raise ValueError("fresh-RGB yaw closure steering fractions must be non-zero and within [-1,1]")


@dataclass(frozen=True)
class FreshRGBYawClosureSequence:
    first_speed_mps: float
    first_steering_rad: float
    second_speed_mps: float
    second_steering_rad: float
    leg_duration_seconds: float
    predicted_mid_x_m: float
    predicted_mid_y_m: float
    predicted_mid_yaw_rad: float
    predicted_final_x_m: float
    predicted_final_y_m: float
    predicted_final_yaw_rad: float
    yaw_improvement_rad: float
    cost: float

    @property
    def total_execution_seconds(self) -> float:
        return 2.0 * float(self.leg_duration_seconds)


class FreshRGBYawClosurePlanner:
    """Search a paired Ackermann shunt for a fresh-RGB-confirmed yaw tail.

    For positive target yaw, a forward/positive-steer stroke followed by a
    reverse/negative-steer stroke produces the same-sign chassis yaw change on
    both legs.  The reverse leg approximately cancels translation.  The mirror
    sequence handles negative yaw.  Every candidate is checked at the midpoint
    *and* final pose, so a yaw correction cannot buy liveness by escaping the
    small position basin.
    """

    def __init__(self, config: FreshRGBYawClosureConfig) -> None:
        config.validate()
        self.config = config
        self.reset()

    def reset(self) -> None:
        self.search_count = 0
        self.activation_count = 0
        self.accepted_count = 0
        self.executed_seconds = 0.0
        self.last_candidate_count = 0
        # V9.3.12-R4-E1 telemetry: do not let later empty searches erase the
        # fact that a physically executed closure had valid candidates.
        self.total_candidate_count = 0
        self.no_candidate_search_count = 0
        self.last_selected_candidate_count = 0
        self.last_selected: FreshRGBYawClosureSequence | None = None

    def _simulate(self, x: float, y: float, yaw: float, *, speed: float, steering: float, duration: float) -> tuple[float, float, float]:
        remaining = float(duration)
        state = (float(x), float(y), float(yaw))
        while remaining > 1e-9:
            dt = min(0.05, remaining)
            state = TerminalKinematicMPC.predict_target_pose(
                *state,
                speed=float(speed),
                steering=float(steering),
                wheelbase=self.config.wheelbase_m,
                dt=dt,
            )
            remaining -= dt
        return state

    def search(
        self,
        *,
        target_x_m: float,
        target_y_m: float,
        target_yaw_rad: float,
        current_speed_mps: float,
        current_direction: int = 0,
        position_gate_override_m: float | None = None,
    ) -> FreshRGBYawClosureSequence | None:
        c = self.config
        self.search_count += 1
        distance = math.hypot(float(target_x_m), float(target_y_m))
        abs_yaw = abs(float(target_yaw_rad))
        position_gate = (
            c.position_gate_m
            if position_gate_override_m is None
            else max(c.position_gate_m, float(position_gate_override_m))
        )
        if (
            distance > position_gate
            or abs_yaw < c.yaw_min_rad
            or abs_yaw > c.yaw_max_rad
            or abs(float(current_speed_mps)) > c.maximum_speed_for_activation_mps
            or self.activation_count >= c.max_activations
            or self.executed_seconds >= c.maximum_total_execution_seconds
        ):
            self.last_candidate_count = 0
            self.no_candidate_search_count += 1
            return None

        yaw_sign = 1.0 if float(target_yaw_rad) >= 0.0 else -1.0
        candidates: list[FreshRGBYawClosureSequence] = []
        for first_direction in (1, -1):
            first_speed = float(first_direction) * c.speed_mps
            second_speed = -first_speed
            for fraction in c.steering_fractions:
                fraction_abs = abs(float(fraction))
                # speed*steering must have the sign of target_yaw so the target
                # yaw in the moving vehicle frame shrinks on both legs.
                first_steering = yaw_sign * float(first_direction) * fraction_abs * c.steering_limit_rad
                second_steering = -first_steering
                for duration in c.duration_options_s:
                    total = 2.0 * float(duration)
                    if self.executed_seconds + total > c.maximum_total_execution_seconds + 1e-9:
                        continue
                    mx, my, myaw = self._simulate(
                        target_x_m, target_y_m, target_yaw_rad,
                        speed=first_speed, steering=first_steering, duration=duration,
                    )
                    fx, fy, fyaw = self._simulate(
                        mx, my, myaw,
                        speed=second_speed, steering=second_steering, duration=duration,
                    )
                    midpoint_distance = math.hypot(mx, my)
                    final_distance = math.hypot(fx, fy)
                    yaw_improvement = abs_yaw - abs(float(fyaw))
                    if midpoint_distance > c.midpoint_position_guard_m:
                        continue
                    if final_distance > c.final_position_guard_m:
                        continue
                    if yaw_improvement < c.required_yaw_improvement_rad:
                        continue
                    # Avoid an unnecessary sign crossing. A tiny crossing is
                    # acceptable only when already inside the explicit target.
                    if float(target_yaw_rad) * float(fyaw) < 0.0 and abs(float(fyaw)) > c.target_yaw_rad:
                        continue
                    target_deficit = max(0.0, abs(float(fyaw)) - c.target_yaw_rad)
                    first_switch_penalty = 0.018 if current_direction and first_direction != current_direction else 0.0
                    reverse_first_penalty = 0.008 if first_direction < 0 else 0.0
                    cost = (
                        8.0 * target_deficit
                        + 3.0 * final_distance
                        + 1.2 * midpoint_distance
                        + 0.08 * total
                        + 0.03 * (1.0 - fraction_abs)
                        + first_switch_penalty
                        + reverse_first_penalty
                    )
                    candidates.append(FreshRGBYawClosureSequence(
                        first_speed_mps=float(first_speed),
                        first_steering_rad=float(first_steering),
                        second_speed_mps=float(second_speed),
                        second_steering_rad=float(second_steering),
                        leg_duration_seconds=float(duration),
                        predicted_mid_x_m=float(mx),
                        predicted_mid_y_m=float(my),
                        predicted_mid_yaw_rad=float(myaw),
                        predicted_final_x_m=float(fx),
                        predicted_final_y_m=float(fy),
                        predicted_final_yaw_rad=float(fyaw),
                        yaw_improvement_rad=float(yaw_improvement),
                        cost=float(cost),
                    ))
        self.last_candidate_count = len(candidates)
        self.total_candidate_count += len(candidates)
        if not candidates:
            self.no_candidate_search_count += 1
            return None
        self.last_selected_candidate_count = len(candidates)
        best = min(
            candidates,
            key=lambda item: (
                item.cost,
                abs(item.predicted_final_yaw_rad),
                math.hypot(item.predicted_final_x_m, item.predicted_final_y_m),
                item.total_execution_seconds,
            ),
        )
        self.activation_count += 1
        self.accepted_count += 1
        self.executed_seconds += best.total_execution_seconds
        self.last_selected = best
        return best


@dataclass(frozen=True)
class PostClosureBasinGuardConfig:
    """Safety/ownership shield after a verified Fresh-RGB yaw closure.

    This guard does not certify or release.  It only decides whether the
    post-closure state is close enough to retain ownership and whether an MPC
    horizon is allowed to execute without destroying the near-release basin.
    """

    position_guard_m: float
    yaw_guard_rad: float
    mpc_predicted_position_limit_m: float
    mpc_allowed_position_regression_m: float
    mpc_allowed_yaw_regression_rad: float
    continuation_position_gate_m: float

    def validate(self) -> None:
        if self.position_guard_m <= 0.0 or self.yaw_guard_rad <= 0.0:
            raise ValueError("post-closure ownership guard must be positive")
        if not (0.0 < self.mpc_predicted_position_limit_m <= self.position_guard_m):
            raise ValueError("post-closure MPC position limit must lie inside ownership guard")
        if self.mpc_allowed_position_regression_m < 0.0:
            raise ValueError("post-closure MPC position regression allowance must be non-negative")
        if self.mpc_allowed_yaw_regression_rad < 0.0:
            raise ValueError("post-closure MPC yaw regression allowance must be non-negative")
        if not (0.0 < self.continuation_position_gate_m <= self.position_guard_m):
            raise ValueError("post-closure continuation gate must lie inside ownership guard")


class PostClosureBasinGuard:
    """Lexicographic basin shield for the R4-E -> certification handoff."""

    def __init__(self, config: PostClosureBasinGuardConfig) -> None:
        config.validate()
        self.config = config

    def pose_guarded(self, distance_m: float, yaw_rad: float) -> bool:
        c = self.config
        return (
            float(distance_m) <= c.position_guard_m + 1e-9
            and abs(float(yaw_rad)) <= c.yaw_guard_rad + 1e-9
        )

    def mpc_plan_safe(
        self,
        *,
        current_distance_m: float,
        current_yaw_rad: float,
        predicted_distance_m: float,
        predicted_yaw_rad: float,
    ) -> bool:
        c = self.config
        current_distance = float(current_distance_m)
        predicted_distance = float(predicted_distance_m)
        current_abs_yaw = abs(float(current_yaw_rad))
        predicted_abs_yaw = abs(float(predicted_yaw_rad))
        return bool(
            self.pose_guarded(current_distance, current_yaw_rad)
            and predicted_distance <= c.mpc_predicted_position_limit_m + 1e-9
            and predicted_distance
            <= current_distance + c.mpc_allowed_position_regression_m + 1e-9
            and predicted_abs_yaw
            <= current_abs_yaw + c.mpc_allowed_yaw_regression_rad + 1e-9
        )

    def certification_handoff_ready(
        self,
        *,
        filtered_distance_m: float,
        filtered_yaw_rad: float,
        certification_distance_m: float,
        certification_yaw_rad: float,
        prebrake_position_limit_m: float,
        prebrake_yaw_limit_rad: float,
    ) -> bool:
        """Allow *SETTLE entry only* from the multiview certification state.

        Final release still requires the unchanged strict certification,
        Supervisor INTENT and Witness gates.
        """
        return bool(
            self.pose_guarded(filtered_distance_m, filtered_yaw_rad)
            and float(certification_distance_m)
            <= float(prebrake_position_limit_m) + 1e-9
            and abs(float(certification_yaw_rad))
            <= float(prebrake_yaw_limit_rad) + 1e-9
        )


@dataclass(frozen=True)
class StrictRecoveryRetentionConfig:
    """Bounded post-basin recovery after the normal terminal budgets are exhausted.

    This planner never certifies or releases.  It only searches short Ackermann
    arcs that reduce a conservative strict-deficit proxy while keeping the
    predicted carried-load target inside a small position envelope.
    """

    wheelbase_m: float
    steering_limit_rad: float
    speed_mps: float
    activation_distance_m: float
    activation_yaw_rad: float
    target_position_m: float
    target_yaw_rad: float
    predicted_position_guard_m: float
    predicted_yaw_guard_rad: float
    position_scale_m: float
    yaw_scale_rad: float
    required_deficit_improvement: float
    duration_options_s: tuple[float, ...]
    steering_fractions: tuple[float, ...]
    maximum_speed_for_activation_mps: float
    max_activations: int
    cooldown_seconds: float
    maximum_total_execution_seconds: float

    def validate(self) -> None:
        if self.wheelbase_m <= 0.0 or self.steering_limit_rad <= 0.0 or self.speed_mps <= 0.0:
            raise ValueError("strict-recovery vehicle limits must be positive")
        if not (
            0.0 < self.target_position_m < self.activation_distance_m
            and self.target_position_m < self.predicted_position_guard_m
        ):
            raise ValueError("strict-recovery position envelopes are invalid")
        if not (0.0 < self.target_yaw_rad < self.activation_yaw_rad <= self.predicted_yaw_guard_rad):
            raise ValueError("strict-recovery yaw envelopes are invalid")
        if self.position_scale_m <= 0.0 or self.yaw_scale_rad <= 0.0:
            raise ValueError("strict-recovery deficit scales must be positive")
        if self.required_deficit_improvement <= 0.0:
            raise ValueError("strict-recovery improvement threshold must be positive")
        if self.maximum_speed_for_activation_mps < 0.0:
            raise ValueError("strict-recovery activation speed must be non-negative")
        if self.max_activations <= 0 or self.cooldown_seconds < 0.0 or self.maximum_total_execution_seconds <= 0.0:
            raise ValueError("strict-recovery activation budget is invalid")
        if not self.duration_options_s or any(item <= 0.0 for item in self.duration_options_s):
            raise ValueError("strict-recovery durations must be positive")
        if not self.steering_fractions or any(abs(item) > 1.0 for item in self.steering_fractions):
            raise ValueError("strict-recovery steering fractions must be within [-1,1]")


class StrictRecoveryRetentionPlanner:
    """Small retention lattice that improves a conservative near-release deficit."""

    def __init__(self, config: StrictRecoveryRetentionConfig) -> None:
        config.validate()
        self.config = config
        self.reset()

    def reset(self) -> None:
        self.search_count = 0
        self.activation_count = 0
        self.accepted_count = 0
        self.executed_seconds = 0.0
        self.last_activation_time: float | None = None
        self.last_selected: TerminalMicroPrimitive | None = None
        self.last_candidate_count = 0

    def deficit(self, x: float, y: float, yaw: float) -> float:
        c = self.config
        position_over = max(0.0, math.hypot(float(x), float(y)) - c.target_position_m)
        yaw_over = max(0.0, abs(float(yaw)) - c.target_yaw_rad)
        return position_over / c.position_scale_m + yaw_over / c.yaw_scale_rad

    def pose_within_guard(self, x: float, y: float, yaw: float) -> bool:
        """Return whether the mean task pose is inside the R4 retention guard.

        This is a motion-ownership interlock only.  It is intentionally not a
        release certification predicate.
        """
        c = self.config
        return (
            math.hypot(float(x), float(y)) <= c.predicted_position_guard_m + 1e-9
            and abs(float(yaw)) <= c.predicted_yaw_guard_rad + 1e-9
        )

    def cooldown_remaining(self, now: float) -> float:
        """Return the remaining bounded cooldown after the last activation."""
        if self.last_activation_time is None:
            return 0.0
        return max(
            0.0,
            self.config.cooldown_seconds - (float(now) - self.last_activation_time),
        )

    def motion_budget_exhausted(self) -> bool:
        """Whether no additional R4 bounded motion may be scheduled."""
        c = self.config
        return bool(
            self.activation_count >= c.max_activations
            or self.executed_seconds >= c.maximum_total_execution_seconds - 1e-9
        )

    def _simulate(self, x: float, y: float, yaw: float, *, speed: float, steering: float, duration: float) -> tuple[float, float, float]:
        remaining = float(duration)
        state = (float(x), float(y), float(yaw))
        while remaining > 1e-9:
            dt = min(0.05, remaining)
            state = TerminalKinematicMPC.predict_target_pose(
                *state,
                speed=float(speed),
                steering=float(steering),
                wheelbase=self.config.wheelbase_m,
                dt=dt,
            )
            remaining -= dt
        return state

    def search(
        self,
        *,
        now: float,
        target_x_m: float,
        target_y_m: float,
        target_yaw_rad: float,
        current_speed_mps: float,
        current_direction: int = 0,
    ) -> TerminalMicroPrimitive | None:
        c = self.config
        self.search_count += 1
        distance = math.hypot(float(target_x_m), float(target_y_m))
        abs_yaw = abs(float(target_yaw_rad))
        current_deficit = self.deficit(target_x_m, target_y_m, target_yaw_rad)
        if (
            current_deficit <= 0.0
            or distance > c.activation_distance_m
            or abs_yaw > c.activation_yaw_rad
            or abs(float(current_speed_mps)) > c.maximum_speed_for_activation_mps
            or self.activation_count >= c.max_activations
            or self.executed_seconds >= c.maximum_total_execution_seconds
            or (
                self.last_activation_time is not None
                and float(now) - self.last_activation_time < c.cooldown_seconds
            )
        ):
            self.last_candidate_count = 0
            return None

        candidates: list[TerminalMicroPrimitive] = []
        for direction in (1, -1):
            speed = float(direction) * c.speed_mps
            for fraction in c.steering_fractions:
                steering = float(fraction) * c.steering_limit_rad
                for duration in c.duration_options_s:
                    if self.executed_seconds + duration > c.maximum_total_execution_seconds + 1e-9:
                        continue
                    px, py, pyaw = self._simulate(
                        target_x_m,
                        target_y_m,
                        target_yaw_rad,
                        speed=speed,
                        steering=steering,
                        duration=duration,
                    )
                    predicted_distance = math.hypot(px, py)
                    predicted_abs_yaw = abs(float(pyaw))
                    if predicted_distance > c.predicted_position_guard_m:
                        continue
                    if predicted_abs_yaw > c.predicted_yaw_guard_rad:
                        continue
                    predicted_deficit = self.deficit(px, py, pyaw)
                    improvement = current_deficit - predicted_deficit
                    if improvement < c.required_deficit_improvement:
                        continue
                    # Never trade a large position excursion for a tiny yaw gain.
                    if predicted_distance > max(distance + 0.012, c.target_position_m + 0.015):
                        continue
                    switch_penalty = 0.012 if current_direction and direction != current_direction else 0.0
                    reverse_penalty = 0.008 if direction < 0 else 0.0
                    cost = (
                        4.5 * predicted_deficit
                        + 2.5 * predicted_distance
                        + 0.65 * predicted_abs_yaw
                        + 0.08 * abs(speed) * duration
                        + switch_penalty
                        + reverse_penalty
                    )
                    candidates.append(
                        TerminalMicroPrimitive(
                            speed_mps=float(speed),
                            steering_rad=float(steering),
                            duration_seconds=float(duration),
                            predicted_x_m=float(px),
                            predicted_y_m=float(py),
                            predicted_yaw_rad=float(pyaw),
                            current_deficit=float(current_deficit),
                            predicted_deficit=float(predicted_deficit),
                            deficit_improvement=float(improvement),
                            cost=float(cost),
                        )
                    )
        self.last_candidate_count = len(candidates)
        if not candidates:
            return None
        best = min(candidates, key=lambda item: (item.cost, -item.deficit_improvement, item.duration_seconds))
        self.activation_count += 1
        self.accepted_count += 1
        self.executed_seconds += best.duration_seconds
        self.last_activation_time = float(now)
        self.last_selected = best
        return best

# ---------------------------------------------------------------------------
# V9.3.12-R4-E2 -- Certification-Basin Closure
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class CertificationBasinClosureConfig:
    """Observation-only recenter search after a strict certification reject.

    The planner is deliberately distinct from ReleaseDecisionSupervisor. It
    never certifies and never releases. It only searches a tiny Ackermann
    sequence that improves the *conservative certification deficit* while the
    ordinary filtered task state remains inside the retained near-basin.
    """

    wheelbase_m: float
    steering_limit_rad: float
    speed_mps: float
    filtered_position_guard_m: float
    filtered_yaw_guard_rad: float
    certification_position_activation_m: float
    certification_yaw_activation_rad: float
    predicted_filtered_position_guard_m: float
    predicted_filtered_yaw_guard_rad: float
    strict_position_limit_m: float
    strict_yaw_limit_rad: float
    position_scale_m: float
    yaw_scale_rad: float
    required_predicted_deficit_improvement: float
    allowed_filtered_position_regression_m: float
    duration_options_s: tuple[float, ...]
    steering_fractions: tuple[float, ...]
    second_leg_duration_fractions: tuple[float, ...]
    maximum_speed_for_activation_mps: float
    max_activations: int
    maximum_total_execution_seconds: float

    def validate(self) -> None:
        if self.wheelbase_m <= 0.0 or self.steering_limit_rad <= 0.0 or self.speed_mps <= 0.0:
            raise ValueError("certification-basin closure vehicle limits must be positive")
        if self.filtered_position_guard_m <= 0.0 or self.filtered_yaw_guard_rad <= 0.0:
            raise ValueError("certification-basin filtered guard must be positive")
        if self.certification_position_activation_m <= 0.0 or self.certification_yaw_activation_rad <= 0.0:
            raise ValueError("certification-basin activation envelope must be positive")
        if self.predicted_filtered_position_guard_m <= 0.0 or self.predicted_filtered_yaw_guard_rad <= 0.0:
            raise ValueError("certification-basin predicted guard must be positive")
        if self.strict_position_limit_m <= 0.0 or self.strict_yaw_limit_rad <= 0.0:
            raise ValueError("certification-basin strict limits must be positive")
        if self.position_scale_m <= 0.0 or self.yaw_scale_rad <= 0.0:
            raise ValueError("certification-basin deficit scales must be positive")
        if self.required_predicted_deficit_improvement <= 0.0:
            raise ValueError("certification-basin required improvement must be positive")
        if self.allowed_filtered_position_regression_m < 0.0:
            raise ValueError("certification-basin filtered regression allowance must be non-negative")
        if not self.duration_options_s or any(x <= 0.0 for x in self.duration_options_s):
            raise ValueError("certification-basin durations must be positive")
        if not self.steering_fractions or any(not (0.0 <= abs(x) <= 1.0) for x in self.steering_fractions):
            raise ValueError("certification-basin steering fractions must be within [-1,1]")
        if not self.second_leg_duration_fractions or any(not (0.0 <= x <= 1.0) for x in self.second_leg_duration_fractions):
            raise ValueError("certification-basin second-leg fractions must lie in [0,1]")
        if self.maximum_speed_for_activation_mps < 0.0:
            raise ValueError("certification-basin activation speed must be non-negative")
        if self.max_activations <= 0 or self.maximum_total_execution_seconds <= 0.0:
            raise ValueError("certification-basin motion budget must be positive")


@dataclass(frozen=True)
class CertificationBasinClosureSequence:
    first_speed_mps: float
    first_steering_rad: float
    first_duration_seconds: float
    second_speed_mps: float
    second_steering_rad: float
    second_duration_seconds: float
    predicted_filtered_mid_x_m: float
    predicted_filtered_mid_y_m: float
    predicted_filtered_mid_yaw_rad: float
    predicted_filtered_final_x_m: float
    predicted_filtered_final_y_m: float
    predicted_filtered_final_yaw_rad: float
    predicted_certification_final_x_m: float
    predicted_certification_final_y_m: float
    predicted_certification_final_yaw_rad: float
    current_strict_deficit: float
    predicted_strict_deficit: float
    deficit_improvement: float
    maximum_predicted_filtered_distance_m: float
    cost: float
    model_mode: str = "ERROR_SPACE_LEGACY"

    @property
    def total_execution_seconds(self) -> float:
        return float(self.first_duration_seconds) + float(self.second_duration_seconds)

    @property
    def has_second_leg(self) -> bool:
        return self.second_duration_seconds > 1e-9 and abs(self.second_speed_mps) > 1e-9


class CertificationBasinClosurePlanner:
    """Bounded certification-space closure with an optional full-pose model.

    Historical E2 calls may still use the legacy error-space interface for
    archived regression.  E5 runtime supplies the rigid carried-load pose and
    both world-fixed target poses, so every hypothetical Ackermann motion is
    evaluated in the same full-pose semantics used by the E5 POSITION corridor.
    This prevents the E4 load-lever-arm bug from re-entering through the
    POSITION->YAW handoff.
    """

    FULL_POSE_MODEL = "FULL_POSE_RIGID_LOAD"
    LEGACY_MODEL = "ERROR_SPACE_LEGACY"

    def __init__(self, config: CertificationBasinClosureConfig) -> None:
        config.validate()
        self.config = config
        self.reset()

    def reset(self) -> None:
        self.search_count = 0
        self.activation_count = 0
        self.total_candidate_count = 0
        self.no_candidate_search_count = 0
        self.executed_seconds = 0.0
        self.last_candidate_count = 0
        self.full_pose_search_count = 0
        self.legacy_error_space_search_count = 0
        self.last_model_mode = self.LEGACY_MODEL
        self.last_selected: CertificationBasinClosureSequence | None = None

    @staticmethod
    def strict_deficit(
        *,
        distance_m: float,
        yaw_rad: float,
        position_margin_m: float,
        yaw_margin_rad: float,
        position_limit_m: float,
        yaw_limit_rad: float,
        position_scale_m: float,
        yaw_scale_rad: float,
    ) -> float:
        position_deficit = max(
            0.0,
            float(distance_m) + max(0.0, float(position_margin_m)) - float(position_limit_m),
        ) / float(position_scale_m)
        yaw_deficit = max(
            0.0,
            abs(float(yaw_rad)) + max(0.0, float(yaw_margin_rad)) - float(yaw_limit_rad),
        ) / float(yaw_scale_rad)
        return float(position_deficit + yaw_deficit)

    def _simulate(
        self,
        state: tuple[float, float, float],
        *,
        speed: float,
        steering: float,
        duration: float,
    ) -> tuple[float, float, float]:
        """Legacy error-space propagation retained for archived E2 tests."""
        remaining = max(0.0, float(duration))
        x, y, yaw = map(float, state)
        while remaining > 1e-9:
            dt = min(0.05, remaining)
            x, y, yaw = TerminalKinematicMPC.predict_target_pose(
                x, y, yaw,
                speed=float(speed), steering=float(steering),
                wheelbase=self.config.wheelbase_m, dt=dt,
            )
            remaining -= dt
        return float(x), float(y), float(yaw)

    @staticmethod
    def _load_to_target_error(
        load_pose: tuple[float, float, float],
        target_pose: tuple[float, float, float],
    ) -> tuple[float, float, float]:
        load_x, load_y, load_yaw = map(float, load_pose)
        target_x, target_y, target_yaw = map(float, target_pose)
        dx = target_x - load_x
        dy = target_y - load_y
        cosine = math.cos(target_yaw)
        sine = math.sin(target_yaw)
        longitudinal = cosine * dx + sine * dy
        lateral = -sine * dx + cosine * dy
        yaw = (target_yaw - load_yaw + math.pi) % (2.0 * math.pi) - math.pi
        return float(longitudinal), float(lateral), float(yaw)

    def _simulate_full_pose_leg(
        self,
        *,
        load_pose: tuple[float, float, float],
        task_target_pose: tuple[float, float, float],
        certification_target_pose: tuple[float, float, float],
        speed: float,
        steering: float,
        duration: float,
    ) -> tuple[
        tuple[float, float, float],
        tuple[float, float, float],
        tuple[float, float, float],
        tuple[float, float, float],
        float,
        float,
    ]:
        remaining = max(0.0, float(duration))
        task = tuple(map(float, task_target_pose))
        cert = tuple(map(float, certification_target_pose))
        load = tuple(map(float, load_pose))
        initial = self._load_to_target_error(load, task)
        maximum_task_distance = math.hypot(initial[0], initial[1])
        maximum_task_abs_yaw = abs(initial[2])
        while remaining > 1e-9:
            dt = min(0.05, remaining)
            task = TerminalKinematicMPC.predict_target_pose(
                *task,
                speed=float(speed), steering=float(steering),
                wheelbase=self.config.wheelbase_m, dt=dt,
            )
            cert = TerminalKinematicMPC.predict_target_pose(
                *cert,
                speed=float(speed), steering=float(steering),
                wheelbase=self.config.wheelbase_m, dt=dt,
            )
            task_error = self._load_to_target_error(load, task)
            maximum_task_distance = max(
                maximum_task_distance,
                math.hypot(task_error[0], task_error[1]),
            )
            maximum_task_abs_yaw = max(maximum_task_abs_yaw, abs(task_error[2]))
            remaining -= dt
        return (
            tuple(map(float, task)),
            tuple(map(float, cert)),
            self._load_to_target_error(load, task),
            self._load_to_target_error(load, cert),
            float(maximum_task_distance),
            float(maximum_task_abs_yaw),
        )

    @staticmethod
    def _full_pose_args_present(
        load_pose_in_base: tuple[float, float, float] | None,
        task_target_pose_in_base: tuple[float, float, float] | None,
        certification_target_pose_in_base: tuple[float, float, float] | None,
    ) -> bool:
        supplied = (
            load_pose_in_base is not None,
            task_target_pose_in_base is not None,
            certification_target_pose_in_base is not None,
        )
        if any(supplied) and not all(supplied):
            raise ValueError(
                "full-pose certification closure requires load + task target + certification target"
            )
        return all(supplied)

    def _filtered_guarded(self, x: float, y: float, yaw: float) -> bool:
        c = self.config
        return bool(
            math.hypot(float(x), float(y)) <= c.predicted_filtered_position_guard_m + 1e-9
            and abs(float(yaw)) <= c.predicted_filtered_yaw_guard_rad + 1e-9
        )

    def search(
        self,
        *,
        filtered_x_m: float,
        filtered_y_m: float,
        filtered_yaw_rad: float,
        certification_x_m: float,
        certification_y_m: float,
        certification_yaw_rad: float,
        position_margin_m: float,
        yaw_margin_rad: float,
        current_speed_mps: float,
        current_direction: int = 0,
        load_pose_in_base: tuple[float, float, float] | None = None,
        task_target_pose_in_base: tuple[float, float, float] | None = None,
        certification_target_pose_in_base: tuple[float, float, float] | None = None,
    ) -> CertificationBasinClosureSequence | None:
        c = self.config
        self.search_count += 1
        filtered_distance = math.hypot(float(filtered_x_m), float(filtered_y_m))
        certification_distance = math.hypot(float(certification_x_m), float(certification_y_m))
        if (
            filtered_distance > c.filtered_position_guard_m
            or abs(float(filtered_yaw_rad)) > c.filtered_yaw_guard_rad
            or certification_distance > c.certification_position_activation_m
            or abs(float(certification_yaw_rad)) > c.certification_yaw_activation_rad
            or abs(float(current_speed_mps)) > c.maximum_speed_for_activation_mps
            or self.activation_count >= c.max_activations
            or self.executed_seconds >= c.maximum_total_execution_seconds
        ):
            self.last_candidate_count = 0
            self.no_candidate_search_count += 1
            return None

        use_full_pose = self._full_pose_args_present(
            load_pose_in_base,
            task_target_pose_in_base,
            certification_target_pose_in_base,
        )
        if use_full_pose:
            self.full_pose_search_count += 1
            self.last_model_mode = self.FULL_POSE_MODEL
        else:
            self.legacy_error_space_search_count += 1
            self.last_model_mode = self.LEGACY_MODEL

        current_deficit = self.strict_deficit(
            distance_m=certification_distance,
            yaw_rad=certification_yaw_rad,
            position_margin_m=position_margin_m,
            yaw_margin_rad=yaw_margin_rad,
            position_limit_m=c.strict_position_limit_m,
            yaw_limit_rad=c.strict_yaw_limit_rad,
            position_scale_m=c.position_scale_m,
            yaw_scale_rad=c.yaw_scale_rad,
        )
        if current_deficit <= 1e-9:
            self.last_candidate_count = 0
            self.no_candidate_search_count += 1
            return None

        steering_values = sorted({
            0.0,
            *(
                sign * abs(float(frac)) * c.steering_limit_rad
                for frac in c.steering_fractions
                for sign in (-1.0, 1.0)
                if abs(float(frac)) > 1e-9
            ),
        })
        first_controls = [
            (direction * c.speed_mps, steering)
            for direction in (-1.0, 1.0)
            for steering in steering_values
        ]
        second_steering_values = (-c.steering_limit_rad, 0.0, c.steering_limit_rad)
        second_controls = [
            (direction * c.speed_mps, steering)
            for direction in (-1.0, 1.0)
            for steering in second_steering_values
        ]

        filtered_initial = (float(filtered_x_m), float(filtered_y_m), float(filtered_yaw_rad))
        cert_initial = (float(certification_x_m), float(certification_y_m), float(certification_yaw_rad))
        candidates: list[CertificationBasinClosureSequence] = []

        for duration in c.duration_options_s:
            for speed1, steer1 in first_controls:
                if use_full_pose:
                    assert load_pose_in_base is not None
                    assert task_target_pose_in_base is not None
                    assert certification_target_pose_in_base is not None
                    (
                        task_mid_pose,
                        cert_mid_pose,
                        fmid,
                        cmid,
                        first_max_distance,
                        first_max_yaw,
                    ) = self._simulate_full_pose_leg(
                        load_pose=load_pose_in_base,
                        task_target_pose=task_target_pose_in_base,
                        certification_target_pose=certification_target_pose_in_base,
                        speed=speed1,
                        steering=steer1,
                        duration=duration,
                    )
                    if (
                        first_max_distance > c.predicted_filtered_position_guard_m + 1e-9
                        or first_max_yaw > c.predicted_filtered_yaw_guard_rad + 1e-9
                    ):
                        continue
                else:
                    fmid = self._simulate(filtered_initial, speed=speed1, steering=steer1, duration=duration)
                    cmid = self._simulate(cert_initial, speed=speed1, steering=steer1, duration=duration)
                    task_mid_pose = cert_mid_pose = None
                    first_max_distance = max(filtered_distance, math.hypot(fmid[0], fmid[1]))
                    if not self._filtered_guarded(*fmid):
                        continue

                leg2_options = [(0.0, 0.0, 0.0)]
                for second_fraction in c.second_leg_duration_fractions:
                    second_duration = float(duration) * float(second_fraction)
                    if second_duration <= 1e-9:
                        continue
                    for speed2, steer2 in second_controls:
                        leg2_options.append((speed2, steer2, second_duration))

                for speed2, steer2, duration2 in leg2_options:
                    total = float(duration) + float(duration2)
                    if self.executed_seconds + total > c.maximum_total_execution_seconds + 1e-9:
                        continue
                    if duration2 > 1e-9:
                        if use_full_pose:
                            assert task_mid_pose is not None and cert_mid_pose is not None
                            (
                                _task_final_pose,
                                _cert_final_pose,
                                ffinal,
                                cfinal,
                                second_max_distance,
                                second_max_yaw,
                            ) = self._simulate_full_pose_leg(
                                load_pose=load_pose_in_base,
                                task_target_pose=task_mid_pose,
                                certification_target_pose=cert_mid_pose,
                                speed=speed2,
                                steering=steer2,
                                duration=duration2,
                            )
                            maximum_filtered_distance = max(first_max_distance, second_max_distance)
                            maximum_filtered_yaw = max(first_max_yaw, second_max_yaw)
                            if (
                                maximum_filtered_distance > c.predicted_filtered_position_guard_m + 1e-9
                                or maximum_filtered_yaw > c.predicted_filtered_yaw_guard_rad + 1e-9
                            ):
                                continue
                        else:
                            ffinal = self._simulate(fmid, speed=speed2, steering=steer2, duration=duration2)
                            cfinal = self._simulate(cmid, speed=speed2, steering=steer2, duration=duration2)
                            maximum_filtered_distance = max(
                                filtered_distance,
                                math.hypot(fmid[0], fmid[1]),
                                math.hypot(ffinal[0], ffinal[1]),
                            )
                    else:
                        ffinal, cfinal = fmid, cmid
                        maximum_filtered_distance = first_max_distance

                    if not self._filtered_guarded(*ffinal):
                        continue
                    ffinal_distance = math.hypot(ffinal[0], ffinal[1])
                    if ffinal_distance > filtered_distance + c.allowed_filtered_position_regression_m + 1e-9:
                        continue
                    predicted_deficit = self.strict_deficit(
                        distance_m=math.hypot(cfinal[0], cfinal[1]),
                        yaw_rad=cfinal[2],
                        position_margin_m=position_margin_m,
                        yaw_margin_rad=yaw_margin_rad,
                        position_limit_m=c.strict_position_limit_m,
                        yaw_limit_rad=c.strict_yaw_limit_rad,
                        position_scale_m=c.position_scale_m,
                        yaw_scale_rad=c.yaw_scale_rad,
                    )
                    improvement = current_deficit - predicted_deficit
                    if improvement < c.required_predicted_deficit_improvement:
                        continue
                    direction1 = 1 if speed1 > 0.0 else -1
                    switch_penalty = 0.015 if current_direction and direction1 != current_direction else 0.0
                    reverse_penalty = 0.008 if speed1 < 0.0 else 0.0
                    second_motion_penalty = 0.015 if duration2 > 1e-9 else 0.0
                    cost = (
                        9.0 * predicted_deficit
                        + 4.0 * ffinal_distance
                        + 2.0 * maximum_filtered_distance
                        + 0.12 * total
                        + switch_penalty + reverse_penalty + second_motion_penalty
                    )
                    candidates.append(CertificationBasinClosureSequence(
                        first_speed_mps=float(speed1),
                        first_steering_rad=float(steer1),
                        first_duration_seconds=float(duration),
                        second_speed_mps=float(speed2),
                        second_steering_rad=float(steer2),
                        second_duration_seconds=float(duration2),
                        predicted_filtered_mid_x_m=float(fmid[0]),
                        predicted_filtered_mid_y_m=float(fmid[1]),
                        predicted_filtered_mid_yaw_rad=float(fmid[2]),
                        predicted_filtered_final_x_m=float(ffinal[0]),
                        predicted_filtered_final_y_m=float(ffinal[1]),
                        predicted_filtered_final_yaw_rad=float(ffinal[2]),
                        predicted_certification_final_x_m=float(cfinal[0]),
                        predicted_certification_final_y_m=float(cfinal[1]),
                        predicted_certification_final_yaw_rad=float(cfinal[2]),
                        current_strict_deficit=float(current_deficit),
                        predicted_strict_deficit=float(predicted_deficit),
                        deficit_improvement=float(improvement),
                        maximum_predicted_filtered_distance_m=float(maximum_filtered_distance),
                        cost=float(cost),
                        model_mode=(self.FULL_POSE_MODEL if use_full_pose else self.LEGACY_MODEL),
                    ))

        self.last_candidate_count = len(candidates)
        self.total_candidate_count += len(candidates)
        if not candidates:
            self.no_candidate_search_count += 1
            return None
        best = min(
            candidates,
            key=lambda item: (
                item.predicted_strict_deficit,
                item.cost,
                -item.deficit_improvement,
                item.total_execution_seconds,
            ),
        )
        self.activation_count += 1
        self.executed_seconds += best.total_execution_seconds
        self.last_selected = best
        return best

# ---------------------------------------------------------------------------
# V9.3.12-R4-E5 -- Load-Offset-Aware POSITION Recenter + Guaranteed Rollback
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class PositionBlockerRecenterConfig:
    """Bounded two-stage Ackermann corridor for a lateral-dominant POSITION blocker.

    R4-E4 closed the steering actuator and vehicle-path execution loop, then
    exposed the remaining modelling error: the planner was propagating a
    ``DockingError`` as if it were a world-fixed pose in the moving base frame.
    That omits the carried-load lever arm during vehicle rotation.  E5 keeps
    the same bounded corridor and actuator closure, but the runtime planner now
    propagates the *world-fixed target poses* while holding the carried-load
    pose rigid in the vehicle frame, then recomputes the task/certification
    errors from those full poses.

    The legacy error-space interface remains for archived regression tests; E5
    runtime calls always provide full poses and are counted separately.
    """

    wheelbase_m: float
    steering_limit_rad: float
    speed_mps: float
    filtered_position_activation_m: float
    filtered_yaw_activation_rad: float
    certification_position_activation_m: float
    certification_yaw_activation_rad: float
    minimum_lateral_fraction: float
    strict_position_limit_m: float
    strict_yaw_limit_rad: float
    predicted_position_headroom_m: float
    predicted_yaw_headroom_rad: float
    maximum_predicted_filtered_excursion_m: float
    final_filtered_position_guard_m: float
    final_filtered_yaw_guard_rad: float
    departure_duration_options_s: tuple[float, ...]
    return_duration_options_s: tuple[float, ...]
    steering_fractions: tuple[float, ...]
    maximum_speed_for_activation_mps: float
    maximum_total_execution_seconds: float
    # E6-only topology contract.  Keep False by default so archived E5
    # regression fixtures retain their historical planner semantics.
    require_non_retrace_topology: bool = False

    def validate(self) -> None:
        if self.wheelbase_m <= 0.0 or self.steering_limit_rad <= 0.0 or self.speed_mps <= 0.0:
            raise ValueError("position-recenter vehicle limits must be positive")
        if self.filtered_position_activation_m <= 0.0 or self.filtered_yaw_activation_rad <= 0.0:
            raise ValueError("position-recenter filtered activation envelope must be positive")
        if self.certification_position_activation_m <= 0.0 or self.certification_yaw_activation_rad <= 0.0:
            raise ValueError("position-recenter certification activation envelope must be positive")
        if not (0.0 < self.minimum_lateral_fraction <= 1.0):
            raise ValueError("position-recenter lateral fraction must be in (0,1]")
        if self.strict_position_limit_m <= 0.0 or self.strict_yaw_limit_rad <= 0.0:
            raise ValueError("position-recenter strict limits must be positive")
        if not (0.0 <= self.predicted_position_headroom_m < self.strict_position_limit_m):
            raise ValueError("position-recenter position headroom is invalid")
        if not (0.0 <= self.predicted_yaw_headroom_rad < self.strict_yaw_limit_rad):
            raise ValueError("position-recenter yaw headroom is invalid")
        if self.maximum_predicted_filtered_excursion_m <= self.filtered_position_activation_m:
            raise ValueError("position-recenter excursion guard must exceed activation envelope")
        if self.final_filtered_position_guard_m <= 0.0 or self.final_filtered_yaw_guard_rad <= 0.0:
            raise ValueError("position-recenter final filtered guards must be positive")
        if not self.departure_duration_options_s or any(x <= 0.0 for x in self.departure_duration_options_s):
            raise ValueError("position-recenter departure durations must be positive")
        if not self.return_duration_options_s or any(x <= 0.0 for x in self.return_duration_options_s):
            raise ValueError("position-recenter return durations must be positive")
        if not self.steering_fractions or any(not (0.0 < abs(x) <= 1.0) for x in self.steering_fractions):
            raise ValueError("position-recenter steering fractions must lie in (0,1]")
        if self.maximum_speed_for_activation_mps < 0.0:
            raise ValueError("position-recenter activation speed must be non-negative")
        if self.maximum_total_execution_seconds <= 0.0:
            raise ValueError("position-recenter execution budget must be positive")


@dataclass(frozen=True)
class PositionBlockerRecenterPlan:
    departure_speed_mps: float
    departure_steering_rad: float
    departure_duration_seconds: float
    nominal_return_speed_mps: float
    nominal_return_steering_rad: float
    nominal_return_duration_seconds: float
    predicted_mid_filtered_x_m: float
    predicted_mid_filtered_y_m: float
    predicted_mid_filtered_yaw_rad: float
    predicted_mid_certification_x_m: float
    predicted_mid_certification_y_m: float
    predicted_mid_certification_yaw_rad: float
    predicted_final_filtered_x_m: float
    predicted_final_filtered_y_m: float
    predicted_final_filtered_yaw_rad: float
    predicted_final_certification_x_m: float
    predicted_final_certification_y_m: float
    predicted_final_certification_yaw_rad: float
    predicted_effective_position_m: float
    predicted_effective_yaw_rad: float
    maximum_predicted_filtered_excursion_m: float
    cost: float
    model_mode: str = "ERROR_SPACE_LEGACY"

    @property
    def total_execution_seconds(self) -> float:
        return float(self.departure_duration_seconds) + float(self.nominal_return_duration_seconds)


@dataclass(frozen=True)
class PositionBlockerReturnPlan:
    speed_mps: float
    steering_rad: float
    duration_seconds: float
    predicted_final_filtered_x_m: float
    predicted_final_filtered_y_m: float
    predicted_final_filtered_yaw_rad: float
    predicted_final_certification_x_m: float
    predicted_final_certification_y_m: float
    predicted_final_certification_yaw_rad: float
    predicted_effective_position_m: float
    predicted_effective_yaw_rad: float
    cost: float
    model_mode: str = "ERROR_SPACE_LEGACY"


class PositionBlockerRecenterPlanner:
    """Blocker-aware lateral recenter with a fresh-RGB apex checkpoint.

    In E5 runtime the state model is full-pose and load-offset-aware:

    * the carried load is a rigid pose in the vehicle frame;
    * placement/certification targets are world-fixed poses expressed in the
      current vehicle frame and are propagated by the Ackermann base motion;
    * task/certification errors are recomputed after every prediction step.

    POSITION is treated lexicographically.  A POSITION corridor only has to
    place conservative position inside the unchanged strict position limit and
    keep yaw inside the existing certification-closure activation envelope.
    If yaw remains the next blocker, the already-bounded E2 YAW closure owns it.
    """

    FULL_POSE_MODEL = "FULL_POSE_RIGID_LOAD"
    LEGACY_MODEL = "ERROR_SPACE_LEGACY"

    def __init__(self, config: PositionBlockerRecenterConfig) -> None:
        config.validate()
        self.config = config
        self.reset()

    def reset(self) -> None:
        self.search_count = 0
        self.activation_count = 0
        self.total_candidate_count = 0
        self.no_candidate_search_count = 0
        self.return_replan_count = 0
        self.return_candidate_count = 0
        self.return_no_candidate_count = 0
        self.full_pose_search_count = 0
        self.full_pose_return_replan_count = 0
        self.legacy_error_space_search_count = 0
        # V9.3.12-R4-E6: a same-steering/opposite-speed pair is an exact
        # kinematic retrace, not a lateral recenter. Count and reject those
        # topologies in the full-pose POSITION planner.
        self.retrace_candidate_reject_count = 0
        self.topology_candidate_count = 0
        self.last_candidate_count = 0
        self.last_return_candidate_count = 0
        self.last_selected: PositionBlockerRecenterPlan | None = None
        self.last_return_selected: PositionBlockerReturnPlan | None = None
        self.last_model_mode = self.LEGACY_MODEL

    def _simulate(
        self,
        state: tuple[float, float, float],
        *,
        speed: float,
        steering: float,
        duration: float,
    ) -> tuple[float, float, float]:
        """Legacy error-space propagation retained only for regression."""
        remaining = max(0.0, float(duration))
        x, y, yaw = map(float, state)
        while remaining > 1e-9:
            dt = min(0.05, remaining)
            x, y, yaw = TerminalKinematicMPC.predict_target_pose(
                x,
                y,
                yaw,
                speed=float(speed),
                steering=float(steering),
                wheelbase=self.config.wheelbase_m,
                dt=dt,
            )
            remaining -= dt
        return float(x), float(y), float(yaw)

    @staticmethod
    def _load_to_target_error(
        load_pose: tuple[float, float, float],
        target_pose: tuple[float, float, float],
    ) -> tuple[float, float, float]:
        """Return load-to-target error in the target-yaw frame."""
        load_x, load_y, load_yaw = map(float, load_pose)
        target_x, target_y, target_yaw = map(float, target_pose)
        dx = target_x - load_x
        dy = target_y - load_y
        cosine = math.cos(target_yaw)
        sine = math.sin(target_yaw)
        longitudinal = cosine * dx + sine * dy
        lateral = -sine * dx + cosine * dy
        yaw = (target_yaw - load_yaw + math.pi) % (2.0 * math.pi) - math.pi
        return float(longitudinal), float(lateral), float(yaw)

    def _simulate_full_pose_leg(
        self,
        *,
        load_pose: tuple[float, float, float],
        task_target_pose: tuple[float, float, float],
        certification_target_pose: tuple[float, float, float],
        speed: float,
        steering: float,
        duration: float,
    ) -> tuple[
        tuple[float, float, float],
        tuple[float, float, float],
        tuple[float, float, float],
        tuple[float, float, float],
        float,
        float,
    ]:
        """Propagate fixed targets around a rigid carried-load pose.

        ``TerminalKinematicMPC.predict_target_pose`` is correct for a *fixed
        target pose* expressed in the moving base frame.  E4 incorrectly fed a
        ``DockingError`` into that function.  E5 instead propagates each target
        pose and recomputes the error against the load pose that remains rigid
        in the base frame.
        """
        remaining = max(0.0, float(duration))
        task = tuple(map(float, task_target_pose))
        cert = tuple(map(float, certification_target_pose))
        load = tuple(map(float, load_pose))
        initial_task_error = self._load_to_target_error(load, task)
        maximum_task_distance = math.hypot(initial_task_error[0], initial_task_error[1])
        maximum_task_abs_yaw = abs(initial_task_error[2])
        while remaining > 1e-9:
            dt = min(0.05, remaining)
            task = TerminalKinematicMPC.predict_target_pose(
                *task,
                speed=float(speed),
                steering=float(steering),
                wheelbase=self.config.wheelbase_m,
                dt=dt,
            )
            cert = TerminalKinematicMPC.predict_target_pose(
                *cert,
                speed=float(speed),
                steering=float(steering),
                wheelbase=self.config.wheelbase_m,
                dt=dt,
            )
            task_error = self._load_to_target_error(load, task)
            maximum_task_distance = max(
                maximum_task_distance,
                math.hypot(task_error[0], task_error[1]),
            )
            maximum_task_abs_yaw = max(maximum_task_abs_yaw, abs(task_error[2]))
            remaining -= dt
        task_error = self._load_to_target_error(load, task)
        cert_error = self._load_to_target_error(load, cert)
        return (
            tuple(map(float, task)),
            tuple(map(float, cert)),
            tuple(map(float, task_error)),
            tuple(map(float, cert_error)),
            float(maximum_task_distance),
            float(maximum_task_abs_yaw),
        )

    @staticmethod
    def effective_position(
        x: float,
        y: float,
        position_margin_m: float,
    ) -> float:
        return float(math.hypot(float(x), float(y)) + max(0.0, float(position_margin_m)))

    @staticmethod
    def effective_yaw(
        yaw: float,
        yaw_margin_rad: float,
    ) -> float:
        return float(abs(float(yaw)) + max(0.0, float(yaw_margin_rad)))

    def _activation_ready(
        self,
        *,
        filtered_x_m: float,
        filtered_y_m: float,
        filtered_yaw_rad: float,
        certification_x_m: float,
        certification_y_m: float,
        certification_yaw_rad: float,
        current_speed_mps: float,
    ) -> bool:
        c = self.config
        filtered_distance = math.hypot(float(filtered_x_m), float(filtered_y_m))
        cert_distance = math.hypot(float(certification_x_m), float(certification_y_m))
        lateral_fraction = abs(float(certification_y_m)) / max(1e-9, cert_distance)
        return bool(
            filtered_distance <= c.filtered_position_activation_m + 1e-9
            and abs(float(filtered_yaw_rad)) <= c.filtered_yaw_activation_rad + 1e-9
            and cert_distance <= c.certification_position_activation_m + 1e-9
            and abs(float(certification_yaw_rad)) <= c.certification_yaw_activation_rad + 1e-9
            and lateral_fraction >= c.minimum_lateral_fraction - 1e-9
            and abs(float(current_speed_mps)) <= c.maximum_speed_for_activation_mps + 1e-9
        )

    def _strict_ready_with_headroom(
        self,
        *,
        certification_state: tuple[float, float, float],
        position_margin_m: float,
        yaw_margin_rad: float,
    ) -> tuple[bool, float, float]:
        """Legacy all-axis strict-ready check."""
        c = self.config
        effective_position = self.effective_position(
            certification_state[0], certification_state[1], position_margin_m
        )
        effective_yaw = self.effective_yaw(certification_state[2], yaw_margin_rad)
        return (
            bool(
                effective_position
                <= c.strict_position_limit_m - c.predicted_position_headroom_m + 1e-9
                and effective_yaw
                <= c.strict_yaw_limit_rad - c.predicted_yaw_headroom_rad + 1e-9
            ),
            float(effective_position),
            float(effective_yaw),
        )

    def _position_ready_yaw_recoverable(
        self,
        *,
        certification_state: tuple[float, float, float],
        position_margin_m: float,
        yaw_margin_rad: float,
    ) -> tuple[bool, float, float]:
        """E5 lexicographic POSITION criterion.

        POSITION must clear the unchanged strict position limit.  Yaw is not
        allowed to become unbounded, but it may remain above strict because the
        already bounded E2 YAW certification closure is the next authority
        after POSITION is removed as the short-circuit blocker.
        """
        c = self.config
        effective_position = self.effective_position(
            certification_state[0], certification_state[1], position_margin_m
        )
        effective_yaw = self.effective_yaw(certification_state[2], yaw_margin_rad)
        return (
            bool(
                effective_position
                <= c.strict_position_limit_m - c.predicted_position_headroom_m + 1e-9
                and effective_yaw <= c.certification_yaw_activation_rad + 1e-9
            ),
            float(effective_position),
            float(effective_yaw),
        )

    def _steering_values(self) -> list[float]:
        c = self.config
        return sorted(
            {
                sign * abs(float(frac)) * c.steering_limit_rad
                for frac in c.steering_fractions
                for sign in (-1.0, 1.0)
            }
        )

    @staticmethod
    def _full_pose_args_present(
        load_pose_in_base: tuple[float, float, float] | None,
        task_target_pose_in_base: tuple[float, float, float] | None,
        certification_target_pose_in_base: tuple[float, float, float] | None,
    ) -> bool:
        supplied = [
            load_pose_in_base is not None,
            task_target_pose_in_base is not None,
            certification_target_pose_in_base is not None,
        ]
        if any(supplied) and not all(supplied):
            raise ValueError("E5 full-pose recenter requires load + task target + certification target")
        return all(supplied)

    def search_departure(
        self,
        *,
        filtered_x_m: float,
        filtered_y_m: float,
        filtered_yaw_rad: float,
        certification_x_m: float,
        certification_y_m: float,
        certification_yaw_rad: float,
        position_margin_m: float,
        yaw_margin_rad: float,
        current_speed_mps: float,
        terminal_budget_remaining_s: float,
        load_pose_in_base: tuple[float, float, float] | None = None,
        task_target_pose_in_base: tuple[float, float, float] | None = None,
        certification_target_pose_in_base: tuple[float, float, float] | None = None,
    ) -> PositionBlockerRecenterPlan | None:
        c = self.config
        self.search_count += 1
        if not self._activation_ready(
            filtered_x_m=filtered_x_m,
            filtered_y_m=filtered_y_m,
            filtered_yaw_rad=filtered_yaw_rad,
            certification_x_m=certification_x_m,
            certification_y_m=certification_y_m,
            certification_yaw_rad=certification_yaw_rad,
            current_speed_mps=current_speed_mps,
        ):
            self.last_candidate_count = 0
            self.no_candidate_search_count += 1
            return None

        use_full_pose = self._full_pose_args_present(
            load_pose_in_base,
            task_target_pose_in_base,
            certification_target_pose_in_base,
        )
        if use_full_pose:
            self.full_pose_search_count += 1
            self.last_model_mode = self.FULL_POSE_MODEL
        else:
            self.legacy_error_space_search_count += 1
            self.last_model_mode = self.LEGACY_MODEL

        filtered_initial = (
            float(filtered_x_m),
            float(filtered_y_m),
            float(filtered_yaw_rad),
        )
        cert_initial = (
            float(certification_x_m),
            float(certification_y_m),
            float(certification_yaw_rad),
        )
        steering_values = self._steering_values()
        candidates: list[PositionBlockerRecenterPlan] = []

        for departure_direction in (-1.0, 1.0):
            departure_speed = departure_direction * c.speed_mps
            for departure_steering in steering_values:
                for departure_duration in c.departure_duration_options_s:
                    if use_full_pose:
                        assert load_pose_in_base is not None
                        assert task_target_pose_in_base is not None
                        assert certification_target_pose_in_base is not None
                        (
                            task_mid_pose,
                            cert_mid_pose,
                            fmid,
                            cmid,
                            depart_max_excursion,
                            depart_max_abs_yaw,
                        ) = self._simulate_full_pose_leg(
                            load_pose=load_pose_in_base,
                            task_target_pose=task_target_pose_in_base,
                            certification_target_pose=certification_target_pose_in_base,
                            speed=departure_speed,
                            steering=departure_steering,
                            duration=departure_duration,
                        )
                        mid_filtered_distance = math.hypot(fmid[0], fmid[1])
                        if (
                            depart_max_excursion > c.maximum_predicted_filtered_excursion_m + 1e-9
                            or depart_max_abs_yaw > math.radians(12.0)
                        ):
                            continue
                    else:
                        fmid = self._simulate(
                            filtered_initial,
                            speed=departure_speed,
                            steering=departure_steering,
                            duration=departure_duration,
                        )
                        cmid = self._simulate(
                            cert_initial,
                            speed=departure_speed,
                            steering=departure_steering,
                            duration=departure_duration,
                        )
                        task_mid_pose = cert_mid_pose = None
                        mid_filtered_distance = math.hypot(fmid[0], fmid[1])
                        depart_max_excursion = max(
                            math.hypot(filtered_initial[0], filtered_initial[1]),
                            mid_filtered_distance,
                        )
                        if (
                            mid_filtered_distance > c.maximum_predicted_filtered_excursion_m + 1e-9
                            or abs(float(fmid[2])) > math.radians(12.0)
                        ):
                            continue

                    return_speed = -departure_speed
                    for return_steering in steering_values:
                        if (
                            use_full_pose
                            and c.require_non_retrace_topology
                            and departure_steering * return_steering >= 0.0
                        ):
                            # Opposite speed + same steering exactly retraces the
                            # departure circle. E5 selected this and therefore
                            # produced only ~4 mm of physical lateral recenter.
                            self.retrace_candidate_reject_count += len(c.return_duration_options_s)
                            continue
                        for return_duration in c.return_duration_options_s:
                            total = float(departure_duration) + float(return_duration)
                            if total > c.maximum_total_execution_seconds + 1e-9:
                                continue
                            if total + 2.0 > float(terminal_budget_remaining_s) + 1e-9:
                                continue

                            if use_full_pose:
                                assert task_mid_pose is not None and cert_mid_pose is not None
                                (
                                    _task_final_pose,
                                    _cert_final_pose,
                                    ffinal,
                                    cfinal,
                                    return_max_excursion,
                                    return_max_abs_yaw,
                                ) = self._simulate_full_pose_leg(
                                    load_pose=load_pose_in_base,
                                    task_target_pose=task_mid_pose,
                                    certification_target_pose=cert_mid_pose,
                                    speed=return_speed,
                                    steering=return_steering,
                                    duration=return_duration,
                                )
                                max_excursion = max(depart_max_excursion, return_max_excursion)
                                if (
                                    max_excursion > c.maximum_predicted_filtered_excursion_m + 1e-9
                                    or return_max_abs_yaw > math.radians(12.0)
                                ):
                                    continue
                            else:
                                ffinal = self._simulate(
                                    fmid,
                                    speed=return_speed,
                                    steering=return_steering,
                                    duration=return_duration,
                                )
                                cfinal = self._simulate(
                                    cmid,
                                    speed=return_speed,
                                    steering=return_steering,
                                    duration=return_duration,
                                )
                                max_excursion = max(
                                    math.hypot(filtered_initial[0], filtered_initial[1]),
                                    mid_filtered_distance,
                                    math.hypot(ffinal[0], ffinal[1]),
                                )

                            final_filtered_distance = math.hypot(ffinal[0], ffinal[1])
                            if (
                                final_filtered_distance > c.final_filtered_position_guard_m + 1e-9
                                or abs(float(ffinal[2])) > c.final_filtered_yaw_guard_rad + 1e-9
                            ):
                                continue

                            if use_full_pose:
                                ready, effective_position, effective_yaw = (
                                    self._position_ready_yaw_recoverable(
                                        certification_state=cfinal,
                                        position_margin_m=position_margin_m,
                                        yaw_margin_rad=yaw_margin_rad,
                                    )
                                )
                            else:
                                ready, effective_position, effective_yaw = (
                                    self._strict_ready_with_headroom(
                                        certification_state=cfinal,
                                        position_margin_m=position_margin_m,
                                        yaw_margin_rad=yaw_margin_rad,
                                    )
                                )
                            if not ready:
                                continue

                            # Full-pose E5 prefers a robust POSITION headroom
                            # while explicitly charging both excursion and yaw
                            # left for the bounded E2 YAW closure.
                            cost = (
                                24.0 * effective_position
                                + 0.75 * effective_yaw
                                + 2.0 * max_excursion
                                + 0.03 * total
                            )
                            if use_full_pose:
                                self.topology_candidate_count += 1
                            candidates.append(
                                PositionBlockerRecenterPlan(
                                    departure_speed_mps=float(departure_speed),
                                    departure_steering_rad=float(departure_steering),
                                    departure_duration_seconds=float(departure_duration),
                                    nominal_return_speed_mps=float(return_speed),
                                    nominal_return_steering_rad=float(return_steering),
                                    nominal_return_duration_seconds=float(return_duration),
                                    predicted_mid_filtered_x_m=float(fmid[0]),
                                    predicted_mid_filtered_y_m=float(fmid[1]),
                                    predicted_mid_filtered_yaw_rad=float(fmid[2]),
                                    predicted_mid_certification_x_m=float(cmid[0]),
                                    predicted_mid_certification_y_m=float(cmid[1]),
                                    predicted_mid_certification_yaw_rad=float(cmid[2]),
                                    predicted_final_filtered_x_m=float(ffinal[0]),
                                    predicted_final_filtered_y_m=float(ffinal[1]),
                                    predicted_final_filtered_yaw_rad=float(ffinal[2]),
                                    predicted_final_certification_x_m=float(cfinal[0]),
                                    predicted_final_certification_y_m=float(cfinal[1]),
                                    predicted_final_certification_yaw_rad=float(cfinal[2]),
                                    predicted_effective_position_m=float(effective_position),
                                    predicted_effective_yaw_rad=float(effective_yaw),
                                    maximum_predicted_filtered_excursion_m=float(max_excursion),
                                    cost=float(cost),
                                    model_mode=(
                                        self.FULL_POSE_MODEL if use_full_pose else self.LEGACY_MODEL
                                    ),
                                )
                            )

        self.last_candidate_count = len(candidates)
        self.total_candidate_count += len(candidates)
        if not candidates:
            self.no_candidate_search_count += 1
            return None

        if use_full_pose:
            best = min(
                candidates,
                key=lambda item: (
                    item.predicted_effective_position_m
                    + 0.08 * item.maximum_predicted_filtered_excursion_m
                    + 0.012 * max(
                        0.0,
                        item.predicted_effective_yaw_rad - self.config.strict_yaw_limit_rad,
                    ),
                    item.predicted_effective_yaw_rad,
                    item.maximum_predicted_filtered_excursion_m,
                    item.total_execution_seconds,
                    item.cost,
                ),
            )
        else:
            # Preserve the E4 legacy ranking for archived tests.
            best = min(
                candidates,
                key=lambda item: (
                    item.predicted_effective_position_m
                    + 0.05 * item.maximum_predicted_filtered_excursion_m
                    + 0.001 * item.total_execution_seconds,
                    item.predicted_effective_yaw_rad,
                    item.maximum_predicted_filtered_excursion_m,
                    item.cost,
                ),
            )
        self.activation_count += 1
        self.last_selected = best
        return best

    def search_return(
        self,
        *,
        filtered_x_m: float,
        filtered_y_m: float,
        filtered_yaw_rad: float,
        certification_x_m: float,
        certification_y_m: float,
        certification_yaw_rad: float,
        position_margin_m: float,
        yaw_margin_rad: float,
        preferred_speed_sign: int,
        terminal_budget_remaining_s: float,
        departure_steering_rad: float | None = None,
        departure_speed_mps: float | None = None,
        load_pose_in_base: tuple[float, float, float] | None = None,
        task_target_pose_in_base: tuple[float, float, float] | None = None,
        certification_target_pose_in_base: tuple[float, float, float] | None = None,
    ) -> PositionBlockerReturnPlan | None:
        """Re-plan the return leg from the *fresh observed full-pose midpoint*."""
        c = self.config
        self.return_replan_count += 1
        use_full_pose = self._full_pose_args_present(
            load_pose_in_base,
            task_target_pose_in_base,
            certification_target_pose_in_base,
        )
        if use_full_pose:
            self.full_pose_return_replan_count += 1
            self.last_model_mode = self.FULL_POSE_MODEL
        else:
            self.last_model_mode = self.LEGACY_MODEL

        filtered_initial = (
            float(filtered_x_m),
            float(filtered_y_m),
            float(filtered_yaw_rad),
        )
        cert_initial = (
            float(certification_x_m),
            float(certification_y_m),
            float(certification_yaw_rad),
        )
        if math.hypot(filtered_initial[0], filtered_initial[1]) > c.maximum_predicted_filtered_excursion_m + 0.04:
            self.last_return_candidate_count = 0
            self.return_no_candidate_count += 1
            return None

        steering_values = self._steering_values()
        direction_order = [1 if preferred_speed_sign >= 0 else -1]
        direction_order.append(-direction_order[0])
        candidates: list[PositionBlockerReturnPlan] = []
        for direction in direction_order:
            speed = float(direction) * c.speed_mps
            if (
                use_full_pose
                and c.require_non_retrace_topology
                and departure_speed_mps is not None
                and float(departure_speed_mps) * speed >= 0.0
            ):
                # The E6 parking-style lateral S-curve returns with opposite
                # translation direction as well as opposite steering sign.
                continue
            direction_penalty = 0.0 if direction == direction_order[0] else 0.08
            for steering in steering_values:
                if (
                    use_full_pose
                    and c.require_non_retrace_topology
                    and departure_steering_rad is not None
                    and float(departure_steering_rad) * float(steering) >= 0.0
                ):
                    self.retrace_candidate_reject_count += len(c.return_duration_options_s)
                    continue
                for duration in c.return_duration_options_s:
                    if float(duration) + 1.5 > float(terminal_budget_remaining_s) + 1e-9:
                        continue
                    if use_full_pose:
                        assert load_pose_in_base is not None
                        assert task_target_pose_in_base is not None
                        assert certification_target_pose_in_base is not None
                        (
                            _task_final_pose,
                            _cert_final_pose,
                            ffinal,
                            cfinal,
                            max_excursion,
                            max_abs_yaw,
                        ) = self._simulate_full_pose_leg(
                            load_pose=load_pose_in_base,
                            task_target_pose=task_target_pose_in_base,
                            certification_target_pose=certification_target_pose_in_base,
                            speed=speed,
                            steering=steering,
                            duration=duration,
                        )
                        if (
                            max_excursion > c.maximum_predicted_filtered_excursion_m + 0.04 + 1e-9
                            or max_abs_yaw > math.radians(12.0)
                        ):
                            continue
                    else:
                        ffinal = self._simulate(
                            filtered_initial,
                            speed=speed,
                            steering=steering,
                            duration=duration,
                        )
                        cfinal = self._simulate(
                            cert_initial,
                            speed=speed,
                            steering=steering,
                            duration=duration,
                        )

                    final_filtered_distance = math.hypot(ffinal[0], ffinal[1])
                    if (
                        final_filtered_distance > c.final_filtered_position_guard_m + 1e-9
                        or abs(float(ffinal[2])) > c.final_filtered_yaw_guard_rad + 1e-9
                    ):
                        continue
                    if use_full_pose:
                        ready, effective_position, effective_yaw = (
                            self._position_ready_yaw_recoverable(
                                certification_state=cfinal,
                                position_margin_m=position_margin_m,
                                yaw_margin_rad=yaw_margin_rad,
                            )
                        )
                    else:
                        ready, effective_position, effective_yaw = (
                            self._strict_ready_with_headroom(
                                certification_state=cfinal,
                                position_margin_m=position_margin_m,
                                yaw_margin_rad=yaw_margin_rad,
                            )
                        )
                    if not ready:
                        continue
                    cost = (
                        24.0 * effective_position
                        + 0.75 * effective_yaw
                        + 0.05 * float(duration)
                        + direction_penalty
                    )
                    if use_full_pose:
                        self.topology_candidate_count += 1
                    candidates.append(
                        PositionBlockerReturnPlan(
                            speed_mps=float(speed),
                            steering_rad=float(steering),
                            duration_seconds=float(duration),
                            predicted_final_filtered_x_m=float(ffinal[0]),
                            predicted_final_filtered_y_m=float(ffinal[1]),
                            predicted_final_filtered_yaw_rad=float(ffinal[2]),
                            predicted_final_certification_x_m=float(cfinal[0]),
                            predicted_final_certification_y_m=float(cfinal[1]),
                            predicted_final_certification_yaw_rad=float(cfinal[2]),
                            predicted_effective_position_m=float(effective_position),
                            predicted_effective_yaw_rad=float(effective_yaw),
                            cost=float(cost),
                            model_mode=(
                                self.FULL_POSE_MODEL if use_full_pose else self.LEGACY_MODEL
                            ),
                        )
                    )

        self.last_return_candidate_count = len(candidates)
        self.return_candidate_count += len(candidates)
        if not candidates:
            self.return_no_candidate_count += 1
            return None
        best = min(
            candidates,
            key=lambda item: (
                item.predicted_effective_position_m,
                item.predicted_effective_yaw_rad,
                item.duration_seconds,
                item.cost,
            ),
        )
        self.last_return_selected = best
        return best
