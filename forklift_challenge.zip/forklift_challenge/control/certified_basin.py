"""V9.3.11 temporal certification memory for terminal release.

This module is deliberately independent of MuJoCo and project geometry.  It
turns noisy frame-level certification evidence into a short-lived, auditable
certified basin.  Persistence can only keep a previously earned basin alive;
a separate consensus-entry route may create a basin only after bounded
high-confidence evidence has accumulated.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class CertifiedBasinConfig:
    hold_seconds: float
    consensus_evidence_seconds: float
    consensus_evidence_decay: float
    # Backward-compatible default preserves V9.3.11. V9.3.12 sets False:
    # consensus may accumulate as estimator evidence but can no longer create
    # release certification.
    allow_consensus_entry: bool = True

    def validate(self) -> None:
        if self.hold_seconds <= 0.0:
            raise ValueError("certified basin hold_seconds must be positive")
        if self.consensus_evidence_seconds <= 0.0:
            raise ValueError("certified basin consensus evidence must be positive")
        if not 0.0 < self.consensus_evidence_decay <= 1.0:
            raise ValueError("certified basin consensus decay must be in (0, 1]")


@dataclass(frozen=True)
class CertifiedBasinUpdate:
    certified: bool
    source: str
    active: bool
    age_seconds: float
    consensus_evidence_seconds: float
    entered: bool
    exited: bool


class CertifiedBasinLatch:
    """Short-lived Schmitt-style memory around release certification.

    STRICT is the preferred entry path. CONSENSUS is an optional independent
    evidence path whose geometric/vision safety conditions are computed by the
    caller. Once entered, PERSISTED may bridge brief frame-level jitter while
    the caller's loose/support envelope remains safe. The lease is never
    renewed by PERSISTED frames, so persistence cannot become an indefinite
    release authorization.
    """

    def __init__(self, config: CertifiedBasinConfig) -> None:
        config.validate()
        self.config = config
        self.reset()

    def reset(self) -> None:
        self.active = False
        self.source = "NONE"
        self._entry_time: float | None = None
        self._lease_time: float | None = None
        self._last_update_time: float | None = None
        self.consensus_evidence_seconds = 0.0
        self.enter_count = 0
        self.strict_enter_count = 0
        self.consensus_enter_count = 0
        self.exit_count = 0
        self.persisted_frame_count = 0
        self.persisted_pass_count = 0
        self.longest_active_seconds = 0.0
        self.first_certification_time: float | None = None

    def _dt(self, now: float) -> float:
        now = float(now)
        previous = self._last_update_time
        self._last_update_time = now
        if previous is None:
            return 0.0
        return max(0.0, min(0.20, now - previous))

    def update(
        self,
        now: float,
        *,
        strict_certified: bool,
        consensus_candidate: bool,
        support_safe: bool,
    ) -> CertifiedBasinUpdate:
        now = float(now)
        dt = self._dt(now)
        entered = False
        exited = False

        if consensus_candidate:
            self.consensus_evidence_seconds += dt
        else:
            self.consensus_evidence_seconds = max(
                0.0,
                self.consensus_evidence_seconds
                - self.config.consensus_evidence_decay * dt,
            )

        entry_source: str | None = None
        if strict_certified:
            entry_source = "STRICT"
        elif (
            self.config.allow_consensus_entry
            and not self.active
            and consensus_candidate
            and self.consensus_evidence_seconds >= self.config.consensus_evidence_seconds
        ):
            entry_source = "CONSENSUS"

        if entry_source is not None:
            if not self.active:
                entered = True
                self.enter_count += 1
                self._entry_time = now
                if self.first_certification_time is None:
                    self.first_certification_time = now
            self.active = True
            self.source = entry_source
            self._lease_time = now
            if entry_source == "STRICT":
                self.strict_enter_count += int(entered)
            else:
                self.consensus_enter_count += int(entered)

        if self.active:
            lease_time = now if self._lease_time is None else self._lease_time
            age = max(0.0, now - lease_time)
            if not strict_certified and entry_source is None:
                if support_safe and age <= self.config.hold_seconds:
                    self.persisted_frame_count += 1
                    self.persisted_pass_count += 1
                    current_duration = 0.0 if self._entry_time is None else max(0.0, now - self._entry_time)
                    self.longest_active_seconds = max(self.longest_active_seconds, current_duration)
                    return CertifiedBasinUpdate(
                        certified=True,
                        source="PERSISTED",
                        active=True,
                        age_seconds=age,
                        consensus_evidence_seconds=self.consensus_evidence_seconds,
                        entered=entered,
                        exited=False,
                    )
                self.active = False
                self.source = "NONE"
                self.exit_count += 1
                exited = True
                self._entry_time = None
                self._lease_time = None
            else:
                current_duration = 0.0 if self._entry_time is None else max(0.0, now - self._entry_time)
                self.longest_active_seconds = max(self.longest_active_seconds, current_duration)
                return CertifiedBasinUpdate(
                    certified=True,
                    source=self.source,
                    active=True,
                    age_seconds=age,
                    consensus_evidence_seconds=self.consensus_evidence_seconds,
                    entered=entered,
                    exited=False,
                )

        return CertifiedBasinUpdate(
            certified=False,
            source="NONE",
            active=False,
            age_seconds=0.0,
            consensus_evidence_seconds=self.consensus_evidence_seconds,
            entered=entered,
            exited=exited,
        )
