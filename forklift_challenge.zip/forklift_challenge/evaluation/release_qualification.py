"""Release qualification rules for the frozen V8.2 controller."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from pathlib import Path
from typing import Any, Mapping


@dataclass(frozen=True)
class ReleaseThresholds:
    minimum_success_rate: float
    minimum_pickup_opportunity_detection_rate: float = 0.85
    require_preinsert_ready_rate: float = 1.0
    require_first_preinsert_rate: float = 1.0
    require_pickup_vision_use_rate: float = 1.0
    maximum_pickup_fused_position_p95_m: float = 0.08
    maximum_pickup_fused_yaw_p95_deg: float = 5.0
    maximum_accepted_severe_pickup_outliers: int = 0
    minimum_placement_detection_rate: float = 0.80
    maximum_placement_position_rmse_m: float = 0.08
    require_terminal_vision_use_rate: float = 1.0
    maximum_render_failures: int = 0
    maximum_render_invalid_frames: int = 0
    maximum_render_context_warnings: int = 0
    maximum_episode_timeout_rate: float = 1.0
    maximum_long_episode_rate: float = 1.0
    maximum_terminal_budget_exhausted_rate: float = 1.0


@dataclass(frozen=True)
class Check:
    name: str
    value: float | int | None
    requirement: str
    passed: bool

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class QualificationResult:
    label: str
    hard_gate: bool
    passed: bool
    checks: tuple[Check, ...]
    summary_path: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "label": self.label,
            "hard_gate": self.hard_gate,
            "passed": self.passed,
            "checks": [check.to_dict() for check in self.checks],
            "summary_path": self.summary_path,
        }


FORMAL_THRESHOLDS = {
    "moderate_easy": ReleaseThresholds(minimum_success_rate=0.80),
    "moderate_nominal": ReleaseThresholds(minimum_success_rate=0.70),
    "finals_easy": ReleaseThresholds(
        minimum_success_rate=0.50,
        minimum_pickup_opportunity_detection_rate=0.85,
    ),
}

COMBINED_INFORMATIONAL = ReleaseThresholds(
    minimum_success_rate=0.40,
    minimum_pickup_opportunity_detection_rate=0.80,
)


def _get(summary: Mapping[str, Any], key: str) -> Any:
    if key not in summary:
        raise KeyError(f"summary is missing required field: {key}")
    return summary[key]


def qualify_summary(
    summary: Mapping[str, Any],
    *,
    label: str,
    thresholds: ReleaseThresholds,
    hard_gate: bool = True,
    summary_path: str = "",
) -> QualificationResult:
    checks = (
        Check(
            "success_rate",
            float(_get(summary, "success_rate")),
            f">= {thresholds.minimum_success_rate:.0%}",
            float(_get(summary, "success_rate"))
            >= thresholds.minimum_success_rate,
        ),
        Check(
            "pickup_opportunity_detection_rate",
            float(_get(summary, "average_pickup_vision_opportunity_detection_rate")),
            f">= {thresholds.minimum_pickup_opportunity_detection_rate:.0%}",
            float(_get(summary, "average_pickup_vision_opportunity_detection_rate"))
            >= thresholds.minimum_pickup_opportunity_detection_rate,
        ),
        Check(
            "pickup_preinsert_ready_rate",
            float(_get(summary, "pickup_vision_preinsert_ready_rate")),
            "= 100%",
            float(_get(summary, "pickup_vision_preinsert_ready_rate"))
            >= thresholds.require_preinsert_ready_rate,
        ),
        Check(
            "pickup_first_detection_preinsert_rate",
            float(_get(summary, "pickup_vision_first_detection_preinsert_rate")),
            "= 100%",
            float(_get(summary, "pickup_vision_first_detection_preinsert_rate"))
            >= thresholds.require_first_preinsert_rate,
        ),
        Check(
            "pickup_vision_use_rate",
            float(_get(summary, "pickup_vision_use_rate")),
            "= 100%",
            float(_get(summary, "pickup_vision_use_rate"))
            >= thresholds.require_pickup_vision_use_rate,
        ),
        Check(
            "pickup_fused_position_p95_m",
            float(_get(summary, "average_pickup_vision_fused_position_p95_m")),
            f"<= {thresholds.maximum_pickup_fused_position_p95_m:.3f} m",
            float(_get(summary, "average_pickup_vision_fused_position_p95_m"))
            <= thresholds.maximum_pickup_fused_position_p95_m,
        ),
        Check(
            "pickup_fused_yaw_p95_deg",
            float(_get(summary, "average_pickup_vision_fused_yaw_p95_deg")),
            f"<= {thresholds.maximum_pickup_fused_yaw_p95_deg:.1f} deg",
            float(_get(summary, "average_pickup_vision_fused_yaw_p95_deg"))
            <= thresholds.maximum_pickup_fused_yaw_p95_deg,
        ),
        Check(
            "accepted_severe_pickup_outliers",
            int(_get(summary, "total_pickup_vision_control_accepted_severe_outlier_count")),
            "= 0",
            int(_get(summary, "total_pickup_vision_control_accepted_severe_outlier_count"))
            <= thresholds.maximum_accepted_severe_pickup_outliers,
        ),
        Check(
            "placement_detection_rate",
            float(_get(summary, "average_vision_detection_rate")),
            f">= {thresholds.minimum_placement_detection_rate:.0%}",
            float(_get(summary, "average_vision_detection_rate"))
            >= thresholds.minimum_placement_detection_rate,
        ),
        Check(
            "placement_position_rmse_m",
            float(_get(summary, "average_vision_position_rmse_m")),
            f"<= {thresholds.maximum_placement_position_rmse_m:.3f} m",
            float(_get(summary, "average_vision_position_rmse_m"))
            <= thresholds.maximum_placement_position_rmse_m,
        ),
        Check(
            "terminal_vision_use_rate",
            float(_get(summary, "vision_terminal_use_rate")),
            "= 100%",
            float(_get(summary, "vision_terminal_use_rate"))
            >= thresholds.require_terminal_vision_use_rate,
        ),
        Check(
            "render_failure_count",
            int(_get(summary, "render_failure_count")),
            "= 0",
            int(_get(summary, "render_failure_count"))
            <= thresholds.maximum_render_failures,
        ),
        Check(
            "render_invalid_frame_count",
            int(_get(summary, "render_invalid_frame_count")),
            "= 0",
            int(_get(summary, "render_invalid_frame_count"))
            <= thresholds.maximum_render_invalid_frames,
        ),
        Check(
            "render_context_warning_count",
            int(_get(summary, "render_context_warning_count")),
            "= 0",
            int(_get(summary, "render_context_warning_count"))
            <= thresholds.maximum_render_context_warnings,
        ),
        Check(
            "episode_timeout_rate",
            float(summary.get("episode_timeout_rate", 0.0)),
            f"<= {thresholds.maximum_episode_timeout_rate:.0%}",
            float(summary.get("episode_timeout_rate", 0.0))
            <= thresholds.maximum_episode_timeout_rate,
        ),
        Check(
            "long_episode_rate",
            float(summary.get("long_episode_rate", 0.0)),
            f"<= {thresholds.maximum_long_episode_rate:.0%}",
            float(summary.get("long_episode_rate", 0.0))
            <= thresholds.maximum_long_episode_rate,
        ),
        Check(
            "terminal_budget_exhausted_rate",
            float(summary.get("terminal_budget_exhausted_rate", 0.0)),
            f"<= {thresholds.maximum_terminal_budget_exhausted_rate:.0%}",
            float(summary.get("terminal_budget_exhausted_rate", 0.0))
            <= thresholds.maximum_terminal_budget_exhausted_rate,
        ),
    )
    passed = all(check.passed for check in checks)
    return QualificationResult(
        label=label,
        hard_gate=hard_gate,
        passed=passed,
        checks=checks,
        summary_path=summary_path,
    )


def qualify_summary_file(
    path: str | Path,
    *,
    label: str,
    thresholds: ReleaseThresholds,
    hard_gate: bool = True,
) -> QualificationResult:
    path = Path(path)
    summary = json.loads(path.read_text(encoding="utf-8"))
    return qualify_summary(
        summary,
        label=label,
        thresholds=thresholds,
        hard_gate=hard_gate,
        summary_path=str(path),
    )


def overall_pass(results: list[QualificationResult]) -> bool:
    return all(result.passed for result in results if result.hard_gate)
