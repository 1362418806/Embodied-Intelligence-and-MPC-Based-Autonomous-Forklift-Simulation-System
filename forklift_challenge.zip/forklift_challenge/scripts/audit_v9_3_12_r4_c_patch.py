from pathlib import Path
import ast
import yaml

ROOT = Path(__file__).resolve().parents[1]
checks = []

def check(name, ok):
    checks.append((name, bool(ok)))
    print(f"{'PASS' if ok else 'FAIL'} {name}")

control = (ROOT / 'control' / 'terminal_micro_primitives.py').read_text(encoding='utf-8')
task = (ROOT / 'task' / 'pickup_state_machine.py').read_text(encoding='utf-8')
config_path = ROOT / 'configs' / 'vehicle_v9_3_12_r4_c.yaml'
config = yaml.safe_load(config_path.read_text(encoding='utf-8'))

ast.parse(control)
ast.parse(task)
check('control AST', True)
check('task AST', True)
check('pose guard helper', 'def pose_within_guard' in control)
check('cooldown helper', 'def cooldown_remaining' in control)
check('budget helper', 'def motion_budget_exhausted' in control)
check('handoff interlock', 'R4-C retention handoff interlock' in task)
check('final settle lease', 'R4-C final strict-evidence settle' in task)
check('instant strict chain preserved', 'placement_release_witness_require_instant_strict_for_intent' in task)

base = config['autonomy']
overrides = config['perception']['terminal_autonomy_overrides']
check('base retention off', float(base['placement_strict_recovery_retention_enabled']) == 0.0)
check('base final settle off', float(base['placement_strict_recovery_retention_final_settle_seconds']) == 0.0)
check('weak retention on', float(overrides['weak_guide']['placement_strict_recovery_retention_enabled']) == 1.0)
check('weak final settle 0.9s', abs(float(overrides['weak_guide']['placement_strict_recovery_retention_final_settle_seconds']) - 0.9) < 1e-9)
check('consensus release authority off', float(overrides['weak_guide']['placement_certified_basin_consensus_release_authority']) == 0.0)
check('instant strict intent gate on', float(overrides['weak_guide']['placement_release_witness_require_instant_strict_for_intent']) == 1.0)
check('R4-C output root', config['batch']['output_root'] == 'outputs/v9_3_12_r4_c_batch')

raise SystemExit(0 if all(ok for _, ok in checks) else 2)
