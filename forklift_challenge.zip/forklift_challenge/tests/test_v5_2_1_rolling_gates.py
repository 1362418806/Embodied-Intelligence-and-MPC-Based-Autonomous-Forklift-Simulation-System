"""Regression tests for V5.2.1 rolling ALIGN/INSERT gates."""

from __future__ import annotations

from pathlib import Path

import yaml

from control.docking_controller import DockingController
from interfaces.observation import ForkliftObservation, Pose3D
from task.pickup_state_machine import (
    PickupParameters,
    PickupState,
    PickupStateMachine,
)


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def pose(x=0.0, y=0.0, yaw=0.0) -> Pose3D:
    return Pose3D(x=x, y=y, z=0.0, roll=0.0, pitch=0.0, yaw=yaw)


def observation(
    sim_time: float,
    *,
    pallet_x: float,
    pallet_y: float = 0.0,
    pallet_yaw: float = 0.0,
) -> ForkliftObservation:
    return ForkliftObservation(
        sim_time=sim_time,
        vehicle_pose_world=pose(),
        vehicle_linear_velocity=(0.0, 0.0, 0.0),
        vehicle_angular_velocity=(0.0, 0.0, 0.0),
        steering_left=0.0,
        steering_right=0.0,
        front_wheel_speed_left=0.0,
        front_wheel_speed_right=0.0,
        lift_position=0.04,
        lift_velocity=0.0,
        pallet_pose_world=pose(3.2),
        pallet_pose_in_base=pose(pallet_x, pallet_y, pallet_yaw),
        placement_pose_in_base=pose(5.0, -1.0),
        fork_contact_count=0,
        load_state="GROUND",
    )


def load_machine() -> PickupStateMachine:
    config_path = PROJECT_ROOT / "configs" / "vehicle_v5_2_1.yaml"
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    values = config["controller"]
    controller = DockingController(
        distance_gain=float(values["distance_gain"]),
        heading_gain=float(values["heading_gain"]),
        yaw_gain=float(values["yaw_gain"]),
        lateral_gain=float(values["lateral_gain"]),
        lookahead_distance=float(values["lookahead_distance"]),
        maximum_steering=float(values["maximum_steering"]),
        minimum_creep_speed=float(values["minimum_creep_speed"]),
        heading_slowdown_angle=float(values["heading_slowdown_angle"]),
        yaw_slowdown_angle=float(values["yaw_slowdown_angle"]),
        minimum_alignment_scale=float(values["minimum_alignment_scale"]),
    )
    return PickupStateMachine(
        parameters=PickupParameters.from_mapping(config["autonomy"]),
        docking_controller=controller,
    )


def set_state(machine: PickupStateMachine, state: PickupState) -> None:
    machine.state = state
    machine._state_enter_time = 0.0
    machine._reset_progress(0.0)


def test_align_keeps_rolling_after_nominal_gate_when_line_is_not_ready() -> None:
    machine = load_machine()
    set_state(machine, PickupState.ALIGN)
    decision = machine.step(
        observation(1.0, pallet_x=2.68, pallet_y=0.13, pallet_yaw=0.0)
    )
    assert decision.state == PickupState.ALIGN
    assert decision.action.speed_target > 0.0
    assert "Acquiring" in decision.status


def test_align_handoff_still_uses_nominal_gate() -> None:
    machine = load_machine()
    set_state(machine, PickupState.ALIGN)
    first = machine.step(
        observation(1.0, pallet_x=2.74, pallet_y=0.04, pallet_yaw=0.02)
    )
    assert first.state == PickupState.ALIGN
    assert first.action.speed_target == 0.0
    second = machine.step(
        observation(1.25, pallet_x=2.74, pallet_y=0.04, pallet_yaw=0.02)
    )
    assert second.state == PickupState.INSERT


def test_insert_keeps_rolling_after_nominal_gate_for_final_correction() -> None:
    machine = load_machine()
    set_state(machine, PickupState.INSERT)
    decision = machine.step(
        observation(1.0, pallet_x=1.58, pallet_y=0.12, pallet_yaw=0.02)
    )
    assert decision.state == PickupState.INSERT
    assert decision.action.speed_target > 0.0


def test_insert_completes_inside_the_correction_window() -> None:
    machine = load_machine()
    set_state(machine, PickupState.INSERT)
    decision = machine.step(
        observation(1.0, pallet_x=1.52, pallet_y=0.04, pallet_yaw=0.03)
    )
    assert decision.state == PickupState.LIFT


def test_insert_recovers_only_at_final_abort_boundary() -> None:
    machine = load_machine()
    set_state(machine, PickupState.INSERT)
    decision = machine.step(
        observation(1.0, pallet_x=1.44, pallet_y=0.12, pallet_yaw=0.02)
    )
    assert decision.state == PickupState.RECOVER_REVERSE


def test_config_has_enough_time_for_physical_insertion() -> None:
    machine = load_machine()
    assert machine.parameters.insert_timeout == 30.0
    assert machine.parameters.insertion_minimum_speed == 0.045
