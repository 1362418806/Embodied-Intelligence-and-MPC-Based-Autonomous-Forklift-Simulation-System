"""Coarse structured-guide adapter for finals weak-guidance testing.

The adapter deliberately reduces only the relative guide supplied to the
controller.  It never reads MuJoCo truth and therefore cannot improve the
controller's estimate.  RGB pipelines remain free to refine the coarse guide.
"""
from __future__ import annotations

from dataclasses import replace
import math

from interfaces.observation import ForkliftObservation, Pose3D


def _quantize(value: float, resolution: float) -> float:
    if resolution <= 0.0:
        return float(value)
    return round(float(value) / float(resolution)) * float(resolution)


def quantize_pose(pose: Pose3D, *, position_resolution_m: float, yaw_resolution_rad: float) -> Pose3D:
    """Quantize a relative pose without adding privileged information."""
    return Pose3D(
        _quantize(pose.x, position_resolution_m),
        _quantize(pose.y, position_resolution_m),
        _quantize(pose.z, position_resolution_m),
        pose.roll,
        pose.pitch,
        _quantize(pose.yaw, yaw_resolution_rad),
    )


def quantize_weak_guide_observation(
    observation: ForkliftObservation,
    *,
    position_resolution_m: float = 0.20,
    yaw_resolution_deg: float = 10.0,
) -> ForkliftObservation:
    """Return an observation whose structured target guides are coarse.

    Only ``pallet_pose_in_base`` and ``placement_pose_in_base`` are modified.
    Vehicle state, contacts and world-space physics telemetry are untouched.
    """
    yaw_resolution_rad = math.radians(float(yaw_resolution_deg))
    pallet = observation.pallet_pose_in_base
    placement = observation.placement_pose_in_base
    return replace(
        observation,
        pallet_pose_in_base=(
            None if pallet is None else quantize_pose(
                pallet,
                position_resolution_m=position_resolution_m,
                yaw_resolution_rad=yaw_resolution_rad,
            )
        ),
        placement_pose_in_base=(
            None if placement is None else quantize_pose(
                placement,
                position_resolution_m=position_resolution_m,
                yaw_resolution_rad=yaw_resolution_rad,
            )
        ),
    )
