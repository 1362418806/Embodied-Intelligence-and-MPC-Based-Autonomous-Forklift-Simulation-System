"""Independent ground-truth scoring for noisy-pose terminal placement."""

from __future__ import annotations

from dataclasses import asdict, dataclass


@dataclass(frozen=True)
class TerminalValidation:
    passed: bool
    failure_reason: str | None
    placement_position_ok: bool
    placement_yaw_ok: bool
    release_motion_ok: bool
    load_released: bool

    def to_dict(self):
        return asdict(self)


def validate_terminal_mission(
    *,
    mission_done: bool,
    placement_error_m: float,
    placement_yaw_error_rad: float,
    release_motion_m: float,
    load_state: str,
    position_tolerance_m: float,
    yaw_tolerance_rad: float,
    release_motion_tolerance_m: float,
) -> TerminalValidation:
    position_ok = float(placement_error_m) <= float(position_tolerance_m) + 1e-9
    yaw_ok = abs(float(placement_yaw_error_rad)) <= float(yaw_tolerance_rad) + 1e-9
    motion_ok = float(release_motion_m) <= float(release_motion_tolerance_m) + 1e-9
    released = not str(load_state).startswith("LIFTED")

    if not mission_done:
        return TerminalValidation(
            passed=False,
            failure_reason=None,
            placement_position_ok=position_ok,
            placement_yaw_ok=yaw_ok,
            release_motion_ok=motion_ok,
            load_released=released,
        )

    if not position_ok:
        reason = (
            "ground-truth final placement outside position tolerance "
            f"({placement_error_m:.3f}>{position_tolerance_m:.3f}m)"
        )
    elif not yaw_ok:
        reason = (
            "ground-truth final placement outside yaw tolerance "
            f"({placement_yaw_error_rad:.3f}>{yaw_tolerance_rad:.3f}rad)"
        )
    elif not motion_ok:
        reason = (
            "ground-truth pallet motion exceeded withdrawal tolerance "
            f"({release_motion_m:.3f}>{release_motion_tolerance_m:.3f}m)"
        )
    elif not released:
        reason = "ground-truth pallet remained lifted at mission end"
    else:
        reason = None

    return TerminalValidation(
        passed=reason is None,
        failure_reason=reason,
        placement_position_ok=position_ok,
        placement_yaw_ok=yaw_ok,
        release_motion_ok=motion_ok,
        load_released=released,
    )
