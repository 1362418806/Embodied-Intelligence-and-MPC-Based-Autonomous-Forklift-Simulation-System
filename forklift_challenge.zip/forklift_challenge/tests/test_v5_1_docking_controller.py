"""V5.1 controller tests for stand-off planning and rolling ALIGN."""

from __future__ import annotations

import math

from control.docking_controller import (
    DockingController,
    object_standoff_target,
)
from interfaces.observation import Pose3D


def pose(x: float, y: float = 0.0, yaw: float = 0.0) -> Pose3D:
    return Pose3D(x=x, y=y, z=0.0, roll=0.0, pitch=0.0, yaw=yaw)


def controller() -> DockingController:
    return DockingController(
        distance_gain=0.78,
        heading_gain=1.45,
        yaw_gain=0.72,
        lateral_gain=0.82,
        lookahead_distance=0.95,
        maximum_steering=0.36,
        minimum_creep_speed=0.055,
        heading_slowdown_angle=0.75,
        yaw_slowdown_angle=0.52,
        minimum_alignment_scale=0.32,
    )


def test_standoff_target_is_planned_along_object_axis() -> None:
    yaw = math.radians(30.0)
    target = object_standoff_target(
        pose(4.0, y=1.0, yaw=yaw),
        standoff_distance=2.0,
    )
    assert math.isclose(target.x, 4.0 - 2.0 * math.cos(yaw), abs_tol=1e-12)
    assert math.isclose(target.y, 1.0 - 2.0 * math.sin(yaw), abs_tol=1e-12)
    assert math.isclose(target.yaw, yaw, abs_tol=1e-12)


def test_rolling_alignment_minimum_speed_override_is_applied() -> None:
    result = controller().command(
        pose(2.90, y=0.08, yaw=math.radians(3.0)),
        standoff_distance=2.85,
        maximum_speed=0.13,
        minimum_speed_override=0.075,
        stop_distance=0.0,
        lift_target=0.04,
    )
    assert result.error.longitudinal > 0.0
    assert result.action.speed_target >= 0.075
    assert abs(result.action.steering_command) > 0.0


def test_overshot_standoff_never_causes_uncommanded_reverse() -> None:
    result = controller().command(
        pose(2.70),
        standoff_distance=2.85,
        maximum_speed=0.13,
        minimum_speed_override=0.075,
        stop_distance=0.0,
        lift_target=0.04,
    )
    assert result.error.longitudinal < 0.0
    assert result.action.speed_target == 0.0
