"""Unit tests for forklift lift/drive safety interlocks."""

from __future__ import annotations

import math

import pytest

from control.safety import LiftDriveInterlock


def make_interlock(*, enabled: bool = True) -> LiftDriveInterlock:
    interlock = LiftDriveInterlock(
        enabled=enabled,
        velocity_threshold=0.01,
        settle_time=0.20,
    )
    interlock.reset(lift_target=0.0, sim_time=0.0)
    return interlock


def test_target_change_immediately_blocks_drive() -> None:
    interlock = make_interlock()
    result = interlock.resolve(
        requested_speed=0.4,
        lift_velocity=0.0,
        lift_target=0.3,
        sim_time=1.0,
    )

    assert result.lift_motion_active
    assert result.reason == "target-change"
    assert math.isclose(result.applied_speed, 0.0)


def test_lift_velocity_keeps_interlock_active() -> None:
    interlock = make_interlock()
    interlock.resolve(
        requested_speed=0.0,
        lift_velocity=0.0,
        lift_target=0.3,
        sim_time=1.0,
    )
    result = interlock.resolve(
        requested_speed=0.4,
        lift_velocity=0.08,
        lift_target=0.3,
        sim_time=1.1,
    )

    assert result.lift_motion_active
    assert result.reason == "moving"
    assert math.isclose(result.applied_speed, 0.0)


def test_drive_releases_after_velocity_settles_despite_position_error() -> None:
    """Regression: elevated forks must be able to drive after settling."""
    interlock = make_interlock()
    interlock.resolve(
        requested_speed=0.0,
        lift_velocity=0.05,
        lift_target=0.6,
        sim_time=1.0,
    )
    result = interlock.resolve(
        requested_speed=0.3,
        lift_velocity=0.0,
        lift_target=0.6,
        sim_time=1.25,
    )

    assert not result.lift_motion_active
    assert result.reason == "off"
    assert math.isclose(result.applied_speed, 0.3)


def test_disabled_interlock_preserves_drive_command() -> None:
    interlock = make_interlock(enabled=False)
    result = interlock.resolve(
        requested_speed=-0.25,
        lift_velocity=0.2,
        lift_target=0.8,
        sim_time=1.0,
    )

    assert not result.lift_motion_active
    assert result.reason == "disabled"
    assert math.isclose(result.applied_speed, -0.25)


def test_invalid_interlock_parameters_are_rejected() -> None:
    with pytest.raises(ValueError, match="velocity_threshold"):
        LiftDriveInterlock(
            enabled=True,
            velocity_threshold=-0.01,
            settle_time=0.2,
        )
