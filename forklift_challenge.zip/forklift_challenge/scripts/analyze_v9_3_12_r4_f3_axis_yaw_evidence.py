"""Analyze V9.3.12-R4-F3 axis-separated carried-load yaw evidence.

Runtime/controller telemetry is reported independently from simulator ground
truth. Ground truth is consumed only for offline diagnostic attribution and
never by the controller.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from statistics import median
from typing import Any


def wrap_rad(v: float) -> float:
    return (float(v) + math.pi) % (2.0 * math.pi) - math.pi


def rows(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def _range(values: list[float]) -> float | None:
    return max(values) - min(values) if values else None


def _median(values: list[float]) -> float | None:
    return median(values) if values else None


def analyze(path: Path) -> dict[str, Any]:
    data = rows(path)
    target_bias: list[float] = []
    load_bias: list[float] = []
    relative_bias: list[float] = []
    motion_sigmas: list[float] = []
    release_sigmas: list[float] = []
    translation_stale: list[float] = []
    yaw_stale: list[float] = []
    truth_strict_times: list[float] = []
    split_authority_frames = 0
    rigid_split_authority_frames = 0
    sources: dict[str, int] = {}

    for row in data:
        d = row.get("decision") or {}
        gt = row.get("ground_truth_observation") or {}
        gt_load = gt.get("pallet_pose_in_base") or {}
        gt_target = gt.get("placement_pose_in_base") or {}

        ms = d.get("carried_load_motion_yaw_sigma_deg")
        rs = d.get("carried_load_release_yaw_sigma_deg")
        if ms is not None:
            motion_sigmas.append(float(ms))
        if rs is not None:
            release_sigmas.append(float(rs))
        ts = d.get("carried_load_translation_evidence_stale_seconds")
        ys = d.get("carried_load_yaw_evidence_stale_seconds")
        if ts is not None and math.isfinite(float(ts)):
            translation_stale.append(float(ts))
        if ys is not None and math.isfinite(float(ys)):
            yaw_stale.append(float(ys))
        src = str(d.get("carried_load_yaw_evidence_source") or "NONE")
        sources[src] = sources.get(src, 0) + 1

        if ms is not None and rs is not None:
            # The historical E-series motion gate remains 1.25 deg. A split
            # frame is one in which motion is authorized by independent yaw
            # observability while the full release risk remains conservative.
            if float(ms) <= 1.25 + 1e-9 and float(rs) > 1.25 + 1e-9:
                split_authority_frames += 1
                if bool(d.get("rigid_load_constraint_active", False)):
                    rigid_split_authority_frames += 1

        ctl_load = d.get("strict_release_certification_load_yaw_deg")
        ctl_target = d.get("strict_release_certification_target_yaw_deg")
        if ctl_load is not None and ctl_target is not None and gt_load and gt_target:
            truth_load_deg = math.degrees(float(gt_load.get("yaw", 0.0)))
            truth_target_deg = math.degrees(float(gt_target.get("yaw", 0.0)))
            target_bias.append(math.degrees(wrap_rad(math.radians(float(ctl_target) - truth_target_deg))))
            load_bias.append(math.degrees(wrap_rad(math.radians(float(ctl_load) - truth_load_deg))))
            ctl_rel = math.radians(float(ctl_target) - float(ctl_load))
            truth_rel = float(gt_target.get("yaw", 0.0)) - float(gt_load.get("yaw", 0.0))
            relative_bias.append(math.degrees(wrap_rad(ctl_rel - truth_rel)))

        if gt_load and gt_target:
            dx = float(gt_target.get("x", 0.0)) - float(gt_load.get("x", 0.0))
            dy = float(gt_target.get("y", 0.0)) - float(gt_load.get("y", 0.0))
            pos = math.hypot(dx, dy)
            yaw = abs(math.degrees(wrap_rad(float(gt_target.get("yaw", 0.0)) - float(gt_load.get("yaw", 0.0)))))
            if pos < 0.095 and yaw < 4.6:
                t = gt.get("sim_time")
                if t is not None:
                    truth_strict_times.append(float(t))

    last = (data[-1].get("decision") or {}) if data else {}
    truth_dwell = 0.0
    if len(truth_strict_times) >= 2:
        # Diagnostic occupancy span, not controller input.
        truth_dwell = max(truth_strict_times) - min(truth_strict_times)

    return {
        "trace": str(path),
        "samples": len(data),
        "f1_anchor_used": bool(last.get("carried_load_yaw_anchor_used", False)),
        "f1_anchor_samples": int(last.get("carried_load_yaw_anchor_sample_count") or 0),
        "f1_anchor_spread_deg": last.get("carried_load_yaw_anchor_spread_deg"),
        "f3_anchor_seed_sigma_deg": last.get("carried_load_yaw_anchor_seed_sigma_deg"),
        "f3_yaw_evidence_source_final": last.get("carried_load_yaw_evidence_source"),
        "f3_yaw_evidence_source_counts": sources,
        "f3_motion_yaw_sigma_median_deg": _median(motion_sigmas),
        "f3_motion_yaw_sigma_range_deg": _range(motion_sigmas),
        "f3_motion_yaw_sigma_min_deg": min(motion_sigmas) if motion_sigmas else None,
        "f3_motion_yaw_sigma_max_deg": max(motion_sigmas) if motion_sigmas else None,
        "f3_release_yaw_sigma_median_deg": _median(release_sigmas),
        "f3_release_yaw_sigma_range_deg": _range(release_sigmas),
        "f3_release_yaw_sigma_min_deg": min(release_sigmas) if release_sigmas else None,
        "f3_release_yaw_sigma_max_deg": max(release_sigmas) if release_sigmas else None,
        "f3_motion_authorized_release_conservative_frames": split_authority_frames,
        "f3_rigid_motion_authorized_release_conservative_frames": rigid_split_authority_frames,
        "translation_evidence_stale_median_s": _median(translation_stale),
        "yaw_evidence_stale_median_s": _median(yaw_stale),
        "terminal_yaw_authority_enabled": bool(last.get("terminal_load_reacquisition_yaw_authority_enabled", True)),
        "terminal_position_only_updates": int(last.get("terminal_load_reacquisition_position_only_update_count") or 0),
        "terminal_yaw_suppressed": int(last.get("terminal_load_reacquisition_yaw_suppressed_count") or 0),
        "yaw_closure_search_count": int(last.get("placement_fresh_rgb_yaw_closure_search_count") or 0),
        "yaw_closure_activation_count": int(last.get("placement_fresh_rgb_yaw_closure_activation_count") or 0),
        "post_closure_ownership_entries": int(last.get("placement_post_closure_basin_entry_count") or 0),
        "strict_certified_final": bool(last.get("strict_release_certified", False)),
        "strict_blocker_final": last.get("strict_release_certification_blocker"),
        "release_witness_capture_count": int(last.get("release_witness_capture_count") or 0),
        "truth_strict_sample_count": len(truth_strict_times),
        "truth_strict_occupancy_span_s": truth_dwell,
        "diagnostic_target_yaw_bias_median_deg": _median(target_bias),
        "diagnostic_load_yaw_bias_median_deg": _median(load_bias),
        "diagnostic_relative_yaw_bias_median_deg": _median(relative_bias),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("trace", type=Path)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    result = analyze(args.trace)
    if args.json:
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0
    print("V9.3.12-R4-F3 axis-separated yaw evidence")
    print(f"trace: {result['trace']}")
    print(
        "anchor used/samples/spread/seed-sigma: "
        f"{result['f1_anchor_used']} / {result['f1_anchor_samples']} / "
        f"{result['f1_anchor_spread_deg']} / {result['f3_anchor_seed_sigma_deg']} deg"
    )
    print(
        "motion/release yaw sigma median: "
        f"{result['f3_motion_yaw_sigma_median_deg']} / "
        f"{result['f3_release_yaw_sigma_median_deg']} deg"
    )
    print(
        "split-authority frames total/rigid: "
        f"{result['f3_motion_authorized_release_conservative_frames']} / "
        f"{result['f3_rigid_motion_authorized_release_conservative_frames']}"
    )
    print(
        "translation/yaw evidence stale median: "
        f"{result['translation_evidence_stale_median_s']} / "
        f"{result['yaw_evidence_stale_median_s']} s | "
        f"source={result['f3_yaw_evidence_source_final']}"
    )
    print(
        "F2 contract yaw-authority/position-only/yaw-suppressed: "
        f"{result['terminal_yaw_authority_enabled']} / "
        f"{result['terminal_position_only_updates']} / "
        f"{result['terminal_yaw_suppressed']}"
    )
    print(
        "yaw closure search/activation/post-closure: "
        f"{result['yaw_closure_search_count']} / "
        f"{result['yaw_closure_activation_count']} / "
        f"{result['post_closure_ownership_entries']}"
    )
    print(
        "GT diagnostic target/load/relative yaw bias medians: "
        f"{result['diagnostic_target_yaw_bias_median_deg']} / "
        f"{result['diagnostic_load_yaw_bias_median_deg']} / "
        f"{result['diagnostic_relative_yaw_bias_median_deg']} deg"
    )
    print(
        "strict/witness/truth-strict-span: "
        f"{result['strict_certified_final']} / "
        f"{result['release_witness_capture_count']} / "
        f"{result['truth_strict_occupancy_span_s']} s"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
