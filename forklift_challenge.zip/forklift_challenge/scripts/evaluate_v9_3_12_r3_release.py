"""Evaluate V9.3.12-R3 operational promotion, runtime health and competition precision."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from evaluation.release_qualification import (
    COMBINED_INFORMATIONAL,
    FORMAL_THRESHOLDS,
    ReleaseThresholds,
    overall_pass,
    qualify_summary_file,
)


PROMOTION = {
    "moderate_easy": ReleaseThresholds(
        minimum_success_rate=0.90,
        maximum_episode_timeout_rate=0.0,
        maximum_long_episode_rate=0.10,
        maximum_terminal_budget_exhausted_rate=0.10,
    ),
    "moderate_nominal": ReleaseThresholds(
        minimum_success_rate=0.85,
        maximum_episode_timeout_rate=0.0,
        maximum_long_episode_rate=0.10,
        maximum_terminal_budget_exhausted_rate=0.10,
    ),
    "finals_easy": ReleaseThresholds(
        minimum_success_rate=0.70,
        maximum_episode_timeout_rate=0.0,
        maximum_long_episode_rate=0.10,
        maximum_terminal_budget_exhausted_rate=0.10,
    ),
}

FINALS_FOUNDATION_PRECISION_TARGETS = {
    "moderate_easy": 0.90,
    "moderate_nominal": 0.80,
    "finals_easy": 0.60,
}

DECISION_LATENCY_TARGETS = {
    "maximum_average_certification_to_release_seconds": 3.0,
    "maximum_average_release_supervisor_hold_seconds": 8.0,
    "maximum_intent_abort_rate": 0.25,
}


def _precision_summary(path: Path) -> dict:
    summary = json.loads(path.read_text(encoding="utf-8"))
    release = summary.get("precision_diagnostics", {}).get("stages", {}).get(
        "release_command", {}
    )
    grounded = summary.get("precision_diagnostics", {}).get("stages", {}).get(
        "grounded", {}
    )
    final = summary.get("precision_diagnostics", {}).get("stages", {}).get(
        "final", {}
    )
    derived = summary.get("precision_diagnostics", {}).get("derived", {})
    return {
        "rate": summary.get("competition_precision_success_rate", 0.0),
        "count": summary.get("competition_precision_success_count", 0),
        "episodes": summary.get("episode_count", 0),
        "position_rate": summary.get("competition_position_pass_rate", 0.0),
        "yaw_rate": summary.get("competition_yaw_pass_rate", 0.0),
        "episode_timeout_rate": summary.get("episode_timeout_rate", 0.0),
        "long_episode_rate": summary.get("long_episode_rate", 0.0),
        "terminal_budget_exhausted_rate": summary.get(
            "terminal_budget_exhausted_rate", 0.0
        ),
        "duration_p95_seconds": summary.get("duration_p95_seconds"),
        "release_truth_position_mean_m": release.get("truth_position_mean_m"),
        "grounded_truth_position_mean_m": grounded.get("truth_position_mean_m"),
        "final_truth_position_mean_m": final.get("truth_position_mean_m"),
        "lowering_pallet_translation_mean_m": derived.get(
            "lowering_pallet_translation_m", {}
        ).get("mean"),
        "withdrawal_pallet_translation_mean_m": derived.get(
            "withdrawal_pallet_translation_m", {}
        ).get("mean"),
        "release_supervisor_certification_to_release_seconds": summary.get(
            "average_release_supervisor_certification_to_release_seconds"
        ),
        "release_supervisor_hold_seconds_per_episode": (
            float(summary.get("total_release_supervisor_hold_seconds", 0.0))
            / max(1, int(summary.get("episode_count", 0)))
        ),
        "release_supervisor_intent_abort_rate": (
            float(summary.get("total_release_supervisor_intent_abort_count", 0))
            / max(1, int(summary.get("total_release_supervisor_intent_count", 0)))
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--moderate-easy", type=Path, required=True)
    parser.add_argument("--moderate-nominal", type=Path, required=True)
    parser.add_argument("--finals-easy", type=Path, required=True)
    parser.add_argument("--combined", type=Path)
    parser.add_argument(
        "--output",
        type=Path,
        default=PROJECT_ROOT / "outputs" / "v9_3_9_release_report",
    )
    args = parser.parse_args()

    paths = {
        "moderate_easy": args.moderate_easy,
        "moderate_nominal": args.moderate_nominal,
        "finals_easy": args.finals_easy,
    }
    historical = [
        qualify_summary_file(
            paths[key], label=key, thresholds=FORMAL_THRESHOLDS[key]
        )
        for key in paths
    ]
    promotion = [
        qualify_summary_file(paths[key], label=key, thresholds=PROMOTION[key])
        for key in paths
    ]
    combined = None
    if args.combined:
        combined = qualify_summary_file(
            args.combined,
            label="finals_combined",
            thresholds=COMBINED_INFORMATIONAL,
            hard_gate=False,
        )

    historical_pass = overall_pass(historical)
    promotion_pass = overall_pass(promotion)
    precision = {key: _precision_summary(path) for key, path in paths.items()}
    finals_foundation_precision_pass = all(
        precision[key]["rate"] >= FINALS_FOUNDATION_PRECISION_TARGETS[key]
        for key in paths
    )

    decision_latency_pass = all(
        precision[key]["release_supervisor_certification_to_release_seconds"] is not None
        and precision[key]["release_supervisor_certification_to_release_seconds"]
        <= DECISION_LATENCY_TARGETS["maximum_average_certification_to_release_seconds"]
        and precision[key]["release_supervisor_hold_seconds_per_episode"]
        <= DECISION_LATENCY_TARGETS["maximum_average_release_supervisor_hold_seconds"]
        and precision[key]["release_supervisor_intent_abort_rate"]
        <= DECISION_LATENCY_TARGETS["maximum_intent_abort_rate"]
        for key in paths
    )

    args.output.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema": "forklift_v9_3_9_release_qualification_v1",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "historical_pass": historical_pass,
        "promotion_runtime_pass": promotion_pass,
        "finals_foundation_precision_pass": finals_foundation_precision_pass,
        "finals_foundation_precision_targets": FINALS_FOUNDATION_PRECISION_TARGETS,
        "decision_latency_pass": decision_latency_pass,
        "decision_latency_targets": DECISION_LATENCY_TARGETS,
        "historical_results": [result.to_dict() for result in historical],
        "promotion_results": [result.to_dict() for result in promotion],
        "combined_result": None if combined is None else combined.to_dict(),
        "competition_precision": precision,
        "policy": {
            "geometry_compensation_used": False,
            "competition_position_limit_m": 0.10,
            "competition_yaw_limit_deg": 5.0,
            "oracle_terminal_geometry_allowed_for_release": False,
            "global_episode_limit_seconds": 260.0,
            "long_episode_threshold_seconds": 180.0,
        },
    }
    (args.output / "qualification.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )

    lines = [
        "# V9.3.12-R3 Release Qualification",
        "",
        f"Historical 80/70/50: **{'PASS' if historical_pass else 'FAIL'}**",
        (
            "Promotion + runtime health: "
            f"**{'PASS' if promotion_pass else 'FAIL'}**"
        ),
        (
            "V9.3 finals-foundation precision targets: "
            f"**{'PASS' if finals_foundation_precision_pass else 'FAIL'}**"
        ),
        (
            "V9.3.12-R3 decision-latency targets: "
            f"**{'PASS' if decision_latency_pass else 'FAIL'}**"
        ),
        "",
        "## Competition precision and runtime",
    ]
    for key, value in precision.items():
        lines.append(
            f"- {key}: precision {value['count']}/{value['episodes']} = "
            f"{value['rate']:.1%}; timeout={value['episode_timeout_rate']:.1%}; "
            f"long={value['long_episode_rate']:.1%}; "
            f"terminal_budget={value['terminal_budget_exhausted_rate']:.1%}; "
            f"cert->release={value['release_supervisor_certification_to_release_seconds']}; "
            f"hold/ep={value['release_supervisor_hold_seconds_per_episode']:.2f}s; "
            f"intent_abort={value['release_supervisor_intent_abort_rate']:.1%}"
        )
    lines += [
        "",
        "Oracle terminal geometry is diagnostic-only and never qualifies a release.",
        "No fixed terminal geometry compensation/offset is used in V9.3.12-R3.",
    ]
    (args.output / "qualification.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )

    print(
        f"V9.3.12-R3 historical 80/70/50 baseline: "
        f"{'PASS' if historical_pass else 'FAIL'}"
    )
    print(
        f"V9.3.12-R3 promotion + runtime health: "
        f"{'PASS' if promotion_pass else 'FAIL'}"
    )
    print(
        "V9.3.12-R3 finals-foundation competition precision: "
        f"{'PASS' if finals_foundation_precision_pass else 'FAIL'}"
    )
    print(
        "V9.3.12-R3 terminal decision latency: "
        f"{'PASS' if decision_latency_pass else 'FAIL'}"
    )
    for key, value in precision.items():
        print(
            f"  {key}: precision={value['rate']:.1%} "
            f"(target={FINALS_FOUNDATION_PRECISION_TARGETS[key]:.0%}), "
            f"timeout={value['episode_timeout_rate']:.1%}, "
            f"long={value['long_episode_rate']:.1%}, "
            f"terminal_budget={value['terminal_budget_exhausted_rate']:.1%}"
        )
    if combined is not None:
        print(
            f"  finals_combined: {'PASS' if combined.passed else 'FAIL'} "
            "[informational]"
        )
    print(f"report: {args.output.resolve()}")
    return 0 if (promotion_pass and finals_foundation_precision_pass and decision_latency_pass) else 2


if __name__ == "__main__":
    raise SystemExit(main())
