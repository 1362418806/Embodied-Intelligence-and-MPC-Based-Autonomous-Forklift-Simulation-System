"""Deterministic initial-pose randomization for forklift pickup episodes."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import math
import random
from typing import Any

import mujoco


@dataclass(frozen=True)
class Pose2D:
    """Planar pose in metres and radians."""

    x: float
    y: float
    yaw: float

    def to_dict(self) -> dict[str, float]:
        return asdict(self)


@dataclass(frozen=True)
class Scenario:
    """Complete deterministic start condition for one episode."""

    scenario_id: str
    difficulty: str
    seed: int
    forklift: Pose2D
    pallet: Pose2D

    def to_dict(self) -> dict[str, Any]:
        return {
            "scenario_id": self.scenario_id,
            "difficulty": self.difficulty,
            "seed": self.seed,
            "forklift": self.forklift.to_dict(),
            "pallet": self.pallet.to_dict(),
        }


@dataclass(frozen=True)
class _Ranges:
    forklift_x: tuple[float, float]
    forklift_y: tuple[float, float]
    forklift_yaw_deg: tuple[float, float]
    pallet_x: tuple[float, float]
    pallet_y: tuple[float, float]
    pallet_yaw_deg: tuple[float, float]


_RANGES: dict[str, _Ranges] = {
    # Starts farther behind the v4 baseline so Ackermann steering has enough
    # longitudinal distance to remove lateral and heading errors.
    "easy": _Ranges(
        forklift_x=(-0.85, -0.55),
        forklift_y=(-0.12, 0.12),
        forklift_yaw_deg=(-4.0, 4.0),
        pallet_x=(3.18, 3.22),
        pallet_y=(-0.03, 0.03),
        pallet_yaw_deg=(-1.0, 1.0),
    ),
    "nominal": _Ranges(
        forklift_x=(-1.20, -0.70),
        forklift_y=(-0.24, 0.24),
        forklift_yaw_deg=(-8.0, 8.0),
        pallet_x=(3.15, 3.25),
        pallet_y=(-0.07, 0.07),
        pallet_yaw_deg=(-3.0, 3.0),
    ),
    "challenge": _Ranges(
        forklift_x=(-1.50, -0.85),
        forklift_y=(-0.34, 0.34),
        forklift_yaw_deg=(-12.0, 12.0),
        pallet_x=(3.12, 3.28),
        pallet_y=(-0.10, 0.10),
        pallet_yaw_deg=(-5.0, 5.0),
    ),
}


_NAMED: dict[str, tuple[Pose2D, Pose2D, str]] = {
    "baseline": (
        Pose2D(0.0, 0.0, 0.0),
        Pose2D(3.20, 0.0, 0.0),
        "baseline",
    ),
    # Forklift starts on vehicle-right, so the pallet is left in the base frame.
    "lateral_left": (
        Pose2D(-1.00, -0.22, 0.0),
        Pose2D(3.20, 0.0, 0.0),
        "validation",
    ),
    "lateral_right": (
        Pose2D(-1.00, 0.22, 0.0),
        Pose2D(3.20, 0.0, 0.0),
        "validation",
    ),
    # Vehicle yaw is opposite the requested correction direction.
    "yaw_left": (
        Pose2D(-1.00, 0.0, math.radians(-8.0)),
        Pose2D(3.20, 0.0, 0.0),
        "validation",
    ),
    "yaw_right": (
        Pose2D(-1.00, 0.0, math.radians(8.0)),
        Pose2D(3.20, 0.0, 0.0),
        "validation",
    ),
    "combined": (
        Pose2D(-1.10, -0.20, math.radians(-6.0)),
        Pose2D(3.20, 0.05, math.radians(2.0)),
        "validation",
    ),
}


def named_scenario(name: str) -> Scenario:
    """Return one deterministic validation scenario by name."""
    try:
        forklift, pallet, difficulty = _NAMED[name]
    except KeyError as exc:
        options = ", ".join(sorted(_NAMED))
        raise ValueError(f"unknown scenario {name!r}; choose from: {options}") from exc
    return Scenario(
        scenario_id=name,
        difficulty=difficulty,
        seed=0,
        forklift=forklift,
        pallet=pallet,
    )


class ScenarioSampler:
    """Generate reproducible scenarios from one master seed."""

    def __init__(self, *, seed: int, difficulty: str = "easy") -> None:
        if difficulty not in _RANGES:
            options = ", ".join(sorted(_RANGES))
            raise ValueError(f"unknown difficulty {difficulty!r}; choose from: {options}")
        self.seed = int(seed)
        self.difficulty = difficulty
        self._random = random.Random(self.seed)
        self._index = 0

    @staticmethod
    def difficulties() -> tuple[str, ...]:
        return tuple(sorted(_RANGES))

    @staticmethod
    def named_scenarios() -> tuple[str, ...]:
        return tuple(sorted(_NAMED))

    def sample(self) -> Scenario:
        ranges = _RANGES[self.difficulty]
        episode_seed = self._random.randrange(0, 2**31 - 1)
        rng = random.Random(episode_seed)
        self._index += 1

        def uniform(bounds: tuple[float, float]) -> float:
            return rng.uniform(bounds[0], bounds[1])

        return Scenario(
            scenario_id=f"{self.difficulty}_{self._index:04d}",
            difficulty=self.difficulty,
            seed=episode_seed,
            forklift=Pose2D(
                x=uniform(ranges.forklift_x),
                y=uniform(ranges.forklift_y),
                yaw=math.radians(uniform(ranges.forklift_yaw_deg)),
            ),
            pallet=Pose2D(
                x=uniform(ranges.pallet_x),
                y=uniform(ranges.pallet_y),
                yaw=math.radians(uniform(ranges.pallet_yaw_deg)),
            ),
        )


def _required_joint(model: mujoco.MjModel, name: str) -> int:
    joint_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, name)
    if joint_id < 0:
        raise RuntimeError(f"required free joint was not found: {name}")
    return int(joint_id)


def _set_freejoint_pose(
    model: mujoco.MjModel,
    data: mujoco.MjData,
    *,
    joint_name: str,
    pose: Pose2D,
) -> None:
    joint_id = _required_joint(model, joint_name)
    qpos = int(model.jnt_qposadr[joint_id])
    # Preserve the model's configured z coordinate.  Only planar position and
    # yaw are randomized so the vehicle and pallet settle naturally on ground.
    data.qpos[qpos] = pose.x
    data.qpos[qpos + 1] = pose.y
    half_yaw = 0.5 * pose.yaw
    data.qpos[qpos + 3 : qpos + 7] = (
        math.cos(half_yaw),
        0.0,
        0.0,
        math.sin(half_yaw),
    )


def apply_scenario(
    model: mujoco.MjModel,
    data: mujoco.MjData,
    scenario: Scenario,
) -> None:
    """Apply a scenario after ``mj_resetData`` and clear dynamic state."""
    _set_freejoint_pose(
        model,
        data,
        joint_name="forklift_free",
        pose=scenario.forklift,
    )
    _set_freejoint_pose(
        model,
        data,
        joint_name="pallet_load_free",
        pose=scenario.pallet,
    )
    data.qvel[:] = 0.0
    data.ctrl[:] = 0.0
    data.qacc_warmstart[:] = 0.0
    mujoco.mj_forward(model, data)
