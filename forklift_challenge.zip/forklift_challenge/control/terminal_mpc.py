"""Lightweight shooting MPC for terminal rear-Ackermann placement.

The controller intentionally has no MuJoCo or project-specific dependencies.
It optimizes the desired-vehicle pose residual with a kinematic bicycle model
and uses the measured carried-pallet lateral/yaw residual only to seed useful
steering candidates.  The planner is receding-horizon: only the first control
of the best two-phase sequence is applied before replanning.
"""

from __future__ import annotations

from dataclasses import dataclass
import math


def wrap_angle(angle: float) -> float:
    return (float(angle) + math.pi) % (2.0 * math.pi) - math.pi


def clamp(value: float, lower: float, upper: float) -> float:
    return max(float(lower), min(float(upper), float(value)))


@dataclass(frozen=True)
class TerminalMPCConfig:
    wheelbase: float
    horizon_steps: int
    prediction_dt: float
    forward_max_speed: float
    reverse_max_speed: float
    steering_limit: float
    speed_gain: float
    geometry_speed_floor: float
    geometry_trigger_lateral: float
    geometry_trigger_yaw: float
    trust_radius: float
    weight_longitudinal: float
    weight_lateral: float
    weight_yaw: float
    terminal_weight_longitudinal: float
    terminal_weight_lateral: float
    terminal_weight_yaw: float
    weight_speed: float
    weight_steering: float
    weight_steering_change: float
    reverse_penalty: float
    direction_switch_penalty: float
    task_lateral_gain: float
    task_yaw_gain: float
    task_lookahead: float

    def validate(self) -> None:
        if self.wheelbase <= 0.0:
            raise ValueError("wheelbase must be positive")
        if self.horizon_steps < 4:
            raise ValueError("horizon_steps must be >= 4")
        if self.prediction_dt <= 0.0:
            raise ValueError("prediction_dt must be positive")
        if min(self.forward_max_speed, self.reverse_max_speed) <= 0.0:
            raise ValueError("MPC speed limits must be positive")
        if self.steering_limit <= 0.0:
            raise ValueError("steering_limit must be positive")
        if self.trust_radius <= 0.0:
            raise ValueError("trust_radius must be positive")
        if self.task_lookahead <= 0.0:
            raise ValueError("task_lookahead must be positive")


@dataclass(frozen=True)
class TerminalMPCPlan:
    speed: float
    steering: float
    cost: float
    predicted_x: float
    predicted_y: float
    predicted_yaw: float
    candidate_count: int
    feasible_candidate_count: int
    mode: str

    @property
    def predicted_distance(self) -> float:
        return math.hypot(self.predicted_x, self.predicted_y)


class TerminalKinematicMPC:
    """Two-phase finite-horizon shooting MPC.

    A small deterministic control lattice is evaluated at each solve.  This is
    deliberately solver-free so the patch does not add scipy/cvxpy/runtime
    dependencies.  The horizon can represent forward-only, reverse-only and
    forward/reverse S-shaped terminal manoeuvres.
    """

    def __init__(self, config: TerminalMPCConfig) -> None:
        config.validate()
        self.config = config

    @staticmethod
    def predict_target_pose(
        x: float,
        y: float,
        yaw: float,
        *,
        speed: float,
        steering: float,
        wheelbase: float,
        dt: float,
    ) -> tuple[float, float, float]:
        """Public one-step model interface for V9.3 model identification."""
        return TerminalKinematicMPC._propagate(
            x, y, yaw, speed=speed, steering=steering, wheelbase=wheelbase, dt=dt
        )

    @staticmethod
    def _propagate(
        x: float,
        y: float,
        yaw: float,
        *,
        speed: float,
        steering: float,
        wheelbase: float,
        dt: float,
    ) -> tuple[float, float, float]:
        """Propagate target pose expressed in the moving vehicle frame."""
        yaw_delta = float(speed) * math.tan(float(steering)) / float(wheelbase) * float(dt)
        if abs(yaw_delta) <= 1e-10:
            dx = float(speed) * float(dt)
            dy = 0.0
        else:
            curvature = math.tan(float(steering)) / float(wheelbase)
            radius = 1.0 / curvature
            dx = radius * math.sin(yaw_delta)
            dy = radius * (1.0 - math.cos(yaw_delta))

        tx = float(x) - dx
        ty = float(y) - dy
        cosine = math.cos(yaw_delta)
        sine = math.sin(yaw_delta)
        next_x = cosine * tx + sine * ty
        next_y = -sine * tx + cosine * ty
        return float(next_x), float(next_y), wrap_angle(float(yaw) - yaw_delta)

    def _steering_grid(self, task_lateral: float, task_yaw: float) -> tuple[float, ...]:
        c = self.config
        feedback = math.atan2(
            c.task_lateral_gain * float(task_lateral),
            c.task_lookahead,
        ) + c.task_yaw_gain * float(task_yaw)
        feedback = clamp(feedback, -c.steering_limit, c.steering_limit)
        raw = (
            -c.steering_limit,
            -0.5 * c.steering_limit,
            0.0,
            0.5 * c.steering_limit,
            c.steering_limit,
            feedback,
            -feedback,
        )
        unique: list[float] = []
        for value in raw:
            value = round(float(value), 9)
            if not any(abs(value - old) <= 1e-8 for old in unique):
                unique.append(value)
        return tuple(unique)

    def solve(
        self,
        *,
        target_x: float,
        target_y: float,
        target_yaw: float,
        task_lateral: float,
        task_yaw: float,
        current_speed: float,
        previous_steering: float,
        first_direction_constraint: int = 0,
    ) -> TerminalMPCPlan:
        """Solve one receding-horizon terminal plan.

        ``first_direction_constraint`` is a scheduler-level Schmitt lock for
        the first applied control only: +1 permits forward/hold starts, -1
        permits reverse/hold starts, and 0 leaves the lattice unconstrained.
        The second half of a candidate may still change direction, so the MPC
        can reason about an S-shaped future trajectory without commanding a
        noisy first-action sign flip at every replan.
        """
        c = self.config
        first_direction_constraint = int(first_direction_constraint)
        if first_direction_constraint not in (-1, 0, 1):
            raise ValueError("first_direction_constraint must be -1, 0, or 1")
        geometry_bad = (
            abs(float(task_lateral)) >= c.geometry_trigger_lateral
            or abs(float(task_yaw)) >= c.geometry_trigger_yaw
        )
        adaptive = c.speed_gain * abs(float(target_x))
        if geometry_bad:
            adaptive = max(adaptive, c.geometry_speed_floor)
        adaptive = max(0.008, adaptive)
        forward_speed = min(c.forward_max_speed, adaptive)
        reverse_speed = min(c.reverse_max_speed, adaptive)
        magnitudes = (0.60, 1.00)
        direction_pairs = (
            (1, 1, "FWD"),
            (-1, -1, "REV"),
            (1, -1, "FWD_REV"),
            (-1, 1, "REV_FWD"),
            (1, 0, "FWD_STOP"),
            (-1, 0, "REV_STOP"),
            (0, 0, "HOLD"),
        )
        steering_grid = self._steering_grid(task_lateral, task_yaw)
        split = max(2, c.horizon_steps // 2)

        best: TerminalMPCPlan | None = None
        candidates = 0
        feasible = 0
        for magnitude in magnitudes:
            for first_dir, second_dir, mode in direction_pairs:
                if (
                    first_direction_constraint > 0
                    and first_dir < 0
                ):
                    continue
                if (
                    first_direction_constraint < 0
                    and first_dir > 0
                ):
                    continue
                v1 = (
                    first_dir * (forward_speed if first_dir > 0 else reverse_speed)
                    * magnitude
                )
                v2 = (
                    second_dir * (forward_speed if second_dir > 0 else reverse_speed)
                    * magnitude
                )
                for steer1 in steering_grid:
                    for steer2 in steering_grid:
                        candidates += 1
                        x = float(target_x)
                        y = float(target_y)
                        yaw = wrap_angle(float(target_yaw))
                        cost = 0.0
                        last_steer = float(previous_steering)
                        rejected = False
                        for step in range(c.horizon_steps):
                            speed = v1 if step < split else v2
                            steering = steer1 if step < split else steer2
                            x, y, yaw = self._propagate(
                                x,
                                y,
                                yaw,
                                speed=speed,
                                steering=steering,
                                wheelbase=c.wheelbase,
                                dt=c.prediction_dt,
                            )
                            if math.hypot(x, y) > c.trust_radius:
                                rejected = True
                                break
                            cost += (
                                c.weight_longitudinal * x * x
                                + c.weight_lateral * y * y
                                + c.weight_yaw * yaw * yaw
                                + c.weight_speed * speed * speed
                                + c.weight_steering * steering * steering
                                + c.weight_steering_change
                                * (steering - last_steer) ** 2
                            )
                            if speed < 0.0:
                                cost += c.reverse_penalty * abs(speed)
                            last_steer = steering
                        if rejected:
                            continue
                        feasible += 1
                        cost += (
                            c.terminal_weight_longitudinal * x * x
                            + c.terminal_weight_lateral * y * y
                            + c.terminal_weight_yaw * yaw * yaw
                        )
                        if first_dir != 0 and second_dir != 0 and first_dir != second_dir:
                            cost += c.direction_switch_penalty
                        # Avoid commanding an instantaneous sign reversal while
                        # the chassis still carries meaningful opposite speed.
                        if current_speed * v1 < 0.0 and abs(current_speed) > 0.012:
                            cost += 4.0 * c.direction_switch_penalty

                        plan = TerminalMPCPlan(
                            speed=float(v1),
                            steering=float(steer1),
                            cost=float(cost),
                            predicted_x=float(x),
                            predicted_y=float(y),
                            predicted_yaw=float(yaw),
                            candidate_count=0,
                            feasible_candidate_count=0,
                            mode=str(mode),
                        )
                        if best is None or plan.cost < best.cost:
                            best = plan

        if best is None:
            return TerminalMPCPlan(
                speed=0.0,
                steering=0.0,
                cost=float("inf"),
                predicted_x=float(target_x),
                predicted_y=float(target_y),
                predicted_yaw=wrap_angle(float(target_yaw)),
                candidate_count=int(candidates),
                feasible_candidate_count=0,
                mode="INFEASIBLE",
            )
        return TerminalMPCPlan(
            speed=best.speed,
            steering=best.steering,
            cost=best.cost,
            predicted_x=best.predicted_x,
            predicted_y=best.predicted_y,
            predicted_yaw=best.predicted_yaw,
            candidate_count=int(candidates),
            feasible_candidate_count=int(feasible),
            mode=best.mode,
        )
