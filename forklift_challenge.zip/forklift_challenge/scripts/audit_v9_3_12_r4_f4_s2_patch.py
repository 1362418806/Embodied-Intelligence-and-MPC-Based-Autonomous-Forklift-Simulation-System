"""Static/invariant audit for V9.3.12-R4-F4 release centre-yaw closure."""
from __future__ import annotations

import copy
import math
from pathlib import Path
import py_compile

import yaml

ROOT = Path(__file__).resolve().parents[1]


def check(name: str, ok: bool) -> None:
    print(f"{'PASS' if ok else 'FAIL'} {name}")
    if not ok:
        raise AssertionError(name)


def main() -> int:
    compile_files = (
        "control/release_center_yaw_conflict_guard.py",
        "control/release_decision_supervisor.py",
        "perception/vision_placement.py",
        "task/pickup_state_machine.py",
        "simulator/dual_vision_mission_episode.py",
        "evaluation/dual_vision_metrics.py",
        "scripts/analyze_v9_3_12_r4_f4_release_center_yaw.py",
        "scripts/run_v9_3_12_r4_f4_s2_batch.py",
        "scripts/analyze_v9_3_12_r4_f4_s2_conflict_guard.py",
        "scripts/evaluate_v9_3_12_r4_f4_s2_freeze.py",
    )
    for rel in compile_files:
        py_compile.compile(str(ROOT / rel), doraise=True)
        check(f"compile:{rel}", True)

    f3 = yaml.safe_load((ROOT / "configs" / "vehicle_v9_3_12_r4_f3.yaml").read_text(encoding="utf-8"))
    f4_baseline = yaml.safe_load((ROOT / "configs" / "vehicle_v9_3_12_r4_f4.yaml").read_text(encoding="utf-8"))
    f4 = yaml.safe_load((ROOT / "configs" / "vehicle_v9_3_12_r4_f4_s2.yaml").read_text(encoding="utf-8"))
    base = f4["autonomy"]
    weak = f4["perception"]["terminal_autonomy_overrides"]["weak_guide"]
    vision = f4["vision"]["profiles"]["weak_guide"]

    terminal_overrides = f4["perception"]["terminal_autonomy_overrides"]
    missing_override_schema = {
        profile: sorted(set(values) - set(base))
        for profile, values in terminal_overrides.items()
        if set(values) - set(base)
    }
    check(
        "all terminal autonomy override keys are registered in root autonomy schema",
        not missing_override_schema,
    )

    check("F4 center-yaw authority registered in root autonomy schema", "placement_strict_release_center_yaw_anchor_enabled" in base)
    check("legacy/base F4 center-yaw authority remains disabled", base["placement_strict_release_center_yaw_anchor_enabled"] == 0.0)
    check("F4 yaw RSS authority registered in root autonomy schema", "placement_strict_release_center_yaw_rss_enabled" in base)
    check("legacy/base F4 yaw RSS remains disabled", base["placement_strict_release_center_yaw_rss_enabled"] == 0.0)
    check("weak-guide center-yaw anchor enabled", weak["placement_strict_release_center_yaw_anchor_enabled"] == 1.0)
    check("weak-guide guarded yaw RSS enabled", weak["placement_strict_release_center_yaw_rss_enabled"] == 1.0)
    s2_keys = (
        "placement_strict_release_center_yaw_continuity_guard_enabled",
        "placement_strict_release_center_yaw_max_reanchor_jump_rad",
        "placement_strict_release_center_yaw_revalidation_seconds",
        "placement_strict_release_center_yaw_revalidation_tolerance_rad",
    )
    check("S2 schema keys registered at root", all(key in base for key in s2_keys))
    check("legacy/base S2 guard remains disabled", base["placement_strict_release_center_yaw_continuity_guard_enabled"] == 0.0)
    check("weak-guide S2 continuity guard enabled", weak["placement_strict_release_center_yaw_continuity_guard_enabled"] == 1.0)
    check("S2 re-anchor threshold is 2deg", math.isclose(float(weak["placement_strict_release_center_yaw_max_reanchor_jump_rad"]), math.radians(2.0), abs_tol=1e-12))
    check("S2 revalidation interval is 0.75s", math.isclose(float(weak["placement_strict_release_center_yaw_revalidation_seconds"]), 0.75, abs_tol=1e-12))
    check("S2 revalidation tolerance is 0.5deg", math.isclose(float(weak["placement_strict_release_center_yaw_revalidation_tolerance_rad"]), math.radians(0.5), abs_tol=1e-12))
    check("F3 axis split remains enabled", weak["placement_carried_yaw_axis_evidence_enabled"] == 1.0)
    check("F2 terminal yaw authority remains disabled", weak["placement_terminal_load_reacquisition_yaw_authority_enabled"] == 0.0)
    check("F1 late-insert load yaw anchor remains enabled", weak["placement_carried_visual_yaw_anchor_enabled"] == 1.0)
    check("E7 centre witness remains required", vision["center_yaw_witness_enabled"] is True)
    check("release centre-yaw anchor is short lived", math.isclose(float(vision["release_center_yaw_anchor_hold_seconds"]), 1.5, abs_tol=1e-12))
    check("release centre-yaw anchor inherits matured E7 witness without double-gating", int(vision["release_center_yaw_anchor_minimum_samples"]) == 1)
    check("release centre-yaw world spread <=0.5deg", float(vision["release_center_yaw_anchor_max_world_spread_deg"]) <= 0.5)

    # S2 itself changes only the four continuity-guard schema/profile keys relative to F4.
    s2_cmp = copy.deepcopy(f4)
    for key in s2_keys:
        s2_cmp["autonomy"].pop(key, None)
        s2_cmp["perception"]["terminal_autonomy_overrides"]["weak_guide"].pop(key, None)
    check("S2 config has no collateral drift relative to F4", s2_cmp == f4_baseline)

    # No collateral config tuning relative to F3 except the explicit F4 knobs.
    cmp = copy.deepcopy(f4)
    cmp["autonomy"].pop("placement_strict_release_center_yaw_anchor_enabled", None)
    cmp["autonomy"].pop("placement_strict_release_center_yaw_rss_enabled", None)
    for key in (
        "placement_strict_release_center_yaw_continuity_guard_enabled",
        "placement_strict_release_center_yaw_max_reanchor_jump_rad",
        "placement_strict_release_center_yaw_revalidation_seconds",
        "placement_strict_release_center_yaw_revalidation_tolerance_rad",
    ):
        cmp["autonomy"].pop(key, None)
    cmp_weak = cmp["perception"]["terminal_autonomy_overrides"]["weak_guide"]
    cmp_weak.pop("placement_strict_release_center_yaw_anchor_enabled", None)
    cmp_weak.pop("placement_strict_release_center_yaw_rss_enabled", None)
    for key in (
        "placement_strict_release_center_yaw_continuity_guard_enabled",
        "placement_strict_release_center_yaw_max_reanchor_jump_rad",
        "placement_strict_release_center_yaw_revalidation_seconds",
        "placement_strict_release_center_yaw_revalidation_tolerance_rad",
    ):
        cmp_weak.pop(key, None)
    cmp_vision = cmp["vision"]["profiles"]["weak_guide"]
    for key in (
        "release_center_yaw_anchor_enabled",
        "release_center_yaw_anchor_hold_seconds",
        "release_center_yaw_anchor_window",
        "release_center_yaw_anchor_minimum_samples",
        "release_center_yaw_anchor_max_world_spread_deg",
    ):
        cmp_vision.pop(key, None)
    check("F4 config has no collateral tuning drift", cmp == f3)

    # Frozen competition/release contract.
    check("strict position remains 9.5cm", math.isclose(float(weak["placement_strict_release_position_limit_m"]), 0.095, abs_tol=1e-12))
    check("strict yaw remains 4.6deg", math.isclose(float(weak["placement_strict_release_yaw_limit_rad"]), math.radians(4.6), abs_tol=1e-12))
    check("observer 1deg yaw floor unchanged", math.isclose(float(weak["placement_carried_observer_minimum_yaw_sigma_rad"]), math.radians(1.0), abs_tol=1e-12))
    check("yaw sigma gain unchanged", math.isclose(float(weak["placement_strict_release_yaw_sigma_gain"]), 0.22, abs_tol=1e-12))
    check("execution yaw reserve unchanged", math.isclose(float(weak["placement_strict_release_execution_yaw_reserve_rad"]), math.radians(0.4), abs_tol=1e-12))
    check("target yaw floor unchanged", math.isclose(float(weak["placement_strict_release_target_yaw_margin_floor_rad"]), math.radians(0.35), abs_tol=1e-12))
    check("consensus release authority remains off", float(weak["placement_certified_basin_consensus_release_authority"]) == 0.0)
    check("terminal budget remains 90s", math.isclose(float(weak["placement_terminal_budget_seconds"]), 90.0, abs_tol=1e-12))

    vision_source = (ROOT / "perception" / "vision_placement.py").read_text(encoding="utf-8")
    check("release center anchor uses raw centre PnP pose", "detection.center_target_pose_in_base" in vision_source)
    check("release center anchor requires HIGH RGB", 'confidence_class == "high"' in vision_source)
    check("release center anchor uses world-yaw cluster", "release_center_yaw_world_history" in vision_source)
    helper = vision_source.split("def _release_center_yaw_target_pose", 1)[1].split("def _measurement_matches_guide", 1)[0]
    check("release center anchor preserves certification x", "x=float(certification_target_base.x)" in helper)
    check("release center anchor preserves certification y", "y=float(certification_target_base.y)" in helper)

    source = (ROOT / "task" / "pickup_state_machine.py").read_text(encoding="utf-8")
    strict = source.split("def _strict_release_certified", 1)[1].split("def _placement_release_update_evidence", 1)[0]
    check("guarded yaw RSS requires trusted position RSS envelope", "and rss_enabled" in strict)
    check("guarded yaw RSS requires rigid load monitor", "and rigid_monitor.active" in strict)
    check("guarded yaw RSS requires motion-yaw observability", "self._motion_carried_load_yaw_sigma_rad()" in strict)
    check("strict yaw keeps full release sigma", "p.placement_strict_release_yaw_sigma_gain\n            * self._effective_carried_load_yaw_sigma_rad()" in strict)
    check("strict yaw keeps stale-yaw term", "stale_yaw," in strict)
    check("strict yaw keeps target-yaw margin", "target_yaw_margin," in strict)
    check("strict yaw keeps additive execution reserve", "execution_reserve=p.placement_strict_release_execution_yaw_reserve_rad" in strict)
    legacy_target = source.split("def _certification_target_pose_in_base", 1)[1].split("def _strict_release_target_pose_in_base", 1)[0]
    strict_target = source.split("def _strict_release_target_pose_in_base", 1)[1].split("def _load_to_certification_error", 1)[0]
    check("F4 center yaw does not leak into legacy recenter target", "_placement_release_center_yaw_target_pose_in_base" not in legacy_target)
    check("F4 center yaw is present in release-only target", "_placement_release_center_yaw_target_pose_in_base" in strict_target)
    check("S2 conflict removes centre target release authority", "and not self._strict_release_center_yaw_conflict_active" in strict_target)
    check("S2 conflict disables CENTER_YAW_RSS", "and not self._strict_release_center_yaw_conflict_active" in strict)
    check("S2 uses world-yaw continuity helper", "def _release_center_yaw_world_yaw" in source and "ReleaseCenterYawConflictGuard" in source)
    check("S2 invalidates Supervisor evidence immediately", "invalidate_external_evidence" in source)
    check("S2 has explicit conflict blocker", 'blocker = "CENTER_YAW_CONFLICT"' in strict)
    check("release-only strict error path is explicit", "def _load_to_strict_release_error" in source)
    metrics_source = (ROOT / "evaluation" / "dual_vision_metrics.py").read_text(encoding="utf-8")
    sim_source = (ROOT / "simulator" / "dual_vision_mission_episode.py").read_text(encoding="utf-8")
    check("F4 release anchor telemetry is aggregated", "total_release_center_yaw_anchor_active_frame_count" in metrics_source)
    check("F4 yaw RSS telemetry is aggregated", "total_strict_release_center_yaw_rss_frame_count" in metrics_source)
    check("S2 conflict telemetry is aggregated", "total_strict_release_center_yaw_conflict_count" in metrics_source and "strict_release_center_yaw_conflict_count" in sim_source)
    check("F4 release target/yaw-risk modes are captured", "controller_release_yaw_risk_budget_mode" in sim_source and "controller_release_target_source" in sim_source)
    check("consensus quality still uses full release yaw sigma", "self._effective_carried_load_yaw_sigma_rad()\n                <= p.placement_certified_basin_consensus_max_load_yaw_sigma_rad" in strict)
    check("no runtime truth use introduced", "ground_truth" not in source and "ground_truth" not in vision_source)

    print("V9.3.12-R4-F4-S2 static audit: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
