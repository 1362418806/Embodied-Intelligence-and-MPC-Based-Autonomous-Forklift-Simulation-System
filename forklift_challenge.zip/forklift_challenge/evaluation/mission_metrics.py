"""Metrics for complete pickup-transport-place missions."""
from __future__ import annotations
from dataclasses import asdict, dataclass, field
import csv, json
from pathlib import Path
from statistics import mean
from typing import Any, Iterable

@dataclass(frozen=True)
class MissionResult:
    scenario_id: str
    difficulty: str
    seed: int
    success: bool
    final_state: str
    failure_reason: str | None
    duration_seconds: float
    path_length_m: float
    max_abs_steering_deg: float
    max_load_tilt_deg: float
    final_placement_error_m: float
    final_placement_yaw_error_deg: float
    release_pallet_motion_m: float
    steering_exercised: bool
    recovery_count: int = 0
    state_durations: dict[str, float] = field(default_factory=dict)
    scenario: dict[str, Any] = field(default_factory=dict)
    def to_dict(self) -> dict[str, Any]: return asdict(self)

def summarize_missions(results: Iterable[MissionResult]) -> dict[str, Any]:
    items=list(results); successes=[x for x in items if x.success]
    failures: dict[str,int]={}; by: dict[str,dict[str,Any]]={}
    for item in items:
        if not item.success:
            key=item.failure_reason or item.final_state or 'unknown'; failures[key]=failures.get(key,0)+1
        bucket=by.setdefault(item.difficulty,{'episodes':0,'successes':0}); bucket['episodes']+=1; bucket['successes']+=int(item.success)
    for bucket in by.values(): bucket['success_rate']=bucket['successes']/bucket['episodes']
    if not items:
        return {'episode_count':0,'success_count':0,'success_rate':0.0,'failure_reasons':{},'by_difficulty':{}}
    return {
        'episode_count':len(items), 'success_count':len(successes), 'success_rate':len(successes)/len(items),
        'steering_exercised_rate':sum(x.steering_exercised for x in items)/len(items),
        'average_duration_seconds':mean(x.duration_seconds for x in items),
        'average_path_length_m':mean(x.path_length_m for x in items),
        'average_success_duration_seconds':mean(x.duration_seconds for x in successes) if successes else None,
        'average_success_placement_error_m':mean(x.final_placement_error_m for x in successes) if successes else None,
        'maximum_success_placement_error_m':max((x.final_placement_error_m for x in successes),default=None),
        'maximum_load_tilt_deg':max(x.max_load_tilt_deg for x in items),
        'failure_reasons':failures, 'by_difficulty':by,
    }

def write_mission_results(output_dir: Path, results: Iterable[MissionResult]) -> dict[str, Any]:
    output_dir.mkdir(parents=True,exist_ok=True); items=list(results); summary=summarize_missions(items)
    with (output_dir/'episodes.jsonl').open('w',encoding='utf-8') as f:
        for x in items: f.write(json.dumps(x.to_dict(),ensure_ascii=False)+'\n')
    fields=['scenario_id','difficulty','seed','success','final_state','failure_reason','duration_seconds','path_length_m','max_abs_steering_deg','max_load_tilt_deg','final_placement_error_m','final_placement_yaw_error_deg','release_pallet_motion_m','steering_exercised','recovery_count']
    with (output_dir/'episodes.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
        for x in items:
            row=x.to_dict(); w.writerow({k:row[k] for k in fields})
    (output_dir/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    return summary
