"""Run V9.3.12 with colour-coded fork-pocket and placement RGB fusion."""

from __future__ import annotations

from dataclasses import replace
import importlib.util
from pathlib import Path
import sys
from types import ModuleType
from typing import Any

import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from perception.appearance_stress import AppearanceStressPipeline
from perception.pose_pipeline import PosePipeline
from perception.terminal_fusion import apply_terminal_autonomy_overrides
from perception.vision_placement import VisionPlacementPipeline
from perception.vision_pickup import VisionPickupPipeline
from simulator.camera_renderer import MultiCameraRenderer
from simulator.observation_builder import ObservationBuilder as TruthObservationBuilder
from task.pickup_state_machine import PickupStateMachine as BasePickupStateMachine


BASE_SCRIPT = PROJECT_ROOT / "scripts" / "run_forklift_v5_1.py"
DEFAULT_CONFIG = PROJECT_ROOT / "configs" / "vehicle_v9_3_12.yaml"


def _consume_option(name: str) -> str | None:
    if name not in sys.argv:
        return None
    index = sys.argv.index(name)
    if index + 1 >= len(sys.argv):
        raise ValueError(f"{name} requires a value")
    value = sys.argv[index + 1]
    del sys.argv[index : index + 2]
    return value


def _config_path_from_argv() -> Path:
    if "--config" in sys.argv:
        index = sys.argv.index("--config")
        if index + 1 >= len(sys.argv):
            raise ValueError("--config requires a value")
        return Path(sys.argv[index + 1]).resolve()
    return DEFAULT_CONFIG


def _load_application() -> ModuleType:
    if not BASE_SCRIPT.is_file():
        raise FileNotFoundError(f"base interactive script does not exist: {BASE_SCRIPT}")
    name = "_forklift_v9_3_9_interactive_base"
    spec = importlib.util.spec_from_file_location(name, BASE_SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load base script: {BASE_SCRIPT}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main() -> int:
    profile_override = _consume_option("--perception-profile")
    appearance_override = _consume_option("--appearance-profile")
    seed_override = _consume_option("--perception-seed")
    config_path = _config_path_from_argv()
    with config_path.open("r", encoding="utf-8") as stream:
        config: dict[str, Any] = yaml.safe_load(stream)

    perception = config["perception"]
    vision_config = config["vision"]
    pickup_vision_config = config["pickup_vision"]
    appearance_config = config["appearance_stress"]
    camera_config = config["camera"]
    profile_name = str(profile_override or perception["default_profile"])
    appearance_profile_name = str(
        appearance_override
        or appearance_config["default_profile"]
    )
    seed = int(
        seed_override
        if seed_override is not None
        else config["randomization"]["default_seed"]
    )
    autonomy_overrides = perception.get(
        "terminal_autonomy_overrides", {}
    ).get(profile_name, {})
    runtime_state: dict[str, Any] = {
        "controller_state": None,
        "pickup_vision_ready": False,
        "placement_vision_ready": False,
        "placement_vision_raw_position_spread_m": None,
        "placement_vision_raw_yaw_spread_deg": None,
        "placement_certification_target_pose_in_base": None,
        "placement_vision_multiview_ready": False,
        "placement_vision_multiview_samples": 0,
        "placement_vision_multiview_position_spread_m": None,
        "placement_vision_multiview_yaw_spread_deg": None,
        "placement_vision_fast_slow_position_disagreement_m": None,
        "placement_vision_fast_slow_yaw_disagreement_deg": None,
    }

    class VisionObservationBuilder:
        def __init__(self, model) -> None:
            self.truth_builder = TruthObservationBuilder(model)
            self.pipeline = PosePipeline.from_config(
                perception,
                profile_name=profile_name,
                seed=seed,
            )
            self.pickup_vision = VisionPickupPipeline.from_config(
                pickup_vision_config,
                profile_name=profile_name,
                image_width=int(camera_config["width"]),
                image_height=int(camera_config["height"]),
            )
            self.vision = VisionPlacementPipeline.from_config(
                vision_config,
                profile_name=profile_name,
                image_width=int(camera_config["width"]),
                image_height=int(camera_config["height"]),
            )
            self.appearance = AppearanceStressPipeline.from_config(
                appearance_config,
                profile_name=appearance_profile_name,
                seed=seed,
                image_width=int(camera_config["width"]),
                image_height=int(camera_config["height"]),
            )
            import mujoco
            self.appearance.apply_camera_extrinsics(
                model,
                mujoco,
                (
                    self.pickup_vision.camera_name,
                    self.vision.camera_name,
                ),
            )
            self.renderer = MultiCameraRenderer(
                model,
                width=int(camera_config["width"]),
                height=int(camera_config["height"]),
            )

        def build(self, data, *, fork_contact_count: int, load_state: str):
            truth = self.truth_builder.build(
                data,
                fork_contact_count=fork_contact_count,
                load_state=load_state,
            )
            frame = self.pipeline.step(truth)
            pickup_rgb = None
            if self.pickup_vision.wants_image(
                sim_time=truth.sim_time,
                controller_state=runtime_state["controller_state"],
                observation=frame.observation,
            ):
                pickup_rgb = self.renderer.render(
                    data,
                    self.pickup_vision.camera_name,
                )
                pickup_rgb = self.appearance.apply(
                    pickup_rgb,
                    channel="pickup",
                ).image
            pickup_frame = self.pickup_vision.step(
                frame=frame,
                rgb=pickup_rgb,
                controller_state=runtime_state["controller_state"],
            )
            runtime_state["pickup_vision_ready"] = (
                self.pickup_vision.ready_for_insert()
            )
            fused_frame = replace(frame, observation=pickup_frame.observation)
            rgb = None
            if self.vision.wants_image(
                sim_time=truth.sim_time,
                controller_state=runtime_state["controller_state"],
            ):
                rgb = self.renderer.render(data, self.vision.camera_name)
                rgb = self.appearance.apply(
                    rgb,
                    channel="placement",
                ).image
            placement_frame = self.vision.step(
                frame=fused_frame,
                rgb=rgb,
                controller_state=runtime_state["controller_state"],
            )
            # Keep the FSM release gate synchronized with the same placement
            # consensus that produced the observation used for control.
            runtime_state["placement_vision_ready"] = self.vision.release_ready()
            runtime_state["placement_vision_raw_position_spread_m"] = getattr(
                placement_frame.diagnostics, "raw_release_position_spread_m", None
            )
            runtime_state["placement_vision_raw_yaw_spread_deg"] = getattr(
                placement_frame.diagnostics, "raw_release_yaw_spread_deg", None
            )
            runtime_state["placement_certification_target_pose_in_base"] = getattr(
                placement_frame, "certification_target_pose_in_base", None
            )
            runtime_state["placement_vision_multiview_ready"] = bool(getattr(
                placement_frame.diagnostics, "certification_multiview_ready", False
            ))
            runtime_state["placement_vision_multiview_samples"] = int(getattr(
                placement_frame.diagnostics, "certification_multiview_samples", 0
            ))
            runtime_state["placement_vision_multiview_position_spread_m"] = getattr(
                placement_frame.diagnostics, "certification_multiview_position_spread_m", None
            )
            runtime_state["placement_vision_multiview_yaw_spread_deg"] = getattr(
                placement_frame.diagnostics, "certification_multiview_yaw_spread_deg", None
            )
            runtime_state["placement_vision_fast_slow_position_disagreement_m"] = getattr(
                placement_frame.diagnostics, "certification_fast_slow_position_disagreement_m", None
            )
            runtime_state["placement_vision_fast_slow_yaw_disagreement_deg"] = getattr(
                placement_frame.diagnostics, "certification_fast_slow_yaw_disagreement_deg", None
            )
            return placement_frame.observation

        def close(self) -> None:
            self.renderer.close()

        def __del__(self) -> None:
            try:
                self.close()
            except Exception:
                pass

    class ProfileAwarePickupStateMachine(BasePickupStateMachine):
        def __init__(self, *, parameters, docking_controller) -> None:
            if autonomy_overrides:
                parameters = replace(parameters, **autonomy_overrides)
                parameters.validate()
            super().__init__(
                parameters=parameters,
                docking_controller=docking_controller,
            )
            runtime_state["controller_state"] = self.state.value

        def reset(self, sim_time: float) -> None:
            super().reset(sim_time)
            runtime_state["controller_state"] = self.state.value

        def step(self, observation):
            decision = super().step(
                observation,
                pickup_vision_ready=bool(
                    runtime_state["pickup_vision_ready"]
                ),
                placement_vision_ready=bool(
                    runtime_state["placement_vision_ready"]
                ),
                placement_vision_raw_position_spread_m=(
                    runtime_state["placement_vision_raw_position_spread_m"]
                ),
                placement_vision_raw_yaw_spread_deg=(
                    runtime_state["placement_vision_raw_yaw_spread_deg"]
                ),
                placement_certification_target_pose_in_base=(
                    runtime_state["placement_certification_target_pose_in_base"]
                ),
                placement_vision_multiview_ready=(
                    runtime_state["placement_vision_multiview_ready"]
                ),
                placement_vision_multiview_samples=(
                    runtime_state["placement_vision_multiview_samples"]
                ),
                placement_vision_multiview_position_spread_m=(
                    runtime_state["placement_vision_multiview_position_spread_m"]
                ),
                placement_vision_multiview_yaw_spread_deg=(
                    runtime_state["placement_vision_multiview_yaw_spread_deg"]
                ),
                placement_vision_fast_slow_position_disagreement_m=(
                    runtime_state["placement_vision_fast_slow_position_disagreement_m"]
                ),
                placement_vision_fast_slow_yaw_disagreement_deg=(
                    runtime_state["placement_vision_fast_slow_yaw_disagreement_deg"]
                ),
            )
            runtime_state["controller_state"] = decision.state.value
            return decision

    application = _load_application()
    application.DEFAULT_CONFIG = config_path
    application.ObservationBuilder = VisionObservationBuilder
    application.PickupStateMachine = ProfileAwarePickupStateMachine
    print(
        f"V9.3.12 perception={profile_name} | "
        f"appearance={appearance_profile_name} | seed={seed} | "
        "dual RGB confidence arbitration enabled"
    )
    return int(application.main())


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (FileNotFoundError, KeyError, RuntimeError, ValueError, yaml.YAMLError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
