"""Scenario sampling and MuJoCo pose-application tests."""

from __future__ import annotations

import math
from pathlib import Path

import mujoco

from scenarios.randomization import ScenarioSampler, apply_scenario, named_scenario


PROJECT_ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = PROJECT_ROOT / "assets" / "forklift" / "forklift_v5.xml"


def test_random_sampler_is_reproducible() -> None:
    first = ScenarioSampler(seed=1234, difficulty="nominal")
    second = ScenarioSampler(seed=1234, difficulty="nominal")
    assert first.sample() == second.sample()
    assert first.sample() == second.sample()


def test_easy_scenarios_stay_inside_declared_safe_envelope() -> None:
    sampler = ScenarioSampler(seed=7, difficulty="easy")
    for _ in range(50):
        scenario = sampler.sample()
        assert -0.85 <= scenario.forklift.x <= -0.55
        assert abs(scenario.forklift.y) <= 0.12
        assert abs(math.degrees(scenario.forklift.yaw)) <= 4.0
        assert 3.18 <= scenario.pallet.x <= 3.22


def test_named_lateral_scenarios_require_opposite_corrections() -> None:
    left = named_scenario("lateral_left")
    right = named_scenario("lateral_right")
    assert left.forklift.y < left.pallet.y
    assert right.forklift.y > right.pallet.y


def test_apply_scenario_changes_free_joint_planar_pose() -> None:
    model = mujoco.MjModel.from_xml_path(str(MODEL_PATH))
    data = mujoco.MjData(model)
    scenario = named_scenario("combined")
    apply_scenario(model, data, scenario)

    forklift_joint = mujoco.mj_name2id(
        model,
        mujoco.mjtObj.mjOBJ_JOINT,
        "forklift_free",
    )
    pallet_joint = mujoco.mj_name2id(
        model,
        mujoco.mjtObj.mjOBJ_JOINT,
        "pallet_load_free",
    )
    forklift_qpos = int(model.jnt_qposadr[forklift_joint])
    pallet_qpos = int(model.jnt_qposadr[pallet_joint])

    assert math.isclose(data.qpos[forklift_qpos], scenario.forklift.x)
    assert math.isclose(data.qpos[forklift_qpos + 1], scenario.forklift.y)
    assert math.isclose(data.qpos[pallet_qpos], scenario.pallet.x)
    assert math.isclose(data.qpos[pallet_qpos + 1], scenario.pallet.y)
