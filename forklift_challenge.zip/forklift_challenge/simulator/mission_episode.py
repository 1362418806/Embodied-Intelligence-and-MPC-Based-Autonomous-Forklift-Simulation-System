"""Headless execution of one complete pickup-transport-place mission."""
from __future__ import annotations
import json, math
from pathlib import Path
from typing import Any, Iterable
import mujoco
import numpy as np
from control.ackermann import front_drive_angular_speeds, rear_ackermann_angles
from control.docking_controller import DockingController
from control.safety import LiftDriveInterlock
from evaluation.mission_metrics import MissionResult
from scenarios.randomization import Scenario, apply_scenario
from simulator.observation_builder import ObservationBuilder
from task.pickup_state_machine import PickupParameters, PickupState, PickupStateMachine

PROJECT_ROOT=Path(__file__).resolve().parents[1]

def _require_id(model, object_type, name):
    oid=mujoco.mj_name2id(model,object_type,name)
    if oid<0: raise RuntimeError(f"required MuJoCo object was not found: {name}")
    return int(oid)

def _rpy(data,q):
    w,x,y,z=data.qpos[q+3:q+7]; sr=2*(w*x+y*z); cr=1-2*(x*x+y*y); roll=math.atan2(sr,cr); sp=2*(w*y-z*x); pitch=math.copysign(math.pi/2,sp) if abs(sp)>=1 else math.asin(sp); sy=2*(w*z+x*y); cy=1-2*(y*y+z*z); return roll,pitch,math.atan2(sy,cy)

def _contacts(data, first: Iterable[int], second: Iterable[int]):
    a=set(first); b=set(second); n=0
    for i in range(data.ncon):
        g1=int(data.contact[i].geom1); g2=int(data.contact[i].geom2)
        n += int((g1 in a and g2 in b) or (g2 in a and g1 in b))
    return n

def _controller(values: dict[str,Any]):
    return DockingController(distance_gain=float(values['distance_gain']),heading_gain=float(values['heading_gain']),yaw_gain=float(values['yaw_gain']),lateral_gain=float(values.get('lateral_gain',0)),lookahead_distance=float(values.get('lookahead_distance',.75)),maximum_steering=float(values['maximum_steering']),minimum_creep_speed=float(values['minimum_creep_speed']),heading_slowdown_angle=float(values['heading_slowdown_angle']),yaw_slowdown_angle=float(values.get('yaw_slowdown_angle',values['heading_slowdown_angle'])),minimum_alignment_scale=float(values.get('minimum_alignment_scale',.2)))

def _placement_error(obs):
    dx=obs.placement_pose_in_base.x-obs.pallet_pose_in_base.x; dy=obs.placement_pose_in_base.y-obs.pallet_pose_in_base.y
    return math.hypot(dx,dy), abs(math.degrees((obs.placement_pose_in_base.yaw-obs.pallet_pose_in_base.yaw+math.pi)%(2*math.pi)-math.pi))

def run_mission_episode(config: dict[str,Any], scenario: Scenario, *, max_episode_seconds: float|None=None, trace_path: Path|None=None) -> MissionResult:
    model_path=(PROJECT_ROOT/config['model']['xml_path']).resolve(); model=mujoco.MjModel.from_xml_path(str(model_path)); data=mujoco.MjData(model); mujoco.mj_resetData(model,data); apply_scenario(model,data,scenario)
    drive=config['drive']; lift=config['lift']; pickup=config['pickup']; safety=config['safety']; autonomy=config['autonomy']; batch=config.get('batch',{})
    ids={n:_require_id(model,mujoco.mjtObj.mjOBJ_ACTUATOR,n) for n in ('front_left_drive_velocity','front_right_drive_velocity','rear_left_steer_position','rear_right_steer_position','lift_position')}
    joints={n:_require_id(model,mujoco.mjtObj.mjOBJ_JOINT,n) for n in ('forklift_free','pallet_load_free','lift_joint')}
    fq=int(model.jnt_qposadr[joints['forklift_free']]); pq=int(model.jnt_qposadr[joints['pallet_load_free']]); ld=int(model.jnt_dofadr[joints['lift_joint']])
    fork={_require_id(model,mujoco.mjtObj.mjOBJ_GEOM,n) for n in ('left_fork','right_fork')}; pallet={_require_id(model,mujoco.mjtObj.mjOBJ_GEOM,n) for n in ('pallet_center_runner','pallet_left_runner','pallet_right_runner','pallet_deck','cargo_box')}
    initial=float(lift['initial_target']); data.ctrl[ids['lift_position']]=initial
    for _ in range(int(round(float(batch.get('settle_seconds',.5))/model.opt.timestep))): mujoco.mj_step(model,data)
    ground=float(data.qpos[pq+2]); builder=ObservationBuilder(model); machine=PickupStateMachine(parameters=PickupParameters.from_mapping(autonomy),docking_controller=_controller(config['controller'])); machine.reset(float(data.time))
    interlock=LiftDriveInterlock(enabled=bool(safety['stop_drive_during_lift']),velocity_threshold=float(safety['lift_velocity_threshold']),settle_time=float(safety['lift_settle_time_seconds'])); interlock.reset(lift_target=initial,sim_time=float(data.time))
    def status():
        z=float(data.qpos[pq+2]); r,p,_=_rpy(data,pq); tilt=max(abs(math.degrees(r)),abs(math.degrees(p))); c=_contacts(data,fork,pallet); lifted=z-ground>=float(pickup['lifted_height_threshold']); s='LIFTED' if lifted else ('ENGAGED' if c else 'GROUND'); return c,s,tilt
    start=float(data.time); limit=float(max_episode_seconds or batch.get('max_episode_seconds',260)); trace_hz=float(batch.get('trace_hz',10)); next_trace=start; period=1/trace_hz; stream=None
    if trace_path is not None: trace_path.parent.mkdir(parents=True,exist_ok=True); stream=trace_path.open('w',encoding='utf-8')
    current=machine.state.value; enter=start; durations={}; prev=(float(data.qpos[fq]),float(data.qpos[fq+1])); path=0.; maxsteer=0.; maxtilt=0.; final='FAILED'; reason=None; release_start=None; release_motion=0.; decision=None
    try:
        while float(data.time)-start<=limit:
            c,ls,tilt=status(); obs=builder.build(data,fork_contact_count=c,load_state=ls); decision=machine.step(obs); maxtilt=max(maxtilt,tilt)
            if decision.state.value!=current:
                durations[current]=durations.get(current,0.)+float(data.time)-enter; current=decision.state.value; enter=float(data.time)
                if current==PickupState.PLACE_RETREAT.value: release_start=(obs.pallet_pose_world.x,obs.pallet_pose_world.y)
            if release_start is not None: release_motion=max(release_motion,math.hypot(obs.pallet_pose_world.x-release_start[0],obs.pallet_pose_world.y-release_start[1]))
            action=decision.action; requested=0. if action.emergency_stop else action.speed_target; resolved=interlock.resolve(requested_speed=requested,lift_velocity=float(data.qvel[ld]),lift_target=action.lift_target,sim_time=float(data.time))
            steer=max(-float(drive['maximum_steering_command']),min(float(drive['maximum_steering_command']),action.steering_command)); angles=rear_ackermann_angles(steer,float(drive['wheelbase']),float(drive['rear_track'])); lo,ro=front_drive_angular_speeds(resolved.applied_speed,steer,float(drive['wheelbase']),float(drive['front_track']),float(drive['front_wheel_radius']))
            data.ctrl[ids['front_left_drive_velocity']]=lo; data.ctrl[ids['front_right_drive_velocity']]=ro; data.ctrl[ids['rear_left_steer_position']]=angles.left; data.ctrl[ids['rear_right_steer_position']]=angles.right; data.ctrl[ids['lift_position']]=max(float(lift['minimum_height']),min(float(lift['maximum_height']),action.lift_target)); maxsteer=max(maxsteer,abs(math.degrees(steer)))
            if stream and float(data.time)+1e-12>=next_trace:
                stream.write(json.dumps({'observation':obs.to_dict(),'decision':decision.to_dict(),'applied_speed':resolved.applied_speed,'interlock_reason':resolved.reason},ensure_ascii=False)+'\n')
                while next_trace<=float(data.time): next_trace+=period
            if decision.state in (PickupState.DONE,PickupState.FAILED): final=decision.state.value; reason=decision.failure_reason; break
            mujoco.mj_step(model,data); cur=(float(data.qpos[fq]),float(data.qpos[fq+1])); path+=math.hypot(cur[0]-prev[0],cur[1]-prev[1]); prev=cur
            if not np.isfinite(data.qpos).all() or not np.isfinite(data.qvel).all(): reason='non-finite MuJoCo state'; break
        else: reason=f'episode exceeded {limit:.1f}s'
    finally:
        if stream: stream.close()
    end=float(data.time); durations[current]=durations.get(current,0.)+max(0.,end-enter); c,ls,tilt=status(); obs=builder.build(data,fork_contact_count=c,load_state=ls); pe,ye=_placement_error(obs); success=final==PickupState.DONE.value
    return MissionResult(scenario_id=scenario.scenario_id,difficulty=scenario.difficulty,seed=scenario.seed,success=success,final_state=final,failure_reason=None if success else (reason or 'unknown failure'),duration_seconds=max(0.,end-start),path_length_m=path,max_abs_steering_deg=maxsteer,max_load_tilt_deg=max(maxtilt,tilt),final_placement_error_m=pe,final_placement_yaw_error_deg=ye,release_pallet_motion_m=release_motion,steering_exercised=maxsteer>=float(batch.get('steering_exercised_degrees',1)),recovery_count=machine.recovery_count,state_durations={k:round(v,6) for k,v in durations.items()},scenario=scenario.to_dict())
