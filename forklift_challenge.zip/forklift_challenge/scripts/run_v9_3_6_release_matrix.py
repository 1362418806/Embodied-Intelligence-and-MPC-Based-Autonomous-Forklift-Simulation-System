"""Run the V9.3.6 independent release-qualification matrix."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import subprocess
import sys
import time

PROJECT_ROOT = Path(__file__).resolve().parents[1]
BATCH_ROOT = PROJECT_ROOT / "outputs" / "v9_3_6_batch"


def _newest_summary(after_ns: int) -> Path:
    candidates = [
        path
        for path in BATCH_ROOT.glob("batch_*/summary.json")
        if path.stat().st_mtime_ns >= after_ns
    ]
    if not candidates:
        raise RuntimeError("batch runner produced no new summary.json")
    return max(candidates, key=lambda p: p.stat().st_mtime_ns)


def _run(
    *,
    episodes: int,
    difficulty: str,
    profile: str,
    appearance: str,
    seed: int,
    trace_failures: bool,
) -> Path:
    command = [
        sys.executable,
        str(PROJECT_ROOT / "scripts" / "run_v9_3_6_batch.py"),
        "--episodes", str(episodes),
        "--difficulty", difficulty,
        "--profile", profile,
        "--appearance-profile", appearance,
        "--seed", str(seed),
    ]
    if trace_failures:
        command.append("--trace-failures")
    before = time.time_ns()
    print("\n>", " ".join(command))
    completed = subprocess.run(command, cwd=PROJECT_ROOT)
    if completed.returncode != 0:
        raise SystemExit(completed.returncode)
    return _newest_summary(before)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--episodes", type=int, default=20)
    parser.add_argument("--combined-episodes", type=int, default=20)
    parser.add_argument(
        "--seed",
        type=int,
        default=20260810,
        help="Independent release seed; V9.1.3 qualification used 20260809.",
    )
    parser.add_argument("--trace-failures", action="store_true")
    args = parser.parse_args()

    summaries = {}
    summaries["moderate_easy"] = _run(
        episodes=args.episodes,
        difficulty="easy",
        profile="moderate",
        appearance="moderate",
        seed=args.seed,
        trace_failures=args.trace_failures,
    )
    summaries["moderate_nominal"] = _run(
        episodes=args.episodes,
        difficulty="nominal",
        profile="moderate",
        appearance="moderate",
        seed=args.seed,
        trace_failures=args.trace_failures,
    )
    summaries["finals_easy"] = _run(
        episodes=args.episodes,
        difficulty="easy",
        profile="finals",
        appearance="finals",
        seed=args.seed,
        trace_failures=args.trace_failures,
    )
    summaries["combined"] = _run(
        episodes=args.combined_episodes,
        difficulty="easy",
        profile="finals",
        appearance="combined",
        seed=args.seed,
        trace_failures=args.trace_failures,
    )

    report_dir = (
        PROJECT_ROOT
        / "outputs"
        / "v9_3_6_release_report"
        / f"seed_{args.seed}"
    )
    command = [
        sys.executable,
        str(PROJECT_ROOT / "scripts" / "evaluate_v9_3_6_release.py"),
        "--moderate-easy", str(summaries["moderate_easy"]),
        "--moderate-nominal", str(summaries["moderate_nominal"]),
        "--finals-easy", str(summaries["finals_easy"]),
        "--combined", str(summaries["combined"]),
        "--output", str(report_dir),
    ]
    completed = subprocess.run(command, cwd=PROJECT_ROOT)

    manifest = {
        "seed": args.seed,
        "episodes": args.episodes,
        "combined_episodes": args.combined_episodes,
        "summaries": {
            key: str(path.resolve())
            for key, path in summaries.items()
        },
    }
    report_dir.mkdir(parents=True, exist_ok=True)
    (report_dir / "matrix_manifest.json").write_text(
        json.dumps(manifest, indent=2),
        encoding="utf-8",
    )
    return int(completed.returncode)


if __name__ == "__main__":
    raise SystemExit(main())
