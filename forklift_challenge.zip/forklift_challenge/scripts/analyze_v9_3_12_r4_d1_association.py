"""Analyze V9.3.12-R4-D1 terminal-load image-association audit JSONL.

This is a diagnostic-only tool. It distinguishes two primary hypotheses:
  A) wrong blue blob selected;
  B) propagated load projection / camera-cargo geometry is systematically offset.

It never feeds data back to control.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
import math
from pathlib import Path
import statistics
from typing import Any, Iterable


def _records(path: Path) -> Iterable[dict[str, Any]]:
    paths = [path] if path.is_file() else sorted(path.rglob("*.jsonl"))
    for p in paths:
        with p.open("r", encoding="utf-8") as stream:
            for line in stream:
                if not line.strip():
                    continue
                try:
                    item = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if item.get("schema") == "v9_3_12_r4_d1_terminal_load_association_v1":
                    item["_source"] = str(p)
                    yield item


def _median(values: list[float]) -> float | None:
    return None if not values else float(statistics.median(values))


def _pct(n: int, d: int) -> float:
    return 0.0 if d <= 0 else 100.0 * n / d


def analyze(records: list[dict[str, Any]]) -> dict[str, Any]:
    requested = [r for r in records if r.get("requested")]
    detected = [r for r in requested if r.get("detected")]
    status = Counter(str(r.get("final_status", r.get("status", "unknown"))) for r in requested)
    selected_ranks = Counter()
    best_iou_ranks = Counter()
    component_counts: list[float] = []
    selected_center_errors: list[float] = []
    best_center_errors: list[float] = []
    selected_ious: list[float] = []
    best_ious: list[float] = []
    fit_errors: list[float] = []
    coverages: list[float] = []
    wrong_blob_votes = 0
    projection_votes = 0
    selected_is_best_votes = 0
    evaluable = 0

    for r in detected:
        components = r.get("components") or []
        if not components:
            continue
        evaluable += 1
        component_counts.append(float(len(components)))
        sr = r.get("selected_rank")
        br = r.get("best_iou_rank")
        if sr is not None:
            selected_ranks[int(sr)] += 1
        if br is not None:
            best_iou_ranks[int(br)] += 1
        selected = r.get("selected_component")
        if selected is None and sr is not None and int(sr) < len(components):
            selected = components[int(sr)]
        if selected is None:
            continue
        selected_iou = float(selected.get("iou_with_prior", 0.0))
        selected_center = float(selected.get("center_error_to_prior_px", math.inf))
        best_iou = max(float(c.get("iou_with_prior", 0.0)) for c in components)
        best_center = min(float(c.get("center_error_to_prior_px", math.inf)) for c in components)
        selected_ious.append(selected_iou)
        selected_center_errors.append(selected_center)
        best_ious.append(best_iou)
        best_center_errors.append(best_center)
        if r.get("fitted_center_error_px") is not None:
            fit_errors.append(float(r["fitted_center_error_px"]))
        if r.get("fitted_prior_coverage") is not None:
            coverages.append(float(r["fitted_prior_coverage"]))

        alternative_materially_better = bool(
            (br is not None and sr is not None and int(br) != int(sr) and best_iou >= selected_iou + 0.05)
            or best_center <= selected_center - 20.0
        )
        if alternative_materially_better:
            wrong_blob_votes += 1
        if sr == br:
            selected_is_best_votes += 1
        # Strong projection-mismatch evidence: not even the *best* observed blue
        # component overlaps the prior polygon, and the nearest blue component is
        # well outside the original 42 px association gate.
        if best_iou <= 0.01 and best_center > 42.0:
            projection_votes += 1

    wrong_ratio = 0.0 if evaluable == 0 else wrong_blob_votes / evaluable
    projection_ratio = 0.0 if evaluable == 0 else projection_votes / evaluable
    selected_best_ratio = 0.0 if evaluable == 0 else selected_is_best_votes / evaluable

    if evaluable == 0:
        diagnosis = "INSUFFICIENT_DATA"
        rationale = "No detected association frames were found."
    elif wrong_ratio >= 0.50:
        diagnosis = "WRONG_BLOB_SELECTION_LIKELY"
        rationale = (
            "A materially better alternative blue component exists in at least half of evaluable frames. "
            "Fix candidate disambiguation before touching projection calibration or consensus gates."
        )
    elif projection_ratio >= 0.70 and selected_best_ratio >= 0.70:
        diagnosis = "PROJECTION_OR_GEOMETRY_MISMATCH_LIKELY"
        rationale = (
            "The selected component is usually already the best prior-associated blue component, yet even the best "
            "component has near-zero overlap and remains outside the 42 px gate. This points to camera/cargo projection "
            "geometry rather than blob ranking."
        )
    elif projection_ratio >= 0.70:
        diagnosis = "GLOBAL_ASSOCIATION_MISMATCH_LIKELY"
        rationale = (
            "No blue component overlaps the propagated projection in most frames. Inspect overlays to separate camera/cargo "
            "projection calibration from an HSV mask that is observing a different physical blue surface."
        )
    else:
        diagnosis = "MIXED_OR_AMBIGUOUS"
        rationale = "Evidence is mixed; inspect overlay frames and per-component JSON metrics before changing behavior."

    return {
        "schema": "v9_3_12_r4_d1_association_analysis_v1",
        "record_count": len(records),
        "requested_count": len(requested),
        "detected_count": len(detected),
        "evaluable_count": evaluable,
        "status_counts": dict(status),
        "selected_rank_counts": dict(selected_ranks),
        "best_iou_rank_counts": dict(best_iou_ranks),
        "component_count_median": _median(component_counts),
        "selected_center_error_px_median": _median(selected_center_errors),
        "best_center_error_px_median": _median(best_center_errors),
        "selected_iou_median": _median(selected_ious),
        "best_iou_median": _median(best_ious),
        "fitted_center_error_px_median": _median(fit_errors),
        "fitted_coverage_median": _median(coverages),
        "wrong_blob_vote_count": wrong_blob_votes,
        "wrong_blob_vote_percent": _pct(wrong_blob_votes, evaluable),
        "projection_mismatch_vote_count": projection_votes,
        "projection_mismatch_vote_percent": _pct(projection_votes, evaluable),
        "selected_is_best_iou_count": selected_is_best_votes,
        "selected_is_best_iou_percent": _pct(selected_is_best_votes, evaluable),
        "diagnosis": diagnosis,
        "rationale": rationale,
    }


def _fmt(value: Any, digits: int = 3) -> str:
    if value is None:
        return "n/a"
    if isinstance(value, float):
        return f"{value:.{digits}f}"
    return str(value)


def render_markdown(summary: dict[str, Any]) -> str:
    return f"""# V9.3.12-R4-D1 Terminal Reacquisition Association Audit\n\n## Diagnosis\n\n**{summary['diagnosis']}**\n\n{summary['rationale']}\n\n## Evidence\n\n- Requested RGB samples: {summary['requested_count']}\n- Detected raw candidates: {summary['detected_count']}\n- Evaluable association frames: {summary['evaluable_count']}\n- Median blue component count: {_fmt(summary['component_count_median'], 1)}\n- Median selected center error: {_fmt(summary['selected_center_error_px_median'], 1)} px\n- Median nearest-component center error: {_fmt(summary['best_center_error_px_median'], 1)} px\n- Median selected IoU with prior: {_fmt(summary['selected_iou_median'])}\n- Median best-component IoU with prior: {_fmt(summary['best_iou_median'])}\n- Median fitted center error: {_fmt(summary['fitted_center_error_px_median'], 1)} px\n- Median fitted coverage: {_fmt(summary['fitted_coverage_median'])}\n- Wrong-blob evidence: {summary['wrong_blob_vote_count']}/{summary['evaluable_count']} ({summary['wrong_blob_vote_percent']:.1f}%)\n- Projection-mismatch evidence: {summary['projection_mismatch_vote_count']}/{summary['evaluable_count']} ({summary['projection_mismatch_vote_percent']:.1f}%)\n- Selected component already best-IoU: {summary['selected_is_best_iou_count']}/{summary['evaluable_count']} ({summary['selected_is_best_iou_percent']:.1f}%)\n\n## Status counts\n\n```json\n{json.dumps(summary['status_counts'], ensure_ascii=False, indent=2)}\n```\n\n## Next action\n\n- `WRONG_BLOB_SELECTION_LIKELY`: fix blue-component disambiguation only.\n- `PROJECTION_OR_GEOMETRY_MISMATCH_LIKELY`: audit front-camera extrinsics, FOV/intrinsics, pallet reference, cargo-box geometry, and image perturbation transform consistency.\n- `GLOBAL_ASSOCIATION_MISMATCH_LIKELY`: inspect overlays to determine whether the blue mask is observing a different physical surface than the projected cargo model.\n- `MIXED_OR_AMBIGUOUS`: do not change thresholds; inspect the generated `reacq_debug` images first.\n"""


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("path", type=Path, help="Association JSONL file or directory containing audit JSONL files")
    parser.add_argument("--output-json", type=Path)
    parser.add_argument("--output-md", type=Path)
    args = parser.parse_args()
    records = list(_records(args.path.resolve()))
    summary = analyze(records)
    print(render_markdown(summary))
    if args.output_json:
        args.output_json.parent.mkdir(parents=True, exist_ok=True)
        args.output_json.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    if args.output_md:
        args.output_md.parent.mkdir(parents=True, exist_ok=True)
        args.output_md.write_text(render_markdown(summary), encoding="utf-8")
    return 0 if summary["diagnosis"] != "INSUFFICIENT_DATA" else 2


if __name__ == "__main__":
    raise SystemExit(main())
