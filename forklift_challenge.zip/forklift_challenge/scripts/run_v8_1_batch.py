"""Batch evaluation for V8.1 dual-RGB pickup and placement missions."""

from __future__ import annotations

import argparse
from datetime import datetime
from pathlib import Path
import sys
from typing import Any

import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from evaluation.dual_vision_metrics import write_dual_vision_results
from scenarios.randomization import ScenarioSampler
from simulator.dual_vision_mission_episode import run_vision_mission_episode


DEFAULT_CONFIG = PROJECT_ROOT / "configs" / "vehicle_v8_1.yaml"


def load_config(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise FileNotFoundError(f"configuration file does not exist: {path}")
    with path.open("r", encoding="utf-8") as stream:
        config = yaml.safe_load(stream)
    if not isinstance(config, dict):
        raise ValueError("configuration root must be a mapping")
    if "perception" not in config:
        raise KeyError("perception")
    return config


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--episodes", type=int, default=20)
    parser.add_argument("--seed", type=int)
    parser.add_argument("--difficulty", choices=ScenarioSampler.difficulties())
    parser.add_argument("--profile", choices=("clean", "moderate", "finals"))
    parser.add_argument("--output", type=Path)
    parser.add_argument("--max-time", type=float)
    parser.add_argument("--trace-failures", action="store_true")
    parser.add_argument("--trace-all", action="store_true")
    parser.add_argument("--require-success-rate", type=float, default=0.0)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    config = load_config(args.config.resolve())
    seed = int(
        args.seed
        if args.seed is not None
        else config["randomization"]["default_seed"]
    )
    difficulty = str(
        args.difficulty
        if args.difficulty is not None
        else config["randomization"]["default_difficulty"]
    )
    profile = str(
        args.profile
        if args.profile is not None
        else config["perception"]["default_profile"]
    )
    sampler = ScenarioSampler(seed=seed, difficulty=difficulty)
    scenarios = [sampler.sample() for _ in range(args.episodes)]
    output = (
        args.output.resolve()
        if args.output
        else (
            PROJECT_ROOT
            / config["batch"]["output_root"]
            / f"batch_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{profile}"
        ).resolve()
    )
    output.mkdir(parents=True, exist_ok=True)
    results = []
    print(
        f"Running {len(scenarios)} V8.1 dual-vision missions | seed={seed} | "
        f"difficulty={difficulty} | profile={profile} | output={output}"
    )
    for index, scenario in enumerate(scenarios, 1):
        trace = (
            output / "traces" / f"{scenario.scenario_id}.jsonl"
            if args.trace_all
            else None
        )
        result = run_vision_mission_episode(
            config,
            scenario,
            profile_name=profile,
            max_episode_seconds=args.max_time,
            trace_path=trace,
        )
        results.append(result)
        verdict = "PASS" if result.success else "FAIL"
        reason = "" if result.success else f" | {result.failure_reason}"
        print(
            f"[{index:02d}/{len(scenarios):02d}] {verdict} "
            f"{scenario.scenario_id:<16} t={result.duration_seconds:5.1f}s "
            f"place={result.final_placement_error_m:.3f}m "
            f"vision={result.vision_detection_rate:.0%} "
            f"vision_rmse="
            f"{result.vision_position_rmse_m if result.vision_position_rmse_m is not None else float('nan'):.3f}m "
            f"pose_rmse={result.pallet_position_rmse_m:.3f}/"
            f"{result.placement_position_rmse_m:.3f}m{reason}"
        )
        if args.trace_failures and not result.success and trace is None:
            run_vision_mission_episode(
                config,
                scenario,
                profile_name=profile,
                max_episode_seconds=args.max_time,
                trace_path=output
                / "failure_traces"
                / f"{scenario.scenario_id}.jsonl",
            )

    summary = write_dual_vision_results(output, results)
    print("\nV8.1 dual-RGB mission summary")
    print(f"  success: {summary['success_count']}/{summary['episode_count']}")
    print(f"  success_rate: {summary['success_rate']:.1%}")
    print(
        "  avg_success_placement_error: "
        f"{summary['average_success_placement_error_m']}"
    )
    print(
        "  estimate_rmse pallet/placement: "
        f"{summary['average_pallet_position_rmse_m']:.3f}/"
        f"{summary['average_placement_position_rmse_m']:.3f}m"
    )
    print(
        "  pallet-pocket detection/rmse/use: "
        f"{summary['average_pickup_vision_detection_rate']:.1%}/"
        f"{summary['average_pickup_vision_position_rmse_m']}/"
        f"{summary['pickup_vision_use_rate']:.1%}"
    )
    print(
        "  RGB marker detection/rmse/use: "
        f"{summary['average_vision_detection_rate']:.1%}/"
        f"{summary['average_vision_position_rmse_m']}/"
        f"{summary['vision_terminal_use_rate']:.1%}"
    )
    print(f"  results: {output}")
    return 2 if summary["success_rate"] < args.require_success_rate else 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (FileNotFoundError, KeyError, RuntimeError, ValueError, yaml.YAMLError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
