from pathlib import Path
import ast, yaml
ROOT=Path(__file__).resolve().parents[1]
sim=(ROOT/'simulator/dual_vision_mission_episode.py').read_text(encoding='utf-8')
reacq=(ROOT/'perception/terminal_load_reacquisition.py').read_text(encoding='utf-8')
cfg=yaml.safe_load((ROOT/'configs/vehicle_v9_3_12_r4_d.yaml').read_text(encoding='utf-8'))
checks={
 'sim syntax': lambda: ast.parse(sim) is not None,
 'reacq syntax': lambda: ast.parse(reacq) is not None,
 'pipeline import': lambda: 'TerminalLoadReacquisitionPipeline' in sim,
 'pipeline config': lambda: 'terminal_load_reacquisition_config = config.get("terminal_load_reacquisition")' in sim,
 'wants_image wiring': lambda: 'terminal_load_reacquisition.wants_image(' in sim,
 'step wiring': lambda: 'terminal_load_reacquisition.step(' in sim,
 'observer handoff': lambda: 'terminal_load_reacquisition_pose_in_base=(' in sim,
 'result metrics': lambda: 'terminal_load_reacquisition_sample_count=(' in sim,
 'trace metrics': lambda: '"terminal_load_reacquisition": (' in sim,
 'weak-guide enabled': lambda: bool(cfg['terminal_load_reacquisition']['profiles']['weak_guide']['enabled']),
 'strict release unchanged': lambda: cfg['autonomy'].get('placement_release_competition_position_tolerance', 0.10) <= 0.10,
}
failed=[]
for name,fn in checks.items():
 try: ok=bool(fn())
 except Exception: ok=False
 print(f"{name:28s} {'PASS' if ok else 'FAIL'}")
 if not ok: failed.append(name)
if failed: raise SystemExit('R4-D audit failed: '+', '.join(failed))
print('R4-D audit PASS')
