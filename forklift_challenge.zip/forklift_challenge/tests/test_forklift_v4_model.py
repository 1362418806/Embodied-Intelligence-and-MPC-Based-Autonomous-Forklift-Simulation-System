"""Structural checks for the v4 autonomous-pickup package."""

from __future__ import annotations

from pathlib import Path

import mujoco
import yaml

from interfaces.action import ForkliftAction


PROJECT_ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = PROJECT_ROOT / "assets" / "forklift" / "forklift_v4.xml"
CONFIG_PATH = PROJECT_ROOT / "configs" / "vehicle_v4.yaml"


def named_id(model: mujoco.MjModel, object_type: mujoco.mjtObj, name: str) -> int:
    object_id = mujoco.mj_name2id(model, object_type, name)
    assert object_id >= 0, f"Missing MuJoCo object: {name}"
    return object_id


def test_v4_model_compiles_with_pickup_objects_and_cameras() -> None:
    model = mujoco.MjModel.from_xml_path(str(MODEL_PATH))
    named_id(model, mujoco.mjtObj.mjOBJ_BODY, "forklift")
    named_id(model, mujoco.mjtObj.mjOBJ_BODY, "pallet_load")
    named_id(model, mujoco.mjtObj.mjOBJ_CAMERA, "front_rgb")
    named_id(model, mujoco.mjtObj.mjOBJ_CAMERA, "fork_rgb")
    named_id(model, mujoco.mjtObj.mjOBJ_SITE, "placement_target")


def test_v4_config_has_controller_and_autonomy_sections() -> None:
    with CONFIG_PATH.open("r", encoding="utf-8") as stream:
        config = yaml.safe_load(stream)
    assert config["model"]["xml_path"].endswith("forklift_v4.xml")
    assert config["controller"]["maximum_steering"] > 0.0
    assert config["autonomy"]["pre_approach_distance"] > config["autonomy"]["insertion_distance"]
    assert config["autonomy"]["retreat_speed"] < 0.0


def test_action_interface_serializes() -> None:
    action = ForkliftAction(
        speed_target=0.2,
        steering_command=0.1,
        lift_target=0.3,
    )
    assert action.to_dict() == {
        "speed_target": 0.2,
        "steering_command": 0.1,
        "lift_target": 0.3,
        "emergency_stop": False,
    }
