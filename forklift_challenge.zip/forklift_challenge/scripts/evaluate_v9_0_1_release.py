"""Evaluate V9.0.1 release summaries and emit JSON + Markdown report."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from evaluation.release_qualification import (
    COMBINED_INFORMATIONAL,
    FORMAL_THRESHOLDS,
    overall_pass,
    qualify_summary_file,
)


def _markdown(results, passed: bool) -> str:
    lines = [
        "# V9.0.1 Release Qualification",
        "",
        f"Overall formal release: **{'PASS' if passed else 'FAIL'}**",
        "",
        "| Group | Hard gate | Result |",
        "|---|---:|---:|",
    ]
    for result in results:
        lines.append(
            f"| {result.label} | {'yes' if result.hard_gate else 'no'} | "
            f"{'PASS' if result.passed else 'FAIL'} |"
        )
    lines.extend(["", "## Detailed checks", ""])
    for result in results:
        lines.append(f"### {result.label}")
        lines.append("")
        lines.append("| Check | Value | Requirement | Result |")
        lines.append("|---|---:|---:|---:|")
        for check in result.checks:
            value = check.value
            if isinstance(value, float):
                rendered = f"{value:.6g}"
            else:
                rendered = str(value)
            lines.append(
                f"| {check.name} | {rendered} | {check.requirement} | "
                f"{'PASS' if check.passed else 'FAIL'} |"
            )
        lines.append("")
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--moderate-easy", type=Path, required=True)
    parser.add_argument("--moderate-nominal", type=Path, required=True)
    parser.add_argument("--finals-easy", type=Path, required=True)
    parser.add_argument("--combined", type=Path)
    parser.add_argument(
        "--output",
        type=Path,
        default=PROJECT_ROOT / "outputs" / "v9_0_1_release_report",
    )
    args = parser.parse_args()

    results = [
        qualify_summary_file(
            args.moderate_easy,
            label="moderate_easy",
            thresholds=FORMAL_THRESHOLDS["moderate_easy"],
        ),
        qualify_summary_file(
            args.moderate_nominal,
            label="moderate_nominal",
            thresholds=FORMAL_THRESHOLDS["moderate_nominal"],
        ),
        qualify_summary_file(
            args.finals_easy,
            label="finals_easy",
            thresholds=FORMAL_THRESHOLDS["finals_easy"],
        ),
    ]
    if args.combined is not None:
        results.append(
            qualify_summary_file(
                args.combined,
                label="finals_combined",
                thresholds=COMBINED_INFORMATIONAL,
                hard_gate=False,
            )
        )

    passed = overall_pass(results)
    args.output.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema": "forklift_v9_release_qualification_v1",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "overall_formal_pass": passed,
        "results": [result.to_dict() for result in results],
    }
    (args.output / "qualification.json").write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )
    (args.output / "qualification.md").write_text(
        _markdown(results, passed),
        encoding="utf-8",
    )

    print(f"V9.0.1 formal release: {'PASS' if passed else 'FAIL'}")
    for result in results:
        print(
            f"  {result.label}: "
            f"{'PASS' if result.passed else 'FAIL'}"
            + (" [informational]" if not result.hard_gate else "")
        )
        for check in result.checks:
            if not check.passed:
                print(
                    f"    FAIL {check.name}: "
                    f"{check.value} ({check.requirement})"
                )
    print(f"report: {args.output.resolve()}")
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
