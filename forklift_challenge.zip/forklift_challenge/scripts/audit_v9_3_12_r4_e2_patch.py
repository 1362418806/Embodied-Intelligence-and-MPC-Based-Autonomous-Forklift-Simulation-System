"""Static/invariant audit for V9.3.12-R4-E2 Certification-Basin Closure."""
from __future__ import annotations

import math
from pathlib import Path
import py_compile
import sys

import yaml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from control.terminal_micro_primitives import CertificationBasinClosureConfig, CertificationBasinClosurePlanner


def check(name: str, condition: bool) -> None:
    print(f"{'PASS' if condition else 'FAIL'} {name}")
    if not condition:
        raise AssertionError(name)


def main() -> int:
    files = [
        ROOT / "control" / "terminal_micro_primitives.py",
        ROOT / "task" / "pickup_state_machine.py",
        ROOT / "simulator" / "dual_vision_mission_episode.py",
        ROOT / "evaluation" / "dual_vision_metrics.py",
        ROOT / "scripts" / "run_v9_3_12_r4_e2_batch.py",
        ROOT / "scripts" / "analyze_v9_3_12_r4_e2_certification_basin.py",
    ]
    for path in files:
        py_compile.compile(str(path), doraise=True)
    check("Python syntax", True)

    cfg_path = ROOT / "configs" / "vehicle_v9_3_12_r4_e2.yaml"
    cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
    weak = cfg["perception"]["terminal_autonomy_overrides"]["weak_guide"]
    check("E2 enabled in weak-guide", weak["placement_certification_basin_closure_enabled"] == 1.0)
    check("strict position unchanged", weak["placement_strict_release_position_limit_m"] == 0.095)
    check("strict yaw unchanged", math.isclose(weak["placement_strict_release_yaw_limit_rad"], math.radians(4.6), rel_tol=1e-9))
    check("90s terminal budget unchanged", weak["placement_terminal_budget_seconds"] == 90.0)
    check("consensus release authority OFF", weak["placement_certified_basin_consensus_release_authority"] == 0.0)
    check("post-closure main guard retained", weak["placement_post_closure_basin_position_guard_m"] == 0.105)
    check("E2 exit envelope contains main guard", weak["placement_post_closure_exit_position_guard_m"] >= weak["placement_post_closure_basin_position_guard_m"])
    check("E2 motion budget <=1.5s", weak["placement_certification_basin_closure_maximum_total_execution_seconds"] <= 1.5)
    check("E2 max activations <=2", weak["placement_certification_basin_closure_max_activations"] <= 2)

    task_source = (ROOT / "task" / "pickup_state_machine.py").read_text(encoding="utf-8")
    check("gray-zone hold closes E1 gap", "V9.3.12-R4-E2 post-closure gray-zone hold" in task_source)
    check("E2 uses certification error", "certification_error = self._load_to_certification_error(observation)" in task_source)
    check("E2 waits for strict reject", "self._strict_release_certification_reject_count > 0" in task_source)
    check("E2 has no release authority", "certification-basin closure selected" in task_source and "Release Supervisor" not in (ROOT / "control" / "terminal_micro_primitives.py").read_text(encoding="utf-8"))
    check("Supervisor suppressed only during E2 feedback cycle", "certification-space recenter owns motion" in task_source)

    planner = CertificationBasinClosurePlanner(
        CertificationBasinClosureConfig(
            wheelbase_m=0.93,
            steering_limit_rad=0.17,
            speed_mps=0.05,
            filtered_position_guard_m=0.105,
            filtered_yaw_guard_rad=math.radians(6.5),
            certification_position_activation_m=0.13,
            certification_yaw_activation_rad=math.radians(7.0),
            predicted_filtered_position_guard_m=0.105,
            predicted_filtered_yaw_guard_rad=math.radians(6.5),
            strict_position_limit_m=0.095,
            strict_yaw_limit_rad=math.radians(4.6),
            position_scale_m=0.01,
            yaw_scale_rad=math.radians(1.0),
            required_predicted_deficit_improvement=0.15,
            allowed_filtered_position_regression_m=0.01,
            duration_options_s=(0.20, 0.35, 0.50),
            steering_fractions=(0.55, 1.0),
            second_leg_duration_fractions=(0.0, 0.50, 1.0),
            maximum_speed_for_activation_mps=0.02,
            max_activations=2,
            maximum_total_execution_seconds=1.50,
        )
    )
    selected = planner.search(
        filtered_x_m=-0.010,
        filtered_y_m=-0.078,
        filtered_yaw_rad=math.radians(3.03),
        certification_x_m=-0.020,
        certification_y_m=-0.091,
        certification_yaw_rad=math.radians(4.153),
        position_margin_m=0.01726,
        yaw_margin_rad=math.radians(0.9715),
        current_speed_mps=0.0,
    )
    check("E1-trace-like counterfactual has bounded candidate", selected is not None)
    assert selected is not None
    check("candidate improves strict deficit", selected.predicted_strict_deficit < selected.current_strict_deficit)
    check("candidate respects 10.5cm filtered guard", selected.maximum_predicted_filtered_distance_m <= 0.105 + 1e-9)

    print("\nV9.3.12-R4-E2 audit PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
