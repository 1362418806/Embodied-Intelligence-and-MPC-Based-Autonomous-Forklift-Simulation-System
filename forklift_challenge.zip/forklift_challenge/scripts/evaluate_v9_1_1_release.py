"""Evaluate V9.1.1 baseline release gates and stricter optimization targets."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from evaluation.release_qualification import (
    COMBINED_INFORMATIONAL,
    FORMAL_THRESHOLDS,
    V9_1_PROMOTION_THRESHOLDS,
    overall_pass,
    qualify_summary_file,
)


def _markdown(baseline, promotion, combined, baseline_pass, promotion_pass):
    lines = [
        "# V9.1.1 Release Qualification",
        "",
        f"Historical 80/70/50 baseline: **{'PASS' if baseline_pass else 'FAIL'}**",
        f"V9.1.1 promotion target 90/85/70: **{'PASS' if promotion_pass else 'FAIL'}**",
        "",
        "| Group | Baseline | V9.1.1 target |",
        "|---|---:|---:|",
    ]
    promo_by = {item.label: item for item in promotion}
    for item in baseline:
        target = promo_by[item.label]
        lines.append(
            f"| {item.label} | {'PASS' if item.passed else 'FAIL'} | "
            f"{'PASS' if target.passed else 'FAIL'} |"
        )
    if combined is not None:
        lines.append(
            f"| finals_combined (informational) | — | "
            f"{'PASS' if combined.passed else 'FAIL'} |"
        )
    lines.extend(["", "## Competition precision (<0.10 m and <5 deg)", ""])
    for result in promotion:
        import json as _json
        summary = _json.loads(Path(result.summary_path).read_text(encoding="utf-8"))
        lines.append(
            f"- {result.label}: {summary.get('competition_precision_success_rate', 0.0):.1%} "
            f"({summary.get('competition_precision_success_count', 0)}/"
            f"{summary.get('episode_count', 0)})"
        )
    lines.extend(["", "This precision rate is reported separately from the operational 0.22 m mission gate.", "", "## V9.1.1 promotion checks", ""])
    for result in promotion:
        lines.append(f"### {result.label}")
        lines.append("")
        lines.append("| Check | Value | Requirement | Result |")
        lines.append("|---|---:|---:|---:|")
        for check in result.checks:
            value = f"{check.value:.6g}" if isinstance(check.value, float) else str(check.value)
            lines.append(
                f"| {check.name} | {value} | {check.requirement} | "
                f"{'PASS' if check.passed else 'FAIL'} |"
            )
        lines.append("")
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--moderate-easy", type=Path, required=True)
    parser.add_argument("--moderate-nominal", type=Path, required=True)
    parser.add_argument("--finals-easy", type=Path, required=True)
    parser.add_argument("--combined", type=Path)
    parser.add_argument(
        "--output",
        type=Path,
        default=PROJECT_ROOT / "outputs" / "v9_1_1_release_report",
    )
    args = parser.parse_args()

    paths = {
        "moderate_easy": args.moderate_easy,
        "moderate_nominal": args.moderate_nominal,
        "finals_easy": args.finals_easy,
    }
    baseline = [
        qualify_summary_file(
            paths[label], label=label, thresholds=FORMAL_THRESHOLDS[label]
        )
        for label in paths
    ]
    promotion = [
        qualify_summary_file(
            paths[label], label=label, thresholds=V9_1_PROMOTION_THRESHOLDS[label]
        )
        for label in paths
    ]
    combined = None
    if args.combined is not None:
        combined = qualify_summary_file(
            args.combined,
            label="finals_combined",
            thresholds=COMBINED_INFORMATIONAL,
            hard_gate=False,
        )

    baseline_pass = overall_pass(baseline)
    promotion_pass = overall_pass(promotion)
    args.output.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema": "forklift_v9_1_1_release_qualification_v1",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "historical_baseline_pass": baseline_pass,
        "v9_1_1_promotion_pass": promotion_pass,
        "baseline_results": [item.to_dict() for item in baseline],
        "promotion_results": [item.to_dict() for item in promotion],
        "combined_result": None if combined is None else combined.to_dict(),
        "competition_precision": {
            label: {
                "rate": json.loads(paths[label].read_text(encoding="utf-8")).get(
                    "competition_precision_success_rate", 0.0
                ),
                "count": json.loads(paths[label].read_text(encoding="utf-8")).get(
                    "competition_precision_success_count", 0
                ),
                "episodes": json.loads(paths[label].read_text(encoding="utf-8")).get(
                    "episode_count", 0
                ),
            }
            for label in paths
        },
    }
    (args.output / "qualification.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )
    (args.output / "qualification.md").write_text(
        _markdown(baseline, promotion, combined, baseline_pass, promotion_pass),
        encoding="utf-8",
    )

    print(f"V9.1.1 historical 80/70/50 baseline: {'PASS' if baseline_pass else 'FAIL'}")
    print(f"V9.1.1 promotion 90/85/70: {'PASS' if promotion_pass else 'FAIL'}")
    for label, path in paths.items():
        summary = json.loads(path.read_text(encoding="utf-8"))
        print(
            f"  {label} competition <0.10m/<5deg: "
            f"{summary.get('competition_precision_success_count', 0)}/"
            f"{summary.get('episode_count', 0)} = "
            f"{summary.get('competition_precision_success_rate', 0.0):.1%}"
        )
    for result in promotion:
        print(f"  {result.label}: {'PASS' if result.passed else 'FAIL'}")
        for check in result.checks:
            if not check.passed:
                print(f"    FAIL {check.name}: {check.value} ({check.requirement})")
    if combined is not None:
        print(
            f"  finals_combined: {'PASS' if combined.passed else 'FAIL'} "
            "[informational]"
        )
    print(f"report: {args.output.resolve()}")
    return 0 if promotion_pass else 2


if __name__ == "__main__":
    raise SystemExit(main())
