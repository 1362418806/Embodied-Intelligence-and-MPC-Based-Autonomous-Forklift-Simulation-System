"""Import-path smoke tests for V5.2 wrapper scripts."""

from __future__ import annotations

import importlib.util
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def load_wrapper(filename: str):
    path = PROJECT_ROOT / "scripts" / filename
    spec = importlib.util.spec_from_file_location(
        f"_test_{path.stem}",
        path,
    )
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_interactive_wrapper_uses_local_v5_1_script() -> None:
    module = load_wrapper("run_forklift_v5_2.py")
    assert module.BASE_SCRIPT == (
        PROJECT_ROOT / "scripts" / "run_forklift_v5_1.py"
    )
    assert module.DEFAULT_CONFIG == (
        PROJECT_ROOT / "configs" / "vehicle_v5_2.yaml"
    )


def test_batch_wrapper_uses_local_v5_1_script() -> None:
    module = load_wrapper("run_v5_2_batch.py")
    assert module.BASE_SCRIPT == (
        PROJECT_ROOT / "scripts" / "run_v5_1_batch.py"
    )
    assert module.DEFAULT_CONFIG == (
        PROJECT_ROOT / "configs" / "vehicle_v5_2.yaml"
    )
