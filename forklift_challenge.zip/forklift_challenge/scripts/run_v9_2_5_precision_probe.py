"""Run paired V9.2.5 normal/oracle terminal-geometry precision diagnostics."""

from __future__ import annotations

import argparse
from datetime import datetime
import json
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from evaluation.dual_vision_metrics import write_dual_vision_results
from scenarios.randomization import ScenarioSampler
from scripts.run_v9_2_5_batch import DEFAULT_CONFIG, load_config
from simulator.dual_vision_mission_episode import run_vision_mission_episode


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--episodes", type=int, default=10)
    parser.add_argument("--seed", type=int, default=20260810)
    parser.add_argument("--difficulty", choices=ScenarioSampler.difficulties(), default="easy")
    parser.add_argument("--profile", choices=("clean", "moderate", "finals"), default="finals")
    parser.add_argument(
        "--appearance-profile",
        choices=("clean", "moderate", "finals", "combined"),
        default="finals",
    )
    parser.add_argument("--max-time", type=float)
    parser.add_argument("--output", type=Path)
    return parser.parse_args()


def _stage_position(result, stage: str, source: str = "truth"):
    value = result.precision_diagnostics.get("stages", {}).get(stage)
    if not isinstance(value, dict):
        return None
    return value.get(source, {}).get("position_error_m")


def _geometry_precise(result) -> bool:
    return bool(
        result.final_placement_error_m < 0.10
        and abs(result.final_placement_yaw_error_deg) < 5.0
    )


def _classify(normal, oracle) -> str:
    normal_precision = _geometry_precise(normal)
    oracle_precision = _geometry_precise(oracle)
    oracle_release = oracle.precision_diagnostics.get("stages", {}).get("release_command")
    oracle_release_ready = bool(
        isinstance(oracle_release, dict)
        and oracle_release.get("truth_competition_ready", False)
    )
    if normal_precision:
        return "already_competition_precise"
    if oracle_precision:
        return "perception_or_estimation_limited"
    if oracle_release_ready:
        return "release_or_withdrawal_dynamics_limited"
    return "terminal_controller_or_vehicle_geometry_limited"


def main() -> int:
    args = parse_args()
    config = load_config(args.config.resolve())
    sampler = ScenarioSampler(seed=args.seed, difficulty=args.difficulty)
    scenarios = [sampler.sample() for _ in range(args.episodes)]
    output = (
        args.output.resolve()
        if args.output
        else (
            PROJECT_ROOT
            / "outputs"
            / "v9_2_5_precision_probe"
            / f"probe_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{args.profile}_{args.appearance_profile}"
        ).resolve()
    )
    normal_dir = output / "normal"
    oracle_dir = output / "oracle_terminal_geometry"
    normal_results = []
    oracle_results = []
    comparisons = []

    for index, scenario in enumerate(scenarios, 1):
        normal = run_vision_mission_episode(
            config,
            scenario,
            profile_name=args.profile,
            appearance_profile_name=args.appearance_profile,
            max_episode_seconds=args.max_time,
            terminal_oracle_geometry=False,
        )
        oracle = run_vision_mission_episode(
            config,
            scenario,
            profile_name=args.profile,
            appearance_profile_name=args.appearance_profile,
            max_episode_seconds=args.max_time,
            terminal_oracle_geometry=True,
        )
        normal_results.append(normal)
        oracle_results.append(oracle)
        classification = _classify(normal, oracle)
        comparisons.append(
            {
                "scenario_id": scenario.scenario_id,
                "classification": classification,
                "normal": {
                    "success": normal.success,
                    "duration_seconds": normal.duration_seconds,
                    "final_position_error_m": normal.final_placement_error_m,
                    "final_yaw_error_deg": normal.final_placement_yaw_error_deg,
                    "release_truth_position_error_m": _stage_position(normal, "release_command"),
                    "terminal_alignment_seconds": normal.terminal_alignment_seconds,
                },
                "oracle": {
                    "success": oracle.success,
                    "duration_seconds": oracle.duration_seconds,
                    "final_position_error_m": oracle.final_placement_error_m,
                    "final_yaw_error_deg": oracle.final_placement_yaw_error_deg,
                    "release_truth_position_error_m": _stage_position(oracle, "release_command"),
                    "terminal_alignment_seconds": oracle.terminal_alignment_seconds,
                },
            }
        )
        print(
            f"[{index:02d}/{len(scenarios):02d}] {scenario.scenario_id} "
            f"normal={normal.final_placement_error_m:.3f}m/"
            f"{normal.final_placement_yaw_error_deg:.1f}deg "
            f"oracle={oracle.final_placement_error_m:.3f}m/"
            f"{oracle.final_placement_yaw_error_deg:.1f}deg | {classification}"
        )

    normal_summary = write_dual_vision_results(normal_dir, normal_results)
    oracle_summary = write_dual_vision_results(oracle_dir, oracle_results)
    counts: dict[str, int] = {}
    for item in comparisons:
        label = str(item["classification"])
        counts[label] = counts.get(label, 0) + 1
    normal_geometry_precision_rate = (
        sum(_geometry_precise(item) for item in normal_results) / len(normal_results)
        if normal_results else 0.0
    )
    oracle_geometry_precision_rate = (
        sum(_geometry_precise(item) for item in oracle_results) / len(oracle_results)
        if oracle_results else 0.0
    )
    payload = {
        "schema": "forklift_v9_2_5_precision_probe_v1",
        "seed": args.seed,
        "episodes": args.episodes,
        "difficulty": args.difficulty,
        "profile": args.profile,
        "appearance_profile": args.appearance_profile,
        "normal_summary": normal_summary,
        "oracle_summary": oracle_summary,
        "normal_geometry_precision_rate": normal_geometry_precision_rate,
        "oracle_geometry_precision_rate": oracle_geometry_precision_rate,
        "classification_counts": counts,
        "comparisons": comparisons,
    }
    output.mkdir(parents=True, exist_ok=True)
    (output / "precision_probe.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print("\nV9.2.5 precision probe")
    print(
        "  normal competition precision: "
        f"{normal_summary['competition_precision_success_rate']:.1%}"
    )
    print(
        "  oracle competition precision: "
        f"{oracle_summary['competition_precision_success_rate']:.1%}"
    )
    print(
        "  normal/oracle geometry-only precision: "
        f"{normal_geometry_precision_rate:.1%}/"
        f"{oracle_geometry_precision_rate:.1%}"
    )
    for label, count in sorted(counts.items()):
        print(f"  {label}: {count}/{args.episodes}")
    print(f"  report: {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
