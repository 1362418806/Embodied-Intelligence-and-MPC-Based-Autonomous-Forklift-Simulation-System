"""Stable action interface for teleoperation and autonomous algorithms."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class ForkliftAction:
    """High-level actuator request produced by an algorithm.

    The simulator adapter converts ``speed_target`` and ``steering_command``
    into individual wheel commands. Values use SI units and the same sign
    convention as the v3 teleoperation interface.
    """

    speed_target: float
    steering_command: float
    lift_target: float
    emergency_stop: bool = False

    @classmethod
    def stopped(cls, *, lift_target: float) -> "ForkliftAction":
        """Build a zero-motion action while holding the requested fork height."""
        return cls(
            speed_target=0.0,
            steering_command=0.0,
            lift_target=float(lift_target),
            emergency_stop=False,
        )

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable mapping."""
        return asdict(self)
