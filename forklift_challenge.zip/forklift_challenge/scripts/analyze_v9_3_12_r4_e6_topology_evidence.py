"""Analyze V9.3.12-R4-E6 topology-constrained recenter and evidence finalization."""
from __future__ import annotations

import argparse
from collections import Counter
import json
import math
from pathlib import Path


def _time(row: dict) -> float:
    return float((row.get("estimated_observation", {}) or {}).get("sim_time", 0.0))


def _wrap(a: float) -> float:
    return (float(a) + math.pi) % (2.0 * math.pi) - math.pi


def _segment_path_and_yaw(rows: list[dict]) -> tuple[float, float]:
    if len(rows) < 2:
        return 0.0, 0.0
    path = 0.0
    for a, b in zip(rows, rows[1:]):
        pa = (a.get("ground_truth_observation", {}) or {}).get("vehicle_pose_world")
        pb = (b.get("ground_truth_observation", {}) or {}).get("vehicle_pose_world")
        if pa and pb:
            path += math.hypot(float(pb["x"]) - float(pa["x"]), float(pb["y"]) - float(pa["y"]))
    p0 = (rows[0].get("ground_truth_observation", {}) or {}).get("vehicle_pose_world")
    p1 = (rows[-1].get("ground_truth_observation", {}) or {}).get("vehicle_pose_world")
    yaw = 0.0 if not p0 or not p1 else math.degrees(abs(_wrap(float(p1["yaw"]) - float(p0["yaw"]))))
    return float(path), float(yaw)


def _truth_precision(row: dict) -> tuple[float, float] | None:
    gt = row.get("ground_truth_observation", {}) or {}
    pallet = gt.get("pallet_pose_world")
    target = gt.get("placement_pose_world")
    if not pallet or not target:
        return None
    return (
        float(math.hypot(float(pallet["x"]) - float(target["x"]), float(pallet["y"]) - float(target["y"]))),
        float(math.degrees(abs(_wrap(float(target["yaw"]) - float(pallet["yaw"]))))),
    )


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("trace", type=Path)
    ap.add_argument("--output-json", type=Path)
    ap.add_argument("--output-md", type=Path)
    args = ap.parse_args()

    rows = [json.loads(x) for x in args.trace.read_text(encoding="utf-8").splitlines() if x.strip()]
    phases: Counter[str] = Counter()
    phase_rows: dict[str, list[dict]] = {}
    activation_jumps = 0
    last_activation = 0
    first_activation = None
    first_return = None
    first_evidence = None
    first_rollback = None
    active_truth: list[tuple[float, float]] = []

    for row in rows:
        d = row.get("decision", {}) or {}
        phase = str(d.get("placement_position_blocker_recenter_phase", "IDLE"))
        phases[phase] += 1
        phase_rows.setdefault(phase, []).append(row)
        t = _time(row)
        act = int(d.get("placement_position_blocker_recenter_activation_count", 0))
        if act > last_activation:
            activation_jumps += act - last_activation
            if first_activation is None:
                first_activation = t
        last_activation = max(last_activation, act)
        if phase == "RETURN" and first_return is None:
            first_return = t
        if phase == "FINAL_EVIDENCE_HOLD" and first_evidence is None:
            first_evidence = t
        if phase.startswith("ROLLBACK") and first_rollback is None:
            first_rollback = t
        if phase != "IDLE":
            tp = _truth_precision(row)
            if tp is not None:
                active_truth.append(tp)

    last = (rows[-1].get("decision", {}) or {}) if rows else {}
    depart_path, depart_yaw = _segment_path_and_yaw(phase_rows.get("DEPART", []))
    return_path, return_yaw = _segment_path_and_yaw(phase_rows.get("RETURN", []))
    unwind_path, unwind_yaw = _segment_path_and_yaw(phase_rows.get("ROLLBACK_RETURN_UNWIND", []))
    rollback_path, rollback_yaw = _segment_path_and_yaw(phase_rows.get("ROLLBACK", []))
    final_truth = _truth_precision(rows[-1]) if rows else None

    activation = int(last.get("placement_position_blocker_recenter_activation_count", 0))
    topology_candidates = int(last.get("placement_position_blocker_recenter_topology_candidate_count", 0))
    retrace_rejects = int(last.get("placement_position_blocker_recenter_retrace_candidate_reject_count", 0))
    return_candidates = int(last.get("placement_position_blocker_recenter_return_candidate_count", 0))
    live_strict_attempts = int(last.get("placement_position_blocker_recenter_final_live_strict_attempt_count", 0))
    evidence_timeouts = int(last.get("placement_position_blocker_recenter_final_evidence_timeout_count", 0))
    rollback_success = int(last.get("placement_position_blocker_recenter_rollback_success_count", 0))
    rollback_failure = int(last.get("placement_position_blocker_recenter_rollback_failure_count", 0))
    release = int(last.get("placement_release_commit_count", 0))
    strict = bool(last.get("strict_release_certified", False))

    if release > 0:
        diagnosis = "CLOSED_STRICT_WITNESS_RELEASE_REACHED"
    elif rollback_failure > 0:
        diagnosis = "ROLLBACK_FAILED_SAFETY_P0"
    elif evidence_timeouts > 0 and rollback_success > 0:
        diagnosis = "EVIDENCE_LEASE_FAILED_BUT_FAILURE_CLOSED_BY_ROLLBACK"
    elif activation > 0 and topology_candidates == 0:
        diagnosis = "NO_NON_RETRACE_S_CURVE_CANDIDATE"
    elif activation > 0 and int(last.get("placement_position_blocker_recenter_full_pose_return_replan_count", 0)) > 0 and return_candidates == 0:
        diagnosis = "FRESH_MIDPOINT_HAS_NO_SAFE_S_CURVE_RETURN"
    elif activation > 0 and phases.get("FINAL_EVIDENCE_HOLD", 0) > 0 and live_strict_attempts == 0:
        diagnosis = "FINAL_EVIDENCE_NEVER_BECAME_STABLE_ENOUGH_FOR_LIVE_STRICT"
    elif strict:
        diagnosis = "STRICT_REACHED_RELEASE_CHAIN_PENDING"
    elif activation > 0:
        diagnosis = "S_CURVE_EXECUTED_STRICT_NOT_REACHED"
    else:
        diagnosis = "E6_NOT_ACTIVATED"

    result = {
        "trace": str(args.trace),
        "samples": len(rows),
        "diagnosis": diagnosis,
        "phase_frame_counts": dict(phases),
        "activation_counter_jumps": activation_jumps,
        "first_activation_time_s": first_activation,
        "first_return_time_s": first_return,
        "first_final_evidence_time_s": first_evidence,
        "first_rollback_time_s": first_rollback,
        "final_activation_count": activation,
        "full_pose_search_count": int(last.get("placement_position_blocker_recenter_full_pose_search_count", 0)),
        "full_pose_return_replan_count": int(last.get("placement_position_blocker_recenter_full_pose_return_replan_count", 0)),
        "legacy_error_space_search_count": int(last.get("placement_position_blocker_recenter_legacy_error_space_search_count", 0)),
        "retrace_candidate_reject_count": retrace_rejects,
        "topology_candidate_count": topology_candidates,
        "return_candidate_count": return_candidates,
        "mid_rgb_updates": int(last.get("placement_position_blocker_recenter_mid_rgb_updates", 0)),
        "final_rgb_updates": int(last.get("placement_position_blocker_recenter_final_rgb_updates", 0)),
        "final_evidence_consistent_rgb_updates": int(last.get("placement_position_blocker_recenter_final_evidence_consistent_rgb_updates", 0)),
        "final_live_strict_attempt_count": live_strict_attempts,
        "final_evidence_timeout_count": evidence_timeouts,
        "predicted_effective_position_m": float(last.get("placement_position_blocker_recenter_last_predicted_effective_position_m", 0.0)),
        "measured_effective_position_m": float(last.get("placement_position_blocker_recenter_last_measured_effective_position_m", 0.0)),
        "predicted_effective_yaw_deg": float(last.get("placement_position_blocker_recenter_last_predicted_effective_yaw_deg", 0.0)),
        "measured_effective_yaw_deg": float(last.get("placement_position_blocker_recenter_last_measured_effective_yaw_deg", 0.0)),
        "position_to_yaw_handoff_count": int(last.get("placement_position_blocker_recenter_yaw_handoff_count", 0)),
        "rollback_count": int(last.get("placement_position_blocker_recenter_rollback_count", 0)),
        "rollback_success_count": rollback_success,
        "rollback_failure_count": rollback_failure,
        "rollback_reason": str(last.get("placement_position_blocker_recenter_rollback_reason", "")),
        "strict_certified": strict,
        "strict_blocker": str(last.get("strict_release_certification_blocker", "")),
        "release_commit_count": release,
        "release_witness_capture_count": int(last.get("release_witness_capture_count", 0)),
        "diagnostic_truth_depart_vehicle_path_m": depart_path,
        "diagnostic_truth_depart_vehicle_yaw_change_deg": depart_yaw,
        "diagnostic_truth_return_vehicle_path_m": return_path,
        "diagnostic_truth_return_vehicle_yaw_change_deg": return_yaw,
        "diagnostic_truth_return_unwind_vehicle_path_m": unwind_path,
        "diagnostic_truth_return_unwind_vehicle_yaw_change_deg": unwind_yaw,
        "diagnostic_truth_rollback_vehicle_path_m": rollback_path,
        "diagnostic_truth_rollback_vehicle_yaw_change_deg": rollback_yaw,
        "diagnostic_truth_min_position_during_e6_m": min((x[0] for x in active_truth), default=None),
        "diagnostic_truth_max_position_during_e6_m": max((x[0] for x in active_truth), default=None),
        "diagnostic_truth_final_position_m": None if final_truth is None else final_truth[0],
        "diagnostic_truth_final_abs_yaw_deg": None if final_truth is None else final_truth[1],
    }

    print("V9.3.12-R4-E6 topology/evidence analysis")
    for key, value in result.items():
        print(f"  {key}: {value}")
    if args.output_json:
        args.output_json.parent.mkdir(parents=True, exist_ok=True)
        args.output_json.write_text(json.dumps(result, indent=2), encoding="utf-8")
    if args.output_md:
        args.output_md.parent.mkdir(parents=True, exist_ok=True)
        lines = ["# V9.3.12-R4-E6 Topology / Evidence Analysis", ""]
        lines += [f"- **{k}**: `{v}`" for k, v in result.items()]
        args.output_md.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
