"""State-transition tests for the autonomous pickup baseline."""

from __future__ import annotations

import math

from control.docking_controller import DockingController
from interfaces.observation import ForkliftObservation, Pose3D
from task.pickup_state_machine import (
    PickupParameters,
    PickupState,
    PickupStateMachine,
)


def make_pose(
    x: float = 0.0,
    y: float = 0.0,
    z: float = 0.0,
    roll: float = 0.0,
    pitch: float = 0.0,
    yaw: float = 0.0,
) -> Pose3D:
    return Pose3D(x=x, y=y, z=z, roll=roll, pitch=pitch, yaw=yaw)


def make_observation(
    *,
    sim_time: float,
    pallet_x: float,
    pallet_y: float = 0.0,
    pallet_yaw: float = 0.0,
    lift_position: float = 0.04,
    lift_velocity: float = 0.0,
    load_state: str = "GROUND",
    vehicle_x: float = 0.0,
    vehicle_y: float = 0.0,
    pallet_roll: float = 0.0,
) -> ForkliftObservation:
    return ForkliftObservation(
        sim_time=sim_time,
        vehicle_pose_world=make_pose(vehicle_x, vehicle_y, z=0.58),
        vehicle_linear_velocity=(0.0, 0.0, 0.0),
        vehicle_angular_velocity=(0.0, 0.0, 0.0),
        steering_left=0.0,
        steering_right=0.0,
        front_wheel_speed_left=0.0,
        front_wheel_speed_right=0.0,
        lift_position=lift_position,
        lift_velocity=lift_velocity,
        pallet_pose_world=make_pose(
            3.2,
            0.0,
            z=0.1 if load_state.startswith("LIFTED") else 0.0,
            roll=pallet_roll,
        ),
        pallet_pose_in_base=make_pose(
            pallet_x,
            pallet_y,
            yaw=pallet_yaw,
        ),
        placement_pose_in_base=make_pose(5.2, -1.5),
        fork_contact_count=0,
        load_state=load_state,
    )


def parameters() -> PickupParameters:
    return PickupParameters(
        insertion_lift_target=0.04,
        transport_lift_target=0.30,
        pre_approach_distance=2.70,
        insertion_distance=1.55,
        approach_max_speed=0.30,
        align_max_speed=0.14,
        insertion_max_speed=0.10,
        retreat_speed=-0.18,
        retreat_distance=0.75,
        approach_capture_distance=0.30,
        pre_position_tolerance=0.055,
        pre_lateral_tolerance=0.055,
        pre_yaw_tolerance=0.070,
        insertion_position_tolerance=0.045,
        insertion_lateral_tolerance=0.045,
        insertion_yaw_tolerance=0.060,
        lift_position_tolerance=0.055,
        lift_velocity_tolerance=0.015,
        lifted_minimum_fork_height=0.12,
        verify_lift_seconds=0.60,
        maximum_load_tilt=0.175,
        lower_timeout=4.0,
        approach_timeout=18.0,
        align_timeout=10.0,
        insert_timeout=12.0,
        lift_timeout=8.0,
        retreat_timeout=10.0,
    )


def machine() -> PickupStateMachine:
    return PickupStateMachine(
        parameters=parameters(),
        docking_controller=DockingController(
            distance_gain=0.75,
            heading_gain=1.35,
            yaw_gain=0.80,
            maximum_steering=0.30,
            minimum_creep_speed=0.04,
            heading_slowdown_angle=0.55,
        ),
    )


def test_nominal_state_sequence_reaches_done() -> None:
    state_machine = machine()
    state_machine.reset(0.0)

    decision = state_machine.step(
        make_observation(sim_time=0.3, pallet_x=3.2)
    )
    assert decision.state == PickupState.APPROACH

    decision = state_machine.step(
        make_observation(sim_time=0.5, pallet_x=2.70)
    )
    assert decision.state == PickupState.ALIGN

    decision = state_machine.step(
        make_observation(sim_time=0.7, pallet_x=2.70)
    )
    assert decision.state == PickupState.INSERT

    decision = state_machine.step(
        make_observation(sim_time=1.0, pallet_x=1.55)
    )
    assert decision.state == PickupState.LIFT
    assert math.isclose(decision.action.lift_target, 0.30)

    decision = state_machine.step(
        make_observation(
            sim_time=1.5,
            pallet_x=1.55,
            lift_position=0.20,
            load_state="LIFTED",
        )
    )
    assert decision.state == PickupState.VERIFY_LIFT

    decision = state_machine.step(
        make_observation(
            sim_time=2.2,
            pallet_x=1.55,
            lift_position=0.25,
            load_state="LIFTED",
            vehicle_x=1.65,
        )
    )
    assert decision.state == PickupState.RETREAT

    decision = state_machine.step(
        make_observation(
            sim_time=2.4,
            pallet_x=1.55,
            lift_position=0.25,
            load_state="LIFTED",
            vehicle_x=0.80,
        )
    )
    assert decision.state == PickupState.DONE
    assert decision.action.speed_target == 0.0


def test_manual_algorithm_output_is_json_serializable() -> None:
    state_machine = machine()
    decision = state_machine.step(
        make_observation(sim_time=0.0, pallet_x=3.2)
    )
    encoded = decision.to_dict()
    assert encoded["state"] == PickupState.LOWER_FORK.value
    assert "action" in encoded
    assert encoded["action"]["lift_target"] == 0.04


def test_excessive_load_tilt_fails_immediately() -> None:
    state_machine = machine()
    decision = state_machine.step(
        make_observation(
            sim_time=0.1,
            pallet_x=3.2,
            pallet_roll=0.30,
        )
    )
    assert decision.state == PickupState.FAILED
    assert decision.failure_reason is not None
    assert "tilt" in decision.failure_reason


def _advance_to_insert(state_machine: PickupStateMachine) -> None:
    """Advance the pure state machine to INSERT without MuJoCo."""
    state_machine.reset(0.0)
    assert state_machine.step(
        make_observation(sim_time=0.3, pallet_x=3.2)
    ).state == PickupState.APPROACH
    assert state_machine.step(
        make_observation(sim_time=0.5, pallet_x=2.70)
    ).state == PickupState.ALIGN
    assert state_machine.step(
        make_observation(sim_time=0.7, pallet_x=2.70)
    ).state == PickupState.INSERT


def test_insert_completion_wins_over_timeout_on_same_decision_step() -> None:
    """A sampled completion at the timeout boundary must enter LIFT."""
    state_machine = machine()
    _advance_to_insert(state_machine)

    # INSERT began at t=0.7. This observation arrives just after its 12 s
    # timeout, but already satisfies the insertion pose tolerance. The old
    # timeout-first ordering incorrectly returned FAILED here.
    decision = state_machine.step(
        make_observation(sim_time=12.71, pallet_x=1.55)
    )

    assert decision.state == PickupState.LIFT
    assert decision.failure_reason is None
    assert math.isclose(decision.action.lift_target, 0.30)


def test_insert_still_fails_after_timeout_when_pose_is_not_reached() -> None:
    state_machine = machine()
    _advance_to_insert(state_machine)

    decision = state_machine.step(
        make_observation(sim_time=12.71, pallet_x=1.80)
    )

    assert decision.state == PickupState.FAILED
    assert decision.failure_reason is not None
    assert "INSERT" in decision.failure_reason
