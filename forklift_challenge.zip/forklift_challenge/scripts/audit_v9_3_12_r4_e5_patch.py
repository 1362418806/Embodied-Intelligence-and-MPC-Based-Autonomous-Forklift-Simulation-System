"""Static/invariant audit for V9.3.12-R4-E5 full-pose recenter + rollback."""
from __future__ import annotations

import math
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[1]


def check(name: str, ok: bool) -> None:
    print(f"{'PASS' if ok else 'FAIL'} {name}")
    if not ok:
        raise AssertionError(name)


def main() -> int:
    py_files = [
        ROOT / "task" / "pickup_state_machine.py",
        ROOT / "control" / "terminal_micro_primitives.py",
        ROOT / "control" / "terminal_mpc.py",
        ROOT / "evaluation" / "dual_vision_metrics.py",
        ROOT / "simulator" / "dual_vision_mission_episode.py",
        ROOT / "scripts" / "run_v9_3_12_r4_e5_batch.py",
        ROOT / "scripts" / "analyze_v9_3_12_r4_e5_full_pose_rollback.py",
        ROOT / "scripts" / "evaluate_v9_3_12_r4_e5_precision_closure.py",
    ]
    for path in py_files:
        compile(path.read_text(encoding="utf-8"), str(path), "exec")
    check("Python syntax", True)

    cfg = yaml.safe_load((ROOT / "configs" / "vehicle_v9_3_12_r4_e5.yaml").read_text(encoding="utf-8"))
    base = cfg["autonomy"]
    weak = cfg["perception"]["terminal_autonomy_overrides"]["weak_guide"]
    state = (ROOT / "task" / "pickup_state_machine.py").read_text(encoding="utf-8")
    micro = (ROOT / "control" / "terminal_micro_primitives.py").read_text(encoding="utf-8")

    check("E5 weak-guide only", base["placement_position_blocker_recenter_enabled"] == 0.0 and weak["placement_position_blocker_recenter_enabled"] == 1.0)
    check("internal position contract unchanged", weak["placement_strict_release_position_limit_m"] == 0.095)
    check("internal yaw contract unchanged", math.isclose(weak["placement_strict_release_yaw_limit_rad"], math.radians(4.6), rel_tol=1e-9))
    check("terminal budget unchanged", weak["placement_terminal_budget_seconds"] == 90.0)
    check("consensus release authority OFF", weak["placement_certified_basin_consensus_release_authority"] == 0.0)
    check("actuator conditioning retained", 0.17 < weak["placement_position_blocker_recenter_presteer_command_rad"] <= 0.40)
    check("odometry closure retained", weak["placement_position_blocker_recenter_odometry_timeout_scale"] > 1.0)
    check("hard corridor abort retained", weak["placement_position_blocker_recenter_hard_abort_distance_m"] <= 0.40)
    check("full-pose model implemented", "FULL_POSE_RIGID_LOAD" in micro and "_simulate_full_pose_leg" in micro)
    check("runtime supplies rigid load pose", "load_pose_in_base=(" in state and "self._effective_pallet_pose_in_base(observation)" in state)
    check("runtime supplies task target pose", "task_target_pose_in_base=(" in state and "observation.placement_pose_in_base" in state)
    check("runtime supplies certification target pose", "certification_target_pose_in_base=(" in state and "_certification_target_pose_in_base" in state)
    check("POSITION is lexicographic", "_position_ready_yaw_recoverable" in micro)
    check("explicit POSITION-to-YAW handoff present", "_position_blocker_recenter_yaw_handoff_ready = True" in state)
    check("handoff does not forge strict blocker", 'self._strict_release_certification_last_blocker = "YAW"' not in state)
    check("E5 YAW follow-up uses full poses", "full-pose semantics as the POSITION corridor" in state and "class CertificationBasinClosurePlanner" in micro and "FULL_POSE_MODEL = \"FULL_POSE_RIGID_LOAD\"" in micro)
    check("fresh midpoint full-pose return present", "V9.3.12-R4-E5 fresh full-pose RETURN selected" in state)
    midpoint = state[state.index('if self._position_blocker_recenter_phase == "MID_RGB_SETTLE"'):state.index('if self._position_blocker_recenter_phase == "RETURN_PRESTEER"')]
    check("midpoint preview mismatch diagnostic-only", "midpoint_prediction_position_tolerance" not in midpoint and "midpoint_prediction_yaw_tolerance" not in midpoint)
    check("guaranteed departure rollback present", 'self._position_blocker_recenter_phase = "ROLLBACK_PRESTEER"' in state and 'self._position_blocker_recenter_phase == "ROLLBACK"' in state)
    check("rollback retraces with opposite speed", "requested_speed = -float(recenter_plan.departure_speed_mps)" in state)
    check("rollback keeps departure steering", "requested_steering = float(recenter_plan.departure_steering_rad)" in state)
    check("partial return unwind present", '"ROLLBACK_RETURN_UNWIND_PRESTEER"' in state and '"ROLLBACK_RETURN_UNWIND"' in state)
    check("rollback requires fresh RGB verification", '"ROLLBACK_RGB_SETTLE"' in state and "_position_blocker_recenter_rollback_rgb_updates" in state)
    check("release chain not bypassed", "RELEASE_INTENT executed" in state and "ReleaseDecisionSupervisor" in state)
    check("no truth state in recenter planner", "ground_truth" not in micro.lower())

    print("\nV9.3.12-R4-E5 audit PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
