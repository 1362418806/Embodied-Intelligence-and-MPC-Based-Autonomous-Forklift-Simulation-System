"""V9.3.12-R4-D2 terminal carried-load visual reacquisition.

The pickup pocket detector is excellent before insertion, but after the pallet is
lifted the fork camera is frequently occluded by the carried load.  This module
therefore uses the already-rendered *front_rgb* image and the distinctive cargo
box appearance to refine the carried pallet pose relative to the forklift.

Design rules:
- runtime never consumes simulator truth;
- the propagated carried-load belief is only a *prior* for a local image fit;
- one RGB frame can never mutate the observer;
- a 4-frame temporal consensus is required before a measurement is exported;
- exported measurements only correct the carried-load observer.  They never
  authorize release directly;
- R4-D2 uses analytic lift kinematics for the projection-only pallet height and
  occlusion-aware blue support association so mast/backrest occlusion does not
  masquerade as a failed full-silhouette match.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
import copy
import math
import statistics
from typing import Any, Mapping, Sequence

import cv2
import numpy as np

from interfaces.observation import Pose3D
from control.docking_controller import wrap_angle


def _rotation(values: Sequence[Sequence[float]], name: str) -> np.ndarray:
    value = np.asarray(values, dtype=float)
    if value.shape != (3, 3):
        raise ValueError(f"{name} must be 3x3")
    if not np.allclose(value.T @ value, np.eye(3), atol=1e-6):
        raise ValueError(f"{name} must be orthonormal")
    if np.linalg.det(value) < 0.999:
        raise ValueError(f"{name} must be right-handed")
    return value


def _vector(values: Sequence[float], name: str) -> np.ndarray:
    value = np.asarray(values, dtype=float)
    if value.shape != (3,):
        raise ValueError(f"{name} must contain three values")
    return value


@dataclass(frozen=True)
class TerminalLoadReacquisitionProfile:
    enabled: bool
    update_hz: float
    active_states: frozenset[str]
    minimum_frames: int
    minimum_duration_seconds: float
    maximum_stale_seconds: float
    maximum_position_innovation_m: float
    maximum_yaw_innovation_rad: float
    maximum_frame_position_spread_m: float
    maximum_frame_yaw_spread_rad: float
    measurement_position_sigma_m: float
    measurement_yaw_sigma_rad: float
    minimum_confidence: float
    minimum_visual_coverage: float
    maximum_center_error_px: float
    minimum_observed_recall: float
    maximum_top_edge_error_px: float
    minimum_horizontal_iou: float
    support_component_min_recall: float
    minimum_blob_area_px: int
    search_position_radius_m: float
    search_yaw_radius_rad: float
    search_iterations: int
    roi_top_fraction: float
    roi_bottom_fraction: float

    @classmethod
    def from_mapping(cls, values: Mapping[str, Any]) -> "TerminalLoadReacquisitionProfile":
        result = cls(
            enabled=bool(values.get("enabled", False)),
            update_hz=float(values.get("update_hz", 10.0)),
            active_states=frozenset(
                str(item)
                for item in values.get(
                    "active_states",
                    ("PLACE_CORRIDOR", "PLACE_ALIGN", "PLACE_PRECISION"),
                )
            ),
            minimum_frames=int(values.get("minimum_frames", 4)),
            minimum_duration_seconds=float(values.get("minimum_duration_seconds", 0.18)),
            maximum_stale_seconds=float(values.get("maximum_stale_seconds", 0.7)),
            maximum_position_innovation_m=float(values.get("maximum_position_innovation_m", 0.060)),
            maximum_yaw_innovation_rad=math.radians(float(values.get("maximum_yaw_innovation_deg", 4.0))),
            maximum_frame_position_spread_m=float(values.get("maximum_frame_position_spread_m", 0.025)),
            maximum_frame_yaw_spread_rad=math.radians(float(values.get("maximum_frame_yaw_spread_deg", 1.5))),
            measurement_position_sigma_m=float(values.get("measurement_position_sigma_m", 0.018)),
            measurement_yaw_sigma_rad=math.radians(float(values.get("measurement_yaw_sigma_deg", 0.9))),
            minimum_confidence=float(values.get("minimum_confidence", 0.48)),
            minimum_visual_coverage=float(values.get("minimum_visual_coverage", 0.30)),
            maximum_center_error_px=float(values.get("maximum_center_error_px", 42.0)),
            minimum_observed_recall=float(values.get("minimum_observed_recall", 0.75)),
            maximum_top_edge_error_px=float(values.get("maximum_top_edge_error_px", 18.0)),
            minimum_horizontal_iou=float(values.get("minimum_horizontal_iou", 0.70)),
            support_component_min_recall=float(values.get("support_component_min_recall", 0.55)),
            minimum_blob_area_px=int(values.get("minimum_blob_area_px", 80)),
            search_position_radius_m=float(values.get("search_position_radius_m", 0.070)),
            search_yaw_radius_rad=math.radians(float(values.get("search_yaw_radius_deg", 5.0))),
            search_iterations=int(values.get("search_iterations", 5)),
            roi_top_fraction=float(values.get("roi_top_fraction", 0.25)),
            roi_bottom_fraction=float(values.get("roi_bottom_fraction", 0.98)),
        )
        if (
            result.update_hz <= 0.0
            or not result.active_states
            or result.minimum_frames < 3
            or result.minimum_duration_seconds <= 0.0
            or result.maximum_stale_seconds <= 0.0
            or result.maximum_position_innovation_m <= 0.0
            or result.maximum_yaw_innovation_rad <= 0.0
            or result.maximum_frame_position_spread_m <= 0.0
            or result.maximum_frame_yaw_spread_rad <= 0.0
            or result.measurement_position_sigma_m <= 0.0
            or result.measurement_yaw_sigma_rad <= 0.0
            or not 0.0 < result.minimum_confidence <= 1.0
            or not 0.0 <= result.minimum_visual_coverage <= 1.0
            or result.maximum_center_error_px <= 0.0
            or not 0.0 <= result.minimum_observed_recall <= 1.0
            or result.maximum_top_edge_error_px <= 0.0
            or not 0.0 <= result.minimum_horizontal_iou <= 1.0
            or not 0.0 <= result.support_component_min_recall <= 1.0
            or result.minimum_blob_area_px <= 0
            or result.search_position_radius_m <= 0.0
            or result.search_yaw_radius_rad <= 0.0
            or result.search_iterations <= 0
            or not 0.0 <= result.roi_top_fraction < result.roi_bottom_fraction <= 1.0
        ):
            raise ValueError("invalid terminal load reacquisition profile")
        return result


@dataclass(frozen=True)
class TerminalLoadGeometry:
    # Rear face of the carried cargo box, expressed in pallet frame.
    rear_x_m: float
    half_width_m: float
    center_z_m: float
    half_height_m: float

    @classmethod
    def from_mapping(cls, values: Mapping[str, Any]) -> "TerminalLoadGeometry":
        result = cls(
            rear_x_m=float(values.get("rear_x_m", -0.42)),
            half_width_m=float(values.get("half_width_m", 0.42)),
            center_z_m=float(values.get("center_z_m", 0.62)),
            half_height_m=float(values.get("half_height_m", 0.30)),
        )
        if result.half_width_m <= 0.0 or result.half_height_m <= 0.0:
            raise ValueError("invalid terminal load geometry")
        return result

    @property
    def rear_face_points(self) -> np.ndarray:
        # Retained for compatibility with older tests/tools.
        x = self.rear_x_m
        y = self.half_width_m
        z0 = self.center_z_m - self.half_height_m
        z1 = self.center_z_m + self.half_height_m
        return np.asarray(
            [(x, y, z1), (x, -y, z1), (x, -y, z0), (x, y, z0)],
            dtype=np.float64,
        )

    @property
    def box_points(self) -> np.ndarray:
        """All eight cargo-box corners in the pallet-body frame.

        R2 deliberately models the visible silhouette of the *whole* cargo
        box.  The terminal front camera normally sees the top/side faces as
        well as the near face, so fitting a single rear face creates a large
        systematic image-centre error even when the propagated load pose is
        good.
        """
        half_length = abs(float(self.rear_x_m))
        y = float(self.half_width_m)
        z0 = float(self.center_z_m - self.half_height_m)
        z1 = float(self.center_z_m + self.half_height_m)
        return np.asarray(
            [(x, yy, z) for x in (-half_length, half_length)
             for yy in (-y, y) for z in (z0, z1)],
            dtype=np.float64,
        )


@dataclass(frozen=True)
class TerminalLoadReacquisitionDiagnostics:
    requested: bool = False
    detected: bool = False
    raw_accepted: bool = False
    consensus_ready: bool = False
    status: str = "inactive"
    confidence: float = 0.0
    reprojection_proxy_px: float | None = None
    raw_position_innovation_m: float | None = None
    raw_yaw_innovation_deg: float | None = None
    consensus_samples: int = 0
    consensus_position_spread_m: float | None = None
    consensus_yaw_spread_deg: float | None = None
    accepted_update_count: int = 0
    rejected_innovation_count: int = 0
    rejected_spread_count: int = 0
    raw_detection_count: int = 0
    sample_count: int = 0
    maximum_stale_seconds_observed: float = 0.0
    history_append_count: int = 0
    low_confidence_count: int = 0
    visual_gate_rejection_count: int = 0
    buffer_span_seconds: float = 0.0
    last_visual_coverage: float | None = None
    last_observed_recall: float | None = None
    last_top_edge_error_px: float | None = None
    last_horizontal_iou: float | None = None
    last_visual_score: float | None = None
    last_reject_reason: str | None = None
    component_count: int = 0
    selected_component_area_px: int = 0
    selected_prior_center_error_px: float | None = None
    association_selected_rank: int | None = None
    association_best_iou_rank: int | None = None
    association_best_center_rank: int | None = None
    association_selected_iou: float | None = None
    association_best_iou: float | None = None
    association_selected_bbox_px: tuple[int, int, int, int] | None = None
    association_prior_bbox_px: tuple[int, int, int, int] | None = None
    association_fitted_bbox_px: tuple[int, int, int, int] | None = None
    association_support_ranks: tuple[int, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class TerminalLoadReacquisitionFrame:
    pose_in_base: Pose3D | None
    diagnostics: TerminalLoadReacquisitionDiagnostics


class TerminalLoadReacquisitionPipeline:
    """Prior-guided RGB tracker for the carried load's rear cargo face."""

    def __init__(
        self,
        *,
        camera_name: str,
        profile: TerminalLoadReacquisitionProfile,
        geometry: TerminalLoadGeometry,
        image_width: int,
        image_height: int,
        fovy_degrees: float,
        camera_position_in_base: Sequence[float],
        camera_rotation_base_from_cv: Sequence[Sequence[float]],
        hsv_ranges: Sequence[Mapping[str, Sequence[int]]],
        morphology_kernel_px: int = 3,
    ) -> None:
        self.camera_name = str(camera_name)
        self.profile = profile
        self.geometry = geometry
        self.image_width = int(image_width)
        self.image_height = int(image_height)
        self.camera_position = _vector(camera_position_in_base, "camera_position_in_base")
        self.rotation_base_from_cv = _rotation(camera_rotation_base_from_cv, "camera_rotation_base_from_cv")
        self.rotation_cv_from_base = self.rotation_base_from_cv.T
        self.morphology_kernel_px = max(1, int(morphology_kernel_px))
        self.hsv_ranges = [
            (
                np.asarray(item["lower"], dtype=np.uint8),
                np.asarray(item["upper"], dtype=np.uint8),
            )
            for item in hsv_ranges
        ]
        if not self.hsv_ranges:
            raise ValueError("terminal load reacquisition needs at least one HSV range")
        fovy = math.radians(float(fovy_degrees))
        focal = 0.5 * self.image_height / math.tan(0.5 * fovy)
        self.camera_matrix = np.asarray(
            [
                [focal, 0.0, 0.5 * (self.image_width - 1)],
                [0.0, focal, 0.5 * (self.image_height - 1)],
                [0.0, 0.0, 1.0],
            ],
            dtype=np.float64,
        )
        self.reset()

    @classmethod
    def from_config(
        cls,
        config: Mapping[str, Any],
        *,
        profile_name: str,
        image_width: int,
        image_height: int,
    ) -> "TerminalLoadReacquisitionPipeline":
        profiles = config.get("profiles", {})
        if profile_name not in profiles:
            raise KeyError(f"terminal load reacquisition profile missing: {profile_name}")
        detector = config["detector"]
        return cls(
            camera_name=str(config.get("camera_name", "front_rgb")),
            profile=TerminalLoadReacquisitionProfile.from_mapping(profiles[profile_name]),
            geometry=TerminalLoadGeometry.from_mapping(config.get("geometry", {})),
            image_width=image_width,
            image_height=image_height,
            fovy_degrees=float(detector.get("fovy_degrees", 72.0)),
            camera_position_in_base=detector["camera_position_in_base"],
            camera_rotation_base_from_cv=detector["camera_rotation_base_from_cv"],
            hsv_ranges=detector.get(
                "hsv_ranges",
                ({"lower": (92, 65, 40), "upper": (140, 255, 255)},),
            ),
            morphology_kernel_px=int(detector.get("morphology_kernel_px", 3)),
        )

    def reset(self) -> None:
        self._last_sample_time: float | None = None
        self._last_detection_time: float | None = None
        # Optional RGB frame identity supplied by newer simulator callers.
        # Keep it separate from sample cadence: it only prevents a duplicated
        # render from being appended twice to the temporal consensus history.
        self._last_processed_frame_id: Any | None = None
        self.duplicate_frame_count = 0
        self._history: list[tuple[float, Pose3D, float]] = []
        self.sample_count = 0
        self.raw_detection_count = 0
        self.accepted_update_count = 0
        self.rejected_innovation_count = 0
        self.rejected_spread_count = 0
        self.maximum_stale_seconds_observed = 0.0
        self.history_append_count = 0
        self.low_confidence_count = 0
        self.visual_gate_rejection_count = 0
        self.last_visual_coverage: float | None = None
        self.last_observed_recall: float | None = None
        self.last_top_edge_error_px: float | None = None
        self.last_horizontal_iou: float | None = None
        self.last_visual_score: float | None = None
        self.last_reject_reason: str | None = "episode_reset"
        self.last_component_count = 0
        self.last_selected_component_area_px = 0
        self.last_selected_prior_center_error_px: float | None = None
        # R4-D2 keeps the D1 audit but changes only image association / projection
        # geometry. Consensus, observer innovation gates, MPC and release authority
        # remain unchanged.
        self._association_audit: dict[str, Any] = {
            "schema": "v9_3_12_r4_d2_terminal_load_association_v1",
            "status": "reset",
            "components": [],
        }
        self.last_status = "reset"
        self.last_confidence = 0.0
        self.last_reprojection_proxy_px: float | None = None
        self.last_raw_position_innovation_m: float | None = None
        self.last_raw_yaw_innovation_rad: float | None = None
        self.last_consensus_position_spread_m: float | None = None
        self.last_consensus_yaw_spread_rad: float | None = None

    def wants_image(self, *, sim_time: float, controller_state: str, prior_pose_in_base: Pose3D | None) -> bool:
        if not self.profile.enabled or prior_pose_in_base is None:
            return False
        if str(controller_state) not in self.profile.active_states:
            return False
        if self._last_sample_time is None:
            return True
        return float(sim_time) - self._last_sample_time >= 1.0 / self.profile.update_hz

    def _mask(self, rgb: np.ndarray) -> np.ndarray:
        hsv = cv2.cvtColor(np.asarray(rgb, dtype=np.uint8), cv2.COLOR_RGB2HSV)
        mask = np.zeros(hsv.shape[:2], dtype=np.uint8)
        for lower, upper in self.hsv_ranges:
            mask = cv2.bitwise_or(mask, cv2.inRange(hsv, lower, upper))
        top = int(round(self.profile.roi_top_fraction * mask.shape[0]))
        bottom = int(round(self.profile.roi_bottom_fraction * mask.shape[0]))
        mask[:top] = 0
        mask[bottom:] = 0
        if self.morphology_kernel_px > 1:
            kernel = np.ones((self.morphology_kernel_px, self.morphology_kernel_px), dtype=np.uint8)
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        return mask

    @staticmethod
    def _components(mask: np.ndarray, *, minimum_area_px: int) -> list[tuple[np.ndarray, tuple[int, int, int, int], int]]:
        count, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
        result: list[tuple[np.ndarray, tuple[int, int, int, int], int]] = []
        for index in range(1, count):
            area = int(stats[index, cv2.CC_STAT_AREA])
            if area < int(minimum_area_px):
                continue
            x = int(stats[index, cv2.CC_STAT_LEFT])
            y = int(stats[index, cv2.CC_STAT_TOP])
            w = int(stats[index, cv2.CC_STAT_WIDTH])
            h = int(stats[index, cv2.CC_STAT_HEIGHT])
            component = np.where(labels == index, 255, 0).astype(np.uint8)
            result.append((component, (x, y, w, h), area))
        result.sort(key=lambda item: item[2], reverse=True)
        return result

    def _visible_polygon_mask(self, projected: np.ndarray) -> np.ndarray:
        polygon = cv2.convexHull(np.asarray(projected, dtype=np.float32)).reshape(-1, 2)
        mask = np.zeros((self.image_height, self.image_width), dtype=np.uint8)
        cv2.fillConvexPoly(mask, np.rint(polygon).astype(np.int32), 255)
        return mask

    @staticmethod
    def _bbox_from_mask(mask: np.ndarray) -> tuple[int, int, int, int] | None:
        ys, xs = np.nonzero(mask)
        if len(xs) == 0:
            return None
        x0 = int(xs.min())
        y0 = int(ys.min())
        x1 = int(xs.max())
        y1 = int(ys.max())
        return (x0, y0, x1 - x0 + 1, y1 - y0 + 1)

    @staticmethod
    def _bbox_center(bbox: tuple[int, int, int, int]) -> tuple[float, float]:
        x, y, w, h = bbox
        return (float(x) + 0.5 * float(w), float(y) + 0.5 * float(h))

    @staticmethod
    def _horizontal_interval_iou(
        first: tuple[int, int, int, int],
        second: tuple[int, int, int, int],
    ) -> float:
        ax0, _, aw, _ = first
        bx0, _, bw, _ = second
        ax1 = ax0 + aw
        bx1 = bx0 + bw
        overlap = max(0.0, min(float(ax1), float(bx1)) - max(float(ax0), float(bx0)))
        union = max(float(ax1), float(bx1)) - min(float(ax0), float(bx0))
        return 0.0 if union <= 0.0 else float(overlap / union)

    def _select_component(
        self,
        components: Sequence[tuple[np.ndarray, tuple[int, int, int, int], int]],
        *,
        prior: Pose3D,
    ) -> tuple[np.ndarray, tuple[int, int, int, int], int, float] | None:
        """Associate the visible blue support with the carried cargo.

        D1 proved that the ~60 px failure was not a wrong-rank problem:
        selected_rank == best_center_rank == best_iou_rank on every sampled
        frame, while every full IoU was zero. The root cause was a vertically
        displaced projection plus mast/backrest occlusion splitting the cargo
        into two thin blue support components.

        D2 accepts components whose *observed support* is mostly explained by
        the projected cargo polygon and unions them before pose fitting. Small
        unrelated blue marker components naturally remain outside the support.
        """
        projected = self.project_pose(prior)
        audit: dict[str, Any] = {
            "schema": "v9_3_12_r4_d2_terminal_load_association_v1",
            "prior_pose_in_base": {
                "x": float(prior.x), "y": float(prior.y), "z": float(prior.z),
                "roll": float(prior.roll), "pitch": float(prior.pitch),
                "yaw": float(prior.yaw),
            },
            "prior_projection_valid": False,
            "components": [],
            "selected_rank": None,
            "best_iou_rank": None,
            "best_center_rank": None,
            "support_ranks": [],
        }
        self._association_audit = audit
        if projected is None or not np.all(np.isfinite(projected)):
            audit["status"] = "prior_projection_invalid"
            return None

        prior_mask = self._visible_polygon_mask(projected)
        ys, xs = np.nonzero(prior_mask)
        if len(xs) < 5:
            audit["status"] = "prior_projection_empty"
            return None

        prior_cx = float(xs.mean())
        prior_cy = float(ys.mean())
        prior_area = float(len(xs))
        prior_bbox = self._bbox_from_mask(prior_mask)
        if prior_bbox is None:
            audit["status"] = "prior_projection_empty"
            return None
        prior_bbox_center = self._bbox_center(prior_bbox)
        audit.update({
            "prior_projection_valid": True,
            "prior_polygon_px": [[float(v[0]), float(v[1])] for v in projected],
            "prior_bbox_px": list(prior_bbox),
            "prior_center_px": [prior_cx, prior_cy],
            "prior_visible_area_px": int(prior_area),
        })

        legacy_best = None
        legacy_best_cost = float("inf")
        component_audit: list[dict[str, Any]] = []
        support_items: list[tuple[int, np.ndarray, tuple[int, int, int, int], int]] = []

        for rank, (component, bbox, area) in enumerate(components[:12]):
            x, y, w, h = bbox
            cx = x + 0.5 * w
            cy = y + 0.5 * h
            center_error = math.hypot(cx - prior_cx, cy - prior_cy)
            horizontal_center_error = abs(cx - prior_bbox_center[0])
            top_edge_error = abs(float(y) - float(prior_bbox[1]))
            overlap = float(np.count_nonzero((component > 0) & (prior_mask > 0)))
            union = float(np.count_nonzero((component > 0) | (prior_mask > 0)))
            iou = 0.0 if union <= 0.0 else overlap / union
            prior_coverage = 0.0 if prior_area <= 0.0 else overlap / prior_area
            observed_recall = 0.0 if area <= 0 else overlap / float(area)
            horizontal_iou = self._horizontal_interval_iou(bbox, prior_bbox)
            area_ratio_error = abs(math.log(max(1.0, float(area)) / max(1.0, prior_area)))
            legacy_cost = center_error / 70.0 + 0.35 * area_ratio_error + 1.25 * (1.0 - iou)
            support_eligible = bool(
                observed_recall >= self.profile.support_component_min_recall
            )
            item = {
                "rank": int(rank),
                "bbox_px": [int(x), int(y), int(w), int(h)],
                "center_px": [float(cx), float(cy)],
                "area_px": int(area),
                "center_error_to_prior_px": float(center_error),
                "horizontal_center_error_to_prior_px": float(horizontal_center_error),
                "top_edge_error_to_prior_px": float(top_edge_error),
                "overlap_with_prior_px": int(overlap),
                "iou_with_prior": float(iou),
                "horizontal_iou_with_prior": float(horizontal_iou),
                "prior_coverage": float(prior_coverage),
                "observed_recall": float(observed_recall),
                "area_ratio_error": float(area_ratio_error),
                "selection_cost": float(legacy_cost),
                "support_eligible": support_eligible,
            }
            component_audit.append(item)
            if legacy_cost < legacy_best_cost:
                legacy_best_cost = legacy_cost
                legacy_best = (component, bbox, area, float(center_error))
                audit["selected_rank"] = int(rank)
            if support_eligible:
                support_items.append((rank, component, bbox, area))

        audit["components"] = component_audit
        if component_audit:
            best_iou = max(component_audit, key=lambda item: item["iou_with_prior"])
            best_center = min(component_audit, key=lambda item: item["center_error_to_prior_px"])
            audit["best_iou_rank"] = int(best_iou["rank"])
            audit["best_iou"] = float(best_iou["iou_with_prior"])
            audit["best_center_rank"] = int(best_center["rank"])
            audit["best_center_error_px"] = float(best_center["center_error_to_prior_px"])

        if support_items:
            support_mask = np.zeros((self.image_height, self.image_width), dtype=np.uint8)
            support_ranks: list[int] = []
            for rank, component, _, _ in support_items:
                support_mask = cv2.bitwise_or(support_mask, component)
                support_ranks.append(int(rank))
            support_bbox = self._bbox_from_mask(support_mask)
            support_area = int(np.count_nonzero(support_mask))
            if support_bbox is not None and support_area > 0:
                support_center = self._bbox_center(support_bbox)
                horizontal_center_error = abs(
                    float(support_center[0]) - float(prior_bbox_center[0])
                )
                overlap = int(np.count_nonzero((support_mask > 0) & (prior_mask > 0)))
                observed_recall = float(overlap / max(1, support_area))
                union = int(np.count_nonzero((support_mask > 0) | (prior_mask > 0)))
                full_iou = 0.0 if union <= 0 else float(overlap / union)
                horizontal_iou = self._horizontal_interval_iou(support_bbox, prior_bbox)
                top_edge_error = abs(float(support_bbox[1]) - float(prior_bbox[1]))
                audit.update({
                    "support_ranks": support_ranks,
                    "support_bbox_px": list(support_bbox),
                    "support_area_px": support_area,
                    "support_observed_recall": observed_recall,
                    "support_horizontal_iou": horizontal_iou,
                    "support_horizontal_center_error_px": horizontal_center_error,
                    "support_top_edge_error_px": top_edge_error,
                    "status": "support_group_selected",
                })
                audit["selected_rank"] = int(support_ranks[0])
                audit["selected_component"] = {
                    "rank": int(support_ranks[0]),
                    "bbox_px": list(support_bbox),
                    "center_px": [float(support_center[0]), float(support_center[1])],
                    "area_px": support_area,
                    "center_error_to_prior_px": float(horizontal_center_error),
                    "iou_with_prior": full_iou,
                    "observed_recall": observed_recall,
                    "horizontal_iou_with_prior": horizontal_iou,
                    "support_ranks": support_ranks,
                }
                return support_mask, support_bbox, support_area, float(horizontal_center_error)

        # Conservative fallback for diagnosis only. The D2 observed-support gate
        # will reject it unless the corrected cargo projection explains pixels.
        if legacy_best is not None and audit["selected_rank"] is not None:
            selected_item = component_audit[int(audit["selected_rank"])]
            audit["selected_component"] = copy.deepcopy(selected_item)
            audit["status"] = "support_group_missing_fallback_selected"
        else:
            audit["status"] = "component_missing"
        return legacy_best

    def project_pose(self, pose: Pose3D) -> np.ndarray | None:
        c = math.cos(float(pose.yaw))
        s = math.sin(float(pose.yaw))
        points = self.geometry.box_points
        base = np.empty_like(points)
        base[:, 0] = float(pose.x) + c * points[:, 0] - s * points[:, 1]
        base[:, 1] = float(pose.y) + s * points[:, 0] + c * points[:, 1]
        base[:, 2] = float(pose.z) + points[:, 2]
        camera = (self.rotation_cv_from_base @ (base - self.camera_position).T).T
        if np.any(camera[:, 2] <= 0.05):
            return None
        u = self.camera_matrix[0, 0] * camera[:, 0] / camera[:, 2] + self.camera_matrix[0, 2]
        v = self.camera_matrix[1, 1] * camera[:, 1] / camera[:, 2] + self.camera_matrix[1, 2]
        projected = np.stack((u, v), axis=1)
        return cv2.convexHull(projected.astype(np.float32)).reshape(-1, 2).astype(np.float64)

    def _candidate_score(
        self,
        pose: Pose3D,
        *,
        observed_mask: np.ndarray,
        observed_bbox: tuple[int, int, int, int],
        prior: Pose3D,
    ) -> tuple[float, float, float, float, float, float, float] | None:
        """Occlusion-aware score for visible terminal cargo support."""
        projected = self.project_pose(pose)
        if projected is None or not np.all(np.isfinite(projected)):
            return None

        polygon_mask = self._visible_polygon_mask(projected)
        pred_bbox = self._bbox_from_mask(polygon_mask)
        if pred_bbox is None:
            return None
        px, py, pw, ph = pred_bbox
        ox, oy, ow, oh = observed_bbox
        pred_cx = float(px) + 0.5 * float(pw)
        obs_cx = float(ox) + 0.5 * float(ow)
        horizontal_center_error_px = abs(pred_cx - obs_cx)
        top_edge_error_px = abs(float(py) - float(oy))
        width_error = abs(math.log(max(1.0, float(pw)) / max(1.0, float(ow))))
        horizontal_iou = self._horizontal_interval_iou(pred_bbox, observed_bbox)

        pred_area = int(np.count_nonzero(polygon_mask))
        observed_area = int(np.count_nonzero(observed_mask > 0))
        if pred_area <= 4 or observed_area <= 0:
            return None
        overlap = int(np.count_nonzero((polygon_mask > 0) & (observed_mask > 0)))
        observed_recall = float(overlap / observed_area)
        prior_coverage = float(overlap / pred_area)

        prior_position = math.hypot(float(pose.x) - float(prior.x), float(pose.y) - float(prior.y))
        prior_yaw = abs(wrap_angle(float(pose.yaw) - float(prior.yaw)))

        # Do not score vertical centre / full silhouette height: those quantities
        # are systematically destroyed by mast/backrest occlusion. The observed
        # support top edge and horizontal footprint remain stable in D1 evidence.
        visual_score = (
            horizontal_center_error_px / 32.0
            + 0.80 * top_edge_error_px / max(1.0, self.profile.maximum_top_edge_error_px)
            + 0.45 * width_error
            + 1.50 * (1.0 - observed_recall)
            + 0.80 * (1.0 - horizontal_iou)
        )
        regularized_score = (
            visual_score
            + 0.12 * prior_position / self.profile.search_position_radius_m
            + 0.08 * prior_yaw / self.profile.search_yaw_radius_rad
        )
        return (
            float(regularized_score),
            float(visual_score),
            float(horizontal_center_error_px),
            float(observed_recall),
            float(top_edge_error_px),
            float(horizontal_iou),
            float(prior_coverage),
        )

    def _fit_pose(
        self,
        *,
        mask: np.ndarray,
        bbox: tuple[int, int, int, int],
        prior: Pose3D,
    ) -> tuple[Pose3D, float, float, float, float, float, float, float] | None:
        best = prior
        scored = self._candidate_score(best, observed_mask=mask, observed_bbox=bbox, prior=prior)
        if scored is None:
            return None
        (
            best_score,
            best_visual_score,
            best_proxy,
            best_observed_recall,
            best_top_edge_error,
            best_horizontal_iou,
            best_prior_coverage,
        ) = scored

        pos_step = self.profile.search_position_radius_m
        yaw_step = self.profile.search_yaw_radius_rad
        for dx in (-pos_step, -0.5 * pos_step, 0.0, 0.5 * pos_step, pos_step):
            for dy in (-pos_step, -0.5 * pos_step, 0.0, 0.5 * pos_step, pos_step):
                for dyaw in (-yaw_step, -0.5 * yaw_step, 0.0, 0.5 * yaw_step, yaw_step):
                    candidate = Pose3D(
                        float(prior.x) + dx,
                        float(prior.y) + dy,
                        float(prior.z),
                        float(prior.roll),
                        float(prior.pitch),
                        wrap_angle(float(prior.yaw) + dyaw),
                    )
                    value = self._candidate_score(
                        candidate, observed_mask=mask, observed_bbox=bbox, prior=prior
                    )
                    if value is not None and value[0] < best_score:
                        best = candidate
                        (
                            best_score, best_visual_score, best_proxy,
                            best_observed_recall, best_top_edge_error,
                            best_horizontal_iou, best_prior_coverage,
                        ) = value

        pos_step *= 0.5
        yaw_step *= 0.5
        for _ in range(self.profile.search_iterations):
            improved = False
            for axis, delta in (
                ("x", pos_step), ("x", -pos_step),
                ("y", pos_step), ("y", -pos_step),
                ("yaw", yaw_step), ("yaw", -yaw_step),
            ):
                candidate = Pose3D(
                    float(best.x) + (delta if axis == "x" else 0.0),
                    float(best.y) + (delta if axis == "y" else 0.0),
                    float(best.z), float(best.roll), float(best.pitch),
                    wrap_angle(float(best.yaw) + (delta if axis == "yaw" else 0.0)),
                )
                value = self._candidate_score(
                    candidate, observed_mask=mask, observed_bbox=bbox, prior=prior
                )
                if value is not None and value[0] + 1e-9 < best_score:
                    best = candidate
                    (
                        best_score, best_visual_score, best_proxy,
                        best_observed_recall, best_top_edge_error,
                        best_horizontal_iou, best_prior_coverage,
                    ) = value
                    improved = True
            if not improved:
                pos_step *= 0.5
                yaw_step *= 0.5

        confidence = float(max(0.0, min(1.0, math.exp(-0.55 * best_visual_score))))
        return (
            best,
            confidence,
            best_proxy,
            best_observed_recall,
            best_visual_score,
            best_top_edge_error,
            best_horizontal_iou,
            best_prior_coverage,
        )

    def association_audit_snapshot(self) -> dict[str, Any]:
        """Return the latest passive image-association audit record."""
        return copy.deepcopy(self._association_audit)

    def debug_overlay_bgr(self, rgb: np.ndarray) -> np.ndarray:
        """Render a diagnostic overlay without affecting runtime decisions.

        Red polygon   = propagated carried-load prior projection
        Yellow box    = selected blue component
        Cyan boxes    = all other blue components
        Green polygon = fitted pose projection
        Right panel   = HSV blue mask used by the detector
        """
        image = cv2.cvtColor(np.asarray(rgb, dtype=np.uint8), cv2.COLOR_RGB2BGR)
        audit = self._association_audit
        support_ranks = {int(v) for v in audit.get("support_ranks", [])}
        for item in audit.get("components", []):
            x, y, w, h = [int(v) for v in item["bbox_px"]]
            rank = int(item["rank"])
            selected = rank == audit.get("selected_rank")
            support = rank in support_ranks
            color = (0, 255, 255) if support else (255, 255, 0)
            thickness = 3 if selected else (2 if support else 1)
            cv2.rectangle(image, (x, y), (x + w, y + h), color, thickness)
            label = (
                f"C{item['rank']} A={item['area_px']} "
                f"d={item['center_error_to_prior_px']:.1f} "
                f"IoU={item['iou_with_prior']:.3f}"
            )
            cv2.putText(image, label, (x, max(14, y - 4)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.38, color, 1, cv2.LINE_AA)

        prior_polygon = audit.get("prior_polygon_px")
        if prior_polygon:
            pts = np.rint(np.asarray(prior_polygon, dtype=float)).astype(np.int32).reshape(-1, 1, 2)
            cv2.polylines(image, [pts], True, (0, 0, 255), 2, cv2.LINE_AA)
        fitted_polygon = audit.get("fitted_polygon_px")
        if fitted_polygon:
            pts = np.rint(np.asarray(fitted_polygon, dtype=float)).astype(np.int32).reshape(-1, 1, 2)
            cv2.polylines(image, [pts], True, (0, 255, 0), 2, cv2.LINE_AA)

        status = str(audit.get("final_status", audit.get("status", "unknown")))
        selected_rank = audit.get("selected_rank")
        best_iou_rank = audit.get("best_iou_rank")
        best_iou = audit.get("best_iou")
        lines = [
            f"R4-D2 {status}",
            f"support={audit.get('support_ranks', [])} selected=C{selected_rank} bestIoU=C{best_iou_rank} bestIoU={best_iou if best_iou is not None else float('nan'):.3f}",
            f"fit_dx={audit.get('fitted_center_error_px', float('nan')):.1f}px recall={audit.get('fitted_observed_recall', float('nan')):.3f} hIoU={audit.get('fitted_horizontal_iou', float('nan')):.3f}",
        ]
        for idx, text in enumerate(lines):
            cv2.putText(image, text, (8, 18 + idx * 17), cv2.FONT_HERSHEY_SIMPLEX,
                        0.45, (255, 255, 255), 2, cv2.LINE_AA)
            cv2.putText(image, text, (8, 18 + idx * 17), cv2.FONT_HERSHEY_SIMPLEX,
                        0.45, (20, 20, 20), 1, cv2.LINE_AA)

        mask = self._mask(rgb)
        mask_bgr = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)
        cv2.putText(mask_bgr, "HSV blue mask", (8, 20), cv2.FONT_HERSHEY_SIMPLEX,
                    0.5, (255, 255, 255), 1, cv2.LINE_AA)
        return np.concatenate((image, mask_bgr), axis=1)

    @staticmethod
    def _circular_mean(values: Sequence[float]) -> float:
        return math.atan2(sum(math.sin(v) for v in values), sum(math.cos(v) for v in values))

    def _consensus(self, now: float) -> tuple[Pose3D, float, float] | None:
        cutoff = float(now) - self.profile.maximum_stale_seconds
        self._history = [item for item in self._history if item[0] >= cutoff]
        if len(self._history) < self.profile.minimum_frames:
            return None
        samples = self._history[-max(self.profile.minimum_frames, 8):]
        if samples[-1][0] - samples[0][0] < self.profile.minimum_duration_seconds:
            return None
        xs = [float(item[1].x) for item in samples]
        ys = [float(item[1].y) for item in samples]
        yaws = [float(item[1].yaw) for item in samples]
        x = statistics.median(xs)
        y = statistics.median(ys)
        yaw = self._circular_mean(yaws)
        pos_spread = math.hypot(
            statistics.pstdev(xs) if len(xs) > 1 else 0.0,
            statistics.pstdev(ys) if len(ys) > 1 else 0.0,
        )
        yaw_deltas = [wrap_angle(value - yaw) for value in yaws]
        yaw_spread = statistics.pstdev(yaw_deltas) if len(yaw_deltas) > 1 else 0.0
        self.last_consensus_position_spread_m = float(pos_spread)
        self.last_consensus_yaw_spread_rad = float(yaw_spread)
        if (
            pos_spread > self.profile.maximum_frame_position_spread_m
            or yaw_spread > self.profile.maximum_frame_yaw_spread_rad
        ):
            self.rejected_spread_count += 1
            return None
        last = samples[-1][1]
        return (
            Pose3D(x, y, float(last.z), float(last.roll), float(last.pitch), yaw),
            float(pos_spread),
            float(yaw_spread),
        )

    def step(
        self,
        *,
        rgb: np.ndarray | None,
        sim_time: float,
        controller_state: str,
        prior_pose_in_base: Pose3D | None,
        frame_id: Any | None = None,
    ) -> TerminalLoadReacquisitionFrame:
        now = float(sim_time)
        active = bool(
            self.profile.enabled
            and str(controller_state) in self.profile.active_states
            and prior_pose_in_base is not None
        )
        requested = active and self.wants_image(
            sim_time=now,
            controller_state=controller_state,
            prior_pose_in_base=prior_pose_in_base,
        )
        detected = False
        raw_accepted = False
        consensus_ready = False
        output: Pose3D | None = None
        status = "inactive" if not active else "waiting"

        if requested:
            self._last_sample_time = now
            self.sample_count += 1
            duplicate_frame = bool(
                frame_id is not None
                and self._last_processed_frame_id is not None
                and frame_id == self._last_processed_frame_id
            )
            if rgb is None:
                status = "image_missing"
            elif duplicate_frame:
                # Newer simulator versions pass frame_id explicitly.  Do not
                # count/re-fit/re-append the same rendered RGB frame twice;
                # otherwise a duplicated render could manufacture the 4-frame
                # temporal consensus without four independent observations.
                self.duplicate_frame_count += 1
                self.last_reject_reason = "duplicate_frame"
                status = "duplicate_frame"
            else:
                if frame_id is not None:
                    self._last_processed_frame_id = frame_id
                components = self._components(
                    self._mask(rgb), minimum_area_px=self.profile.minimum_blob_area_px
                )
                self.last_component_count = len(components)
                selected = self._select_component(components, prior=prior_pose_in_base) if components else None
                if selected is None:
                    status = "cargo_blob_missing"
                    self.last_reject_reason = "cargo_blob_missing"
                else:
                    mask, bbox, area, prior_center_error = selected
                    self.last_selected_component_area_px = int(area)
                    self.last_selected_prior_center_error_px = float(prior_center_error)
                    fitted = self._fit_pose(mask=mask, bbox=bbox, prior=prior_pose_in_base)
                    if fitted is None:
                        status = "fit_failed"
                    else:
                        (
                            measured,
                            confidence,
                            proxy,
                            observed_recall,
                            visual_score,
                            top_edge_error_px,
                            horizontal_iou,
                            prior_coverage,
                        ) = fitted
                        fitted_projected = self.project_pose(measured)
                        fitted_bbox = None
                        if fitted_projected is not None and np.all(np.isfinite(fitted_projected)):
                            fitted_mask = self._visible_polygon_mask(fitted_projected)
                            fitted_bbox = self._bbox_from_mask(fitted_mask)
                            self._association_audit["fitted_polygon_px"] = [
                                [float(v[0]), float(v[1])] for v in fitted_projected
                            ]
                            self._association_audit["fitted_bbox_px"] = (
                                None if fitted_bbox is None else list(fitted_bbox)
                            )
                        self._association_audit.update({
                            "fitted_pose_in_base": {
                                "x": float(measured.x), "y": float(measured.y),
                                "z": float(measured.z), "roll": float(measured.roll),
                                "pitch": float(measured.pitch), "yaw": float(measured.yaw),
                            },
                            "fitted_confidence": float(confidence),
                            "fitted_center_error_px": float(proxy),
                            "fitted_observed_recall": float(observed_recall),
                            "fitted_top_edge_error_px": float(top_edge_error_px),
                            "fitted_horizontal_iou": float(horizontal_iou),
                            "fitted_prior_coverage": float(prior_coverage),
                            "fitted_visual_score": float(visual_score),
                        })
                        detected = True
                        self.raw_detection_count += 1
                        self.last_confidence = float(confidence)
                        self.last_reprojection_proxy_px = float(proxy)
                        self.last_visual_coverage = float(prior_coverage)
                        self.last_observed_recall = float(observed_recall)
                        self.last_top_edge_error_px = float(top_edge_error_px)
                        self.last_horizontal_iou = float(horizontal_iou)
                        self.last_visual_score = float(visual_score)
                        position_innovation = math.hypot(
                            float(measured.x) - float(prior_pose_in_base.x),
                            float(measured.y) - float(prior_pose_in_base.y),
                        )
                        yaw_innovation = abs(wrap_angle(float(measured.yaw) - float(prior_pose_in_base.yaw)))
                        self.last_raw_position_innovation_m = float(position_innovation)
                        self.last_raw_yaw_innovation_rad = float(yaw_innovation)
                        if (
                            proxy > self.profile.maximum_center_error_px
                            or observed_recall < self.profile.minimum_observed_recall
                            or top_edge_error_px > self.profile.maximum_top_edge_error_px
                            or horizontal_iou < self.profile.minimum_horizontal_iou
                        ):
                            self.visual_gate_rejection_count += 1
                            self.last_reject_reason = "visual_association_gate"
                            status = "visual_gate_rejected"
                        elif confidence < self.profile.minimum_confidence:
                            self.low_confidence_count += 1
                            self.last_reject_reason = "low_confidence"
                            status = "low_confidence"
                        elif (
                            position_innovation > self.profile.maximum_position_innovation_m
                            or yaw_innovation > self.profile.maximum_yaw_innovation_rad
                        ):
                            self.rejected_innovation_count += 1
                            self.last_reject_reason = "innovation_gate"
                            status = "innovation_rejected"
                        else:
                            raw_accepted = True
                            self._last_detection_time = now
                            self._history.append((now, measured, confidence))
                            self.history_append_count += 1
                            self.last_reject_reason = None
                            status = "raw_accepted"

        self._association_audit["final_status"] = status
        self._association_audit["sim_time"] = now
        self._association_audit["controller_state"] = str(controller_state)
        self._association_audit["requested"] = bool(requested)
        self._association_audit["detected"] = bool(detected)
        self._association_audit["raw_accepted"] = bool(raw_accepted)

        consensus = self._consensus(now) if active else None
        # Export at most one observer measurement per newly accepted RGB frame.
        # Replaying an old consensus at simulator frame-rate would falsely
        # contract the carried-load covariance without new visual evidence.
        if consensus is not None and raw_accepted:
            output = consensus[0]
            consensus_ready = True
            self.accepted_update_count += 1
            status = "consensus_ready"

        if self._last_detection_time is not None:
            stale = max(0.0, now - self._last_detection_time)
            self.maximum_stale_seconds_observed = max(self.maximum_stale_seconds_observed, stale)

        return TerminalLoadReacquisitionFrame(
            pose_in_base=output,
            diagnostics=TerminalLoadReacquisitionDiagnostics(
                requested=requested,
                detected=detected,
                raw_accepted=raw_accepted,
                consensus_ready=consensus_ready,
                status=status,
                confidence=float(self.last_confidence),
                reprojection_proxy_px=self.last_reprojection_proxy_px,
                raw_position_innovation_m=self.last_raw_position_innovation_m,
                raw_yaw_innovation_deg=(
                    None if self.last_raw_yaw_innovation_rad is None
                    else math.degrees(self.last_raw_yaw_innovation_rad)
                ),
                consensus_samples=len(self._history),
                consensus_position_spread_m=self.last_consensus_position_spread_m,
                consensus_yaw_spread_deg=(
                    None if self.last_consensus_yaw_spread_rad is None
                    else math.degrees(self.last_consensus_yaw_spread_rad)
                ),
                accepted_update_count=self.accepted_update_count,
                rejected_innovation_count=self.rejected_innovation_count,
                rejected_spread_count=self.rejected_spread_count,
                raw_detection_count=self.raw_detection_count,
                sample_count=self.sample_count,
                maximum_stale_seconds_observed=float(self.maximum_stale_seconds_observed),
                history_append_count=self.history_append_count,
                low_confidence_count=self.low_confidence_count,
                visual_gate_rejection_count=self.visual_gate_rejection_count,
                buffer_span_seconds=(
                    0.0 if len(self._history) < 2
                    else max(0.0, float(self._history[-1][0] - self._history[0][0]))
                ),
                last_visual_coverage=self.last_visual_coverage,
                last_observed_recall=self.last_observed_recall,
                last_top_edge_error_px=self.last_top_edge_error_px,
                last_horizontal_iou=self.last_horizontal_iou,
                last_visual_score=self.last_visual_score,
                last_reject_reason=self.last_reject_reason,
                component_count=int(self.last_component_count),
                selected_component_area_px=int(self.last_selected_component_area_px),
                selected_prior_center_error_px=self.last_selected_prior_center_error_px,
                association_selected_rank=self._association_audit.get("selected_rank"),
                association_best_iou_rank=self._association_audit.get("best_iou_rank"),
                association_best_center_rank=self._association_audit.get("best_center_rank"),
                association_selected_iou=(
                    None if self._association_audit.get("selected_component") is None
                    else float(self._association_audit["selected_component"]["iou_with_prior"])
                ),
                association_best_iou=(
                    None if self._association_audit.get("best_iou") is None
                    else float(self._association_audit["best_iou"])
                ),
                association_selected_bbox_px=(
                    None if self._association_audit.get("selected_component") is None
                    else tuple(int(v) for v in self._association_audit["selected_component"]["bbox_px"])
                ),
                association_prior_bbox_px=(
                    None if self._association_audit.get("prior_bbox_px") is None
                    else tuple(int(v) for v in self._association_audit["prior_bbox_px"])
                ),
                association_fitted_bbox_px=(
                    None if self._association_audit.get("fitted_bbox_px") is None
                    else tuple(int(v) for v in self._association_audit["fitted_bbox_px"])
                ),
                association_support_ranks=tuple(
                    int(v) for v in self._association_audit.get("support_ranks", [])
                ),
            ),
        )
