"""Static audit for the non-algorithmic S2.1 delivery-hardening overlay."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import py_compile
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "version_docs" / "V9_3_12_R4_F4_S2_1"


def check(name: str, condition: bool) -> None:
    print(f"{'PASS' if condition else 'FAIL'} {name}")
    if not condition:
        raise AssertionError(name)


def main() -> int:
    tools = (
        "scripts/analyze_v9_3_12_r4_f4_s2_conflict_guard.py",
        "scripts/evaluate_v9_3_12_r4_f4_s2_freeze.py",
        "scripts/run_v9_3_12_r4_f4_s2_1_delivery_audit.py",
        "scripts/audit_v9_3_12_r4_f4_s2_1_delivery.py",
    )
    for rel in tools:
        py_compile.compile(str(ROOT / rel), doraise=True)
        check(f"compile:{rel}", True)
    for rel in tools[:3]:
        result = subprocess.run(
            [sys.executable, str(ROOT / rel), "--help"],
            cwd=ROOT.parent,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
        )
        check(f"direct CLI from outside project:{rel}", result.returncode == 0)

    manifest = json.loads((DOCS / "DIRECT_OVERLAY_MANIFEST.json").read_text(encoding="utf-8"))
    check("manifest version", manifest.get("version") == "V9.3.12-R4-F4-S2.1")
    check("algorithm behavior unchanged", manifest.get("algorithm_behavior_changed") is False)
    for item in manifest["files"]:
        path = ROOT / item["path"]
        check(f"manifest file exists:{item['path']}", path.is_file())
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        check(f"manifest sha256:{item['path']}", digest == item["sha256"])
    print("V9.3.12-R4-F4-S2.1 delivery audit: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
