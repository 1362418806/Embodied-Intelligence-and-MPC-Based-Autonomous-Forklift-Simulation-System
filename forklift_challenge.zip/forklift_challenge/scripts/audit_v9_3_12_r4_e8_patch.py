"""Static/invariant audit for V9.3.12-R4-E8 pre-lift carried-load yaw consensus."""
from __future__ import annotations

import math
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[1]


def check(name: str, ok: bool) -> None:
    print(f"{'PASS' if ok else 'FAIL'} {name}")
    if not ok:
        raise AssertionError(name)


def leaves(obj, prefix=""):
    out = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            p = f"{prefix}.{k}" if prefix else str(k)
            out.update(leaves(v, p))
    else:
        out[prefix] = obj
    return out


def main() -> int:
    py_files = [
        ROOT / "perception" / "prelift_yaw_consensus.py",
        ROOT / "perception" / "color_marker_detector.py",
        ROOT / "perception" / "vision_placement.py",
        ROOT / "perception" / "terminal_load_reacquisition.py",
        ROOT / "task" / "pickup_state_machine.py",
        ROOT / "control" / "terminal_micro_primitives.py",
        ROOT / "control" / "terminal_mpc.py",
        ROOT / "evaluation" / "dual_vision_metrics.py",
        ROOT / "simulator" / "dual_vision_mission_episode.py",
        ROOT / "scripts" / "run_v9_3_12_r4_e8_batch.py",
        ROOT / "scripts" / "analyze_v9_3_12_r4_e8_prelift_yaw_consensus.py",
        ROOT / "scripts" / "evaluate_v9_3_12_r4_e8_precision_closure.py",
    ]
    for path in py_files:
        compile(path.read_text(encoding="utf-8"), str(path), "exec")
    check("Python syntax", True)

    e7 = yaml.safe_load((ROOT / "configs" / "vehicle_v9_3_12_r4_e7.yaml").read_text(encoding="utf-8"))
    e8 = yaml.safe_load((ROOT / "configs" / "vehicle_v9_3_12_r4_e8.yaml").read_text(encoding="utf-8"))
    weak = e8["perception"]["terminal_autonomy_overrides"]["weak_guide"]
    vision = e8["vision"]["profiles"]["weak_guide"]

    check("E8 pre-lift yaw consensus enabled", weak["placement_carried_prelift_yaw_consensus_enabled"] == 1.0)
    check("E7 centre-yaw witness disabled", not bool(vision["center_yaw_witness_enabled"]))
    check("quality min confidence >=0.82", weak["placement_carried_prelift_yaw_consensus_min_confidence"] >= 0.82)
    check("quality reprojection <=2px", weak["placement_carried_prelift_yaw_consensus_max_reprojection_error_px"] <= 2.0)
    check("at least 5 independent samples", int(weak["placement_carried_prelift_yaw_consensus_min_samples"]) >= 5)
    check("consensus spread <=0.35deg", weak["placement_carried_prelift_yaw_consensus_max_spread_rad"] <= math.radians(0.35) + 1e-12)
    check("consensus age bounded", weak["placement_carried_prelift_yaw_consensus_max_age_seconds"] <= 3.2)

    # E8 config must differ from E7 only by disabling the falsified E7 witness
    # and adding the new pre-lift consensus settings.
    a, b = leaves(e7), leaves(e8)
    changed = {k for k in set(a) | set(b) if a.get(k, '<MISSING>') != b.get(k, '<MISSING>')}
    expected = {
        "vision.profiles.weak_guide.center_yaw_witness_enabled",
        "perception.terminal_autonomy_overrides.weak_guide.placement_carried_prelift_yaw_consensus_enabled",
        "perception.terminal_autonomy_overrides.weak_guide.placement_carried_prelift_yaw_consensus_window_seconds",
        "perception.terminal_autonomy_overrides.weak_guide.placement_carried_prelift_yaw_consensus_min_samples",
        "perception.terminal_autonomy_overrides.weak_guide.placement_carried_prelift_yaw_consensus_min_confidence",
        "perception.terminal_autonomy_overrides.weak_guide.placement_carried_prelift_yaw_consensus_max_reprojection_error_px",
        "perception.terminal_autonomy_overrides.weak_guide.placement_carried_prelift_yaw_consensus_max_spread_rad",
        "perception.terminal_autonomy_overrides.weak_guide.placement_carried_prelift_yaw_consensus_max_age_seconds",
    }
    check("E7->E8 config delta is intentionally narrow", changed == expected)

    check("internal position contract unchanged", weak["placement_strict_release_position_limit_m"] == 0.095)
    check("internal yaw contract unchanged", math.isclose(weak["placement_strict_release_yaw_limit_rad"], math.radians(4.6), rel_tol=1e-9))
    check("terminal budget unchanged", weak["placement_terminal_budget_seconds"] == 90.0)
    check("consensus release authority OFF", weak["placement_certified_basin_consensus_release_authority"] == 0.0)

    module = (ROOT / "perception" / "prelift_yaw_consensus.py").read_text(encoding="utf-8").lower()
    state = (ROOT / "task" / "pickup_state_machine.py").read_text(encoding="utf-8").lower()
    check("measurement timestamps de-duplicated", "duplicate_count" in module and "_last_measurement_time" in module)
    check("only yaw replaces legacy seed", "prelift_yaw_consensus" in state and "x=float(cached_world_seed.x)" in state and "yaw=float(snap.world_yaw_rad)" in state)
    check("no GT in new consensus module", "ground_truth" not in module)
    check("no fixed historical yaw compensation", "-1.3" not in module and "historical_offset" not in module and "yaw_bias" not in module)
    check("release chain retained", "releasedecisionsupervisor" in state and "release_intent executed" in state)

    print("\nV9.3.12-R4-E8 audit PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
