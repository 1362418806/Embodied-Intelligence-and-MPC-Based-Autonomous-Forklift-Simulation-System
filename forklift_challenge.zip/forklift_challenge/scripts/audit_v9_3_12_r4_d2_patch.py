"""Static audit for V9.3.12-R4-D2 kinematic-Z + occlusion-aware reacquisition."""
from __future__ import annotations

import ast
from pathlib import Path
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]
FILES = [
    ROOT / "perception" / "terminal_load_reacquisition.py",
    ROOT / "simulator" / "dual_vision_mission_episode.py",
    ROOT / "scripts" / "run_v9_3_12_r4_d2_batch.py",
]


def check(name: str, ok: bool) -> bool:
    print(f"{name:<58} {'PASS' if ok else 'FAIL'}")
    return ok


def main() -> int:
    ok = True
    for path in FILES:
        try:
            ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
            valid = True
        except Exception as exc:
            print(f"{path}: {exc}")
            valid = False
        ok &= check(f"syntax {path.name}", valid)

    cfg_path = ROOT / "configs" / "vehicle_v9_3_12_r4_d2.yaml"
    cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
    reacq = cfg["terminal_load_reacquisition"]
    weak = reacq["profiles"]["weak_guide"]
    projection = reacq["projection"]

    ok &= check("cargo center is body-origin +0.62 m",
                abs(float(reacq["geometry"]["center_z_m"]) - 0.62) < 1e-9)
    ok &= check("projection mode is lift_kinematic",
                str(projection["mode"]) == "lift_kinematic")
    ok &= check("analytic pallet z offset is -0.605 m",
                abs(float(projection["pallet_body_z_from_lift_offset_m"]) + 0.605) < 1e-9)
    ok &= check("observed-support recall gate = 0.75",
                abs(float(weak["minimum_observed_recall"]) - 0.75) < 1e-9)
    ok &= check("horizontal IoU gate = 0.70",
                abs(float(weak["minimum_horizontal_iou"]) - 0.70) < 1e-9)
    ok &= check("top-edge gate = 18 px",
                abs(float(weak["maximum_top_edge_error_px"]) - 18.0) < 1e-9)
    ok &= check("support component recall = 0.55",
                abs(float(weak["support_component_min_recall"]) - 0.55) < 1e-9)

    # Safety/qualification freeze guards.
    ok &= check("minimum consensus frames remains 4", int(weak["minimum_frames"]) == 4)
    ok &= check("minimum consensus duration remains 0.18 s",
                abs(float(weak["minimum_duration_seconds"]) - 0.18) < 1e-9)
    ok &= check("position innovation remains 0.06 m",
                abs(float(weak["maximum_position_innovation_m"]) - 0.06) < 1e-9)
    ok &= check("yaw innovation remains 4 deg",
                abs(float(weak["maximum_yaw_innovation_deg"]) - 4.0) < 1e-9)

    perception = (ROOT / "perception" / "terminal_load_reacquisition.py").read_text(encoding="utf-8")
    simulator = (ROOT / "simulator" / "dual_vision_mission_episode.py").read_text(encoding="utf-8")
    ok &= check("support-group association implemented", "support_group_selected" in perception)
    ok &= check("observed recall used by gate", "minimum_observed_recall" in perception)
    ok &= check("horizontal IoU used by gate", "minimum_horizontal_iou" in perception)
    ok &= check("full-silhouette coverage no longer gates acceptance",
                "or visual_coverage < self.profile.minimum_visual_coverage" not in perception)
    ok &= check("projection prior uses lift proprioception",
                "frame.observation.lift_position" in simulator)
    ok &= check("projection prior z uses configured analytic offset",
                "terminal_load_projection_z_offset_m" in simulator)
    ok &= check("observer prior is not overwritten before RGB consensus",
                "load_projection_prior = load_prior" in simulator)

    # No direct release authority can originate in the reacquisition module.
    ok &= check("reacquisition module has no release authority",
                "release_authority" not in perception and "release_commit" not in perception)

    print("\nR4-D2 audit", "PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
