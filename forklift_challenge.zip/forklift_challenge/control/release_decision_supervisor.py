"""Bounded-latency terminal release supervisor for V9.3.4.

The supervisor deliberately separates three concerns that were previously
interleaved inside PLACE_PRECISION:

1. SETTLE: stop the chassis and accumulate *one* safety signal -- strict
   release certification -- with hysteretic evidence.
2. INTENT: once enough certified evidence exists, latch a one-shot release
   intent.  Single-frame noise may no longer bounce the controller back to MPC.
3. REARM: if the settle attempt times out or a persistent hard violation occurs,
   hand control back to MPC for a bounded correction interval before allowing a
   new settle attempt.

The class contains no MuJoCo or project-specific dependencies so its temporal
semantics can be regression-tested directly.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ReleaseDecisionSupervisorConfig:
    evidence_seconds: float
    evidence_soft_decay: float
    settle_timeout_seconds: float
    intent_execute_delay_seconds: float
    hard_violation_grace_seconds: float
    rearm_cooldown_seconds: float

    def validate(self) -> None:
        if self.evidence_seconds <= 0.0:
            raise ValueError("release supervisor evidence_seconds must be positive")
        if not 0.0 < self.evidence_soft_decay <= 1.0:
            raise ValueError("release supervisor evidence_soft_decay must be in (0, 1]")
        if self.settle_timeout_seconds <= self.evidence_seconds:
            raise ValueError("release supervisor settle timeout must exceed evidence time")
        if self.intent_execute_delay_seconds < 0.0:
            raise ValueError("release supervisor intent delay must be non-negative")
        if self.hard_violation_grace_seconds <= 0.0:
            raise ValueError("release supervisor hard-violation grace must be positive")
        if self.rearm_cooldown_seconds < 0.0:
            raise ValueError("release supervisor rearm cooldown must be non-negative")


@dataclass(frozen=True)
class ReleaseSupervisorUpdate:
    mode: str
    action: str
    evidence_seconds: float
    settle_elapsed_seconds: float
    intent_elapsed_seconds: float
    certified_now: bool
    hard_safe_now: bool


class ReleaseDecisionSupervisor:
    """Deterministic release-intent state machine with bounded stationary dwell."""

    IDLE = "IDLE"
    SETTLE = "SETTLE"
    INTENT = "INTENT"
    COOLDOWN = "COOLDOWN"

    HOLD = "HOLD"
    EXECUTE = "EXECUTE"
    RESUME_MPC = "RESUME_MPC"
    WAIT = "WAIT"

    def __init__(self, config: ReleaseDecisionSupervisorConfig) -> None:
        config.validate()
        self.config = config
        self.reset()

    def reset(self) -> None:
        self.mode = self.IDLE
        self.evidence_seconds = 0.0
        self._last_update_time: float | None = None
        self._settle_start_time: float | None = None
        self._intent_start_time: float | None = None
        self._hard_violation_since: float | None = None
        self._rearm_not_before = 0.0
        self.settle_count = 0
        self.intent_count = 0
        self.intent_abort_count = 0
        self.settle_timeout_count = 0
        self.mpc_resume_count = 0
        self.rearm_count = 0
        self.total_hold_seconds = 0.0
        self.certified_hold_seconds = 0.0
        self.first_certified_time: float | None = None
        self.last_release_time: float | None = None
        self.last_intent_time: float | None = None

    @property
    def active(self) -> bool:
        return self.mode in (self.SETTLE, self.INTENT)

    def can_arm(self, now: float) -> bool:
        return float(now) >= self._rearm_not_before and self.mode in (self.IDLE, self.COOLDOWN)

    def begin_settle(self, now: float) -> None:
        now = float(now)
        if not self.can_arm(now):
            return
        self.mode = self.SETTLE
        self._settle_start_time = now
        self._intent_start_time = None
        self._hard_violation_since = None
        self._last_update_time = now
        # Keep half of previously earned evidence after a soft timeout.  This is
        # deliberate memory across attempts; hard violations still reset it.
        self.evidence_seconds *= 0.5
        self.settle_count += 1

    def _dt(self, now: float) -> float:
        now = float(now)
        last = self._last_update_time
        self._last_update_time = now
        if last is None:
            return 0.0
        return max(0.0, min(0.20, now - last))

    def _persistent_hard_violation(self, now: float, hard_safe: bool) -> bool:
        now = float(now)
        if hard_safe:
            self._hard_violation_since = None
            return False
        if self._hard_violation_since is None:
            self._hard_violation_since = now
            return False
        return now - self._hard_violation_since >= self.config.hard_violation_grace_seconds

    def _resume_mpc(self, now: float, *, hard_violation: bool, settle_timeout: bool) -> ReleaseSupervisorUpdate:
        now = float(now)
        if hard_violation:
            self.evidence_seconds = 0.0
            if self.mode == self.INTENT:
                self.intent_abort_count += 1
        elif settle_timeout:
            self.evidence_seconds *= 0.5
            self.settle_timeout_count += 1
        self.mode = self.COOLDOWN
        self._settle_start_time = None
        self._intent_start_time = None
        self._hard_violation_since = None
        self._rearm_not_before = now + self.config.rearm_cooldown_seconds
        self.mpc_resume_count += 1
        self.rearm_count += 1
        return ReleaseSupervisorUpdate(
            mode=self.mode,
            action=self.RESUME_MPC,
            evidence_seconds=self.evidence_seconds,
            settle_elapsed_seconds=0.0,
            intent_elapsed_seconds=0.0,
            certified_now=False,
            hard_safe_now=not hard_violation,
        )

    def invalidate_external_evidence(self, now: float) -> ReleaseSupervisorUpdate:
        """Immediately invalidate externally supplied release evidence.

        V9.3.12-R4-F4-S2 uses this when the release-only centre-yaw target
        suffers a discontinuous world-yaw re-anchor.  Unlike the historical
        geometric hard-violation path, this semantic break cannot wait for the
        hard-violation grace because the intent execution delay is shorter.
        Counters and cooldown semantics are preserved through ``_resume_mpc``.
        """
        now = float(now)
        self.evidence_seconds = 0.0
        if self.mode in (self.SETTLE, self.INTENT):
            return self._resume_mpc(
                now,
                hard_violation=True,
                settle_timeout=False,
            )
        self._intent_start_time = None
        self._hard_violation_since = None
        self._last_update_time = now
        return ReleaseSupervisorUpdate(
            mode=self.mode,
            action=self.WAIT,
            evidence_seconds=0.0,
            settle_elapsed_seconds=0.0,
            intent_elapsed_seconds=0.0,
            certified_now=False,
            hard_safe_now=False,
        )

    def revoke_intent(self, now: float) -> ReleaseSupervisorUpdate:
        """Immediately revoke an already-latched intent on external witness drift.

        V9.3.9 keeps the historical hard-violation grace for geometric noise,
        but a certification witness mismatch means the evidence itself is no
        longer the state being executed. That semantic break must not wait
        longer than the intent execution delay.
        """
        now = float(now)
        if self.mode != self.INTENT:
            return ReleaseSupervisorUpdate(
                mode=self.mode,
                action=self.WAIT,
                evidence_seconds=self.evidence_seconds,
                settle_elapsed_seconds=0.0,
                intent_elapsed_seconds=0.0,
                certified_now=False,
                hard_safe_now=False,
            )
        return self._resume_mpc(
            now,
            hard_violation=True,
            settle_timeout=False,
        )

    def update(
        self,
        now: float,
        *,
        certified: bool,
        hard_safe: bool,
        intent_authorized: bool = True,
    ) -> ReleaseSupervisorUpdate:
        now = float(now)
        if self.mode == self.COOLDOWN:
            if now >= self._rearm_not_before:
                self.mode = self.IDLE
            return ReleaseSupervisorUpdate(
                mode=self.mode,
                action=self.WAIT,
                evidence_seconds=self.evidence_seconds,
                settle_elapsed_seconds=0.0,
                intent_elapsed_seconds=0.0,
                certified_now=bool(certified),
                hard_safe_now=bool(hard_safe),
            )
        if self.mode == self.IDLE:
            return ReleaseSupervisorUpdate(
                mode=self.mode,
                action=self.WAIT,
                evidence_seconds=self.evidence_seconds,
                settle_elapsed_seconds=0.0,
                intent_elapsed_seconds=0.0,
                certified_now=bool(certified),
                hard_safe_now=bool(hard_safe),
            )

        dt = self._dt(now)
        self.total_hold_seconds += dt
        if certified:
            if self.first_certified_time is None:
                self.first_certified_time = now
            self.certified_hold_seconds += dt

        if self._persistent_hard_violation(now, bool(hard_safe)):
            return self._resume_mpc(now, hard_violation=True, settle_timeout=False)

        if self.mode == self.SETTLE:
            if certified:
                self.evidence_seconds += dt
            elif hard_safe:
                self.evidence_seconds = max(
                    0.0,
                    self.evidence_seconds - self.config.evidence_soft_decay * dt,
                )
            else:
                self.evidence_seconds = 0.0

            settle_start = now if self._settle_start_time is None else self._settle_start_time
            settle_elapsed = max(0.0, now - settle_start)
            if self.evidence_seconds >= self.config.evidence_seconds and intent_authorized:
                self.mode = self.INTENT
                self._intent_start_time = now
                self.last_intent_time = now
                self.intent_count += 1
                return ReleaseSupervisorUpdate(
                    mode=self.mode,
                    action=self.HOLD,
                    evidence_seconds=self.evidence_seconds,
                    settle_elapsed_seconds=settle_elapsed,
                    intent_elapsed_seconds=0.0,
                    certified_now=bool(certified),
                    hard_safe_now=bool(hard_safe),
                )
            if settle_elapsed >= self.config.settle_timeout_seconds:
                return self._resume_mpc(now, hard_violation=False, settle_timeout=True)
            return ReleaseSupervisorUpdate(
                mode=self.mode,
                action=self.HOLD,
                evidence_seconds=self.evidence_seconds,
                settle_elapsed_seconds=settle_elapsed,
                intent_elapsed_seconds=0.0,
                certified_now=bool(certified),
                hard_safe_now=bool(hard_safe),
            )

        # INTENT is deliberately sticky.  Certification is not re-latched on
        # every frame; only a persistent hard-envelope violation can revoke it.
        intent_start = now if self._intent_start_time is None else self._intent_start_time
        intent_elapsed = max(0.0, now - intent_start)
        if intent_elapsed >= self.config.intent_execute_delay_seconds:
            self.last_release_time = now
            return ReleaseSupervisorUpdate(
                mode=self.INTENT,
                action=self.EXECUTE,
                evidence_seconds=self.evidence_seconds,
                settle_elapsed_seconds=0.0,
                intent_elapsed_seconds=intent_elapsed,
                certified_now=bool(certified),
                hard_safe_now=bool(hard_safe),
            )
        return ReleaseSupervisorUpdate(
            mode=self.INTENT,
            action=self.HOLD,
            evidence_seconds=self.evidence_seconds,
            settle_elapsed_seconds=0.0,
            intent_elapsed_seconds=intent_elapsed,
            certified_now=bool(certified),
            hard_safe_now=bool(hard_safe),
        )

    @property
    def certification_to_release_seconds(self) -> float | None:
        if self.first_certified_time is None or self.last_release_time is None:
            return None
        return max(0.0, self.last_release_time - self.first_certified_time)
