"""Run v5.1.1 batch evaluation with corrected import compatibility."""

from __future__ import annotations

import importlib.util
from pathlib import Path
import sys
from types import ModuleType


PROJECT_ROOT = Path(__file__).resolve().parents[1]
BASE_SCRIPT = PROJECT_ROOT / "scripts" / "run_v5_1_batch.py"
DEFAULT_CONFIG = PROJECT_ROOT / "configs" / "vehicle_v5_1_1.yaml"


def load_base_application() -> ModuleType:
    """Load the exact local v5.1 batch script without package assumptions."""
    if not BASE_SCRIPT.is_file():
        raise FileNotFoundError(f"Base v5.1 batch script does not exist: {BASE_SCRIPT}")

    module_name = "_forklift_run_v5_1_batch_application"
    spec = importlib.util.spec_from_file_location(module_name, BASE_SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Unable to create import specification for: {BASE_SCRIPT}")

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def main() -> int:
    application = load_base_application()
    application.DEFAULT_CONFIG = DEFAULT_CONFIG
    return int(application.main())


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (FileNotFoundError, RuntimeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
