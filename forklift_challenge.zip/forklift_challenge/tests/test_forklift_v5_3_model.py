"""MuJoCo model checks for the V5.3 steering-actuator revision."""

from __future__ import annotations

from pathlib import Path

import pytest


mujoco = pytest.importorskip("mujoco")
PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_v53_model_compiles_and_contains_required_actuators() -> None:
    model_path = (
        PROJECT_ROOT / "assets" / "forklift" / "forklift_v5_3.xml"
    )
    model = mujoco.MjModel.from_xml_path(str(model_path))
    for name in (
        "front_left_drive_velocity",
        "front_right_drive_velocity",
        "rear_left_steer_position",
        "rear_right_steer_position",
        "lift_position",
    ):
        actuator_id = mujoco.mj_name2id(
            model,
            mujoco.mjtObj.mjOBJ_ACTUATOR,
            name,
        )
        assert actuator_id >= 0
