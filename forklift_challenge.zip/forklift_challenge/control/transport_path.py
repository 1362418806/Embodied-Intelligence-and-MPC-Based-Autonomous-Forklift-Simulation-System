"""Smooth forward-only transport path generation and pure-pursuit tracking.

The pickup controller can align to a nearby pallet because the target lies
roughly along the vehicle's current heading. Loaded placement is different:
the desired vehicle pose may require a large lateral lane change while ending
parallel to the placement zone. This module creates a fixed cubic Bezier path
with start/end tangent constraints and tracks it with a bounded pure-pursuit
controller.
"""

from __future__ import annotations

from dataclasses import dataclass
import bisect
import math
from typing import Iterable

from interfaces.action import ForkliftAction
from interfaces.observation import Pose3D
from control.docking_controller import DockingError, clamp, wrap_angle


@dataclass(frozen=True)
class TransportPath:
    """Sampled planar path in world coordinates."""

    points: tuple[tuple[float, float], ...]
    cumulative_lengths: tuple[float, ...]
    start_yaw: float
    goal_yaw: float

    @property
    def total_length(self) -> float:
        return float(self.cumulative_lengths[-1])

    @property
    def goal_xy(self) -> tuple[float, float]:
        return self.points[-1]


@dataclass(frozen=True)
class TransportPathCommand:
    """Pure-pursuit output plus progress telemetry."""

    action: ForkliftAction
    error: DockingError
    progress_index: int
    path_progress: float
    remaining_length: float
    goal_distance: float
    goal_yaw_error: float


def _compose_point(
    origin: Pose3D,
    local_x: float,
    local_y: float,
) -> tuple[float, float]:
    cosine = math.cos(float(origin.yaw))
    sine = math.sin(float(origin.yaw))
    return (
        float(origin.x) + cosine * float(local_x) - sine * float(local_y),
        float(origin.y) + sine * float(local_x) + cosine * float(local_y),
    )


def relative_pose_in_frame(
    target_world: Pose3D,
    frame_world: Pose3D,
) -> Pose3D:
    """Express a world pose in another world pose's local frame."""
    dx = float(target_world.x) - float(frame_world.x)
    dy = float(target_world.y) - float(frame_world.y)
    cosine = math.cos(float(frame_world.yaw))
    sine = math.sin(float(frame_world.yaw))
    return Pose3D(
        x=cosine * dx + sine * dy,
        y=-sine * dx + cosine * dy,
        z=float(target_world.z) - float(frame_world.z),
        roll=0.0,
        pitch=0.0,
        yaw=wrap_angle(float(target_world.yaw) - float(frame_world.yaw)),
    )


def relative_pose_to_world(
    frame_world: Pose3D,
    target_in_frame: Pose3D,
) -> Pose3D:
    """Compose a relative planar pose with a world-frame vehicle pose."""
    x, y = _compose_point(frame_world, target_in_frame.x, target_in_frame.y)
    return Pose3D(
        x=float(x),
        y=float(y),
        z=float(frame_world.z) + float(target_in_frame.z),
        roll=0.0,
        pitch=0.0,
        yaw=wrap_angle(float(frame_world.yaw) + float(target_in_frame.yaw)),
    )


def build_cubic_transport_path(
    start_world: Pose3D,
    goal_world: Pose3D,
    *,
    handle_scale: float,
    sample_count: int,
) -> TransportPath:
    """Build a tangent-constrained cubic Bezier transport path.

    Repositioning should first create enough positive longitudinal runway.
    The curve then performs a gentle S-shaped lane change while respecting the
    current and desired vehicle headings.
    """
    if not 0.15 <= float(handle_scale) <= 0.75:
        raise ValueError("handle_scale must be in [0.15, 0.75]")
    if int(sample_count) < 21:
        raise ValueError("sample_count must be at least 21")

    dx = float(goal_world.x) - float(start_world.x)
    dy = float(goal_world.y) - float(start_world.y)
    chord = math.hypot(dx, dy)
    if chord <= 0.5:
        raise ValueError("transport path chord must exceed 0.5m")

    handle = chord * float(handle_scale)
    p0 = (float(start_world.x), float(start_world.y))
    p1 = _compose_point(start_world, handle, 0.0)
    p3 = (float(goal_world.x), float(goal_world.y))
    p2 = (
        p3[0] - handle * math.cos(float(goal_world.yaw)),
        p3[1] - handle * math.sin(float(goal_world.yaw)),
    )

    points: list[tuple[float, float]] = []
    for index in range(int(sample_count)):
        t = index / float(int(sample_count) - 1)
        one_minus = 1.0 - t
        x = (
            one_minus**3 * p0[0]
            + 3.0 * one_minus**2 * t * p1[0]
            + 3.0 * one_minus * t**2 * p2[0]
            + t**3 * p3[0]
        )
        y = (
            one_minus**3 * p0[1]
            + 3.0 * one_minus**2 * t * p1[1]
            + 3.0 * one_minus * t**2 * p2[1]
            + t**3 * p3[1]
        )
        points.append((float(x), float(y)))

    cumulative = [0.0]
    for previous, current in zip(points, points[1:]):
        cumulative.append(
            cumulative[-1]
            + math.hypot(current[0] - previous[0], current[1] - previous[1])
        )

    return TransportPath(
        points=tuple(points),
        cumulative_lengths=tuple(float(value) for value in cumulative),
        start_yaw=wrap_angle(start_world.yaw),
        goal_yaw=wrap_angle(goal_world.yaw),
    )


def _nearest_progress_index(
    path: TransportPath,
    vehicle_world: Pose3D,
    previous_index: int,
) -> int:
    start = max(0, min(int(previous_index), len(path.points) - 1))
    best_index = start
    best_distance_sq = float("inf")
    # Progress is monotonic. Searching all remaining points is inexpensive for
    # a ~200-point path and avoids local-window failure after a large timestep.
    for index in range(start, len(path.points)):
        point = path.points[index]
        dx = point[0] - float(vehicle_world.x)
        dy = point[1] - float(vehicle_world.y)
        distance_sq = dx * dx + dy * dy
        if distance_sq < best_distance_sq:
            best_distance_sq = distance_sq
            best_index = index
    return best_index


def _signed_cross_track(
    path: TransportPath,
    vehicle_world: Pose3D,
    index: int,
) -> float:
    if index <= 0:
        previous = path.points[0]
        following = path.points[1]
    elif index >= len(path.points) - 1:
        previous = path.points[-2]
        following = path.points[-1]
    else:
        previous = path.points[index - 1]
        following = path.points[index + 1]
    tangent_x = following[0] - previous[0]
    tangent_y = following[1] - previous[1]
    norm = math.hypot(tangent_x, tangent_y)
    if norm <= 1e-9:
        return 0.0
    tangent_x /= norm
    tangent_y /= norm
    offset_x = float(vehicle_world.x) - path.points[index][0]
    offset_y = float(vehicle_world.y) - path.points[index][1]
    return float(tangent_x * offset_y - tangent_y * offset_x)


def track_transport_path(
    path: TransportPath,
    vehicle_world: Pose3D,
    *,
    previous_index: int,
    wheelbase: float,
    lookahead_distance: float,
    maximum_speed: float,
    minimum_speed: float,
    steering_limit: float,
    lift_target: float,
    capture_distance: float,
    goal_yaw_tolerance: float,
    speed_gain: float = 0.24,
    steering_speed_floor: float = 0.32,
    steering_slowdown_gain: float = 0.68,
) -> TransportPathCommand:
    """Track a sampled path with bounded pure pursuit."""
    if wheelbase <= 0.0:
        raise ValueError("wheelbase must be positive")
    if lookahead_distance <= 0.0:
        raise ValueError("lookahead_distance must be positive")
    if maximum_speed <= 0.0:
        raise ValueError("maximum_speed must be positive")
    if not 0.0 <= minimum_speed <= maximum_speed:
        raise ValueError("minimum_speed must be in [0, maximum_speed]")
    if steering_limit <= 0.0:
        raise ValueError("steering_limit must be positive")
    if capture_distance <= 0.0 or goal_yaw_tolerance <= 0.0:
        raise ValueError("capture and yaw tolerances must be positive")
    if speed_gain <= 0.0:
        raise ValueError("speed_gain must be positive")
    if not 0.0 < steering_speed_floor <= 1.0:
        raise ValueError("steering_speed_floor must be in (0, 1]")
    if steering_slowdown_gain < 0.0:
        raise ValueError("steering_slowdown_gain must be non-negative")

    nearest = _nearest_progress_index(path, vehicle_world, previous_index)
    nearest_s = path.cumulative_lengths[nearest]
    target_s = min(path.total_length, nearest_s + float(lookahead_distance))
    target_index = min(
        bisect.bisect_left(path.cumulative_lengths, target_s),
        len(path.points) - 1,
    )
    target = path.points[target_index]

    dx = float(target[0]) - float(vehicle_world.x)
    dy = float(target[1]) - float(vehicle_world.y)
    cosine = math.cos(float(vehicle_world.yaw))
    sine = math.sin(float(vehicle_world.yaw))
    local_x = cosine * dx + sine * dy
    local_y = -sine * dx + cosine * dy
    lookahead_sq = max(local_x * local_x + local_y * local_y, 1e-6)
    curvature = 2.0 * local_y / lookahead_sq
    steering = clamp(
        math.atan(float(wheelbase) * curvature),
        -float(steering_limit),
        float(steering_limit),
    )

    goal_x, goal_y = path.goal_xy
    goal_dx = goal_x - float(vehicle_world.x)
    goal_dy = goal_y - float(vehicle_world.y)
    goal_distance = math.hypot(goal_dx, goal_dy)
    goal_yaw_error = wrap_angle(path.goal_yaw - float(vehicle_world.yaw))
    remaining = max(0.0, path.total_length - nearest_s)
    captured = (
        goal_distance <= float(capture_distance)
        and abs(goal_yaw_error) <= float(goal_yaw_tolerance)
    )

    if captured:
        speed = 0.0
        steering = 0.0
    else:
        speed = min(
            float(maximum_speed),
            max(float(minimum_speed), float(speed_gain) * remaining),
        )
        steering_scale = max(
            float(steering_speed_floor),
            1.0
            - float(steering_slowdown_gain)
            * abs(float(steering))
            / float(steering_limit),
        )
        speed *= steering_scale
        speed = max(min(speed, float(maximum_speed)), float(minimum_speed))

    cross_track = _signed_cross_track(path, vehicle_world, nearest)
    carrot_heading = math.atan2(local_y, max(local_x, 1e-9))
    error = DockingError(
        longitudinal=float(remaining),
        lateral=float(cross_track),
        distance=float(goal_distance),
        heading=wrap_angle(carrot_heading),
        yaw=float(goal_yaw_error),
    )
    return TransportPathCommand(
        action=ForkliftAction(
            speed_target=float(speed),
            steering_command=float(steering),
            lift_target=float(lift_target),
        ),
        error=error,
        progress_index=int(nearest),
        path_progress=(
            1.0
            if path.total_length <= 1e-9
            else clamp(nearest_s / path.total_length, 0.0, 1.0)
        ),
        remaining_length=float(remaining),
        goal_distance=float(goal_distance),
        goal_yaw_error=float(goal_yaw_error),
    )
