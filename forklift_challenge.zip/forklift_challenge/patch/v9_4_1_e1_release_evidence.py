from __future__ import annotations

"""V9.4.1-E1 — Fresh Evidence & Release Calibration.

Patch scope is intentionally narrow:
- certification-side fresh carried-load yaw witness;
- source-conditioned position bias floor;
- bounded evidence hold when the vehicle is already near the release basin.

This module MUST NOT write terminal RGB yaw back into the motion observer/controller.
S2 remains an upstream hard safety block.
"""

from collections import deque
from dataclasses import dataclass, field
import math
from typing import Deque, Dict, Optional, Tuple


PATCH_VERSION = "V9.4.1-E1"
PATCH_SCHEMA = "v9_4_1_e1_release_evidence_v1"


def _wrap_deg(value: float) -> float:
    return (float(value) + 180.0) % 360.0 - 180.0


def _yaw_abs_diff_deg(a: float, b: float) -> float:
    return abs(_wrap_deg(float(a) - float(b)))


def _circular_mean_deg(values: Tuple[float, ...]) -> float:
    if not values:
        raise ValueError("values must not be empty")
    s = sum(math.sin(math.radians(v)) for v in values)
    c = sum(math.cos(math.radians(v)) for v in values)
    return _wrap_deg(math.degrees(math.atan2(s, c)))


@dataclass(frozen=True)
class V941E1Config:
    # Competition limits — E1 never relaxes them.
    strict_position_limit_m: float = 0.10
    strict_yaw_limit_deg: float = 5.0

    # Legacy carried-load yaw may self-authorize release only while truly fresh.
    carried_yaw_release_max_age_s: float = 1.00

    # Release-only yaw witness.
    yaw_witness_window_s: float = 1.20
    yaw_witness_max_age_s: float = 0.35
    yaw_witness_min_samples: int = 5
    yaw_witness_min_confidence: float = 0.75
    yaw_witness_max_reprojection_px: float = 8.0
    yaw_witness_max_spread_deg: float = 1.50
    yaw_witness_margin_deg: float = 0.50

    # Independent release-only position witness.
    position_witness_window_s: float = 1.20
    position_witness_max_age_s: float = 0.35
    position_witness_min_samples: int = 5
    position_witness_min_confidence: float = 0.75
    position_witness_max_spread_m: float = 0.025
    position_witness_margin_m: float = 0.010

    # Systematic bias floor. It is a certification-risk floor, not a new
    # competition threshold and not a motion-controller covariance.
    position_bias_floor_m_by_source: Dict[str, float] = field(default_factory=lambda: {
        "MULTIVIEW": 0.040,
        "CENTER_YAW_ANCHOR": 0.040,
        "MULTIVIEW_CONFLICT_FALLBACK": 0.050,
    })
    default_position_bias_floor_m: float = 0.050

    # Avoid certifying exactly on the mathematical boundary.
    position_release_slack_m: float = 0.005
    yaw_release_slack_deg: float = 0.25

    # Evidence hold is only for a near-basin state. It must not hide true
    # controllability failures such as 12–15 degree terminal yaw tails.
    evidence_hold_position_gate_m: float = 0.12
    evidence_hold_yaw_gate_deg: float = 8.0
    evidence_hold_max_s: float = 1.50
    evidence_hold_cooldown_s: float = 0.75


@dataclass(frozen=True)
class V941E1YawWitness:
    ready: bool
    load_yaw_world_deg: Optional[float] = None
    age_s: Optional[float] = None
    sample_count: int = 0
    spread_deg: Optional[float] = None
    mean_confidence: Optional[float] = None
    mean_reprojection_px: Optional[float] = None
    source: str = "TERMINAL_RGB_RELEASE_ONLY"
    independent_from_motion_yaw: bool = True
    reason: str = "NO_WITNESS"


@dataclass(frozen=True)
class V941E1PositionWitness:
    ready: bool
    position_error_m: Optional[float] = None
    age_s: Optional[float] = None
    sample_count: int = 0
    spread_m: Optional[float] = None
    mean_confidence: Optional[float] = None
    source: str = "TERMINAL_RGB_RELEASE_ONLY"
    independent_from_target_belief: bool = True
    reason: str = "NO_WITNESS"


@dataclass(frozen=True)
class V941E1Input:
    sim_time: float

    # Existing strict-certification values.
    estimated_position_error_m: float
    estimated_yaw_error_deg: float
    target_source: str
    target_position_margin_m: float
    target_yaw_margin_deg: float
    target_yaw_world_deg: Optional[float]
    carried_load_yaw_evidence_stale_s: Optional[float]

    # Existing safety chain. S2 remains a hard block.
    strict_center_yaw_conflict_active: bool = False

    # New release-only evidence. These inputs must be independent of the guarded
    # motion-yaw / target-belief state.
    yaw_witness: Optional[V941E1YawWitness] = None
    position_witness: Optional[V941E1PositionWitness] = None


@dataclass(frozen=True)
class V941E1Decision:
    release_authorized: bool
    position_authorized: bool
    yaw_authorized: bool

    request_yaw_witness: bool
    request_position_witness: bool
    hold_for_evidence: bool

    blocker: str
    position_mode: str
    yaw_mode: str

    position_bias_floor_m: float
    effective_position_error_m: Optional[float]
    effective_yaw_error_deg: Optional[float]

    used_position_witness: bool
    used_yaw_witness: bool


class V941E1YawWitnessAccumulator:
    """Accumulates terminal RGB carried-load yaw for RELEASE ONLY.

    Integration invariant:
      detector measurement -> E1 accumulator -> release certification
    and NOT:
      detector measurement -> carried observer / motion yaw update.
    """

    def __init__(self, cfg: Optional[V941E1Config] = None):
        self.cfg = cfg or V941E1Config()
        self._samples: Deque[Tuple[float, float, float, float]] = deque()

    def reset(self) -> None:
        self._samples.clear()

    def add(
        self,
        sim_time: float,
        measured_load_yaw_world_deg: float,
        confidence: float,
        reprojection_error_px: float,
    ) -> None:
        vals = (sim_time, measured_load_yaw_world_deg, confidence, reprojection_error_px)
        if not all(math.isfinite(float(v)) for v in vals):
            return
        if confidence < self.cfg.yaw_witness_min_confidence:
            return
        if reprojection_error_px > self.cfg.yaw_witness_max_reprojection_px:
            return

        self._samples.append(
            (float(sim_time), _wrap_deg(measured_load_yaw_world_deg), float(confidence), float(reprojection_error_px))
        )
        cutoff = float(sim_time) - self.cfg.yaw_witness_window_s
        while self._samples and self._samples[0][0] < cutoff:
            self._samples.popleft()

    def status(self, sim_time: float) -> V941E1YawWitness:
        cfg = self.cfg
        if len(self._samples) < cfg.yaw_witness_min_samples:
            return V941E1YawWitness(False, sample_count=len(self._samples), reason="INSUFFICIENT_SAMPLES")

        newest_t = self._samples[-1][0]
        age_s = float(sim_time) - newest_t
        if age_s < -1e-6 or age_s > cfg.yaw_witness_max_age_s:
            return V941E1YawWitness(False, age_s=age_s, sample_count=len(self._samples), reason="STALE")

        yaws = tuple(v[1] for v in self._samples)
        centre = _circular_mean_deg(yaws)
        spread = max(_yaw_abs_diff_deg(v, centre) for v in yaws)
        mean_conf = sum(v[2] for v in self._samples) / len(self._samples)
        mean_reproj = sum(v[3] for v in self._samples) / len(self._samples)

        if spread > cfg.yaw_witness_max_spread_deg:
            return V941E1YawWitness(
                False, centre, age_s, len(self._samples), spread, mean_conf, mean_reproj,
                reason="SPREAD",
            )
        return V941E1YawWitness(
            True, centre, age_s, len(self._samples), spread, mean_conf, mean_reproj,
            reason="READY",
        )


class V941E1PositionWitnessAccumulator:
    """Accumulates an independent direct pallet-to-placement position error.

    Do not feed the same filtered target belief that strict certification is
    guarding; that would recreate the "consistent but biased" failure mode.
    """

    def __init__(self, cfg: Optional[V941E1Config] = None):
        self.cfg = cfg or V941E1Config()
        self._samples: Deque[Tuple[float, float, float]] = deque()

    def reset(self) -> None:
        self._samples.clear()

    def add(self, sim_time: float, position_error_m: float, confidence: float) -> None:
        vals = (sim_time, position_error_m, confidence)
        if not all(math.isfinite(float(v)) for v in vals):
            return
        if position_error_m < 0.0 or confidence < self.cfg.position_witness_min_confidence:
            return

        self._samples.append((float(sim_time), float(position_error_m), float(confidence)))
        cutoff = float(sim_time) - self.cfg.position_witness_window_s
        while self._samples and self._samples[0][0] < cutoff:
            self._samples.popleft()

    def status(self, sim_time: float) -> V941E1PositionWitness:
        cfg = self.cfg
        if len(self._samples) < cfg.position_witness_min_samples:
            return V941E1PositionWitness(False, sample_count=len(self._samples), reason="INSUFFICIENT_SAMPLES")

        age_s = float(sim_time) - self._samples[-1][0]
        if age_s < -1e-6 or age_s > cfg.position_witness_max_age_s:
            return V941E1PositionWitness(False, age_s=age_s, sample_count=len(self._samples), reason="STALE")

        values = sorted(v[1] for v in self._samples)
        n = len(values)
        median = values[n // 2] if n % 2 else 0.5 * (values[n // 2 - 1] + values[n // 2])
        spread = max(abs(v - median) for v in values)
        mean_conf = sum(v[2] for v in self._samples) / len(self._samples)

        if spread > cfg.position_witness_max_spread_m:
            return V941E1PositionWitness(
                False, median, age_s, n, spread, mean_conf,
                reason="SPREAD",
            )
        return V941E1PositionWitness(
            True, median, age_s, n, spread, mean_conf,
            reason="READY",
        )


class V941E1ReleaseEvidenceGuard:
    """Certification-only safety/liveness repair for V9.4.1-E1."""

    def __init__(self, cfg: Optional[V941E1Config] = None):
        self.cfg = cfg or V941E1Config()

    def evaluate(self, x: V941E1Input) -> V941E1Decision:
        cfg = self.cfg
        est_pos = abs(float(x.estimated_position_error_m))
        est_yaw = abs(float(x.estimated_yaw_error_deg))
        pos_margin = max(0.0, float(x.target_position_margin_m or 0.0))
        yaw_margin = max(0.0, float(x.target_yaw_margin_deg or 0.0))

        source = str(x.target_source or "UNKNOWN")
        bias_floor = cfg.position_bias_floor_m_by_source.get(source, cfg.default_position_bias_floor_m)

        # ---- Position authority -------------------------------------------------
        # Preserve the legacy strict estimate as a prerequisite. An independent
        # witness may rescue only a risk-floor rejection near the strict boundary;
        # it may not turn a plainly >10 cm legacy estimate into a release.
        legacy_position_inside_strict = est_pos <= cfg.strict_position_limit_m
        legacy_position_risk = est_pos + max(pos_margin, bias_floor)
        legacy_position_robust = (
            legacy_position_inside_strict
            and legacy_position_risk <= (cfg.strict_position_limit_m - cfg.position_release_slack_m)
        )

        pw = x.position_witness
        position_witness_ready = bool(
            pw
            and pw.ready
            and pw.independent_from_target_belief
            and pw.position_error_m is not None
            and pw.age_s is not None
            and pw.age_s <= cfg.position_witness_max_age_s
        )
        position_witness_risk: Optional[float] = None
        position_witness_ok = False
        if position_witness_ready:
            spread = max(0.0, float(pw.spread_m or 0.0))
            position_witness_risk = abs(float(pw.position_error_m)) + max(spread, cfg.position_witness_margin_m)
            position_witness_ok = (
                legacy_position_inside_strict
                and position_witness_risk <= (cfg.strict_position_limit_m - cfg.position_release_slack_m)
            )

        position_authorized = legacy_position_robust or position_witness_ok
        request_position_witness = legacy_position_inside_strict and not legacy_position_robust
        if legacy_position_robust:
            position_mode = "LEGACY_ROBUST"
        elif position_witness_ok:
            position_mode = "FRESH_WITNESS"
        elif not legacy_position_inside_strict:
            position_mode = "OUTSIDE_STRICT"
        else:
            position_mode = "BIAS_FLOOR_BLOCK"

        # ---- Yaw authority ------------------------------------------------------
        stale_s = x.carried_load_yaw_evidence_stale_s
        carried_yaw_fresh = bool(
            stale_s is not None
            and math.isfinite(float(stale_s))
            and 0.0 <= float(stale_s) <= cfg.carried_yaw_release_max_age_s
        )
        legacy_yaw_risk = est_yaw + yaw_margin
        legacy_yaw_ok = carried_yaw_fresh and (
            legacy_yaw_risk <= (cfg.strict_yaw_limit_deg - cfg.yaw_release_slack_deg)
        )

        yw = x.yaw_witness
        yaw_witness_ready = bool(
            yw
            and yw.ready
            and yw.independent_from_motion_yaw
            and yw.load_yaw_world_deg is not None
            and yw.age_s is not None
            and yw.age_s <= cfg.yaw_witness_max_age_s
            and x.target_yaw_world_deg is not None
        )
        yaw_witness_risk: Optional[float] = None
        yaw_witness_ok = False
        if yaw_witness_ready:
            witness_error = _yaw_abs_diff_deg(float(yw.load_yaw_world_deg), float(x.target_yaw_world_deg))
            spread = max(0.0, float(yw.spread_deg or 0.0))
            yaw_witness_risk = witness_error + max(spread, cfg.yaw_witness_margin_deg)
            yaw_witness_ok = yaw_witness_risk <= (cfg.strict_yaw_limit_deg - cfg.yaw_release_slack_deg)

        yaw_authorized = legacy_yaw_ok or yaw_witness_ok
        request_yaw_witness = not legacy_yaw_ok
        if legacy_yaw_ok:
            yaw_mode = "LEGACY_FRESH"
        elif yaw_witness_ok:
            yaw_mode = "FRESH_WITNESS"
        elif carried_yaw_fresh:
            yaw_mode = "STRICT_YAW_BLOCK"
        else:
            yaw_mode = "STALE_YAW_BLOCK"

        # ---- S2 remains upstream/hard ------------------------------------------
        if x.strict_center_yaw_conflict_active:
            return V941E1Decision(
                release_authorized=False,
                position_authorized=position_authorized,
                yaw_authorized=False,
                request_yaw_witness=True,
                request_position_witness=request_position_witness,
                hold_for_evidence=False,
                blocker="S2_CENTER_YAW_CONFLICT",
                position_mode=position_mode,
                yaw_mode="S2_HARD_BLOCK",
                position_bias_floor_m=bias_floor,
                effective_position_error_m=(position_witness_risk if position_witness_ok else legacy_position_risk),
                effective_yaw_error_deg=(yaw_witness_risk if yaw_witness_ok else legacy_yaw_risk),
                used_position_witness=position_witness_ok,
                used_yaw_witness=False,
            )

        release_authorized = position_authorized and yaw_authorized

        # Hold only when current estimates are already close enough that an evidence
        # refresh is plausibly useful. Do not turn a true reachability failure into
        # an evidence-hold loop.
        hold_for_evidence = bool(
            not release_authorized
            and (request_yaw_witness or request_position_witness)
            and est_pos <= cfg.evidence_hold_position_gate_m
            and est_yaw <= cfg.evidence_hold_yaw_gate_deg
        )

        if release_authorized:
            blocker = "NONE"
        elif not position_authorized and not yaw_authorized:
            blocker = "POSITION_AND_YAW_EVIDENCE"
        elif not position_authorized:
            blocker = "POSITION_EVIDENCE"
        else:
            blocker = "YAW_EVIDENCE"

        return V941E1Decision(
            release_authorized=release_authorized,
            position_authorized=position_authorized,
            yaw_authorized=yaw_authorized,
            request_yaw_witness=request_yaw_witness,
            request_position_witness=request_position_witness,
            hold_for_evidence=hold_for_evidence,
            blocker=blocker,
            position_mode=position_mode,
            yaw_mode=yaw_mode,
            position_bias_floor_m=bias_floor,
            effective_position_error_m=(position_witness_risk if position_witness_ok else legacy_position_risk),
            effective_yaw_error_deg=(yaw_witness_risk if yaw_witness_ok else legacy_yaw_risk),
            used_position_witness=position_witness_ok,
            used_yaw_witness=yaw_witness_ok,
        )


class V941E1EvidenceHoldSupervisor:
    """Bounded stop-first hold for collecting release evidence.

    Caller reuses the existing zero-speed/stop-first path. This class does not add
    a new controller mode and does not alter MPC/recenter logic.
    """

    def __init__(self, cfg: Optional[V941E1Config] = None):
        self.cfg = cfg or V941E1Config()
        self._hold_started_s: Optional[float] = None
        self._cooldown_until_s: float = -math.inf

    def reset(self) -> None:
        self._hold_started_s = None
        self._cooldown_until_s = -math.inf

    def update(self, sim_time: float, requested: bool, release_authorized: bool) -> bool:
        now = float(sim_time)
        if release_authorized:
            self._hold_started_s = None
            return False
        if now < self._cooldown_until_s:
            return False
        if not requested:
            self._hold_started_s = None
            return False
        if self._hold_started_s is None:
            self._hold_started_s = now
            return True
        if now - self._hold_started_s <= self.cfg.evidence_hold_max_s:
            return True

        self._hold_started_s = None
        self._cooldown_until_s = now + self.cfg.evidence_hold_cooldown_s
        return False
