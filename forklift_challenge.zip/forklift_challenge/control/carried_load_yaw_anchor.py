"""V9.3.12-R4-F1 quality-aware pre-lift carried-load yaw anchoring.

The pickup marker pose becomes increasingly occluded late in INSERT. The
existing world-frame handoff is correct, but selecting the *last* accepted yaw
allows a low-confidence/high-reprojection frame to overwrite a better recent
estimate. This module keeps a short history of high-quality world-yaw samples
and returns a circular-mean anchor only when the cluster is internally stable.

No truth state, fixed yaw offset, release threshold change, or control action is
used here.
"""

from __future__ import annotations

from dataclasses import dataclass
import math


def wrap_angle(angle: float) -> float:
    return (float(angle) + math.pi) % (2.0 * math.pi) - math.pi


@dataclass(frozen=True)
class LateInsertYawAnchorConfig:
    window_seconds: float
    minimum_samples: int
    minimum_confidence: float
    maximum_reprojection_error_px: float
    maximum_spread_rad: float

    def validate(self) -> None:
        if self.window_seconds <= 0.0:
            raise ValueError("yaw-anchor window must be positive")
        if self.minimum_samples < 2:
            raise ValueError("yaw-anchor minimum_samples must be >= 2")
        if not 0.0 <= self.minimum_confidence <= 1.0:
            raise ValueError("yaw-anchor confidence must be in [0,1]")
        if self.maximum_reprojection_error_px <= 0.0:
            raise ValueError("yaw-anchor reprojection limit must be positive")
        if self.maximum_spread_rad <= 0.0:
            raise ValueError("yaw-anchor spread limit must be positive")


@dataclass(frozen=True)
class YawAnchorSample:
    measurement_time: float
    world_yaw_rad: float
    confidence: float
    reprojection_error_px: float


@dataclass(frozen=True)
class YawAnchorEstimate:
    world_yaw_rad: float
    sample_count: int
    spread_rad: float
    newest_measurement_time: float
    newest_confidence: float
    newest_reprojection_error_px: float


class LateInsertYawAnchor:
    """Short-window quality-gated circular yaw estimator."""

    def __init__(self, config: LateInsertYawAnchorConfig) -> None:
        config.validate()
        self.config = config
        self.reset()

    def reset(self) -> None:
        self._samples: list[YawAnchorSample] = []
        self._last_measurement_time: float | None = None
        self.accepted_sample_count = 0
        self.quality_reject_count = 0
        self.duplicate_reject_count = 0
        self.last_estimate: YawAnchorEstimate | None = None

    def add(
        self,
        *,
        measurement_time: float,
        world_yaw_rad: float,
        confidence: float | None,
        reprojection_error_px: float | None,
    ) -> YawAnchorEstimate | None:
        t = float(measurement_time)
        if self._last_measurement_time is not None and t <= self._last_measurement_time + 1e-9:
            self.duplicate_reject_count += 1
            return self.last_estimate
        self._last_measurement_time = t

        conf = -math.inf if confidence is None else float(confidence)
        reproj = math.inf if reprojection_error_px is None else float(reprojection_error_px)
        if (
            not math.isfinite(conf)
            or not math.isfinite(reproj)
            or conf < self.config.minimum_confidence
            or reproj > self.config.maximum_reprojection_error_px
        ):
            self.quality_reject_count += 1
            self._prune(t)
            self.last_estimate = self._estimate()
            return self.last_estimate

        self._samples.append(
            YawAnchorSample(
                measurement_time=t,
                world_yaw_rad=wrap_angle(world_yaw_rad),
                confidence=conf,
                reprojection_error_px=reproj,
            )
        )
        self.accepted_sample_count += 1
        self._prune(t)
        self.last_estimate = self._estimate()
        return self.last_estimate

    def _prune(self, newest_time: float) -> None:
        cutoff = float(newest_time) - self.config.window_seconds
        self._samples = [s for s in self._samples if s.measurement_time >= cutoff - 1e-9]

    def _estimate(self) -> YawAnchorEstimate | None:
        if len(self._samples) < self.config.minimum_samples:
            return None
        sine = sum(math.sin(s.world_yaw_rad) for s in self._samples)
        cosine = sum(math.cos(s.world_yaw_rad) for s in self._samples)
        if abs(sine) < 1e-12 and abs(cosine) < 1e-12:
            return None
        yaw = math.atan2(sine, cosine)
        spread = max(abs(wrap_angle(s.world_yaw_rad - yaw)) for s in self._samples)
        if spread > self.config.maximum_spread_rad:
            return None
        newest = max(self._samples, key=lambda s: s.measurement_time)
        return YawAnchorEstimate(
            world_yaw_rad=wrap_angle(yaw),
            sample_count=len(self._samples),
            spread_rad=float(spread),
            newest_measurement_time=float(newest.measurement_time),
            newest_confidence=float(newest.confidence),
            newest_reprojection_error_px=float(newest.reprojection_error_px),
        )
