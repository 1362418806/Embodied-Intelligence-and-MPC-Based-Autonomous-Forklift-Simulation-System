"""Headless execution of one autonomous pickup episode."""

from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any, Iterable

import mujoco
import numpy as np

from control.ackermann import front_drive_angular_speeds, rear_ackermann_angles
from control.docking_controller import DockingController, object_standoff_error
from control.safety import LiftDriveInterlock
from evaluation.metrics import EpisodeResult
from scenarios.randomization import Scenario, apply_scenario
from simulator.observation_builder import ObservationBuilder
from task.pickup_state_machine import (
    PickupDecision,
    PickupParameters,
    PickupState,
    PickupStateMachine,
)


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _require_id(
    model: mujoco.MjModel,
    object_type: mujoco.mjtObj,
    name: str,
) -> int:
    object_id = mujoco.mj_name2id(model, object_type, name)
    if object_id < 0:
        raise RuntimeError(f"required MuJoCo object was not found: {name}")
    return int(object_id)


def _rpy_from_freejoint(
    data: mujoco.MjData,
    qpos_address: int,
) -> tuple[float, float, float]:
    w, x, y, z = data.qpos[qpos_address + 3 : qpos_address + 7]
    sinr_cosp = 2.0 * (w * x + y * z)
    cosr_cosp = 1.0 - 2.0 * (x * x + y * y)
    roll = math.atan2(sinr_cosp, cosr_cosp)
    sinp = 2.0 * (w * y - z * x)
    pitch = math.copysign(math.pi / 2.0, sinp) if abs(sinp) >= 1.0 else math.asin(sinp)
    siny_cosp = 2.0 * (w * z + x * y)
    cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
    yaw = math.atan2(siny_cosp, cosy_cosp)
    return roll, pitch, yaw


def _count_cross_contacts(
    data: mujoco.MjData,
    first_group: Iterable[int],
    second_group: Iterable[int],
) -> int:
    first = set(first_group)
    second = set(second_group)
    count = 0
    for index in range(data.ncon):
        contact = data.contact[index]
        geom1 = int(contact.geom1)
        geom2 = int(contact.geom2)
        if (geom1 in first and geom2 in second) or (
            geom2 in first and geom1 in second
        ):
            count += 1
    return count


def _controller_from_config(values: dict[str, Any]) -> DockingController:
    return DockingController(
        distance_gain=float(values["distance_gain"]),
        heading_gain=float(values["heading_gain"]),
        yaw_gain=float(values["yaw_gain"]),
        lateral_gain=float(values.get("lateral_gain", 0.0)),
        lookahead_distance=float(values.get("lookahead_distance", 0.75)),
        maximum_steering=float(values["maximum_steering"]),
        minimum_creep_speed=float(values["minimum_creep_speed"]),
        heading_slowdown_angle=float(values["heading_slowdown_angle"]),
        yaw_slowdown_angle=float(
            values.get("yaw_slowdown_angle", values["heading_slowdown_angle"])
        ),
        minimum_alignment_scale=float(values.get("minimum_alignment_scale", 0.20)),
    )


def run_pickup_episode(
    config: dict[str, Any],
    scenario: Scenario,
    *,
    max_episode_seconds: float | None = None,
    trace_path: Path | None = None,
) -> EpisodeResult:
    """Run one episode without viewer or rendering and return metrics."""
    model_path = (PROJECT_ROOT / config["model"]["xml_path"]).resolve()
    if not model_path.is_file():
        raise FileNotFoundError(f"MJCF model does not exist: {model_path}")

    drive = config["drive"]
    lift = config["lift"]
    pickup = config["pickup"]
    safety = config["safety"]
    controller_values = config["controller"]
    autonomy = config["autonomy"]
    batch = config.get("batch", {})

    wheelbase = float(drive["wheelbase"])
    front_track = float(drive["front_track"])
    rear_track = float(drive["rear_track"])
    wheel_radius = float(drive["front_wheel_radius"])
    steering_max = float(drive["maximum_steering_command"])
    lift_min = float(lift["minimum_height"])
    lift_max = float(lift["maximum_height"])
    lift_initial = float(lift["initial_target"])
    lifted_height_threshold = float(pickup["lifted_height_threshold"])
    tilt_warning_deg = float(pickup["tilt_warning_degrees"])
    settle_seconds = float(batch.get("settle_seconds", 0.50))
    time_limit = float(
        max_episode_seconds
        if max_episode_seconds is not None
        else batch.get("max_episode_seconds", 55.0)
    )
    trace_hz = float(batch.get("trace_hz", 10.0))
    steering_threshold_deg = float(batch.get("steering_exercised_degrees", 1.0))
    if settle_seconds < 0.0 or time_limit <= 0.0 or trace_hz <= 0.0:
        raise ValueError("batch timing values are invalid")

    model = mujoco.MjModel.from_xml_path(str(model_path))
    data = mujoco.MjData(model)
    mujoco.mj_resetData(model, data)
    apply_scenario(model, data, scenario)

    actuator_ids = {
        name: _require_id(model, mujoco.mjtObj.mjOBJ_ACTUATOR, name)
        for name in (
            "front_left_drive_velocity",
            "front_right_drive_velocity",
            "rear_left_steer_position",
            "rear_right_steer_position",
            "lift_position",
        )
    }
    joint_ids = {
        name: _require_id(model, mujoco.mjtObj.mjOBJ_JOINT, name)
        for name in (
            "forklift_free",
            "pallet_load_free",
            "lift_joint",
        )
    }
    forklift_qpos = int(model.jnt_qposadr[joint_ids["forklift_free"]])
    pallet_qpos = int(model.jnt_qposadr[joint_ids["pallet_load_free"]])
    lift_dof = int(model.jnt_dofadr[joint_ids["lift_joint"]])

    fork_geom_ids = {
        _require_id(model, mujoco.mjtObj.mjOBJ_GEOM, "left_fork"),
        _require_id(model, mujoco.mjtObj.mjOBJ_GEOM, "right_fork"),
    }
    pallet_geom_ids = {
        _require_id(model, mujoco.mjtObj.mjOBJ_GEOM, name)
        for name in (
            "pallet_center_runner",
            "pallet_left_runner",
            "pallet_right_runner",
            "pallet_deck",
            "cargo_box",
        )
    }

    # Let randomized bodies settle before the task clock starts.
    data.ctrl[actuator_ids["lift_position"]] = lift_initial
    settle_steps = int(round(settle_seconds / model.opt.timestep))
    for _ in range(settle_steps):
        mujoco.mj_step(model, data)

    ground_load_z = float(data.qpos[pallet_qpos + 2])
    observation_builder = ObservationBuilder(model)
    pickup_machine = PickupStateMachine(
        parameters=PickupParameters.from_mapping(autonomy),
        docking_controller=_controller_from_config(controller_values),
    )
    pickup_machine.reset(float(data.time))
    drive_interlock = LiftDriveInterlock(
        enabled=bool(safety["stop_drive_during_lift"]),
        velocity_threshold=float(safety["lift_velocity_threshold"]),
        settle_time=float(safety["lift_settle_time_seconds"]),
    )
    drive_interlock.reset(lift_target=lift_initial, sim_time=float(data.time))

    def load_status() -> tuple[int, str, float]:
        load_z = float(data.qpos[pallet_qpos + 2])
        load_roll, load_pitch, _ = _rpy_from_freejoint(data, pallet_qpos)
        tilt_deg = max(abs(math.degrees(load_roll)), abs(math.degrees(load_pitch)))
        contacts = _count_cross_contacts(data, fork_geom_ids, pallet_geom_ids)
        lifted = load_z - ground_load_z >= lifted_height_threshold
        state = "LIFTED" if lifted else ("ENGAGED" if contacts > 0 else "GROUND")
        if tilt_deg >= tilt_warning_deg:
            state += "/TILT_WARNING"
        return contacts, state, tilt_deg

    contacts, load_state, load_tilt_deg = load_status()
    observation = observation_builder.build(
        data,
        fork_contact_count=contacts,
        load_state=load_state,
    )
    initial_error = object_standoff_error(
        observation.pallet_pose_in_base,
        standoff_distance=float(autonomy["pre_approach_distance"]),
    )

    task_start = float(data.time)
    current_state = pickup_machine.state.value
    state_enter_time = task_start
    state_durations: dict[str, float] = {}
    path_length = 0.0
    previous_xy = (
        float(data.qpos[forklift_qpos]),
        float(data.qpos[forklift_qpos + 1]),
    )
    max_abs_steering_deg = 0.0
    max_load_tilt_deg = load_tilt_deg
    final_state = PickupState.FAILED.value
    failure_reason: str | None = None
    decision: PickupDecision | None = None
    trace_stream = None
    next_trace_time = task_start
    trace_period = 1.0 / trace_hz

    if trace_path is not None:
        trace_path.parent.mkdir(parents=True, exist_ok=True)
        trace_stream = trace_path.open("w", encoding="utf-8")

    try:
        while float(data.time) - task_start <= time_limit:
            contacts, load_state, load_tilt_deg = load_status()
            observation = observation_builder.build(
                data,
                fork_contact_count=contacts,
                load_state=load_state,
            )
            decision = pickup_machine.step(observation)

            if decision.state.value != current_state:
                state_durations[current_state] = state_durations.get(current_state, 0.0) + (
                    float(data.time) - state_enter_time
                )
                current_state = decision.state.value
                state_enter_time = float(data.time)

            requested_action = decision.action
            requested_speed = (
                0.0 if requested_action.emergency_stop else requested_action.speed_target
            )
            interlock = drive_interlock.resolve(
                requested_speed=requested_speed,
                lift_velocity=float(data.qvel[lift_dof]),
                lift_target=requested_action.lift_target,
                sim_time=float(data.time),
            )
            steering_command = max(
                -steering_max,
                min(steering_max, requested_action.steering_command),
            )
            steer_angles = rear_ackermann_angles(
                steering_command,
                wheelbase,
                rear_track,
            )
            left_omega, right_omega = front_drive_angular_speeds(
                interlock.applied_speed,
                steering_command,
                wheelbase,
                front_track,
                wheel_radius,
            )
            data.ctrl[actuator_ids["front_left_drive_velocity"]] = left_omega
            data.ctrl[actuator_ids["front_right_drive_velocity"]] = right_omega
            data.ctrl[actuator_ids["rear_left_steer_position"]] = steer_angles.left
            data.ctrl[actuator_ids["rear_right_steer_position"]] = steer_angles.right
            data.ctrl[actuator_ids["lift_position"]] = max(
                lift_min,
                min(lift_max, requested_action.lift_target),
            )

            max_abs_steering_deg = max(
                max_abs_steering_deg,
                abs(math.degrees(steering_command)),
            )
            max_load_tilt_deg = max(max_load_tilt_deg, load_tilt_deg)

            if trace_stream is not None and float(data.time) + 1e-12 >= next_trace_time:
                trace_stream.write(
                    json.dumps(
                        {
                            "observation": observation.to_dict(),
                            "decision": decision.to_dict(),
                            "applied_speed": interlock.applied_speed,
                            "interlock_reason": interlock.reason,
                        },
                        ensure_ascii=False,
                    )
                    + "\n"
                )
                while next_trace_time <= float(data.time):
                    next_trace_time += trace_period

            if decision.state in (PickupState.DONE, PickupState.FAILED):
                final_state = decision.state.value
                failure_reason = decision.failure_reason
                break

            mujoco.mj_step(model, data)
            current_xy = (
                float(data.qpos[forklift_qpos]),
                float(data.qpos[forklift_qpos + 1]),
            )
            path_length += math.hypot(
                current_xy[0] - previous_xy[0],
                current_xy[1] - previous_xy[1],
            )
            previous_xy = current_xy

            if not np.isfinite(data.qpos).all() or not np.isfinite(data.qvel).all():
                final_state = PickupState.FAILED.value
                failure_reason = "non-finite MuJoCo state"
                break
        else:
            final_state = PickupState.FAILED.value
            failure_reason = f"episode exceeded {time_limit:.1f}s"
    finally:
        if trace_stream is not None:
            trace_stream.close()

    end_time = float(data.time)
    state_durations[current_state] = state_durations.get(current_state, 0.0) + max(
        0.0,
        end_time - state_enter_time,
    )

    contacts, load_state, load_tilt_deg = load_status()
    final_observation = observation_builder.build(
        data,
        fork_contact_count=contacts,
        load_state=load_state,
    )
    success = final_state == PickupState.DONE.value

    return EpisodeResult(
        scenario_id=scenario.scenario_id,
        difficulty=scenario.difficulty,
        seed=scenario.seed,
        success=success,
        final_state=final_state,
        failure_reason=None if success else (failure_reason or "unknown failure"),
        duration_seconds=max(0.0, end_time - task_start),
        path_length_m=path_length,
        max_abs_steering_deg=max_abs_steering_deg,
        max_load_tilt_deg=max(max_load_tilt_deg, load_tilt_deg),
        initial_lateral_error_m=initial_error.lateral,
        initial_yaw_error_deg=math.degrees(initial_error.yaw),
        final_lateral_error_m=final_observation.pallet_pose_in_base.y,
        final_yaw_error_deg=math.degrees(final_observation.pallet_pose_in_base.yaw),
        steering_exercised=max_abs_steering_deg >= steering_threshold_deg,
        state_durations={key: round(value, 6) for key, value in state_durations.items()},
        scenario=scenario.to_dict(),
    )
