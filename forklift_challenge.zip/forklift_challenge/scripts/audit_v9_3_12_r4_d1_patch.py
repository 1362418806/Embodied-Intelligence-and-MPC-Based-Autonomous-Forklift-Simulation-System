"""Static audit for V9.3.12-R4-D1 association diagnostics."""
from __future__ import annotations

import ast
from pathlib import Path
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]
FILES = [
    ROOT / "perception" / "terminal_load_reacquisition.py",
    ROOT / "simulator" / "dual_vision_mission_episode.py",
    ROOT / "scripts" / "run_v9_3_12_r4_d1_batch.py",
    ROOT / "scripts" / "analyze_v9_3_12_r4_d1_association.py",
]


def check(name: str, ok: bool) -> bool:
    print(f"{name:<48} {'PASS' if ok else 'FAIL'}")
    return ok


def main() -> int:
    ok = True
    for path in FILES:
        try:
            ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
            valid = True
        except Exception as exc:
            print(f"{path}: {exc}")
            valid = False
        ok &= check(f"syntax {path.name}", valid)

    cfg_path = ROOT / "configs" / "vehicle_v9_3_12_r4_d1.yaml"
    cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
    weak = cfg["terminal_load_reacquisition"]["profiles"]["weak_guide"]
    # R4-D1 is diagnostics-only: preserve all R4-D association/consensus gates.
    ok &= check("center gate remains 42 px", float(weak["maximum_center_error_px"]) == 42.0)
    ok &= check("coverage gate remains 0.30", float(weak["minimum_visual_coverage"]) == 0.30)
    ok &= check("minimum frames remains 4", int(weak["minimum_frames"]) == 4)
    ok &= check("minimum duration remains 0.18 s", float(weak["minimum_duration_seconds"]) == 0.18)
    ok &= check("position innovation remains 0.06 m", float(weak["maximum_position_innovation_m"]) == 0.06)
    ok &= check("yaw innovation remains 4 deg", float(weak["maximum_yaw_innovation_deg"]) == 4.0)

    perception = (ROOT / "perception" / "terminal_load_reacquisition.py").read_text(encoding="utf-8")
    simulator = (ROOT / "simulator" / "dual_vision_mission_episode.py").read_text(encoding="utf-8")
    runner = (ROOT / "scripts" / "run_v9_3_12_r4_d1_batch.py").read_text(encoding="utf-8")
    ok &= check("all-component audit present", 'audit["components"] = component_audit' in perception)
    ok &= check("prior projection polygon audited", '"prior_polygon_px"' in perception)
    ok &= check("fitted projection polygon audited", '"fitted_polygon_px"' in perception)
    ok &= check("debug overlay present", "debug_overlay_bgr" in perception)
    ok &= check("audit stream is simulator-side only", "reacq_audit_stream" in simulator)
    ok &= check("sparse debug image capture present", "reacq_debug_image_count" in simulator)
    ok &= check("single episode diagnostic selector present", "--only-episode-index" in runner)
    ok &= check("association audit CLI present", "--reacq-association-audit" in runner)
    ok &= check("debug image CLI present", "--reacq-debug-images" in runner)

    # Guard against accidental direct release authority in the new audit module.
    audit_region = perception[perception.find("association_audit_snapshot"):]
    ok &= check("audit code has no release command", "release_authority" not in audit_region and "release_commit" not in audit_region)
    print("\nR4-D1 audit", "PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
