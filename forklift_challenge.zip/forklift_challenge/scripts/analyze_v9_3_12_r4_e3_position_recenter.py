"""Analyze V9.3.12-R4-E3 blocker-aware POSITION recenter from a trace JSONL.

Ground truth, when present, is used only for offline diagnosis.  All E3 control
telemetry is observation/controller-derived.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path


def _time(row: dict) -> float:
    return float(
        row.get("estimated_observation", {}).get(
            "sim_time", row.get("ground_truth_observation", {}).get("sim_time", 0.0)
        )
    )


def _wrap(angle: float) -> float:
    return math.atan2(math.sin(angle), math.cos(angle))


def _truth_error(row: dict) -> tuple[float, float] | None:
    gt = row.get("ground_truth_observation", {})
    pallet = gt.get("pallet_pose_in_base")
    target = gt.get("placement_pose_in_base")
    if not isinstance(pallet, dict) or not isinstance(target, dict):
        return None
    try:
        dx = float(target["x"]) - float(pallet["x"])
        dy = float(target["y"]) - float(pallet["y"])
        yaw = _wrap(float(target["yaw"]) - float(pallet["yaw"]))
    except (KeyError, TypeError, ValueError):
        return None
    return float(math.hypot(dx, dy)), float(abs(math.degrees(yaw)))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("trace", type=Path)
    parser.add_argument("--output-json", type=Path)
    parser.add_argument("--output-md", type=Path)
    args = parser.parse_args()

    rows = [
        json.loads(line)
        for line in args.trace.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    decisions = [(row, row.get("decision", {})) for row in rows]

    phase_counts: dict[str, int] = {}
    first_phase_time: dict[str, float] = {}
    activation_times: list[float] = []
    return_replan_times: list[float] = []
    final_feedback_times: list[float] = []
    previous_activation = 0
    previous_return_replan = 0
    previous_phase = "IDLE"

    for row, d in decisions:
        phase = str(d.get("placement_position_blocker_recenter_phase", "IDLE"))
        phase_counts[phase] = phase_counts.get(phase, 0) + 1
        if phase not in first_phase_time:
            first_phase_time[phase] = _time(row)
        activation = int(d.get("placement_position_blocker_recenter_activation_count", 0))
        if activation > previous_activation:
            activation_times.append(_time(row))
        previous_activation = activation
        return_replan = int(d.get("placement_position_blocker_recenter_return_replan_count", 0))
        if return_replan > previous_return_replan:
            return_replan_times.append(_time(row))
        previous_return_replan = return_replan
        if previous_phase == "FINAL_RGB_SETTLE" and phase == "IDLE":
            final_feedback_times.append(_time(row))
        previous_phase = phase

    supervisor_settle = [
        (row, d)
        for row, d in decisions
        if d.get("placement_precision_phase") == "RELEASE_SETTLE"
    ]
    strict_pass = [(row, d) for row, d in decisions if bool(d.get("strict_release_certified", False))]
    release_events = [
        (row, d)
        for row, d in decisions
        if "RELEASE_INTENT executed" in str(d.get("status", ""))
    ]

    cert_pos = [
        float(d["strict_release_certification_position_error_m"])
        for _, d in decisions
        if d.get("strict_release_certification_position_error_m") is not None
    ]
    cert_yaw = [
        abs(float(d["strict_release_certification_yaw_error_deg"]))
        for _, d in decisions
        if d.get("strict_release_certification_yaw_error_deg") is not None
    ]
    filtered_pos = [
        float(d["placement_precision_filtered_position_error_m"])
        for _, d in decisions
        if d.get("placement_precision_filtered_position_error_m") is not None
    ]
    filtered_yaw = [
        abs(float(d["placement_precision_filtered_yaw_error_deg"]))
        for _, d in decisions
        if d.get("placement_precision_filtered_yaw_error_deg") is not None
    ]

    truth_series: list[tuple[float, float, float]] = []
    for row, _ in decisions:
        err = _truth_error(row)
        if err is not None:
            truth_series.append((_time(row), err[0], err[1]))

    first_activation = activation_times[0] if activation_times else None
    first_feedback = final_feedback_times[0] if final_feedback_times else None
    truth_during_corridor = []
    if first_activation is not None:
        end = first_feedback if first_feedback is not None else float("inf")
        truth_during_corridor = [item for item in truth_series if first_activation <= item[0] <= end]

    last_d = decisions[-1][1] if decisions else {}
    result = {
        "trace": str(args.trace),
        "samples": len(rows),
        # Selection is inferred from activation counter transition.  This fixes
        # the E2 analyzer bug where the one-frame selection status was absent
        # from the sampled trace even though activation_count=1.
        "position_recenter_selected_count": len(activation_times),
        "position_recenter_phase_frame_counts": phase_counts,
        "first_position_recenter_selection_time_s": first_activation,
        "first_midpoint_rgb_time_s": first_phase_time.get("MID_RGB_SETTLE"),
        "first_return_time_s": first_phase_time.get("RETURN"),
        "first_final_rgb_time_s": first_phase_time.get("FINAL_RGB_SETTLE"),
        "first_final_feedback_time_s": first_feedback,
        "return_replan_event_count": len(return_replan_times),
        "release_supervisor_settle_frame_count": len(supervisor_settle),
        "strict_certified_frame_count": len(strict_pass),
        "release_execute_count": len(release_events),
        "first_release_time_s": None if not release_events else _time(release_events[0][0]),
        "minimum_certification_position_error_m": None if not cert_pos else min(cert_pos),
        "minimum_certification_abs_yaw_error_deg": None if not cert_yaw else min(cert_yaw),
        "minimum_filtered_position_error_m": None if not filtered_pos else min(filtered_pos),
        "minimum_filtered_abs_yaw_error_deg": None if not filtered_yaw else min(filtered_yaw),
        "final_e3_search_count": int(last_d.get("placement_position_blocker_recenter_search_count", 0)),
        "final_e3_activation_count": int(last_d.get("placement_position_blocker_recenter_activation_count", 0)),
        "final_e3_total_candidate_count": int(last_d.get("placement_position_blocker_recenter_total_candidate_count", 0)),
        "final_e3_return_replan_count": int(last_d.get("placement_position_blocker_recenter_return_replan_count", 0)),
        "final_e3_return_candidate_count": int(last_d.get("placement_position_blocker_recenter_return_candidate_count", 0)),
        "final_e3_feedback_reject_count": int(last_d.get("placement_position_blocker_recenter_feedback_reject_count", 0)),
        "final_e3_abort_count": int(last_d.get("placement_position_blocker_recenter_abort_count", 0)),
        "final_e3_midpoint_replan_fail_count": int(last_d.get("placement_position_blocker_recenter_midpoint_replan_fail_count", 0)),
        "final_e3_mid_rgb_updates": int(last_d.get("placement_position_blocker_recenter_mid_rgb_updates", 0)),
        "final_e3_final_rgb_updates": int(last_d.get("placement_position_blocker_recenter_final_rgb_updates", 0)),
        "final_e3_predicted_effective_position_m": float(last_d.get("placement_position_blocker_recenter_last_predicted_effective_position_m", 0.0)),
        "final_e3_measured_effective_position_m": float(last_d.get("placement_position_blocker_recenter_last_measured_effective_position_m", 0.0)),
        "final_e3_measured_position_improvement_m": float(last_d.get("placement_position_blocker_recenter_last_measured_position_improvement_m", 0.0)),
        "final_e3_predicted_effective_yaw_deg": float(last_d.get("placement_position_blocker_recenter_last_predicted_effective_yaw_deg", 0.0)),
        "final_e3_measured_effective_yaw_deg": float(last_d.get("placement_position_blocker_recenter_last_measured_effective_yaw_deg", 0.0)),
        "final_strict_certified": bool(last_d.get("strict_release_certified", False)),
        "final_strict_blocker": str(last_d.get("strict_release_certification_blocker", "NONE")),
        "final_release_commit_count": int(last_d.get("placement_release_commit_count", 0)),
        # OFFLINE DIAGNOSIS ONLY -- never controller input.
        "diagnostic_truth_max_position_during_e3_m": None if not truth_during_corridor else max(x[1] for x in truth_during_corridor),
        "diagnostic_truth_min_position_during_e3_m": None if not truth_during_corridor else min(x[1] for x in truth_during_corridor),
        "diagnostic_truth_final_position_m": None if not truth_series else truth_series[-1][1],
        "diagnostic_truth_final_abs_yaw_deg": None if not truth_series else truth_series[-1][2],
    }

    print("V9.3.12-R4-E3 POSITION-blocker recenter analysis")
    for key, value in result.items():
        print(f"  {key}: {value}")

    if args.output_json:
        args.output_json.parent.mkdir(parents=True, exist_ok=True)
        args.output_json.write_text(
            json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8"
        )
    if args.output_md:
        args.output_md.parent.mkdir(parents=True, exist_ok=True)
        lines = [
            "# V9.3.12-R4-E3 Position-Blocker Recenter Analysis",
            "",
            "> Ground-truth fields below are offline diagnostics only and are never controller inputs.",
            "",
        ]
        lines.extend(f"- **{key}**: {value}" for key, value in result.items())
        args.output_md.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
