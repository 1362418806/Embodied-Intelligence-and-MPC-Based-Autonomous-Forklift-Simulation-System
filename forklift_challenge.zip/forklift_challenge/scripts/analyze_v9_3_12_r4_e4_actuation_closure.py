"""Analyze R4-E4 steering-conditioned, odometry-closed POSITION recenter traces."""
from __future__ import annotations

import argparse
from collections import Counter
import json
import math
from pathlib import Path


def _time(row: dict) -> float:
    return float(row.get("estimated_observation", {}).get("sim_time", 0.0))


def _wrap(a: float) -> float:
    return (float(a) + math.pi) % (2.0 * math.pi) - math.pi


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("trace", type=Path)
    ap.add_argument("--output-json", type=Path)
    ap.add_argument("--output-md", type=Path)
    args = ap.parse_args()
    rows = [json.loads(line) for line in args.trace.read_text(encoding="utf-8").splitlines() if line.strip()]
    phases = Counter()
    status_counts = Counter()
    first = {}
    truth_positions = []
    depart_truth_path = 0.0
    depart_truth_yaw = 0.0
    depart_rows = []
    return_rows = []
    for row in rows:
        d = row.get("decision", {}) or {}
        phase = str(d.get("placement_position_blocker_recenter_phase", "IDLE"))
        phases[phase] += 1
        status = str(d.get("status", ""))
        t = _time(row)
        for key, needle in {
            "selection": "R4-E4 POSITION blocker recenter selected",
            "depart_presteer_ready": "R4-E4 DEPART presteer READY",
            "depart_presteer_timeout": "R4-E4 DEPART presteer TIMEOUT",
            "midpoint_tracked": "R4-E4 midpoint TRACKED + fresh RETURN",
            "midpoint_return_unavailable": "R4-E4 midpoint TRACKED but RETURN unavailable",
            "midpoint_model_fail": "R4-E4 midpoint model-consistency FAIL",
            "return_presteer_ready": "R4-E4 RETURN presteer READY",
            "return_presteer_timeout": "R4-E4 RETURN presteer TIMEOUT",
            "live_strict_capture": "R4-E4 live strict capture",
            "depart_odom_timeout": "R4-E4 DEPART odometry TIMEOUT",
            "return_odom_timeout": "R4-E4 RETURN odometry TIMEOUT",
        }.items():
            if needle in status:
                status_counts[key] += 1
                first.setdefault(key, t)
        if phase == "DEPART":
            depart_rows.append(row)
        if phase == "RETURN":
            return_rows.append(row)
        if phase != "IDLE":
            gt = row.get("ground_truth_observation", {}) or {}
            pal = gt.get("pallet_pose_world")
            target = gt.get("placement_pose_world")
            if pal and target:
                truth_positions.append(math.hypot(float(pal["x"])-float(target["x"]), float(pal["y"])-float(target["y"])))

    def path_and_yaw(segment: list[dict]) -> tuple[float, float]:
        if len(segment) < 2:
            return 0.0, 0.0
        dist = 0.0
        for a,b in zip(segment, segment[1:]):
            pa=a["ground_truth_observation"]["vehicle_pose_world"]
            pb=b["ground_truth_observation"]["vehicle_pose_world"]
            dist += math.hypot(float(pb["x"])-float(pa["x"]), float(pb["y"])-float(pa["y"]))
        y0=float(segment[0]["ground_truth_observation"]["vehicle_pose_world"]["yaw"])
        y1=float(segment[-1]["ground_truth_observation"]["vehicle_pose_world"]["yaw"])
        return dist, math.degrees(abs(_wrap(y1-y0)))

    depart_truth_path, depart_truth_yaw = path_and_yaw(depart_rows)
    return_truth_path, return_truth_yaw = path_and_yaw(return_rows)
    last = (rows[-1].get("decision", {}) or {}) if rows else {}
    result = {
        "trace": str(args.trace),
        "samples": len(rows),
        "phase_frame_counts": dict(phases),
        "status_event_counts": dict(status_counts),
        "first_event_time_s": first,
        "final_activation_count": int(last.get("placement_position_blocker_recenter_activation_count", 0)),
        "final_abort_count": int(last.get("placement_position_blocker_recenter_abort_count", 0)),
        "final_midpoint_replan_fail_count": int(last.get("placement_position_blocker_recenter_midpoint_replan_fail_count", 0)),
        "final_return_replan_count": int(last.get("placement_position_blocker_recenter_return_replan_count", 0)),
        "final_return_candidate_count": int(last.get("placement_position_blocker_recenter_return_candidate_count", 0)),
        "final_presteer_timeout_count": int(last.get("placement_position_blocker_recenter_presteer_timeout_count", 0)),
        "last_effective_steering_deg": float(last.get("placement_position_blocker_recenter_last_effective_steering_deg", 0.0)),
        "last_departure_odometry_m": float(last.get("placement_position_blocker_recenter_last_departure_odometry_m", 0.0)),
        "last_return_odometry_m": float(last.get("placement_position_blocker_recenter_last_return_odometry_m", 0.0)),
        "midpoint_position_deviation_m": float(last.get("placement_position_blocker_recenter_midpoint_position_deviation_m", 0.0)),
        "midpoint_yaw_deviation_deg": float(last.get("placement_position_blocker_recenter_midpoint_yaw_deviation_deg", 0.0)),
        "mid_rgb_updates": int(last.get("placement_position_blocker_recenter_mid_rgb_updates", 0)),
        "final_rgb_updates": int(last.get("placement_position_blocker_recenter_final_rgb_updates", 0)),
        "strict_certified": bool(last.get("strict_release_certified", False)),
        "strict_blocker": str(last.get("strict_release_certification_blocker", "")),
        "release_commit_count": int(last.get("placement_release_commit_count", 0)),
        "diagnostic_truth_depart_vehicle_path_m": depart_truth_path,
        "diagnostic_truth_depart_vehicle_yaw_change_deg": depart_truth_yaw,
        "diagnostic_truth_return_vehicle_path_m": return_truth_path,
        "diagnostic_truth_return_vehicle_yaw_change_deg": return_truth_yaw,
        "diagnostic_truth_max_position_during_e4_m": max(truth_positions) if truth_positions else None,
    }
    print("V9.3.12-R4-E4 actuation-aware recenter analysis")
    for k,v in result.items():
        print(f"  {k}: {v}")
    if args.output_json:
        args.output_json.parent.mkdir(parents=True, exist_ok=True)
        args.output_json.write_text(json.dumps(result, indent=2), encoding="utf-8")
    if args.output_md:
        args.output_md.parent.mkdir(parents=True, exist_ok=True)
        lines=["# V9.3.12-R4-E4 Actuation-Aware Recenter Analysis",""]+[f"- **{k}**: `{v}`" for k,v in result.items()]
        args.output_md.write_text("\n".join(lines)+"\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
