from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import math


class LoadSeedProvenance(str, Enum):
    UNKNOWN = "UNKNOWN"
    RGB_PRELIFT_RECENT = "RGB_PRELIFT_RECENT"
    RGB_PRELIFT_HIGH_CONFIDENCE = "RGB_PRELIFT_HIGH_CONFIDENCE"
    RGB_PRELIFT_STALE = "RGB_PRELIFT_STALE"
    RGB_LIVE = "RGB_LIVE"
    TERMINAL_RGB = "TERMINAL_RGB"
    FUSED_GUIDE = "FUSED_GUIDE"


@dataclass(frozen=True)
class LoadSeedProvenanceConfig:
    recent_max_age_seconds: float = 3.0
    recent_min_confidence: float = 0.48
    recent_max_reprojection_error_px: float = 6.5
    high_confidence_threshold: float = 0.80
    high_confidence_max_age_seconds: float = 9.0
    high_confidence_max_reprojection_error_px: float = 2.0

    def validate(self) -> None:
        if self.recent_max_age_seconds <= 0.0:
            raise ValueError("recent_max_age_seconds must be positive")
        if not 0.0 <= self.recent_min_confidence <= 1.0:
            raise ValueError("recent_min_confidence must be in [0,1]")
        if self.recent_max_reprojection_error_px <= 0.0:
            raise ValueError("recent_max_reprojection_error_px must be positive")
        if not 0.0 <= self.high_confidence_threshold <= 1.0:
            raise ValueError("high_confidence_threshold must be in [0,1]")
        if self.high_confidence_max_age_seconds < self.recent_max_age_seconds:
            raise ValueError("high-confidence age window cannot be shorter than recent window")
        if self.high_confidence_max_reprojection_error_px <= 0.0:
            raise ValueError("high_confidence_max_reprojection_error_px must be positive")


@dataclass(frozen=True)
class LoadSeedAssessment:
    provenance: LoadSeedProvenance
    trusted_for_aggressive_risk: bool
    age_seconds: float
    confidence: float | None
    reprojection_error_px: float | None
    reason: str


def assess_prelift_rgb_seed(
    *,
    age_seconds: float,
    confidence: float | None,
    reprojection_error_px: float | None,
    config: LoadSeedProvenanceConfig,
) -> LoadSeedAssessment:
    """Classify a cached pre-lift RGB seed without consulting simulation truth.

    R4-A deliberately separates *pose source* from *risk authority*. A stale
    RGB-held pose can still be a useful observer seed, but it is not allowed to
    inherit the R3 1.8 cm rigid cap / RSS release budget unless its temporal and
    image-quality evidence justify that trust.
    """
    config.validate()
    age = max(0.0, float(age_seconds))
    conf = None if confidence is None else float(confidence)
    reproj = None if reprojection_error_px is None else float(reprojection_error_px)

    finite_conf = conf is not None and math.isfinite(conf)
    finite_reproj = reproj is not None and math.isfinite(reproj)

    recent_quality = bool(
        age <= config.recent_max_age_seconds
        and finite_conf
        and conf >= config.recent_min_confidence
        and finite_reproj
        and reproj <= config.recent_max_reprojection_error_px
    )
    if recent_quality:
        return LoadSeedAssessment(
            provenance=LoadSeedProvenance.RGB_PRELIFT_RECENT,
            trusted_for_aggressive_risk=True,
            age_seconds=age,
            confidence=conf,
            reprojection_error_px=reproj,
            reason="recent_rgb_quality_pass",
        )

    high_quality_exception = bool(
        age <= config.high_confidence_max_age_seconds
        and finite_conf
        and conf >= config.high_confidence_threshold
        and finite_reproj
        and reproj <= config.high_confidence_max_reprojection_error_px
    )
    if high_quality_exception:
        return LoadSeedAssessment(
            provenance=LoadSeedProvenance.RGB_PRELIFT_HIGH_CONFIDENCE,
            trusted_for_aggressive_risk=True,
            age_seconds=age,
            confidence=conf,
            reprojection_error_px=reproj,
            reason="aged_but_high_confidence_rgb_pass",
        )

    return LoadSeedAssessment(
        provenance=LoadSeedProvenance.RGB_PRELIFT_STALE,
        trusted_for_aggressive_risk=False,
        age_seconds=age,
        confidence=conf,
        reprojection_error_px=reproj,
        reason="rgb_seed_not_trusted_for_aggressive_risk",
    )
