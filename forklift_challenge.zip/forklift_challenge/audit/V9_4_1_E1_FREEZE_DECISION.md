# V9.4.1-E1 Freeze Decision: HOLD

- Source: `/mnt/data/analysis_unpacked/分析/seed_8675309/summary.json`
- Gate: **FAIL**

## Checks

- PASS — episodes>=10
- FAIL — mission>=90%
- FAIL — competition_precision>=90%
- FAIL — terminal_budget<=10%
- PASS — first_cert_to_release<3s
- FAIL — controller_release_truth_fp=0
- FAIL — release_witness_truth_fp=0
- FAIL — release_execution_truth_fp=0
- PASS — S2_telemetry_present
- PASS — F2_terminal_yaw_authority_disabled
- FAIL — E1_telemetry_present
- FAIL — stale_yaw_release_authority=0
- FAIL — terminal_RGB_yaw_motion_writeback=0
- FAIL — S2_regression=0
- FAIL — truth_ready_basin_destroyed_by_stale_evidence=0

## Metrics

- episodes: 10
- mission_rate: 0.8
- competition_precision_rate: 0.5
- terminal_budget_rate: 0.2
- first_cert_to_release_seconds: 0.6322500000013509
- controller_fp: 3
- witness_fp: 3
- execution_fp: 3
- s2_telemetry_present: True
- f2_terminal_yaw_authority_disabled: True
- e1_telemetry_present: False
- e1_stale_yaw_release_authority_count: None
- e1_terminal_rgb_yaw_motion_writeback_count: None
- e1_s2_regression_count: None
- e1_truth_ready_basin_destroyed_by_stale_evidence_count: None
