"""Calibrated pickup measurement and event-level safety metrics for V8.1.3.4."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import math
from typing import Any, Mapping


def _wrap_angle(angle: float) -> float:
    return (float(angle) + math.pi) % (2.0 * math.pi) - math.pi


def _percentile(values: list[float], percentile: float) -> float | None:
    if not values:
        return None
    ordered = sorted(float(value) for value in values)
    if len(ordered) == 1:
        return ordered[0]
    rank = (len(ordered) - 1) * float(percentile) / 100.0
    lower = int(math.floor(rank))
    upper = int(math.ceil(rank))
    if lower == upper:
        return ordered[lower]
    fraction = rank - lower
    return ordered[lower] * (1.0 - fraction) + ordered[upper] * fraction


@dataclass(frozen=True)
class PickupVisionQualityConfig:
    opportunity_states: frozenset[str]
    minimum_marker_width_px: float
    minimum_marker_height_px: float
    image_margin_px: float
    maximum_opportunity_distance_m: float
    outlier_position_threshold_m: float
    outlier_yaw_threshold_deg: float
    severe_outlier_position_threshold_m: float
    severe_outlier_yaw_threshold_deg: float
    percentile: float

    @classmethod
    def from_mapping(
        cls, values: Mapping[str, Any] | None
    ) -> "PickupVisionQualityConfig":
        values = values or {}
        result = cls(
            opportunity_states=frozenset(
                str(item)
                for item in values.get(
                    "opportunity_states",
                    values.get(
                        "visible_states",
                        ("APPROACH", "ALIGN"),
                    ),
                )
            ),
            minimum_marker_width_px=float(
                values.get("minimum_marker_width_px", 3.0)
            ),
            minimum_marker_height_px=float(
                values.get("minimum_marker_height_px", 2.0)
            ),
            image_margin_px=float(values.get("image_margin_px", 2.0)),
            maximum_opportunity_distance_m=float(
                values.get("maximum_opportunity_distance_m", 5.7)
            ),
            outlier_position_threshold_m=float(
                values.get("outlier_position_threshold_m", 0.08)
            ),
            outlier_yaw_threshold_deg=float(
                values.get("outlier_yaw_threshold_deg", 5.0)
            ),
            severe_outlier_position_threshold_m=float(
                values.get(
                    "severe_outlier_position_threshold_m",
                    0.20,
                )
            ),
            severe_outlier_yaw_threshold_deg=float(
                values.get(
                    "severe_outlier_yaw_threshold_deg",
                    12.0,
                )
            ),
            percentile=float(values.get("percentile", 95.0)),
        )
        if not result.opportunity_states:
            raise ValueError("opportunity_states must not be empty")
        for value in (
            result.minimum_marker_width_px,
            result.minimum_marker_height_px,
            result.maximum_opportunity_distance_m,
            result.outlier_position_threshold_m,
            result.outlier_yaw_threshold_deg,
            result.severe_outlier_position_threshold_m,
            result.severe_outlier_yaw_threshold_deg,
        ):
            if value <= 0.0:
                raise ValueError("quality thresholds must be positive")
        if result.image_margin_px < 0.0:
            raise ValueError("image margin must be non-negative")
        if not 0.0 < result.percentile <= 100.0:
            raise ValueError("percentile must be in (0,100]")
        return result


@dataclass(frozen=True)
class PickupVisionQualityMetrics:
    raw_detection_count: int
    raw_position_rmse_m: float | None
    raw_yaw_rmse_deg: float | None
    raw_position_p95_m: float | None
    raw_yaw_p95_deg: float | None
    detector_raw_detection_count: int
    detector_raw_position_rmse_m: float | None
    detector_raw_yaw_rmse_deg: float | None
    detector_raw_position_p95_m: float | None
    detector_raw_yaw_p95_deg: float | None
    fused_frame_count: int
    fused_position_rmse_m: float | None
    fused_yaw_rmse_deg: float | None
    fused_position_p95_m: float | None
    fused_yaw_p95_deg: float | None
    opportunity_count: int
    opportunity_raw_detection_count: int
    opportunity_detection_rate: float
    opportunity_count_by_state: dict[str, int]
    opportunity_detection_count_by_state: dict[str, int]
    raw_detection_rate_by_state: dict[str, float]
    control_detection_rate_by_state: dict[str, float]
    detection_acquired: bool
    first_detection_seconds: float | None
    first_detection_state: str | None
    longest_detection_streak_seconds: float
    last_detection_distance_m: float | None
    detections_before_insert: int
    ready_before_insert: bool
    raw_outlier_count: int
    innovation_rejected_count: int
    measurement_guide_rejected_count: int
    control_accepted_measurement_count: int
    control_accepted_outlier_count: int
    control_accepted_outlier_rate: float
    control_accepted_severe_outlier_count: int
    control_accepted_severe_outlier_rate: float
    average_confidence: float | None
    maximum_reprojection_error_px: float | None
    sample_count_by_state: dict[str, int]
    raw_detection_count_by_state: dict[str, int]
    control_detection_count_by_state: dict[str, int]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    # V8.1.2 compatibility aliases.  V8.1.3 formal evaluation uses geometric
    # opportunities and the raw/control split below.
    @property
    def visible_sample_count(self) -> int:
        return self.opportunity_count

    @property
    def visible_detection_count(self) -> int:
        return self.opportunity_raw_detection_count

    @property
    def visible_detection_rate(self) -> float:
        return self.opportunity_detection_rate

    @property
    def detection_rate_approach(self) -> float:
        return self.raw_detection_rate_by_state.get("APPROACH", 0.0)

    @property
    def detection_rate_align(self) -> float:
        return self.raw_detection_rate_by_state.get("ALIGN", 0.0)

    @property
    def detection_rate_insert(self) -> float:
        return self.raw_detection_rate_by_state.get("INSERT", 0.0)

    @property
    def detection_rate_recovery(self) -> float:
        return self.raw_detection_rate_by_state.get(
            "RECOVER_REVERSE", 0.0
        )

    @property
    def accepted_outlier_count(self) -> int:
        # Historical V8.1.2 name counted raw PnP threshold exceedances.
        return self.raw_outlier_count

    @property
    def detection_count_by_state(self) -> dict[str, int]:
        return self.control_detection_count_by_state



class PickupVisionQualityAccumulator:
    def __init__(
        self,
        *,
        config: PickupVisionQualityConfig,
        update_hz: float,
    ) -> None:
        if update_hz <= 0.0:
            raise ValueError("update_hz must be positive")
        self.config = config
        self.update_hz = float(update_hz)
        self.previous_sample_count = 0
        self.previous_control_detection_count = 0
        self.previous_raw_detection_count = 0
        self.previous_measurement_guide_rejection_count = 0
        self.raw_position_errors: list[float] = []
        self.raw_yaw_errors: list[float] = []
        self.detector_raw_position_errors: list[float] = []
        self.detector_raw_yaw_errors: list[float] = []
        self.fused_position_errors: list[float] = []
        self.fused_yaw_errors: list[float] = []
        self.confidences: list[float] = []
        self.reprojection_errors: list[float] = []
        self.sample_count_by_state: dict[str, int] = {}
        self.raw_detection_count_by_state: dict[str, int] = {}
        self.control_detection_count_by_state: dict[str, int] = {}
        self.opportunity_count_by_state: dict[str, int] = {}
        self.opportunity_detection_count_by_state: dict[str, int] = {}
        self.opportunity_start_time: float | None = None
        self.first_detection_seconds: float | None = None
        self.first_detection_state: str | None = None
        self.current_detection_streak = 0
        self.longest_detection_streak = 0
        self.last_detection_distance_m: float | None = None
        self.raw_outlier_count = 0
        self.innovation_rejected_count = 0
        self.measurement_guide_rejected_count = 0
        self.control_accepted_measurement_count = 0
        self.control_accepted_outlier_count = 0
        self.control_accepted_severe_outlier_count = 0
        self.detections_before_insert = 0
        self.ready_before_insert = False

    @classmethod
    def from_mapping(
        cls,
        values: Mapping[str, Any] | None,
        *,
        update_hz: float,
    ) -> "PickupVisionQualityAccumulator":
        return cls(
            config=PickupVisionQualityConfig.from_mapping(values),
            update_hz=update_hz,
        )

    @staticmethod
    def _pose_error(estimate, truth_pose) -> tuple[float, float]:
        dx = float(estimate.x) - float(truth_pose.x)
        dy = float(estimate.y) - float(truth_pose.y)
        yaw = abs(
            math.degrees(
                _wrap_angle(float(estimate.yaw) - float(truth_pose.yaw))
            )
        )
        return math.hypot(dx, dy), yaw

    @staticmethod
    def _rate(
        samples: Mapping[str, int],
        detections: Mapping[str, int],
        state: str,
    ) -> float:
        denominator = int(samples.get(state, 0))
        if denominator <= 0:
            return 0.0
        return int(detections.get(state, 0)) / denominator

    def add(self, frame, truth, *, visibility=None) -> None:
        diagnostics = frame.diagnostics
        state = str(diagnostics.controller_state or "UNKNOWN")
        now = float(truth.sim_time)

        sample_delta = max(
            0, int(diagnostics.sample_count) - self.previous_sample_count
        )
        control_delta = max(
            0,
            int(diagnostics.detection_count)
            - self.previous_control_detection_count,
        )
        raw_total = int(
            getattr(
                diagnostics,
                "raw_detection_count",
                diagnostics.detection_count,
            )
        )
        raw_delta = max(0, raw_total - self.previous_raw_detection_count)
        guide_rejection_total = int(
            getattr(
                diagnostics,
                "measurement_guide_rejection_count",
                0,
            )
        )
        guide_rejection_delta = max(
            0,
            guide_rejection_total
            - self.previous_measurement_guide_rejection_count,
        )

        self.previous_sample_count = int(diagnostics.sample_count)
        self.previous_control_detection_count = int(
            diagnostics.detection_count
        )
        self.previous_raw_detection_count = raw_total
        self.previous_measurement_guide_rejection_count = (
            guide_rejection_total
        )
        self.measurement_guide_rejected_count += guide_rejection_delta

        if sample_delta:
            self.sample_count_by_state[state] = (
                self.sample_count_by_state.get(state, 0) + sample_delta
            )

        if raw_delta:
            self.raw_detection_count_by_state[state] = (
                self.raw_detection_count_by_state.get(state, 0)
                + raw_delta
            )

        if control_delta:
            self.control_detection_count_by_state[state] = (
                self.control_detection_count_by_state.get(state, 0)
                + control_delta
            )
            if self.first_detection_state is None:
                self.first_detection_state = state
            if self.first_detection_seconds is None:
                start = (
                    now
                    if self.opportunity_start_time is None
                    else self.opportunity_start_time
                )
                self.first_detection_seconds = max(0.0, now - start)
            self.current_detection_streak += control_delta
            self.longest_detection_streak = max(
                self.longest_detection_streak,
                self.current_detection_streak,
            )
            truth_pose = truth.pallet_pose_in_base
            self.last_detection_distance_m = math.hypot(
                float(truth_pose.x), float(truth_pose.y)
            )
        elif sample_delta:
            self.current_detection_streak = 0

        opportunity_visible = (
            state in self.config.opportunity_states
            if visibility is None
            else bool(visibility.visible)
        )
        if (
            sample_delta
            and state in self.config.opportunity_states
            and opportunity_visible
        ):
            self.opportunity_count_by_state[state] = (
                self.opportunity_count_by_state.get(state, 0)
                + sample_delta
            )
            if self.opportunity_start_time is None:
                self.opportunity_start_time = now
            if raw_delta:
                self.opportunity_detection_count_by_state[state] = (
                    self.opportunity_detection_count_by_state.get(state, 0)
                    + min(sample_delta, raw_delta)
                )

        # V8.1.3.4 "raw" means the control-ready per-image measurement
        # before temporal world filtering. The detector-only result is retained
        # in a separate diagnostic series.
        raw_pose = frame.detection_pose_in_base
        detector_pose = getattr(
            frame,
            "detector_pose_in_base",
            raw_pose,
        )
        detection = getattr(frame, "detection", None)

        if detector_pose is not None:
            detector_position_error, detector_yaw_error = self._pose_error(
                detector_pose,
                truth.pallet_pose_in_base,
            )
            self.detector_raw_position_errors.append(
                detector_position_error
            )
            self.detector_raw_yaw_errors.append(detector_yaw_error)

        if raw_pose is not None:
            position_error, yaw_error = self._pose_error(
                raw_pose, truth.pallet_pose_in_base
            )
            self.raw_position_errors.append(position_error)
            self.raw_yaw_errors.append(yaw_error)
            if (
                position_error
                > self.config.outlier_position_threshold_m
                or yaw_error
                > self.config.outlier_yaw_threshold_deg
            ):
                self.raw_outlier_count += 1
            if detection is not None:
                self.confidences.append(float(detection.confidence))
                if detection.reprojection_error_px is not None:
                    self.reprojection_errors.append(
                        float(detection.reprojection_error_px)
                    )

        status = str(getattr(diagnostics, "status", ""))
        if status == "innovation_rejected":
            self.innovation_rejected_count += max(1, raw_delta)

        if diagnostics.pose_source in (
            "rgb_pockets",
            "rgb_pocket_world_hold",
        ):
            position_error, yaw_error = self._pose_error(
                frame.observation.pallet_pose_in_base,
                truth.pallet_pose_in_base,
            )
            self.fused_position_errors.append(position_error)
            self.fused_yaw_errors.append(yaw_error)

            # Event-level safety audit. V8.1.3.3 incremented this counter on
            # every 2 ms hold frame while the status string remained
            # "vision_accepted", producing impossible six-digit totals.
            if control_delta > 0:
                self.control_accepted_measurement_count += control_delta
                if (
                    position_error
                    > self.config.outlier_position_threshold_m
                    or yaw_error
                    > self.config.outlier_yaw_threshold_deg
                ):
                    self.control_accepted_outlier_count += control_delta
                if (
                    position_error
                    > self.config.severe_outlier_position_threshold_m
                    or yaw_error
                    > self.config.severe_outlier_yaw_threshold_deg
                ):
                    self.control_accepted_severe_outlier_count += (
                        control_delta
                    )

        self.detections_before_insert = int(
            getattr(
                diagnostics,
                "detection_count_before_insert",
                self.detections_before_insert,
            )
        )
        self.ready_before_insert = bool(
            self.ready_before_insert
            or getattr(
                diagnostics,
                "preinsert_ready_achieved",
                False,
            )
            or (
                state in self.config.opportunity_states
                and getattr(
                    diagnostics,
                    "ready_for_insert",
                    False,
                )
            )
        )

    def metrics(self) -> PickupVisionQualityMetrics:
        raw_count = len(self.raw_position_errors)
        detector_raw_count = len(self.detector_raw_position_errors)
        fused_count = len(self.fused_position_errors)
        opportunity_count = sum(self.opportunity_count_by_state.values())
        opportunity_detections = sum(
            self.opportunity_detection_count_by_state.values()
        )

        return PickupVisionQualityMetrics(
            raw_detection_count=raw_count,
            raw_position_rmse_m=(
                math.sqrt(
                    sum(value * value for value in self.raw_position_errors)
                    / raw_count
                )
                if raw_count
                else None
            ),
            raw_yaw_rmse_deg=(
                math.sqrt(
                    sum(value * value for value in self.raw_yaw_errors)
                    / raw_count
                )
                if raw_count
                else None
            ),
            raw_position_p95_m=_percentile(
                self.raw_position_errors, self.config.percentile
            ),
            raw_yaw_p95_deg=_percentile(
                self.raw_yaw_errors, self.config.percentile
            ),
            detector_raw_detection_count=detector_raw_count,
            detector_raw_position_rmse_m=(
                math.sqrt(
                    sum(
                        value * value
                        for value in self.detector_raw_position_errors
                    )
                    / detector_raw_count
                )
                if detector_raw_count
                else None
            ),
            detector_raw_yaw_rmse_deg=(
                math.sqrt(
                    sum(
                        value * value
                        for value in self.detector_raw_yaw_errors
                    )
                    / detector_raw_count
                )
                if detector_raw_count
                else None
            ),
            detector_raw_position_p95_m=_percentile(
                self.detector_raw_position_errors,
                self.config.percentile,
            ),
            detector_raw_yaw_p95_deg=_percentile(
                self.detector_raw_yaw_errors,
                self.config.percentile,
            ),
            fused_frame_count=fused_count,
            fused_position_rmse_m=(
                math.sqrt(
                    sum(value * value for value in self.fused_position_errors)
                    / fused_count
                )
                if fused_count
                else None
            ),
            fused_yaw_rmse_deg=(
                math.sqrt(
                    sum(value * value for value in self.fused_yaw_errors)
                    / fused_count
                )
                if fused_count
                else None
            ),
            fused_position_p95_m=_percentile(
                self.fused_position_errors, self.config.percentile
            ),
            fused_yaw_p95_deg=_percentile(
                self.fused_yaw_errors, self.config.percentile
            ),
            opportunity_count=opportunity_count,
            opportunity_raw_detection_count=opportunity_detections,
            opportunity_detection_rate=(
                opportunity_detections / opportunity_count
                if opportunity_count
                else 0.0
            ),
            opportunity_count_by_state=dict(
                self.opportunity_count_by_state
            ),
            opportunity_detection_count_by_state=dict(
                self.opportunity_detection_count_by_state
            ),
            raw_detection_rate_by_state={
                state: self._rate(
                    self.sample_count_by_state,
                    self.raw_detection_count_by_state,
                    state,
                )
                for state in self.sample_count_by_state
            },
            control_detection_rate_by_state={
                state: self._rate(
                    self.sample_count_by_state,
                    self.control_detection_count_by_state,
                    state,
                )
                for state in self.sample_count_by_state
            },
            detection_acquired=bool(
                sum(self.control_detection_count_by_state.values())
            ),
            first_detection_seconds=self.first_detection_seconds,
            first_detection_state=self.first_detection_state,
            longest_detection_streak_seconds=(
                self.longest_detection_streak / self.update_hz
            ),
            last_detection_distance_m=self.last_detection_distance_m,
            detections_before_insert=self.detections_before_insert,
            ready_before_insert=self.ready_before_insert,
            raw_outlier_count=self.raw_outlier_count,
            innovation_rejected_count=self.innovation_rejected_count,
            measurement_guide_rejected_count=(
                self.measurement_guide_rejected_count
            ),
            control_accepted_measurement_count=(
                self.control_accepted_measurement_count
            ),
            control_accepted_outlier_count=(
                self.control_accepted_outlier_count
            ),
            control_accepted_outlier_rate=(
                self.control_accepted_outlier_count
                / self.control_accepted_measurement_count
                if self.control_accepted_measurement_count
                else 0.0
            ),
            control_accepted_severe_outlier_count=(
                self.control_accepted_severe_outlier_count
            ),
            control_accepted_severe_outlier_rate=(
                self.control_accepted_severe_outlier_count
                / self.control_accepted_measurement_count
                if self.control_accepted_measurement_count
                else 0.0
            ),
            average_confidence=(
                sum(self.confidences) / len(self.confidences)
                if self.confidences
                else None
            ),
            maximum_reprojection_error_px=(
                max(self.reprojection_errors)
                if self.reprojection_errors
                else None
            ),
            sample_count_by_state=dict(self.sample_count_by_state),
            raw_detection_count_by_state=dict(
                self.raw_detection_count_by_state
            ),
            control_detection_count_by_state=dict(
                self.control_detection_count_by_state
            ),
        )
