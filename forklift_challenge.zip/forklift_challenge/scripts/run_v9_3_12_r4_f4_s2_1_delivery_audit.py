"""Run the S2.1 replay and freeze-decision toolchain in one reproducible command."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from scripts.analyze_v9_3_12_r4_f4_s2_conflict_guard import analyze, _render
from scripts.evaluate_v9_3_12_r4_f4_s2_freeze import evaluate, render


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("batch", type=Path, help="S2 qualification batch directory")
    parser.add_argument("--output-dir", type=Path, help="Defaults to <batch>/s2_1_delivery_audit")
    args = parser.parse_args()
    batch = args.batch.expanduser().resolve()
    output = (args.output_dir or (batch / "s2_1_delivery_audit")).expanduser().resolve()
    summary_path = batch / "summary.json"
    try:
        replay = analyze(batch)
        summary = json.loads(summary_path.read_text(encoding="utf-8"))
        freeze = evaluate(summary, str(summary_path))
    except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
        parser.error(str(exc))

    output.mkdir(parents=True, exist_ok=True)
    (output / "S2_1_CONFLICT_REPLAY.json").write_text(json.dumps(replay, indent=2), encoding="utf-8")
    (output / "S2_1_CONFLICT_REPLAY.md").write_text(_render(replay) + "\n", encoding="utf-8")
    (output / "S2_1_FREEZE_DECISION.json").write_text(json.dumps(freeze, indent=2), encoding="utf-8")
    (output / "S2_1_FREEZE_DECISION.md").write_text(render(freeze), encoding="utf-8")
    receipt = {
        "schema": "v9_3_12_r4_f4_s2_1_delivery_audit_v1",
        "batch": str(batch),
        "replay_gate": replay["expected_gate"],
        "freeze_decision": freeze["decision"],
        "algorithm_files_modified": False,
    }
    (output / "S2_1_DELIVERY_RECEIPT.json").write_text(json.dumps(receipt, indent=2), encoding="utf-8")
    print(f"Replay gate: {replay['expected_gate']}")
    print(f"Freeze decision: {freeze['decision']}")
    print(f"Reports: {output}")
    return 0 if freeze["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
