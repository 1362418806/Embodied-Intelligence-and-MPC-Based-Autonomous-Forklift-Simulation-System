"""Render validation, retry and GLFW-context diagnostics."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import warnings
from typing import Any, Mapping

import numpy as np


@dataclass(frozen=True)
class RenderHealthConfig:
    maximum_retries: int
    minimum_frame_standard_deviation: float
    capture_context_warnings: bool

    @classmethod
    def from_mapping(
        cls, values: Mapping[str, Any] | None
    ) -> "RenderHealthConfig":
        values = values or {}
        result = cls(
            maximum_retries=int(values.get("maximum_retries", 1)),
            minimum_frame_standard_deviation=float(
                values.get("minimum_frame_standard_deviation", 0.5)
            ),
            capture_context_warnings=bool(
                values.get("capture_context_warnings", True)
            ),
        )
        if result.maximum_retries < 0:
            raise ValueError("maximum_retries must be non-negative")
        if result.minimum_frame_standard_deviation < 0.0:
            raise ValueError(
                "minimum_frame_standard_deviation must be non-negative"
            )
        return result


@dataclass(frozen=True)
class RenderHealthMetrics:
    attempt_count: int
    retry_count: int
    failure_count: int
    invalid_frame_count: int
    context_warning_count: int
    exception_count: int
    channel_failures: dict[str, int]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class RenderHealthTracker:
    def __init__(self, config: RenderHealthConfig) -> None:
        self.config = config
        self.attempt_count = 0
        self.retry_count = 0
        self.failure_count = 0
        self.invalid_frame_count = 0
        self.context_warning_count = 0
        self.exception_count = 0
        self.channel_failures: dict[str, int] = {}

    @classmethod
    def from_mapping(
        cls, values: Mapping[str, Any] | None
    ) -> "RenderHealthTracker":
        return cls(RenderHealthConfig.from_mapping(values))

    def _valid(self, image) -> bool:
        if not isinstance(image, np.ndarray):
            return False
        if image.ndim != 3 or image.shape[2] != 3:
            return False
        if image.size == 0 or not np.isfinite(image).all():
            return False
        return (
            float(np.std(image))
            >= self.config.minimum_frame_standard_deviation
        )

    @staticmethod
    def _is_context_warning(message: str) -> bool:
        lowered = message.lower()
        return (
            "failed to make context current" in lowered
            or "wgl:" in lowered
            or "glfwerror" in lowered
        )

    def render(self, renderer, data, camera_name: str, *, channel: str):
        for attempt_index in range(self.config.maximum_retries + 1):
            self.attempt_count += 1
            image = None
            caught_messages: list[str] = []
            try:
                with warnings.catch_warnings(record=True) as caught:
                    warnings.simplefilter("always")
                    image = renderer.render(data, camera_name)
                caught_messages = [str(item.message) for item in caught]
            except Exception:
                self.exception_count += 1

            if self.config.capture_context_warnings:
                self.context_warning_count += sum(
                    self._is_context_warning(message)
                    for message in caught_messages
                )

            if self._valid(image):
                return image

            self.invalid_frame_count += 1
            if attempt_index < self.config.maximum_retries:
                self.retry_count += 1

        self.failure_count += 1
        self.channel_failures[channel] = (
            self.channel_failures.get(channel, 0) + 1
        )
        return None

    def metrics(self) -> RenderHealthMetrics:
        return RenderHealthMetrics(
            attempt_count=self.attempt_count,
            retry_count=self.retry_count,
            failure_count=self.failure_count,
            invalid_frame_count=self.invalid_frame_count,
            context_warning_count=self.context_warning_count,
            exception_count=self.exception_count,
            channel_failures=dict(self.channel_failures),
        )

    def to_dict(self) -> dict[str, Any]:
        return self.metrics().to_dict()
