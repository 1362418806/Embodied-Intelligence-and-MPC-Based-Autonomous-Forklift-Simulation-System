"""Offline trace analysis for V9.3.12-R4-E fresh-RGB yaw closure.

Ground truth is read only here, after the run, for diagnosis. Runtime control
never consumes these truth fields.
"""
from __future__ import annotations
import argparse, json, math
from pathlib import Path


def wrap(a: float) -> float:
    return (float(a) + math.pi) % (2.0 * math.pi) - math.pi


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('trace', type=Path)
    ap.add_argument('--output-json', type=Path)
    args = ap.parse_args()
    records=[json.loads(x) for x in args.trace.read_text(encoding='utf-8').splitlines() if x.strip()]
    events=[]
    settle_frames=0
    for row in records:
        dec=row.get('decision',{})
        status=str(dec.get('status',''))
        if 'strict-evidence settle' in status:
            settle_frames += 1
        if 'R4-E fresh-RGB yaw closure' in status or 'R4-E post-motion RGB settle' in status:
            gt=row.get('ground_truth_observation',{})
            pallet=gt.get('pallet_pose_in_base',{})
            target=gt.get('placement_pose_in_base',{})
            truth_yaw=None
            truth_pos=None
            if pallet and target:
                truth_yaw=math.degrees(wrap(float(target['yaw'])-float(pallet['yaw'])))
                truth_pos=math.hypot(float(target['x'])-float(pallet['x']), float(target['y'])-float(pallet['y']))
            events.append({
                'sim_time': gt.get('sim_time'),
                'status': status,
                'estimated_position_m': dec.get('placement_precision_filtered_position_error_m'),
                'estimated_yaw_deg': dec.get('placement_precision_filtered_yaw_error_deg'),
                'truth_position_m_diagnostic_only': truth_pos,
                'truth_yaw_deg_diagnostic_only': truth_yaw,
                'rgb_updates': dec.get('terminal_load_reacquisition_update_count'),
                'observer_yaw_sigma_deg': dec.get('placement_carried_observer_yaw_std_deg'),
                'target_fast_slow_yaw_disagreement_deg': dec.get('placement_target_fast_slow_yaw_disagreement_deg'),
                'closure_phase': dec.get('placement_fresh_rgb_yaw_closure_phase'),
                'predicted_improvement_deg': dec.get('placement_fresh_rgb_yaw_closure_last_predicted_yaw_improvement_deg'),
                'measured_improvement_deg': dec.get('placement_fresh_rgb_yaw_closure_last_measured_yaw_improvement_deg'),
            })
    last=records[-1].get('decision',{}) if records else {}
    result={
        'event_count': len(events),
        'strict_evidence_settle_frames': settle_frames,
        'final_settle_count': last.get('placement_strict_recovery_final_settle_count'),
        'closure_search_count': last.get('placement_fresh_rgb_yaw_closure_search_count'),
        'closure_activation_count': last.get('placement_fresh_rgb_yaw_closure_activation_count'),
        'closure_feedback_reject_count': last.get('placement_fresh_rgb_yaw_closure_feedback_reject_count'),
        'last_predicted_improvement_deg': last.get('placement_fresh_rgb_yaw_closure_last_predicted_yaw_improvement_deg'),
        'last_measured_improvement_deg': last.get('placement_fresh_rgb_yaw_closure_last_measured_yaw_improvement_deg'),
        'events': events,
    }
    print(json.dumps(result, indent=2, ensure_ascii=False))
    if args.output_json:
        args.output_json.parent.mkdir(parents=True, exist_ok=True)
        args.output_json.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding='utf-8')
    return 0

if __name__=='__main__':
    raise SystemExit(main())
