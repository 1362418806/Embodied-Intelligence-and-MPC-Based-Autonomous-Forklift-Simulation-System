"""Static audit for V9.3.12-R4-E1 Post-Closure Basin Ownership."""
from pathlib import Path
import ast, yaml
ROOT=Path(__file__).resolve().parents[1]
fsm=(ROOT/"task/pickup_state_machine.py").read_text(encoding="utf-8")
micro=(ROOT/"control/terminal_micro_primitives.py").read_text(encoding="utf-8")
cfg=yaml.safe_load((ROOT/"configs/vehicle_v9_3_12_r4_e1.yaml").read_text(encoding="utf-8"))
ast.parse(fsm); ast.parse(micro)
weak=cfg["perception"]["terminal_autonomy_overrides"]["weak_guide"]
checks=[
 ("ownership enabled", weak["placement_post_closure_basin_ownership_enabled"]==1.0),
 ("hard predicted position cap 10cm", abs(weak["placement_post_closure_mpc_predicted_position_limit_m"]-0.10)<1e-12),
 ("continuation gate <=9.5cm", weak["placement_post_closure_continuation_position_gate_m"]<=0.095+1e-12),
 ("strict position unchanged", abs(weak["placement_strict_release_position_limit_m"]-0.095)<1e-12),
 ("strict yaw unchanged", abs(weak["placement_strict_release_yaw_limit_rad"]-0.08028514559173916)<1e-12),
 ("terminal budget unchanged", abs(weak["placement_terminal_budget_seconds"]-90.0)<1e-12),
 ("consensus release authority off", weak["placement_certified_basin_consensus_release_authority"]==0.0),
 ("MPC veto source present", "R4-E1 post-closure MPC veto" in fsm),
 ("certification handoff source present", "certification_handoff_ready" in fsm),
 ("continuation override source present", "position_gate_override_m" in fsm and "placement_post_closure_continuation_position_gate_m" in fsm),
 ("total candidate telemetry present", "total_candidate_count" in micro and "no_candidate_search_count" in micro),
]
failed=False
for name,ok in checks:
    print(("PASS" if ok else "FAIL"),name)
    failed|=not ok
print("R4-E1 audit", "FAIL" if failed else "PASS")
raise SystemExit(2 if failed else 0)
