"""Physical pallet geometry and stability checks for forklift_v2.xml."""

from __future__ import annotations

import math
from pathlib import Path

import mujoco
import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = PROJECT_ROOT / "assets" / "forklift" / "forklift_v2.xml"


def load_model() -> tuple[mujoco.MjModel, mujoco.MjData]:
    model = mujoco.MjModel.from_xml_path(str(MODEL_PATH))
    data = mujoco.MjData(model)
    mujoco.mj_forward(model, data)
    return model, data


def named_id(model: mujoco.MjModel, object_type: mujoco.mjtObj, name: str) -> int:
    object_id = mujoco.mj_name2id(model, object_type, name)
    assert object_id >= 0, f"Missing MuJoCo object: {name}"
    return object_id


def test_v2_model_compiles_and_contains_pickup_objects() -> None:
    model, _ = load_model()

    for name in (
        "forklift_free",
        "pallet_load_free",
        "lift_joint",
        "rear_left_steer_joint",
        "rear_right_steer_joint",
    ):
        named_id(model, mujoco.mjtObj.mjOBJ_JOINT, name)

    for name in (
        "left_fork",
        "right_fork",
        "pallet_center_runner",
        "pallet_left_runner",
        "pallet_right_runner",
        "pallet_deck",
        "cargo_box",
        "placement_zone",
    ):
        named_id(model, mujoco.mjtObj.mjOBJ_GEOM, name)

    for name in ("left_pocket_center", "right_pocket_center", "pallet_center"):
        named_id(model, mujoco.mjtObj.mjOBJ_SITE, name)


def test_forks_fit_horizontally_between_pallet_runners() -> None:
    model, data = load_model()

    left_fork = named_id(model, mujoco.mjtObj.mjOBJ_GEOM, "left_fork")
    right_fork = named_id(model, mujoco.mjtObj.mjOBJ_GEOM, "right_fork")
    center_runner = named_id(
        model, mujoco.mjtObj.mjOBJ_GEOM, "pallet_center_runner"
    )
    left_runner = named_id(model, mujoco.mjtObj.mjOBJ_GEOM, "pallet_left_runner")
    right_runner = named_id(model, mujoco.mjtObj.mjOBJ_GEOM, "pallet_right_runner")

    left_fork_min = float(data.geom_xpos[left_fork][1] - model.geom_size[left_fork][1])
    left_fork_max = float(data.geom_xpos[left_fork][1] + model.geom_size[left_fork][1])
    right_fork_min = float(data.geom_xpos[right_fork][1] - model.geom_size[right_fork][1])
    right_fork_max = float(data.geom_xpos[right_fork][1] + model.geom_size[right_fork][1])

    center_min = float(data.geom_xpos[center_runner][1] - model.geom_size[center_runner][1])
    center_max = float(data.geom_xpos[center_runner][1] + model.geom_size[center_runner][1])
    left_runner_min = float(data.geom_xpos[left_runner][1] - model.geom_size[left_runner][1])
    right_runner_max = float(data.geom_xpos[right_runner][1] + model.geom_size[right_runner][1])

    clearance = 0.015
    assert left_fork_min > center_max + clearance
    assert left_fork_max < left_runner_min - clearance
    assert right_fork_max < center_min - clearance
    assert right_fork_min > right_runner_max + clearance


def test_forks_fit_vertically_inside_pallet_pockets() -> None:
    model, data = load_model()

    left_fork = named_id(model, mujoco.mjtObj.mjOBJ_GEOM, "left_fork")
    center_runner = named_id(
        model, mujoco.mjtObj.mjOBJ_GEOM, "pallet_center_runner"
    )
    deck = named_id(model, mujoco.mjtObj.mjOBJ_GEOM, "pallet_deck")

    fork_bottom = float(data.geom_xpos[left_fork][2] - model.geom_size[left_fork][2])
    fork_top = float(data.geom_xpos[left_fork][2] + model.geom_size[left_fork][2])
    runner_top = float(
        data.geom_xpos[center_runner][2] + model.geom_size[center_runner][2]
    )
    deck_bottom = float(data.geom_xpos[deck][2] - model.geom_size[deck][2])

    clearance = 0.015
    assert fork_bottom > runner_top + clearance
    assert fork_top < deck_bottom - clearance


def test_pallet_load_settles_upright_without_nan() -> None:
    model, data = load_model()
    load_joint = named_id(model, mujoco.mjtObj.mjOBJ_JOINT, "pallet_load_free")
    qpos_address = int(model.jnt_qposadr[load_joint])

    for _ in range(int(2.0 / model.opt.timestep)):
        mujoco.mj_step(model, data)

    z = float(data.qpos[qpos_address + 2])
    w, x, y, zq = data.qpos[qpos_address + 3 : qpos_address + 7]
    roll = math.atan2(2.0 * (w * x + y * zq), 1.0 - 2.0 * (x * x + y * y))
    pitch_argument = max(-1.0, min(1.0, 2.0 * (w * y - zq * x)))
    pitch = math.asin(pitch_argument)

    assert -0.03 <= z <= 0.08
    assert abs(math.degrees(roll)) < 5.0
    assert abs(math.degrees(pitch)) < 5.0
    assert np.isfinite(data.qpos).all()
    assert np.isfinite(data.qvel).all()


def test_v2_sensors_and_visual_goal_are_configured() -> None:
    model, _ = load_model()

    for name in (
        "fork_tip_position",
        "pallet_position",
        "pallet_orientation",
        "lift_position_sensor",
    ):
        named_id(model, mujoco.mjtObj.mjOBJ_SENSOR, name)

    goal_id = named_id(model, mujoco.mjtObj.mjOBJ_GEOM, "placement_zone")
    assert int(model.geom_contype[goal_id]) == 0
    assert int(model.geom_conaffinity[goal_id]) == 0
