"""V9.3 probabilistic carried-load observer.

The pallet is treated as approximately rigid with respect to the forklift once
VERIFY_LIFT succeeds, but the transform is *not* hard-latched forever.  A slow
probabilistic track is continuously updated from gated measurements while a
faster EMA track is retained for disagreement / release-consensus checks.

This module never consumes simulator truth and never applies a fixed geometric
compensation or historical bias correction.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
import statistics

from control.docking_controller import wrap_angle
from interfaces.observation import Pose3D


@dataclass(frozen=True)
class CarriedLoadObserverConfig:
    initial_position_sigma_m: float
    initial_yaw_sigma_rad: float
    measurement_position_sigma_m: float
    measurement_yaw_sigma_rad: float
    process_position_sigma_m: float
    process_yaw_sigma_rad: float
    minimum_position_sigma_m: float
    minimum_yaw_sigma_rad: float
    position_innovation_gate_m: float
    yaw_innovation_gate_rad: float
    fast_alpha: float

    def validate(self) -> None:
        positive = (
            self.initial_position_sigma_m,
            self.initial_yaw_sigma_rad,
            self.measurement_position_sigma_m,
            self.measurement_yaw_sigma_rad,
            self.minimum_position_sigma_m,
            self.minimum_yaw_sigma_rad,
            self.position_innovation_gate_m,
            self.yaw_innovation_gate_rad,
        )
        if any(value <= 0.0 for value in positive):
            raise ValueError("carried-load observer sigmas/gates must be positive")
        if self.process_position_sigma_m < 0.0 or self.process_yaw_sigma_rad < 0.0:
            raise ValueError("carried-load observer process noise must be non-negative")
        if not 0.0 < self.fast_alpha <= 1.0:
            raise ValueError("carried-load observer fast_alpha must be in (0,1]")


@dataclass(frozen=True)
class CarriedLoadObserverSnapshot:
    active: bool
    pose: Pose3D | None
    fast_pose: Pose3D | None
    position_sigma_m: float
    yaw_sigma_rad: float
    sample_count: int
    update_count: int
    rejection_count: int
    disagreement_position_m: float
    disagreement_yaw_rad: float


class ProbabilisticCarriedLoadObserver:
    """Slow rigid prior + fast live measurement track.

    The state is intentionally tiny (x/y/yaw relative to the forklift).  Roll,
    pitch and z are carried through from the most recent accepted measurement.
    A scalar covariance is used for x/y and one for yaw.  This keeps the module
    deterministic and dependency-free while still exposing the uncertainty and
    innovation interfaces needed by release qualification and later MPC model
    identification.
    """

    def __init__(self, config: CarriedLoadObserverConfig) -> None:
        config.validate()
        self.config = config
        self.reset()

    def reset(self) -> None:
        self._pose: Pose3D | None = None
        self._fast_pose: Pose3D | None = None
        self._position_var = float(self.config.initial_position_sigma_m) ** 2
        self._yaw_var = float(self.config.initial_yaw_sigma_rad) ** 2
        self._sample_count = 0
        self._update_count = 0
        self._rejection_count = 0

    @staticmethod
    def _circular_mean(values: list[float]) -> float:
        return math.atan2(
            sum(math.sin(value) for value in values),
            sum(math.cos(value) for value in values),
        )

    def initialize(
        self,
        samples: list[Pose3D],
        *,
        initial_yaw_sigma_override_rad: float | None = None,
    ) -> bool:
        """Initialize the observer from one or more carried-load poses.

        R4-F3 permits a quality-qualified late-INSERT yaw anchor to carry its
        own conservative yaw covariance into the carried-load observer.  The
        override never bypasses the configured minimum yaw sigma and does not
        affect legacy callers, which continue to use ``initial_yaw_sigma_rad``.
        """
        if not samples:
            return False
        xs = [float(item.x) for item in samples]
        ys = [float(item.y) for item in samples]
        yaws = [float(item.yaw) for item in samples]
        x = statistics.median(xs)
        y = statistics.median(ys)
        yaw = self._circular_mean(yaws)
        last = samples[-1]
        spread_position = math.hypot(
            statistics.pstdev(xs) if len(xs) > 1 else 0.0,
            statistics.pstdev(ys) if len(ys) > 1 else 0.0,
        )
        yaw_deltas = [wrap_angle(value - yaw) for value in yaws]
        spread_yaw = statistics.pstdev(yaw_deltas) if len(yaw_deltas) > 1 else 0.0
        position_sigma = max(
            self.config.minimum_position_sigma_m,
            self.config.initial_position_sigma_m,
            spread_position,
        )
        requested_yaw_sigma = (
            self.config.initial_yaw_sigma_rad
            if initial_yaw_sigma_override_rad is None
            else float(initial_yaw_sigma_override_rad)
        )
        if requested_yaw_sigma <= 0.0:
            raise ValueError("initial yaw sigma override must be positive")
        yaw_sigma = max(
            self.config.minimum_yaw_sigma_rad,
            requested_yaw_sigma,
            spread_yaw,
        )
        pose = Pose3D(
            float(x), float(y), float(last.z), float(last.roll),
            float(last.pitch), float(yaw),
        )
        self._pose = pose
        self._fast_pose = pose
        self._position_var = position_sigma * position_sigma
        self._yaw_var = yaw_sigma * yaw_sigma
        self._sample_count = len(samples)
        self._update_count = 0
        self._rejection_count = 0
        return True

    def _update_fast(self, measurement: Pose3D) -> None:
        if self._fast_pose is None:
            self._fast_pose = measurement
            return
        a = self.config.fast_alpha
        old = self._fast_pose
        yaw = wrap_angle(float(old.yaw) + a * wrap_angle(float(measurement.yaw) - float(old.yaw)))
        self._fast_pose = Pose3D(
            (1.0 - a) * float(old.x) + a * float(measurement.x),
            (1.0 - a) * float(old.y) + a * float(measurement.y),
            (1.0 - a) * float(old.z) + a * float(measurement.z),
            (1.0 - a) * float(old.roll) + a * float(measurement.roll),
            (1.0 - a) * float(old.pitch) + a * float(measurement.pitch),
            yaw,
        )

    def _update_fast_position_only(self, measurement: Pose3D) -> None:
        """Update translational fast-track state without manufacturing yaw evidence.

        V9.3.12-R4-F2 uses terminal silhouette reacquisition as an x/y/z
        measurement only.  The detector is prior-guided in yaw and therefore
        cannot be allowed to drag either the slow or fast yaw track toward its
        own prior.  Roll/pitch are held with yaw for the same reason.
        """
        if self._fast_pose is None:
            return
        a = self.config.fast_alpha
        old = self._fast_pose
        self._fast_pose = Pose3D(
            (1.0 - a) * float(old.x) + a * float(measurement.x),
            (1.0 - a) * float(old.y) + a * float(measurement.y),
            (1.0 - a) * float(old.z) + a * float(measurement.z),
            float(old.roll),
            float(old.pitch),
            float(old.yaw),
        )

    def update(
        self,
        measurement: Pose3D,
        *,
        measurement_position_sigma_m: float | None = None,
        measurement_yaw_sigma_rad: float | None = None,
        position_innovation_gate_m: float | None = None,
        yaw_innovation_gate_rad: float | None = None,
    ) -> bool:
        """Innovation-gated observer update.

        V9.3.12 allows a terminal RGB reacquisition measurement to carry its
        own calibrated measurement noise and gate.  Existing callers omit the
        keyword arguments and retain the exact pre-V9.3.12 behaviour.
        """
        if self._pose is None:
            return self.initialize([measurement])

        pose = self._pose
        dx = float(measurement.x) - float(pose.x)
        dy = float(measurement.y) - float(pose.y)
        position_innovation = math.hypot(dx, dy)
        yaw_innovation = wrap_angle(float(measurement.yaw) - float(pose.yaw))
        position_gate = (
            self.config.position_innovation_gate_m
            if position_innovation_gate_m is None
            else float(position_innovation_gate_m)
        )
        yaw_gate = (
            self.config.yaw_innovation_gate_rad
            if yaw_innovation_gate_rad is None
            else float(yaw_innovation_gate_rad)
        )
        if position_gate <= 0.0 or yaw_gate <= 0.0:
            raise ValueError("carried-load observer innovation gates must be positive")

        # Keep the fast track useful for disagreement diagnostics, but do not
        # let severe outliers enter either track.
        if position_innovation > position_gate or abs(yaw_innovation) > yaw_gate:
            self._rejection_count += 1
            return False

        self._update_fast(measurement)

        # Rigid-body prior: only a small process variance is injected between
        # measurements.  Covariance floors prevent artificial overconfidence.
        self._position_var += self.config.process_position_sigma_m ** 2
        self._yaw_var += self.config.process_yaw_sigma_rad ** 2
        pos_sigma = (
            self.config.measurement_position_sigma_m
            if measurement_position_sigma_m is None
            else float(measurement_position_sigma_m)
        )
        yaw_sigma = (
            self.config.measurement_yaw_sigma_rad
            if measurement_yaw_sigma_rad is None
            else float(measurement_yaw_sigma_rad)
        )
        if pos_sigma <= 0.0 or yaw_sigma <= 0.0:
            raise ValueError("carried-load observer measurement sigmas must be positive")
        r_pos = pos_sigma ** 2
        r_yaw = yaw_sigma ** 2
        k_pos = self._position_var / (self._position_var + r_pos)
        k_yaw = self._yaw_var / (self._yaw_var + r_yaw)
        x = float(pose.x) + k_pos * dx
        y = float(pose.y) + k_pos * dy
        yaw = wrap_angle(float(pose.yaw) + k_yaw * yaw_innovation)
        self._position_var = max(
            self.config.minimum_position_sigma_m ** 2,
            (1.0 - k_pos) * self._position_var,
        )
        self._yaw_var = max(
            self.config.minimum_yaw_sigma_rad ** 2,
            (1.0 - k_yaw) * self._yaw_var,
        )
        self._pose = Pose3D(
            x, y, float(measurement.z), float(measurement.roll),
            float(measurement.pitch), yaw,
        )
        self._update_count += 1
        return True

    def update_position_only(
        self,
        measurement: Pose3D,
        *,
        measurement_position_sigma_m: float | None = None,
        position_innovation_gate_m: float | None = None,
    ) -> bool:
        """Innovation-gated translation-only update.

        This path intentionally leaves yaw mean, yaw covariance and yaw fast
        track unchanged.  It is used when an RGB terminal detector has useful
        translational observability but its yaw is generated by a prior-guided
        silhouette fit and is therefore not independent evidence.
        """
        if self._pose is None:
            # Position-only evidence cannot safely initialize yaw.  All current
            # callers enter here only after VERIFY_LIFT has initialized the
            # carried-load observer from a trusted seed.
            return False

        pose = self._pose
        dx = float(measurement.x) - float(pose.x)
        dy = float(measurement.y) - float(pose.y)
        position_innovation = math.hypot(dx, dy)
        position_gate = (
            self.config.position_innovation_gate_m
            if position_innovation_gate_m is None
            else float(position_innovation_gate_m)
        )
        if position_gate <= 0.0:
            raise ValueError("carried-load observer position innovation gate must be positive")
        if position_innovation > position_gate:
            self._rejection_count += 1
            return False

        self._update_fast_position_only(measurement)
        self._position_var += self.config.process_position_sigma_m ** 2
        pos_sigma = (
            self.config.measurement_position_sigma_m
            if measurement_position_sigma_m is None
            else float(measurement_position_sigma_m)
        )
        if pos_sigma <= 0.0:
            raise ValueError("carried-load observer position measurement sigma must be positive")
        r_pos = pos_sigma ** 2
        k_pos = self._position_var / (self._position_var + r_pos)
        x = float(pose.x) + k_pos * dx
        y = float(pose.y) + k_pos * dy
        self._position_var = max(
            self.config.minimum_position_sigma_m ** 2,
            (1.0 - k_pos) * self._position_var,
        )
        self._pose = Pose3D(
            x, y, float(measurement.z), float(pose.roll),
            float(pose.pitch), float(pose.yaw),
        )
        self._update_count += 1
        return True

    @property
    def active(self) -> bool:
        return self._pose is not None

    @property
    def pose(self) -> Pose3D | None:
        return self._pose

    @property
    def fast_pose(self) -> Pose3D | None:
        return self._fast_pose

    @property
    def position_sigma_m(self) -> float:
        return math.sqrt(max(0.0, self._position_var)) if self.active else 0.0

    @property
    def yaw_sigma_rad(self) -> float:
        return math.sqrt(max(0.0, self._yaw_var)) if self.active else 0.0

    @property
    def disagreement_position_m(self) -> float:
        if self._pose is None or self._fast_pose is None:
            return 0.0
        return math.hypot(
            float(self._pose.x) - float(self._fast_pose.x),
            float(self._pose.y) - float(self._fast_pose.y),
        )

    @property
    def disagreement_yaw_rad(self) -> float:
        if self._pose is None or self._fast_pose is None:
            return 0.0
        return abs(wrap_angle(float(self._pose.yaw) - float(self._fast_pose.yaw)))

    @property
    def update_count(self) -> int:
        return self._update_count

    @property
    def rejection_count(self) -> int:
        return self._rejection_count

    @property
    def sample_count(self) -> int:
        return self._sample_count

    def snapshot(self) -> CarriedLoadObserverSnapshot:
        return CarriedLoadObserverSnapshot(
            active=self.active,
            pose=self._pose,
            fast_pose=self._fast_pose,
            position_sigma_m=self.position_sigma_m,
            yaw_sigma_rad=self.yaw_sigma_rad,
            sample_count=self._sample_count,
            update_count=self._update_count,
            rejection_count=self._rejection_count,
            disagreement_position_m=self.disagreement_position_m,
            disagreement_yaw_rad=self.disagreement_yaw_rad,
        )
