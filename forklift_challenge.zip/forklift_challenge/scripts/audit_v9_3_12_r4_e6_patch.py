"""Static/invariant audit for V9.3.12-R4-E6 topology/evidence closure."""
from __future__ import annotations

import math
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[1]


def check(name: str, ok: bool) -> None:
    print(f"{'PASS' if ok else 'FAIL'} {name}")
    if not ok:
        raise AssertionError(name)


def main() -> int:
    py_files = [
        ROOT / "task" / "pickup_state_machine.py",
        ROOT / "control" / "terminal_micro_primitives.py",
        ROOT / "control" / "terminal_mpc.py",
        ROOT / "evaluation" / "dual_vision_metrics.py",
        ROOT / "simulator" / "dual_vision_mission_episode.py",
        ROOT / "scripts" / "run_v9_3_12_r4_e6_batch.py",
        ROOT / "scripts" / "analyze_v9_3_12_r4_e6_topology_evidence.py",
        ROOT / "scripts" / "evaluate_v9_3_12_r4_e6_precision_closure.py",
    ]
    for path in py_files:
        compile(path.read_text(encoding="utf-8"), str(path), "exec")
    check("Python syntax", True)

    cfg = yaml.safe_load((ROOT / "configs" / "vehicle_v9_3_12_r4_e6.yaml").read_text(encoding="utf-8"))
    base = cfg["autonomy"]
    weak = cfg["perception"]["terminal_autonomy_overrides"]["weak_guide"]
    state = (ROOT / "task" / "pickup_state_machine.py").read_text(encoding="utf-8")
    micro = (ROOT / "control" / "terminal_micro_primitives.py").read_text(encoding="utf-8")

    check("E6 weak-guide only", base["placement_position_blocker_recenter_enabled"] == 0.0 and weak["placement_position_blocker_recenter_enabled"] == 1.0)
    check("non-retrace topology enabled", weak["placement_position_blocker_recenter_require_non_retrace_topology"] == 1.0)
    check("short S-curve budget", weak["placement_position_blocker_recenter_maximum_total_execution_seconds"] == 4.5)
    check("bounded predicted excursion", weak["placement_position_blocker_recenter_maximum_predicted_excursion_m"] == 0.24)
    check("internal position contract unchanged", weak["placement_strict_release_position_limit_m"] == 0.095)
    check("internal yaw contract unchanged", math.isclose(weak["placement_strict_release_yaw_limit_rad"], math.radians(4.6), rel_tol=1e-9))
    check("terminal budget unchanged", weak["placement_terminal_budget_seconds"] == 90.0)
    check("consensus release authority OFF", weak["placement_certified_basin_consensus_release_authority"] == 0.0)
    check("full-pose rigid-load model retained", "FULL_POSE_RIGID_LOAD" in micro and "_simulate_full_pose_leg" in micro)
    check("retrace topology rejected", "require_non_retrace_topology" in micro and "departure_steering * return_steering >= 0.0" in micro)
    check("fresh return receives departure steering", "departure_steering_rad=float(recenter_plan.departure_steering_rad)" in state)
    check("final evidence lease present", '"FINAL_EVIDENCE_HOLD"' in state)
    check("live strict refresh present", "self._strict_release_certified(" in state and "final_live_strict_attempt_count" in state)
    check("post-return failure invokes macro rollback", '_begin_completed_macro_rollback("FINAL_EVIDENCE_NOT_CERTIFIED")' in state)
    check("completed return is retained for unwind", "_position_blocker_recenter_completed_return_plan" in state)
    check("safe rollback retains basin ownership", "self._post_closure_basin_ownership_active = bool(safe_return)" in state)
    check("decision trace exports E6 telemetry", '"placement_position_blocker_recenter_retrace_candidate_reject_count"' in state and '"placement_position_blocker_recenter_final_live_strict_attempt_count"' in state)
    check("POSITION-to-YAW handoff does not forge blocker", 'self._strict_release_certification_last_blocker = "YAW"' not in state)
    check("release chain not bypassed", "ReleaseDecisionSupervisor" in state and "RELEASE_INTENT executed" in state)
    check("no GT in micro planner", "ground_truth" not in micro.lower())

    print("\nV9.3.12-R4-E6 audit PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
