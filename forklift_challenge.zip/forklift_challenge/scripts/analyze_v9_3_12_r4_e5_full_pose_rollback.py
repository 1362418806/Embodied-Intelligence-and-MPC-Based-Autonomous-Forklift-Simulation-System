"""Analyze V9.3.12-R4-E5 full-pose POSITION recenter and guaranteed rollback traces."""
from __future__ import annotations

import argparse
from collections import Counter
import json
import math
from pathlib import Path


def _time(row: dict) -> float:
    return float((row.get("estimated_observation", {}) or {}).get("sim_time", 0.0))


def _wrap(a: float) -> float:
    return (float(a) + math.pi) % (2.0 * math.pi) - math.pi


def _segment_path_and_yaw(rows: list[dict]) -> tuple[float, float]:
    if len(rows) < 2:
        return 0.0, 0.0
    path = 0.0
    for a, b in zip(rows, rows[1:]):
        pa = (a.get("ground_truth_observation", {}) or {}).get("vehicle_pose_world")
        pb = (b.get("ground_truth_observation", {}) or {}).get("vehicle_pose_world")
        if not pa or not pb:
            continue
        path += math.hypot(float(pb["x"]) - float(pa["x"]), float(pb["y"]) - float(pa["y"]))
    p0 = (rows[0].get("ground_truth_observation", {}) or {}).get("vehicle_pose_world")
    p1 = (rows[-1].get("ground_truth_observation", {}) or {}).get("vehicle_pose_world")
    yaw = 0.0 if not p0 or not p1 else math.degrees(abs(_wrap(float(p1["yaw"]) - float(p0["yaw"]))))
    return float(path), float(yaw)


def _truth_precision(row: dict) -> tuple[float, float] | None:
    gt = row.get("ground_truth_observation", {}) or {}
    pallet = gt.get("pallet_pose_world")
    target = gt.get("placement_pose_world")
    if not pallet or not target:
        return None
    pos = math.hypot(float(pallet["x"]) - float(target["x"]), float(pallet["y"]) - float(target["y"]))
    yaw = math.degrees(abs(_wrap(float(target["yaw"]) - float(pallet["yaw"]))))
    return float(pos), float(yaw)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("trace", type=Path)
    ap.add_argument("--output-json", type=Path)
    ap.add_argument("--output-md", type=Path)
    args = ap.parse_args()

    rows = [json.loads(line) for line in args.trace.read_text(encoding="utf-8").splitlines() if line.strip()]
    phases: Counter[str] = Counter()
    status_events: Counter[str] = Counter()
    first: dict[str, float] = {}
    phase_rows: dict[str, list[dict]] = {}
    active_truth: list[tuple[float, float]] = []

    needles = {
        "selection": "R4-E5 POSITION blocker full-pose recenter selected",
        "depart_presteer_ready": "R4-E5 DEPART presteer READY",
        "fresh_return_selected": "R4-E5 fresh full-pose RETURN selected",
        "return_unavailable_rollback": "R4-E5 fresh RETURN unavailable -> guaranteed rollback",
        "mid_rgb_timeout_rollback": "R4-E5 midpoint RGB timeout -> guaranteed rollback",
        "return_presteer_ready": "R4-E5 RETURN presteer READY",
        "live_strict_capture": "R4-E5 live strict capture",
        "return_timeout_unwind": "R4-E5 RETURN odometry timeout -> unwind+rollback",
        "rollback_presteer_ready": "R4-E5 rollback presteer READY",
        "rollback_complete": "R4-E5 rollback complete",
        "final_feedback": "R4-E5 final feedback",
        "hard_safety_abort": "R4-E5 recenter HARD SAFETY ABORT",
        "release_execute": "RELEASE_INTENT executed",
    }

    for row in rows:
        d = row.get("decision", {}) or {}
        phase = str(d.get("placement_position_blocker_recenter_phase", "IDLE"))
        phases[phase] += 1
        phase_rows.setdefault(phase, []).append(row)
        status = str(d.get("status", ""))
        t = _time(row)
        for key, needle in needles.items():
            if needle in status:
                status_events[key] += 1
                first.setdefault(key, t)
        if phase != "IDLE":
            truth = _truth_precision(row)
            if truth is not None:
                active_truth.append(truth)

    last = (rows[-1].get("decision", {}) or {}) if rows else {}
    depart_path, depart_yaw = _segment_path_and_yaw(phase_rows.get("DEPART", []))
    return_path, return_yaw = _segment_path_and_yaw(phase_rows.get("RETURN", []))
    rollback_path, rollback_yaw = _segment_path_and_yaw(phase_rows.get("ROLLBACK", []))
    unwind_path, unwind_yaw = _segment_path_and_yaw(phase_rows.get("ROLLBACK_RETURN_UNWIND", []))
    final_truth = _truth_precision(rows[-1]) if rows else None

    activation_count = int(last.get("placement_position_blocker_recenter_activation_count", 0))
    full_search = int(last.get("placement_position_blocker_recenter_full_pose_search_count", 0))
    full_return = int(last.get("placement_position_blocker_recenter_full_pose_return_replan_count", 0))
    legacy_search = int(last.get("placement_position_blocker_recenter_legacy_error_space_search_count", 0))
    rollback_count = int(last.get("placement_position_blocker_recenter_rollback_count", 0))
    rollback_success = int(last.get("placement_position_blocker_recenter_rollback_success_count", 0))
    rollback_failure = int(last.get("placement_position_blocker_recenter_rollback_failure_count", 0))
    yaw_closure_full_pose_search = int(last.get("placement_certification_basin_closure_full_pose_search_count", 0))
    yaw_closure_legacy_search = int(last.get("placement_certification_basin_closure_legacy_error_space_search_count", 0))
    strict = bool(last.get("strict_release_certified", False))
    release_count = int(last.get("placement_release_commit_count", 0))

    if release_count > 0:
        diagnosis = "CLOSED_RELEASE_PATH_REACHED"
    elif rollback_failure > 0:
        diagnosis = "ROLLBACK_FAILED_REQUIRES_SAFETY_DIAGNOSIS"
    elif rollback_success > 0:
        diagnosis = "RECENTER_RETURN_FAILED_BUT_GUARANTEED_ROLLBACK_WORKED"
    elif activation_count > 0 and full_return == 0:
        diagnosis = "FULL_POSE_DEPART_RAN_BUT_NO_FRESH_RETURN_REPLAN"
    elif activation_count > 0 and full_return > 0 and int(last.get("placement_position_blocker_recenter_return_candidate_count", 0)) == 0:
        diagnosis = "FRESH_FULL_POSE_RETURN_NOT_CONTROLLABLE_IN_CURRENT_GRID"
    elif activation_count > 0 and strict:
        diagnosis = "STRICT_REACHED_RELEASE_CHAIN_PENDING"
    elif activation_count > 0:
        diagnosis = "FULL_POSE_RECENTER_EXECUTED_STRICT_NOT_REACHED"
    else:
        diagnosis = "E5_NOT_ACTIVATED"

    result = {
        "trace": str(args.trace),
        "samples": len(rows),
        "diagnosis": diagnosis,
        "phase_frame_counts": dict(phases),
        "status_event_counts": dict(status_events),
        "first_event_time_s": first,
        "final_activation_count": activation_count,
        "final_full_pose_search_count": full_search,
        "final_full_pose_return_replan_count": full_return,
        "final_legacy_error_space_search_count": legacy_search,
        "final_return_candidate_count": int(last.get("placement_position_blocker_recenter_return_candidate_count", 0)),
        "final_midpoint_position_deviation_m": float(last.get("placement_position_blocker_recenter_midpoint_position_deviation_m", 0.0)),
        "final_midpoint_yaw_deviation_deg": float(last.get("placement_position_blocker_recenter_midpoint_yaw_deviation_deg", 0.0)),
        "final_mid_rgb_updates": int(last.get("placement_position_blocker_recenter_mid_rgb_updates", 0)),
        "final_final_rgb_updates": int(last.get("placement_position_blocker_recenter_final_rgb_updates", 0)),
        "final_predicted_effective_position_m": float(last.get("placement_position_blocker_recenter_last_predicted_effective_position_m", 0.0)),
        "final_predicted_effective_yaw_deg": float(last.get("placement_position_blocker_recenter_last_predicted_effective_yaw_deg", 0.0)),
        "final_measured_effective_position_m": float(last.get("placement_position_blocker_recenter_last_measured_effective_position_m", 0.0)),
        "final_measured_effective_yaw_deg": float(last.get("placement_position_blocker_recenter_last_measured_effective_yaw_deg", 0.0)),
        "rollback_count": rollback_count,
        "rollback_success_count": rollback_success,
        "rollback_failure_count": rollback_failure,
        "rollback_target_odometry_m": float(last.get("placement_position_blocker_recenter_rollback_target_odometry_m", 0.0)),
        "rollback_odometry_m": float(last.get("placement_position_blocker_recenter_last_rollback_odometry_m", 0.0)),
        "return_unwind_odometry_m": float(last.get("placement_position_blocker_recenter_last_return_unwind_odometry_m", 0.0)),
        "rollback_rgb_updates": int(last.get("placement_position_blocker_recenter_rollback_rgb_updates", 0)),
        "rollback_reason": str(last.get("placement_position_blocker_recenter_rollback_reason", "")),
        "position_to_yaw_handoff_count": int(last.get("placement_position_blocker_recenter_yaw_handoff_count", 0)),
        "position_to_yaw_handoff_ready_final": bool(last.get("placement_position_blocker_recenter_yaw_handoff_ready", False)),
        "yaw_closure_full_pose_search_count": yaw_closure_full_pose_search,
        "yaw_closure_legacy_error_space_search_count": yaw_closure_legacy_search,
        "strict_certified": strict,
        "strict_blocker": str(last.get("strict_release_certification_blocker", "")),
        "release_commit_count": release_count,
        "release_witness_capture_count": int(last.get("release_witness_capture_count", 0)),
        "diagnostic_truth_depart_vehicle_path_m": depart_path,
        "diagnostic_truth_depart_vehicle_yaw_change_deg": depart_yaw,
        "diagnostic_truth_return_vehicle_path_m": return_path,
        "diagnostic_truth_return_vehicle_yaw_change_deg": return_yaw,
        "diagnostic_truth_rollback_vehicle_path_m": rollback_path,
        "diagnostic_truth_rollback_vehicle_yaw_change_deg": rollback_yaw,
        "diagnostic_truth_return_unwind_vehicle_path_m": unwind_path,
        "diagnostic_truth_return_unwind_vehicle_yaw_change_deg": unwind_yaw,
        "diagnostic_truth_min_position_during_e5_m": min((x[0] for x in active_truth), default=None),
        "diagnostic_truth_max_position_during_e5_m": max((x[0] for x in active_truth), default=None),
        "diagnostic_truth_final_position_m": None if final_truth is None else final_truth[0],
        "diagnostic_truth_final_abs_yaw_deg": None if final_truth is None else final_truth[1],
    }

    print("V9.3.12-R4-E5 full-pose/rollback analysis")
    for key, value in result.items():
        print(f"  {key}: {value}")

    if args.output_json:
        args.output_json.parent.mkdir(parents=True, exist_ok=True)
        args.output_json.write_text(json.dumps(result, indent=2), encoding="utf-8")
    if args.output_md:
        args.output_md.parent.mkdir(parents=True, exist_ok=True)
        lines = ["# V9.3.12-R4-E5 Full-Pose / Rollback Analysis", ""]
        lines += [f"- **{key}**: `{value}`" for key, value in result.items()]
        args.output_md.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
