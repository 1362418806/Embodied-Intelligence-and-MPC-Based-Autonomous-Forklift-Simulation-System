"""Run the recommended V8.2 appearance robustness matrix."""
from __future__ import annotations

import argparse
from pathlib import Path
import subprocess
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--episodes", type=int, default=20)
    parser.add_argument("--seed", type=int, default=20260803)
    parser.add_argument("--trace-failures", action="store_true")
    args = parser.parse_args()

    jobs = (
        ("easy", "moderate", "moderate"),
        ("nominal", "moderate", "moderate"),
        ("easy", "finals", "finals"),
        ("easy", "finals", "combined"),
    )
    for difficulty, perception, appearance in jobs:
        command = [
            sys.executable,
            str(PROJECT_ROOT / "scripts" / "run_v8_2_1_batch.py"),
            "--episodes",
            str(args.episodes),
            "--difficulty",
            difficulty,
            "--profile",
            perception,
            "--appearance-profile",
            appearance,
            "--seed",
            str(args.seed),
        ]
        if args.trace_failures:
            command.append("--trace-failures")
        print("\n>", " ".join(command))
        completed = subprocess.run(command, cwd=PROJECT_ROOT)
        if completed.returncode != 0:
            return int(completed.returncode)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
