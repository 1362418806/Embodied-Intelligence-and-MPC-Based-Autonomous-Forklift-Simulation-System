"""Regression tests for V5.1.4 alignment corridor and recovery acceptance."""

from __future__ import annotations

from control.docking_controller import DockingController
from interfaces.observation import ForkliftObservation, Pose3D
from task.pickup_state_machine import (
    PickupParameters,
    PickupState,
    PickupStateMachine,
)


def pose(x=0.0, y=0.0, yaw=0.0):
    return Pose3D(x=x, y=y, z=0.0, roll=0.0, pitch=0.0, yaw=yaw)


def observation(
    sim_time,
    *,
    pallet_x=3.02,
    pallet_y=0.04,
    pallet_yaw=0.04,
    vehicle_x=0.0,
    steering_left=0.0,
    steering_right=0.0,
):
    return ForkliftObservation(
        sim_time=sim_time,
        vehicle_pose_world=pose(vehicle_x),
        vehicle_linear_velocity=(0.0, 0.0, 0.0),
        vehicle_angular_velocity=(0.0, 0.0, 0.0),
        steering_left=steering_left,
        steering_right=steering_right,
        front_wheel_speed_left=0.0,
        front_wheel_speed_right=0.0,
        lift_position=0.04,
        lift_velocity=0.0,
        pallet_pose_world=pose(3.2),
        pallet_pose_in_base=pose(pallet_x, pallet_y, pallet_yaw),
        placement_pose_in_base=pose(5.0, -1.0),
        fork_contact_count=0,
        load_state="GROUND",
    )


def parameters():
    return PickupParameters(
        insertion_lift_target=0.04,
        transport_lift_target=0.30,
        pre_approach_distance=2.85,
        insertion_distance=1.60,
        approach_max_speed=0.28,
        align_max_speed=0.085,
        insertion_max_speed=0.09,
        retreat_speed=-0.18,
        retreat_distance=0.75,
        approach_capture_distance=0.48,
        pre_position_tolerance=0.085,
        pre_lateral_tolerance=0.060,
        pre_yaw_tolerance=0.075,
        insertion_position_tolerance=0.055,
        insertion_lateral_tolerance=0.045,
        insertion_yaw_tolerance=0.060,
        lift_position_tolerance=0.055,
        lift_velocity_tolerance=0.015,
        lifted_minimum_fork_height=0.12,
        verify_lift_seconds=0.60,
        maximum_load_tilt=0.175,
        lower_timeout=4.0,
        approach_timeout=35.0,
        align_timeout=20.0,
        insert_timeout=18.0,
        lift_timeout=8.0,
        retreat_timeout=10.0,
        align_minimum_speed=0.040,
        alignment_hold_seconds=0.22,
        progress_timeout=8.0,
        progress_improvement=0.008,
        recovery_speed=-0.24,
        recovery_distance=0.32,
        recovery_timeout=14.0,
        maximum_recoveries=3,
        overshoot_longitudinal_tolerance=0.22,
        recovery_steering_tolerance=0.14,
        recovery_center_hold_seconds=0.12,
        recovery_center_timeout=6.0,
        recovery_unwind_speed=-0.08,
        recovery_unwind_distance=0.16,
        recovery_minimum_distance=0.26,
        align_handoff_longitudinal_tolerance=0.20,
        align_handoff_lateral_tolerance=0.085,
        align_handoff_yaw_tolerance=0.105,
    )


def machine():
    return PickupStateMachine(
        parameters=parameters(),
        docking_controller=DockingController(
            distance_gain=0.62,
            heading_gain=0.95,
            yaw_gain=0.48,
            lateral_gain=0.28,
            lookahead_distance=1.10,
            maximum_steering=0.28,
            minimum_creep_speed=0.035,
            heading_slowdown_angle=0.62,
            yaw_slowdown_angle=0.46,
            minimum_alignment_scale=0.22,
        ),
    )


def enter_align(sm):
    sm.reset(0.0)
    assert sm.step(observation(0.30, pallet_x=3.30)).state == PickupState.APPROACH
    result = sm.step(observation(0.40, pallet_x=3.02))
    assert result.state == PickupState.ALIGN


def test_corridor_handoff_does_not_require_exact_preapproach_point():
    sm = machine()
    enter_align(sm)
    # Standoff target is about 0.17 m ahead and lane errors are acceptable.
    first = sm.step(observation(0.50, pallet_x=3.02))
    assert first.state == PickupState.ALIGN
    assert first.action.speed_target == 0.0
    second = sm.step(observation(0.75, pallet_x=3.02))
    assert second.state == PickupState.INSERT


def test_small_preapproach_overshoot_can_handoff_to_insert():
    sm = machine()
    enter_align(sm)
    # Target is slightly behind, but the insertion target is still well ahead.
    sm.step(observation(0.50, pallet_x=2.73, pallet_y=0.03, pallet_yaw=0.03))
    result = sm.step(
        observation(0.75, pallet_x=2.73, pallet_y=0.03, pallet_yaw=0.03)
    )
    assert result.state == PickupState.INSERT


def test_large_misaligned_overshoot_still_enters_recovery():
    sm = machine()
    enter_align(sm)
    result = sm.step(
        observation(0.55, pallet_x=2.55, pallet_y=0.30, pallet_yaw=0.20)
    )
    assert result.state == PickupState.RECOVER_REVERSE


def test_partial_recovery_is_accepted_at_timeout():
    sm = machine()
    enter_align(sm)
    sm.step(
        observation(
            0.55,
            pallet_x=2.55,
            pallet_y=0.30,
            pallet_yaw=0.20,
            steering_left=-0.20,
            steering_right=-0.16,
        )
    )
    result = sm.step(
        observation(
            14.60,
            pallet_x=2.55,
            pallet_y=0.30,
            pallet_yaw=0.20,
            vehicle_x=-0.27,
            steering_left=-0.05,
            steering_right=-0.04,
        )
    )
    assert result.state == PickupState.APPROACH
    assert "Partial recovery accepted" in result.status
