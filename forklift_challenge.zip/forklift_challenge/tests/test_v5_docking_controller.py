"""V5 robustness checks for the geometric docking controller."""

from __future__ import annotations

import math

from control.docking_controller import DockingController
from interfaces.observation import Pose3D


def pose(x: float, y: float = 0.0, yaw: float = 0.0) -> Pose3D:
    return Pose3D(x=x, y=y, z=0.0, roll=0.0, pitch=0.0, yaw=yaw)


def controller() -> DockingController:
    return DockingController(
        distance_gain=0.72,
        heading_gain=1.20,
        yaw_gain=0.90,
        lateral_gain=0.55,
        lookahead_distance=0.75,
        maximum_steering=0.34,
        minimum_creep_speed=0.04,
        heading_slowdown_angle=0.65,
        yaw_slowdown_angle=0.42,
        minimum_alignment_scale=0.20,
    )


def test_lateral_offsets_produce_opposite_nonzero_steering() -> None:
    left = controller().command(
        pose(4.20, y=0.22),
        standoff_distance=2.70,
        maximum_speed=0.34,
        lift_target=0.04,
    )
    right = controller().command(
        pose(4.20, y=-0.22),
        standoff_distance=2.70,
        maximum_speed=0.34,
        lift_target=0.04,
    )
    assert left.action.steering_command > math.radians(1.0)
    assert right.action.steering_command < -math.radians(1.0)


def test_yaw_error_generates_correct_correction_direction() -> None:
    yaw = math.radians(8.0)
    # Place each object so its desired stand-off point remains directly ahead;
    # the command sign then isolates the orientation correction.
    left = controller().command(
        pose(1.50 + 2.70 * math.cos(yaw), y=2.70 * math.sin(yaw), yaw=yaw),
        standoff_distance=2.70,
        maximum_speed=0.34,
        lift_target=0.04,
    )
    right = controller().command(
        pose(1.50 + 2.70 * math.cos(yaw), y=-2.70 * math.sin(yaw), yaw=-yaw),
        standoff_distance=2.70,
        maximum_speed=0.34,
        lift_target=0.04,
    )
    assert left.action.steering_command > 0.0
    assert right.action.steering_command < 0.0


def test_misalignment_reduces_speed_without_stopping() -> None:
    aligned = controller().command(
        pose(4.20),
        standoff_distance=2.70,
        maximum_speed=0.34,
        lift_target=0.04,
    )
    misaligned = controller().command(
        pose(4.20, y=0.30, yaw=math.radians(10.0)),
        standoff_distance=2.70,
        maximum_speed=0.34,
        lift_target=0.04,
    )
    assert 0.0 < misaligned.action.speed_target < aligned.action.speed_target


def test_v4_constructor_signature_remains_supported() -> None:
    legacy = DockingController(
        distance_gain=0.75,
        heading_gain=1.35,
        yaw_gain=0.80,
        maximum_steering=0.30,
        minimum_creep_speed=0.04,
        heading_slowdown_angle=0.55,
    )
    result = legacy.command(
        pose(3.20),
        standoff_distance=2.70,
        maximum_speed=0.30,
        lift_target=0.04,
    )
    assert result.action.speed_target > 0.0
    assert math.isclose(result.action.steering_command, 0.0, abs_tol=1e-12)
