"""Release-only centre-yaw re-anchor continuity guard for R4-F4-S2.

This module is deliberately geometry-light and has no MuJoCo dependency.  It
tracks a world-yaw proposal stream and turns an abrupt re-anchor into a
short-lived CONFLICT latch.  During CONFLICT the caller must withhold centre-yaw
release authority and may fall back to its existing conservative release path.

A conflict is recoverable: the new proposal must remain inside a tight angular
band for a bounded interval before centre-yaw release authority is restored.
The guard never owns motion control.
"""

from __future__ import annotations

from dataclasses import dataclass
import math


def _wrap_angle(value: float) -> float:
    return math.atan2(math.sin(float(value)), math.cos(float(value)))


@dataclass(frozen=True)
class ReleaseCenterYawConflictGuardConfig:
    maximum_reanchor_jump_rad: float
    revalidation_seconds: float
    revalidation_tolerance_rad: float

    def validate(self) -> None:
        if self.maximum_reanchor_jump_rad <= 0.0:
            raise ValueError("centre-yaw maximum re-anchor jump must be positive")
        if self.revalidation_seconds <= 0.0:
            raise ValueError("centre-yaw revalidation seconds must be positive")
        if self.revalidation_tolerance_rad <= 0.0:
            raise ValueError("centre-yaw revalidation tolerance must be positive")
        if self.revalidation_tolerance_rad >= self.maximum_reanchor_jump_rad:
            raise ValueError("centre-yaw revalidation tolerance must be tighter than jump limit")


@dataclass(frozen=True)
class ReleaseCenterYawConflictGuardUpdate:
    conflict_active: bool
    conflict_started: bool
    revalidated: bool
    current_world_yaw_rad: float | None
    current_jump_rad: float | None
    conflict_count: int
    revalidation_count: int
    last_conflict_jump_rad: float | None


class ReleaseCenterYawConflictGuard:
    """Temporal latch around abrupt world-yaw re-anchors.

    Large jumps are only armed while ``release_precision_active`` is true.
    Outside that state the latest proposal is merely learned as the continuity
    baseline, which prevents early corridor/viewpoint changes from poisoning a
    later release decision.
    """

    def __init__(self, config: ReleaseCenterYawConflictGuardConfig) -> None:
        config.validate()
        self.config = config
        self.reset()

    def reset(self) -> None:
        self.previous_world_yaw_rad: float | None = None
        self.current_world_yaw_rad: float | None = None
        self.current_jump_rad: float | None = None
        self.conflict_active = False
        self._candidate_world_yaw_rad: float | None = None
        self._candidate_since: float | None = None
        self.conflict_count = 0
        self.revalidation_count = 0
        self.last_conflict_jump_rad: float | None = None

    def update(
        self,
        now: float,
        *,
        proposal_world_yaw_rad: float | None,
        release_precision_active: bool,
    ) -> ReleaseCenterYawConflictGuardUpdate:
        now = float(now)
        conflict_started = False
        revalidated = False

        if proposal_world_yaw_rad is None:
            self.current_world_yaw_rad = None
            self.current_jump_rad = None
            # Missing centre evidence cannot count toward revalidation time.
            # Keep an active conflict latched, but require the next proposal to
            # earn a fresh continuous stability interval.
            if self.conflict_active:
                self._candidate_since = None
            elif not release_precision_active:
                # Outside release precision there is no reason to carry an old
                # centre baseline across a long visual gap.  Inside release
                # precision, however, preserve the last world-yaw reference so
                # a short F4 anchor lease dropout cannot let the next re-anchor
                # bypass continuity checking.
                self.previous_world_yaw_rad = None
            return self._snapshot(conflict_started=False, revalidated=False)

        world_yaw = _wrap_angle(float(proposal_world_yaw_rad))
        self.current_world_yaw_rad = world_yaw
        previous = self.previous_world_yaw_rad
        self.current_jump_rad = (
            None if previous is None else abs(_wrap_angle(world_yaw - previous))
        )

        if self.conflict_active:
            reference = self._candidate_world_yaw_rad
            if (
                reference is None
                or abs(_wrap_angle(world_yaw - reference))
                > self.config.revalidation_tolerance_rad
            ):
                self._candidate_world_yaw_rad = world_yaw
                self._candidate_since = now
            else:
                if self._candidate_since is None:
                    self._candidate_since = now
                elif now - self._candidate_since >= self.config.revalidation_seconds:
                    self.conflict_active = False
                    self.revalidation_count += 1
                    revalidated = True
                    self.previous_world_yaw_rad = world_yaw
                    self._candidate_world_yaw_rad = None
                    self._candidate_since = None
            return self._snapshot(conflict_started=False, revalidated=revalidated)

        if not release_precision_active:
            self.previous_world_yaw_rad = world_yaw
            return self._snapshot(conflict_started=False, revalidated=False)

        jump = self.current_jump_rad
        if jump is not None and jump > self.config.maximum_reanchor_jump_rad:
            self.conflict_active = True
            self.conflict_count += 1
            self.last_conflict_jump_rad = float(jump)
            self._candidate_world_yaw_rad = world_yaw
            self._candidate_since = now
            conflict_started = True
            return self._snapshot(conflict_started=True, revalidated=False)

        self.previous_world_yaw_rad = world_yaw
        return self._snapshot(conflict_started=False, revalidated=False)

    def _snapshot(
        self, *, conflict_started: bool, revalidated: bool
    ) -> ReleaseCenterYawConflictGuardUpdate:
        return ReleaseCenterYawConflictGuardUpdate(
            conflict_active=bool(self.conflict_active),
            conflict_started=bool(conflict_started),
            revalidated=bool(revalidated),
            current_world_yaw_rad=self.current_world_yaw_rad,
            current_jump_rad=self.current_jump_rad,
            conflict_count=int(self.conflict_count),
            revalidation_count=int(self.revalidation_count),
            last_conflict_jump_rad=self.last_conflict_jump_rad,
        )
