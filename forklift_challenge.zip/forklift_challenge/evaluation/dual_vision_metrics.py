"""Metrics for V8.2 appearance stress and confidence arbitration."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from collections import Counter
import csv
import json
from pathlib import Path
from statistics import mean
from typing import Any, Iterable


COMPETITION_POSITION_LIMIT_M = 0.10
COMPETITION_YAW_LIMIT_DEG = 5.0


def competition_precision_pass(
    *, mission_success: bool, final_position_error_m: float, final_yaw_error_deg: float
) -> bool:
    return bool(
        mission_success
        and float(final_position_error_m) < COMPETITION_POSITION_LIMIT_M
        and abs(float(final_yaw_error_deg)) < COMPETITION_YAW_LIMIT_DEG
    )


@dataclass(frozen=True)
class DualVisionMissionResult:
    scenario_id: str
    difficulty: str
    seed: int
    perception_profile: str
    success: bool
    final_state: str
    failure_reason: str | None
    duration_seconds: float
    path_length_m: float
    max_abs_steering_deg: float
    max_load_tilt_deg: float
    final_placement_error_m: float
    final_placement_yaw_error_deg: float
    release_pallet_motion_m: float
    steering_exercised: bool
    recovery_count: int
    pallet_position_rmse_m: float
    pallet_yaw_rmse_deg: float
    placement_position_rmse_m: float
    placement_yaw_rmse_deg: float
    maximum_stale_seconds: float
    measurement_dropout_rate: float
    measurement_rejection_rate: float
    pickup_vision_sample_count: int
    pickup_vision_detection_count: int
    pickup_vision_rejection_count: int
    pickup_vision_detection_rate: float
    pickup_vision_position_rmse_m: float | None
    pickup_vision_yaw_rmse_deg: float | None
    pickup_vision_average_confidence: float | None
    pickup_vision_maximum_reprojection_error_px: float | None
    pickup_vision_maximum_stale_seconds: float
    pickup_vision_used_for_pickup: bool
    vision_sample_count: int
    vision_detection_count: int
    vision_rejection_count: int
    vision_detection_rate: float
    vision_position_rmse_m: float | None
    vision_yaw_rmse_deg: float | None
    vision_average_confidence: float | None
    vision_maximum_reprojection_error_px: float | None
    vision_maximum_stale_seconds: float
    vision_used_for_terminal: bool
    state_durations: dict[str, float] = field(default_factory=dict)
    scenario: dict[str, Any] = field(default_factory=dict)

    # V8.1.2 fields.  Defaults preserve V8.1 positional construction.
    pickup_vision_raw_detection_count: int = 0
    pickup_vision_raw_position_p95_m: float | None = None
    pickup_vision_raw_yaw_p95_deg: float | None = None
    pickup_vision_fused_frame_count: int = 0
    pickup_vision_fused_position_rmse_m: float | None = None
    pickup_vision_fused_yaw_rmse_deg: float | None = None
    pickup_vision_visible_sample_count: int = 0
    pickup_vision_visible_detection_count: int = 0
    pickup_vision_visible_detection_rate: float = 0.0
    pickup_vision_detection_rate_approach: float = 0.0
    pickup_vision_detection_rate_align: float = 0.0
    pickup_vision_detection_rate_insert: float = 0.0
    pickup_vision_detection_rate_recovery: float = 0.0
    pickup_vision_detection_acquired: bool = False
    pickup_vision_first_detection_seconds: float | None = None
    pickup_vision_longest_detection_streak_seconds: float = 0.0
    pickup_vision_last_detection_distance_m: float | None = None
    pickup_vision_accepted_outlier_count: int = 0
    pickup_vision_sample_count_by_state: dict[str, int] = field(
        default_factory=dict
    )
    pickup_vision_detection_count_by_state: dict[str, int] = field(
        default_factory=dict
    )
    render_attempt_count: int = 0
    render_retry_count: int = 0
    render_failure_count: int = 0
    render_invalid_frame_count: int = 0
    render_context_warning_count: int = 0
    render_exception_count: int = 0
    render_channel_failures: dict[str, int] = field(default_factory=dict)

    # V8.1.3 geometric opportunity and safety semantics.
    pickup_vision_fused_position_p95_m: float | None = None
    pickup_vision_fused_yaw_p95_deg: float | None = None
    pickup_vision_opportunity_count: int = 0
    pickup_vision_opportunity_detection_count: int = 0
    pickup_vision_opportunity_detection_rate: float = 0.0
    pickup_vision_first_detection_state: str | None = None
    pickup_vision_detections_before_insert: int = 0
    pickup_vision_ready_before_insert: bool = False
    pickup_vision_raw_outlier_count: int = 0
    pickup_vision_innovation_rejected_count: int = 0
    pickup_vision_control_accepted_outlier_count: int = 0
    pickup_vision_opportunity_count_by_state: dict[str, int] = field(
        default_factory=dict
    )
    pickup_vision_opportunity_detection_count_by_state: dict[str, int] = field(
        default_factory=dict
    )
    pickup_vision_raw_detection_rate_by_state: dict[str, float] = field(
        default_factory=dict
    )
    pickup_vision_control_detection_rate_by_state: dict[str, float] = field(
        default_factory=dict
    )

    # V8.1.3.4 detector/control separation and event-level safety metrics.
    pickup_detector_raw_detection_count: int = 0
    pickup_detector_raw_position_rmse_m: float | None = None
    pickup_detector_raw_yaw_rmse_deg: float | None = None
    pickup_detector_raw_position_p95_m: float | None = None
    pickup_detector_raw_yaw_p95_deg: float | None = None
    pickup_vision_control_accepted_measurement_count: int = 0
    pickup_vision_control_accepted_outlier_rate: float = 0.0
    pickup_vision_control_accepted_severe_outlier_count: int = 0
    pickup_vision_control_accepted_severe_outlier_rate: float = 0.0

    pickup_vision_measurement_guide_rejected_count: int = 0

    # V8.2 appearance stress and confidence arbitration.
    appearance_profile: str = "clean"
    appearance_frame_count: int = 0
    appearance_dropout_count: int = 0
    appearance_blur_count: int = 0
    appearance_occlusion_count: int = 0
    appearance_noise_frame_count: int = 0
    appearance_affine_frame_count: int = 0
    appearance_maximum_camera_translation_m: float = 0.0
    appearance_maximum_camera_rotation_deg: float = 0.0
    pickup_vision_high_confidence_count: int = 0
    pickup_vision_medium_confidence_count: int = 0
    pickup_vision_confidence_rejection_count: int = 0
    pickup_vision_reacquire_required_at_end: bool = False
    vision_high_confidence_count: int = 0
    vision_medium_confidence_count: int = 0
    vision_confidence_rejection_count: int = 0
    vision_guide_rejection_count: int = 0
    vision_innovation_rejection_count: int = 0

    # V9.1.2 terminal anti-loop telemetry.
    placement_recovery_count: int = 0
    placement_guard_brake_count: int = 0
    placement_precision_settle_frame_count: int = 0
    placement_precision_settle_exit_count: int = 0

    # V9.2.3 competition-precision controller telemetry.
    placement_precision_forward_frame_count: int = 0
    placement_precision_reverse_frame_count: int = 0
    placement_precision_hold_frame_count: int = 0
    placement_precision_reentry_count: int = 0

    # V9.3.0 nonholonomic terminal-controller telemetry.
    placement_precision_recenter_cycle_count: int = 0
    placement_precision_recenter_frame_count: int = 0
    placement_precision_direction_switch_count: int = 0

    # V9.3.0 MPC + release-commit telemetry.
    placement_mpc_solve_count: int = 0
    placement_mpc_fallback_count: int = 0
    placement_mpc_infeasible_solve_count: int = 0
    placement_mpc_regression_reject_solve_count: int = 0
    placement_release_candidate_count: int = 0
    placement_release_commit_count: int = 0
    placement_release_commit_abort_count: int = 0
    placement_release_prebrake_count: int = 0
    placement_release_prebrake_abort_count: int = 0
    placement_release_block_position_frames: int = 0
    placement_release_block_yaw_frames: int = 0
    placement_release_block_speed_frames: int = 0
    placement_release_block_vision_frames: int = 0
    placement_release_block_observer_frames: int = 0

    # V9.3.0 dual-track probabilistic carried-load observer telemetry.
    placement_carried_observer_active: bool = False
    placement_carried_observer_sample_count: int = 0
    placement_carried_observer_position_std_m: float = 0.0
    placement_carried_observer_yaw_std_deg: float = 0.0
    placement_carried_observer_update_count: int = 0
    placement_carried_observer_rejection_count: int = 0
    placement_carried_observer_disagreement_position_m: float = 0.0
    placement_carried_observer_disagreement_yaw_deg: float = 0.0

    # V9.3.0 passive one-step MPC model-identification telemetry.
    placement_mpc_model_id_sample_count: int = 0
    placement_mpc_model_id_longitudinal_rmse_m: float = 0.0
    placement_mpc_model_id_lateral_rmse_m: float = 0.0
    placement_mpc_model_id_yaw_rmse_deg: float = 0.0

    # V9.3.1 axis-entry corridor + weak-guide visual takeover telemetry.
    terminal_corridor_entry_replan_count: int = 0
    terminal_corridor_axis_frame_count: int = 0
    terminal_corridor_axis_reset_count: int = 0
    # V9.3.2 rolling-corridor event/frame telemetry.
    terminal_corridor_rolling_frame_count: int = 0
    terminal_corridor_handoff_count: int = 0
    terminal_corridor_timeout_handoff_count: int = 0
    terminal_corridor_reacquire_count: int = 0
    terminal_corridor_visual_coarse_frame_count: int = 0
    terminal_corridor_visual_stale_frame_count: int = 0
    terminal_corridor_last_handoff_distance_m: float | None = None
    terminal_corridor_last_handoff_lateral_m: float | None = None
    terminal_corridor_last_handoff_yaw_deg: float | None = None
    vision_visual_takeover_count: int = 0
    pickup_vision_visual_takeover_count: int = 0
    vision_authority_lock_count: int = 0
    vision_authority_unlock_count: int = 0
    pickup_vision_authority_lock_count: int = 0
    pickup_vision_authority_unlock_count: int = 0

    # V9.3.3 carried-load visual authority + strict release certification.
    carried_load_visual_authority_locked: bool = False
    carried_load_visual_lock_count: int = 0
    carried_load_visual_rgb_update_count: int = 0
    carried_load_visual_guide_reject_count: int = 0
    carried_load_visual_rigid_prediction_count: int = 0
    carried_load_visual_handoff_seed_count: int = 0
    # V9.3.12-R4-F1 late-INSERT quality-yaw handoff telemetry.
    carried_load_yaw_anchor_used: bool = False
    carried_load_yaw_anchor_sample_count: int = 0
    carried_load_yaw_anchor_spread_deg: float | None = None
    carried_load_yaw_anchor_delta_from_latest_deg: float | None = None
    carried_load_seed_provenance: str = "UNKNOWN"
    carried_load_seed_trusted_for_aggressive_risk: bool = False
    carried_load_seed_age_seconds: float | None = None
    carried_load_seed_confidence: float | None = None
    carried_load_seed_reprojection_error_px: float | None = None
    controller_release_seed_provenance: str | None = None
    controller_release_seed_trusted_for_aggressive_risk: bool | None = None
    controller_release_seed_age_seconds: float | None = None
    controller_release_risk_budget_mode: str | None = None
    strict_release_certification_pass_count: int = 0
    strict_release_certification_reject_count: int = 0
    terminal_corridor_timeout_handoff_guard_reject_count: int = 0

    # V9.3.4 terminal decision-latency supervisor telemetry.
    carried_load_visual_handoff_fallback_seed_count: int = 0
    release_supervisor_settle_count: int = 0
    release_supervisor_intent_count: int = 0
    release_supervisor_intent_abort_count: int = 0
    release_supervisor_settle_timeout_count: int = 0
    release_supervisor_mpc_resume_count: int = 0
    release_supervisor_hold_seconds: float = 0.0
    release_supervisor_certified_hold_seconds: float = 0.0
    release_supervisor_certification_to_release_seconds: float | None = None

    # V9.3.5 terminal ownership + dynamic load belief telemetry.
    terminal_ownership_mpc_entered: bool = False
    terminal_ownership_direct_mpc_count: int = 0
    terminal_ownership_forced_mpc_count: int = 0
    terminal_ownership_align_timeout_count: int = 0
    terminal_ownership_reacquire_count: int = 0
    terminal_ownership_total_align_seconds: float = 0.0
    terminal_ownership_max_align_seconds: float = 0.0
    carried_load_belief_mode: str = "UNAVAILABLE"
    carried_load_belief_position_sigma_m: float = 0.0
    carried_load_belief_yaw_sigma_deg: float = 0.0
    # V9.3.12-R4-F3 motion-vs-release yaw uncertainty split.
    carried_load_motion_yaw_sigma_deg: float = 0.0
    carried_load_release_yaw_sigma_deg: float = 0.0
    carried_load_yaw_anchor_seed_sigma_deg: float | None = None
    carried_load_yaw_evidence_source: str = "NONE"
    # V9.3.12-R4-F4 release-only centre-yaw / guarded yaw-RSS telemetry.
    release_center_yaw_anchor_seen: bool = False
    release_center_yaw_anchor_active_frame_count: int = 0
    strict_release_center_yaw_rss_frame_count: int = 0
    # V9.3.12-R4-F4-S2 release-only continuity/conflict telemetry.
    strict_release_center_yaw_conflict_count: int = 0
    strict_release_center_yaw_revalidation_count: int = 0
    strict_release_center_yaw_conflict_fallback_frame_count: int = 0
    strict_release_center_yaw_conflict_last_jump_deg: float | None = None
    strict_release_center_yaw_conflict_last_load_stale_seconds: float | None = None
    controller_release_yaw_risk_budget_mode: str | None = None
    controller_release_target_source: str | None = None
    carried_load_belief_distance_since_visual_m: float = 0.0
    carried_load_belief_turn_since_visual_deg: float = 0.0
    carried_load_belief_transport_scaled_frames: int = 0

    # V9.3.8 controller-aligned certification diagnostics. These compare the
    # controller's actual strict certification at release against truth only on
    # the evaluation side; truth is never exposed to runtime control.
    controller_certified_release: bool | None = None
    controller_certified_release_truth_pass: bool | None = None
    controller_certified_release_false_positive: bool = False
    controller_truth_ready_uncertified: bool = False
    controller_release_estimated_position_error_m: float | None = None
    controller_release_estimated_yaw_error_deg: float | None = None
    controller_release_target_raw_position_spread_m: float | None = None
    controller_release_target_raw_yaw_spread_deg: float | None = None
    controller_release_target_position_margin_m: float | None = None
    controller_release_target_yaw_margin_deg: float | None = None
    placement_mpc_yaw_escrow_activation_count: int = 0

    # V9.3.11 certified-basin + near-basin telemetry restored in R4-B.
    certified_basin_enter_count: int = 0
    certified_basin_exit_count: int = 0
    certified_basin_strict_enter_count: int = 0
    certified_basin_consensus_enter_count: int = 0
    certified_basin_persisted_pass_count: int = 0
    certified_basin_longest_active_seconds: float = 0.0
    certified_basin_consensus_false_positive: bool = False
    strict_release_certification_blocker_counts: dict[str, int] = field(default_factory=dict)
    placement_mpc_near_basin_escrow_activation_count: int = 0
    placement_mpc_near_basin_escrow_accepted_plan_count: int = 0
    placement_mpc_near_basin_last_deficit_improvement: float = 0.0

    # V9.3.12 terminal reacquisition + bounded closure telemetry. Runtime may
    # leave these at zero when the opportunistic sensor is disabled.
    terminal_load_reacquisition_sample_count: int = 0
    terminal_load_reacquisition_raw_detection_count: int = 0
    terminal_load_reacquisition_consensus_update_count: int = 0
    terminal_load_reacquisition_observer_update_count: int = 0
    terminal_load_reacquisition_observer_rejection_count: int = 0
    # V9.3.12-R4-F2 terminal translation-only observer telemetry.
    terminal_load_reacquisition_position_only_update_count: int = 0
    terminal_load_reacquisition_yaw_suppressed_count: int = 0
    terminal_load_reacquisition_yaw_authority_enabled: bool = True
    terminal_load_reacquisition_last_measurement_yaw_deg: float | None = None
    terminal_load_reacquisition_last_posterior_yaw_deg: float | None = None
    terminal_load_reacquisition_rejected_innovation_count: int = 0
    terminal_load_reacquisition_rejected_spread_count: int = 0
    terminal_load_reacquisition_maximum_stale_seconds: float = 0.0
    terminal_load_reacquisition_last_position_spread_m: float | None = None
    terminal_load_reacquisition_last_yaw_spread_deg: float | None = None
    terminal_load_reacquisition_last_position_innovation_m: float = 0.0
    terminal_load_reacquisition_last_yaw_innovation_deg: float = 0.0
    placement_micro_primitive_search_count: int = 0
    placement_micro_primitive_activation_count: int = 0
    placement_micro_primitive_accepted_count: int = 0
    placement_micro_primitive_candidate_count: int = 0
    placement_micro_primitive_last_deficit_improvement: float = 0.0

    # V9.3.12-R4-B strict-recovery basin-retention telemetry.
    placement_strict_recovery_retention_search_count: int = 0
    placement_strict_recovery_retention_activation_count: int = 0
    placement_strict_recovery_retention_candidate_count: int = 0
    placement_strict_recovery_retention_last_deficit_improvement: float = 0.0
    placement_strict_recovery_final_settle_count: int = 0

    # V9.3.12-R4-E fresh-RGB paired yaw closure telemetry.
    placement_fresh_rgb_yaw_closure_search_count: int = 0
    placement_fresh_rgb_yaw_closure_activation_count: int = 0
    placement_fresh_rgb_yaw_closure_candidate_count: int = 0
    placement_fresh_rgb_yaw_closure_feedback_reject_count: int = 0
    placement_fresh_rgb_yaw_closure_last_predicted_yaw_improvement_deg: float = 0.0
    placement_fresh_rgb_yaw_closure_last_measured_yaw_improvement_deg: float = 0.0
    placement_fresh_rgb_yaw_closure_total_candidate_count: int = 0
    placement_fresh_rgb_yaw_closure_no_candidate_search_count: int = 0

    # V9.3.12-R4-E1 post-closure ownership telemetry.
    placement_post_closure_basin_ownership_entry_count: int = 0
    placement_post_closure_mpc_veto_count: int = 0
    placement_post_closure_mpc_safe_allow_count: int = 0
    placement_post_closure_certification_handoff_count: int = 0
    placement_post_closure_continuation_search_count: int = 0
    placement_post_closure_continuation_activation_count: int = 0
    placement_post_closure_last_certification_position_m: float | None = None
    placement_post_closure_last_certification_yaw_deg: float | None = None

    # V9.3.12-R4-E2 certification-space closure + gray-zone telemetry.
    placement_post_closure_gray_zone_hold_count: int = 0
    placement_certification_basin_closure_search_count: int = 0
    placement_certification_basin_closure_activation_count: int = 0
    placement_certification_basin_closure_candidate_count: int = 0
    placement_certification_basin_closure_total_candidate_count: int = 0
    placement_certification_basin_closure_no_candidate_search_count: int = 0
    placement_certification_basin_closure_feedback_reject_count: int = 0
    placement_certification_basin_closure_last_predicted_deficit_improvement: float = 0.0
    placement_certification_basin_closure_last_measured_deficit_improvement: float = 0.0
    placement_certification_basin_closure_last_current_deficit: float = 0.0
    placement_certification_basin_closure_last_predicted_deficit: float = 0.0
    placement_certification_basin_closure_post_motion_rgb_updates: int = 0
    placement_certification_basin_closure_supervisor_retry_suppressed_count: int = 0
    placement_certification_basin_closure_full_pose_search_count: int = 0
    placement_certification_basin_closure_legacy_error_space_search_count: int = 0
    placement_certification_basin_closure_last_certification_longitudinal_m: float | None = None
    placement_certification_basin_closure_last_certification_lateral_m: float | None = None

    # V9.3.12-R4-E3 blocker-aware POSITION recenter corridor telemetry.
    placement_position_blocker_recenter_search_count: int = 0
    placement_position_blocker_recenter_activation_count: int = 0
    placement_position_blocker_recenter_candidate_count: int = 0
    placement_position_blocker_recenter_total_candidate_count: int = 0
    placement_position_blocker_recenter_return_replan_count: int = 0
    placement_position_blocker_recenter_return_candidate_count: int = 0
    placement_position_blocker_recenter_feedback_reject_count: int = 0
    placement_position_blocker_recenter_abort_count: int = 0
    placement_position_blocker_recenter_midpoint_replan_fail_count: int = 0
    placement_position_blocker_recenter_mid_rgb_updates: int = 0
    placement_position_blocker_recenter_final_rgb_updates: int = 0
    placement_position_blocker_recenter_last_predicted_effective_position_m: float = 0.0
    placement_position_blocker_recenter_last_predicted_effective_yaw_deg: float = 0.0
    placement_position_blocker_recenter_last_measured_effective_position_m: float = 0.0
    placement_position_blocker_recenter_last_measured_effective_yaw_deg: float = 0.0
    placement_position_blocker_recenter_last_measured_position_improvement_m: float = 0.0
    # V9.3.12-R4-E4 actuator-closure telemetry.
    placement_position_blocker_recenter_presteer_timeout_count: int = 0
    placement_position_blocker_recenter_last_effective_steering_deg: float = 0.0
    placement_position_blocker_recenter_last_departure_odometry_m: float = 0.0
    placement_position_blocker_recenter_last_return_odometry_m: float = 0.0
    placement_position_blocker_recenter_midpoint_position_deviation_m: float = 0.0
    placement_position_blocker_recenter_midpoint_yaw_deviation_deg: float = 0.0
    # V9.3.12-R4-E5 full-pose/load-offset + guaranteed rollback telemetry.
    placement_position_blocker_recenter_full_pose_search_count: int = 0
    placement_position_blocker_recenter_full_pose_return_replan_count: int = 0
    placement_position_blocker_recenter_legacy_error_space_search_count: int = 0
    placement_position_blocker_recenter_rollback_count: int = 0
    placement_position_blocker_recenter_rollback_success_count: int = 0
    placement_position_blocker_recenter_rollback_failure_count: int = 0
    placement_position_blocker_recenter_rollback_target_odometry_m: float = 0.0
    placement_position_blocker_recenter_last_rollback_odometry_m: float = 0.0
    placement_position_blocker_recenter_last_return_unwind_odometry_m: float = 0.0
    placement_position_blocker_recenter_rollback_rgb_updates: int = 0
    placement_position_blocker_recenter_rollback_reason: str = ""
    placement_position_blocker_recenter_yaw_handoff_count: int = 0
    # V9.3.12-R4-E6 topology/evidence telemetry.
    placement_position_blocker_recenter_retrace_candidate_reject_count: int = 0
    placement_position_blocker_recenter_topology_candidate_count: int = 0
    placement_position_blocker_recenter_final_evidence_consistent_rgb_updates: int = 0
    placement_position_blocker_recenter_final_live_strict_attempt_count: int = 0
    placement_position_blocker_recenter_final_evidence_timeout_count: int = 0

    # V9.3.9 task-state precision closure.
    placement_target_multiview_ready: bool = False
    placement_target_multiview_samples: int = 0
    placement_target_multiview_position_spread_m: float | None = None
    placement_target_multiview_yaw_spread_deg: float | None = None
    placement_target_fast_slow_position_disagreement_m: float | None = None
    placement_target_fast_slow_yaw_disagreement_deg: float | None = None
    release_witness_capture_count: int = 0
    release_witness_drift_abort_count: int = 0
    release_witness_instant_strict_gate_block_count: int = 0
    release_witness_truth_pass: bool | None = None
    release_witness_false_positive: bool = False
    release_execution_truth_pass: bool | None = None
    release_execution_false_positive: bool = False
    release_witness_to_execute_seconds: float | None = None
    release_witness_estimated_position_error_m: float | None = None
    release_witness_estimated_yaw_error_deg: float | None = None

    # V9.2.0 episode-budget and precision-diagnosis telemetry.
    terminal_oracle_geometry: bool = False
    episode_timed_out: bool = False
    long_episode: bool = False
    terminal_budget_exhausted: bool = False
    terminal_alignment_seconds: float = 0.0
    precision_diagnostics: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _optional_mean(items, name: str):
    values = [
        float(getattr(item, name))
        for item in items
        if getattr(item, name) is not None
    ]
    return mean(values) if values else None


def _sum_counter_dicts(items, name: str) -> dict[str, int]:
    total: dict[str, int] = {}
    for item in items:
        value = getattr(item, name, {}) or {}
        for key, count in value.items():
            total[str(key)] = total.get(str(key), 0) + int(count)
    return total


def _count_string_values(items, name: str) -> dict[str, int]:
    total: dict[str, int] = {}
    for item in items:
        value = str(getattr(item, name, "NONE"))
        total[value] = total.get(value, 0) + 1
    return total


def _percentile(values: list[float], probability: float) -> float | None:
    if not values:
        return None
    ordered = sorted(float(value) for value in values)
    if len(ordered) == 1:
        return ordered[0]
    index = (len(ordered) - 1) * float(probability)
    lower = int(index)
    upper = min(len(ordered) - 1, lower + 1)
    fraction = index - lower
    return ordered[lower] * (1.0 - fraction) + ordered[upper] * fraction


def _precision_diagnostic_summary(
    items: list[DualVisionMissionResult],
) -> dict[str, Any]:
    stages = (
        "approach_1p5m",
        "approach_1p0m",
        "approach_0p5m",
        "approach_0p2m",
        "terminal_entry",
        "operational_capture",
        "competition_capture",
        "release_command",
        "grounded",
        "retreat_start",
        "final",
    )
    stage_summary: dict[str, Any] = {}
    for stage_name in stages:
        truth_positions: list[float] = []
        truth_yaws: list[float] = []
        estimated_positions: list[float] = []
        estimated_yaws: list[float] = []
        truth_ready = 0
        estimated_ready = 0
        captured = 0
        for item in items:
            stage = item.precision_diagnostics.get("stages", {}).get(stage_name)
            if not isinstance(stage, dict):
                continue
            captured += 1
            truth = stage.get("truth", {})
            estimated = stage.get("estimated", {})
            truth_positions.append(float(truth["position_error_m"]))
            truth_yaws.append(abs(float(truth["yaw_error_deg"])))
            estimated_positions.append(float(estimated["position_error_m"]))
            estimated_yaws.append(abs(float(estimated["yaw_error_deg"])))
            truth_ready += int(bool(stage.get("truth_competition_ready", False)))
            estimated_ready += int(
                bool(stage.get("estimated_competition_ready", False))
            )
        stage_summary[stage_name] = {
            "capture_count": captured,
            "capture_rate": captured / len(items) if items else 0.0,
            "truth_position_mean_m": mean(truth_positions) if truth_positions else None,
            "truth_position_p95_m": _percentile(truth_positions, 0.95),
            "truth_abs_yaw_mean_deg": mean(truth_yaws) if truth_yaws else None,
            "truth_abs_yaw_p95_deg": _percentile(truth_yaws, 0.95),
            "estimated_position_mean_m": (
                mean(estimated_positions) if estimated_positions else None
            ),
            "estimated_abs_yaw_mean_deg": (
                mean(estimated_yaws) if estimated_yaws else None
            ),
            "truth_competition_ready_rate": (
                truth_ready / captured if captured else 0.0
            ),
            "estimated_competition_ready_rate": (
                estimated_ready / captured if captured else 0.0
            ),
        }

    derived_keys = (
        "terminal_to_release_position_delta_m",
        "release_to_ground_position_delta_m",
        "retreat_to_final_position_delta_m",
        "lowering_pallet_translation_m",
        "withdrawal_pallet_translation_m",
        "release_estimation_position_gap_m",
        "release_estimation_yaw_gap_deg",
    )
    derived: dict[str, Any] = {}
    for key in derived_keys:
        values = []
        for item in items:
            value = item.precision_diagnostics.get("derived", {}).get(key)
            if value is not None:
                values.append(float(value))
        derived[key] = {
            "count": len(values),
            "mean": mean(values) if values else None,
            "p95": _percentile(values, 0.95),
        }
    release_false_positive_count = sum(
        bool(item.precision_diagnostics.get("derived", {}).get("release_false_positive", False))
        for item in items
    )
    release_false_negative_count = sum(
        bool(item.precision_diagnostics.get("derived", {}).get("release_false_negative", False))
        for item in items
    )
    derived["release_false_positive_count"] = release_false_positive_count
    derived["release_false_positive_rate"] = release_false_positive_count / len(items) if items else 0.0
    derived["release_false_negative_count"] = release_false_negative_count
    derived["release_false_negative_rate"] = release_false_negative_count / len(items) if items else 0.0
    controller_fp = sum(bool(item.controller_certified_release_false_positive) for item in items)
    controller_fn = sum(bool(item.controller_truth_ready_uncertified) for item in items)
    controller_releases = sum(item.controller_certified_release is not None for item in items)
    derived["controller_certified_release_count"] = controller_releases
    derived["controller_certified_release_false_positive_count"] = controller_fp
    derived["controller_certified_release_false_positive_rate"] = (
        controller_fp / controller_releases if controller_releases else 0.0
    )
    derived["controller_truth_ready_uncertified_count"] = controller_fn
    derived["controller_truth_ready_uncertified_rate"] = (
        controller_fn / len(items) if items else 0.0
    )
    return {"stages": stage_summary, "derived": derived}


def summarize_dual_vision_missions(
    results: Iterable[DualVisionMissionResult],
) -> dict[str, Any]:
    items = list(results)
    successes = [item for item in items if item.success]
    failures: dict[str, int] = {}
    by_difficulty: dict[str, dict[str, Any]] = {}
    by_profile: dict[str, dict[str, Any]] = {}
    by_appearance_profile: dict[str, dict[str, Any]] = {}

    for item in items:
        if not item.success:
            key = item.failure_reason or item.final_state or "unknown"
            failures[key] = failures.get(key, 0) + 1
        for collection, key in (
            (by_difficulty, item.difficulty),
            (by_profile, item.perception_profile),
            (by_appearance_profile, item.appearance_profile),
        ):
            bucket = collection.setdefault(
                key, {"episodes": 0, "successes": 0}
            )
            bucket["episodes"] += 1
            bucket["successes"] += int(item.success)

    for collection in (
        by_difficulty,
        by_profile,
        by_appearance_profile,
    ):
        for bucket in collection.values():
            bucket["success_rate"] = (
                bucket["successes"] / bucket["episodes"]
            )

    seed_provenance_counts: dict[str, int] = {}
    release_seed_provenance_counts: dict[str, int] = {}
    release_risk_budget_mode_counts: dict[str, int] = {}
    release_yaw_risk_budget_mode_counts: dict[str, int] = {}
    release_target_source_counts: dict[str, int] = {}
    for item in items:
        seed_key = str(item.carried_load_seed_provenance or "UNKNOWN")
        seed_provenance_counts[seed_key] = seed_provenance_counts.get(seed_key, 0) + 1
        if item.controller_release_seed_provenance is not None:
            key = str(item.controller_release_seed_provenance)
            release_seed_provenance_counts[key] = release_seed_provenance_counts.get(key, 0) + 1
        if item.controller_release_risk_budget_mode is not None:
            key = str(item.controller_release_risk_budget_mode)
            release_risk_budget_mode_counts[key] = release_risk_budget_mode_counts.get(key, 0) + 1
        if item.controller_release_yaw_risk_budget_mode is not None:
            key = str(item.controller_release_yaw_risk_budget_mode)
            release_yaw_risk_budget_mode_counts[key] = release_yaw_risk_budget_mode_counts.get(key, 0) + 1
        if item.controller_release_target_source is not None:
            key = str(item.controller_release_target_source)
            release_target_source_counts[key] = release_target_source_counts.get(key, 0) + 1

    if not items:
        return {
            "episode_count": 0,
            "success_count": 0,
            "success_rate": 0.0,
            "failure_reasons": {},
            "by_difficulty": {},
            "by_profile": {},
            "by_appearance_profile": {},
        }

    def success_mean(name: str):
        return (
            mean(getattr(item, name) for item in successes)
            if successes
            else None
        )

    return {
        "episode_count": len(items),
        "success_count": len(successes),
        "success_rate": len(successes) / len(items),
        "episode_timeout_count": sum(item.episode_timed_out for item in items),
        "episode_timeout_rate": sum(item.episode_timed_out for item in items) / len(items),
        "long_episode_count": sum(item.long_episode for item in items),
        "long_episode_rate": sum(item.long_episode for item in items) / len(items),
        "terminal_budget_exhausted_count": sum(
            item.terminal_budget_exhausted for item in items
        ),
        "terminal_budget_exhausted_rate": sum(
            item.terminal_budget_exhausted for item in items
        ) / len(items),
        "terminal_oracle_episode_count": sum(
            item.terminal_oracle_geometry for item in items
        ),
        "duration_p50_seconds": _percentile(
            [item.duration_seconds for item in items], 0.50
        ),
        "duration_p95_seconds": _percentile(
            [item.duration_seconds for item in items], 0.95
        ),
        "maximum_duration_seconds": max(item.duration_seconds for item in items),
        "average_terminal_alignment_seconds": mean(
            item.terminal_alignment_seconds for item in items
        ),
        "terminal_alignment_p95_seconds": _percentile(
            [item.terminal_alignment_seconds for item in items], 0.95
        ),
        "precision_diagnostics": _precision_diagnostic_summary(items),
        "competition_position_limit_m": COMPETITION_POSITION_LIMIT_M,
        "competition_yaw_limit_deg": COMPETITION_YAW_LIMIT_DEG,
        "competition_position_pass_count": sum(
            item.success
            and item.final_placement_error_m < COMPETITION_POSITION_LIMIT_M
            for item in items
        ),
        "competition_position_pass_rate": (
            sum(
                item.success
                and item.final_placement_error_m < COMPETITION_POSITION_LIMIT_M
                for item in items
            ) / len(items)
        ),
        "competition_yaw_pass_count": sum(
            item.success
            and abs(item.final_placement_yaw_error_deg) < COMPETITION_YAW_LIMIT_DEG
            for item in items
        ),
        "competition_yaw_pass_rate": (
            sum(
                item.success
                and abs(item.final_placement_yaw_error_deg) < COMPETITION_YAW_LIMIT_DEG
                for item in items
            ) / len(items)
        ),
        "competition_precision_success_count": sum(
            competition_precision_pass(
                mission_success=item.success,
                final_position_error_m=item.final_placement_error_m,
                final_yaw_error_deg=item.final_placement_yaw_error_deg,
            ) for item in items
        ),
        "competition_precision_success_rate": (
            sum(
                competition_precision_pass(
                    mission_success=item.success,
                    final_position_error_m=item.final_placement_error_m,
                    final_yaw_error_deg=item.final_placement_yaw_error_deg,
                ) for item in items
            ) / len(items)
        ),
        "total_placement_recovery_count": sum(
            item.placement_recovery_count for item in items
        ),
        "placement_recovery_episode_rate": (
            sum(item.placement_recovery_count > 0 for item in items) / len(items)
        ),
        "total_placement_guard_brake_count": sum(
            item.placement_guard_brake_count for item in items
        ),
        "total_placement_precision_settle_frame_count": sum(
            item.placement_precision_settle_frame_count for item in items
        ),
        "total_placement_precision_settle_exit_count": sum(
            item.placement_precision_settle_exit_count for item in items
        ),
        "total_placement_precision_forward_frame_count": sum(
            item.placement_precision_forward_frame_count for item in items
        ),
        "total_placement_precision_reverse_frame_count": sum(
            item.placement_precision_reverse_frame_count for item in items
        ),
        "total_placement_precision_hold_frame_count": sum(
            item.placement_precision_hold_frame_count for item in items
        ),
        "total_placement_precision_reentry_count": sum(
            item.placement_precision_reentry_count for item in items
        ),
        "total_placement_precision_recenter_cycle_count": sum(
            item.placement_precision_recenter_cycle_count for item in items
        ),
        "total_placement_precision_recenter_frame_count": sum(
            item.placement_precision_recenter_frame_count for item in items
        ),
        "total_placement_precision_direction_switch_count": sum(
            item.placement_precision_direction_switch_count for item in items
        ),
        "total_placement_mpc_solve_count": sum(
            item.placement_mpc_solve_count for item in items
        ),
        "total_placement_mpc_fallback_count": sum(
            item.placement_mpc_fallback_count for item in items
        ),
        "total_placement_mpc_infeasible_solve_count": sum(
            item.placement_mpc_infeasible_solve_count for item in items
        ),
        "total_placement_mpc_regression_reject_solve_count": sum(
            item.placement_mpc_regression_reject_solve_count for item in items
        ),
        "total_placement_release_candidate_count": sum(
            item.placement_release_candidate_count for item in items
        ),
        "total_placement_release_commit_count": sum(
            item.placement_release_commit_count for item in items
        ),
        "total_placement_release_commit_abort_count": sum(
            item.placement_release_commit_abort_count for item in items
        ),
        "total_placement_release_prebrake_count": sum(
            item.placement_release_prebrake_count for item in items
        ),
        "total_placement_release_prebrake_abort_count": sum(
            item.placement_release_prebrake_abort_count for item in items
        ),
        "total_placement_release_block_position_frames": sum(
            item.placement_release_block_position_frames for item in items
        ),
        "total_placement_release_block_yaw_frames": sum(
            item.placement_release_block_yaw_frames for item in items
        ),
        "total_placement_release_block_speed_frames": sum(
            item.placement_release_block_speed_frames for item in items
        ),
        "total_placement_release_block_vision_frames": sum(
            item.placement_release_block_vision_frames for item in items
        ),
        "total_placement_release_block_observer_frames": sum(
            item.placement_release_block_observer_frames for item in items
        ),
        "placement_carried_observer_active_rate": (
            sum(bool(item.placement_carried_observer_active) for item in items) / len(items)
        ),
        "average_placement_carried_observer_sample_count": mean(
            item.placement_carried_observer_sample_count for item in items
        ),
        "average_placement_carried_observer_position_std_m": mean(
            item.placement_carried_observer_position_std_m for item in items
        ),
        "average_placement_carried_observer_yaw_std_deg": mean(
            item.placement_carried_observer_yaw_std_deg for item in items
        ),
        "average_placement_carried_observer_update_count": mean(
            item.placement_carried_observer_update_count for item in items
        ),
        "total_placement_carried_observer_rejection_count": sum(
            item.placement_carried_observer_rejection_count for item in items
        ),
        "average_placement_carried_observer_disagreement_position_m": mean(
            item.placement_carried_observer_disagreement_position_m for item in items
        ),
        "average_placement_carried_observer_disagreement_yaw_deg": mean(
            item.placement_carried_observer_disagreement_yaw_deg for item in items
        ),
        "total_placement_mpc_model_id_sample_count": sum(
            item.placement_mpc_model_id_sample_count for item in items
        ),
        "average_placement_mpc_model_id_longitudinal_rmse_m": mean(
            item.placement_mpc_model_id_longitudinal_rmse_m for item in items
        ),
        "average_placement_mpc_model_id_lateral_rmse_m": mean(
            item.placement_mpc_model_id_lateral_rmse_m for item in items
        ),
        "average_placement_mpc_model_id_yaw_rmse_deg": mean(
            item.placement_mpc_model_id_yaw_rmse_deg for item in items
        ),
        "total_terminal_corridor_entry_replan_count": sum(
            item.terminal_corridor_entry_replan_count for item in items
        ),
        "total_terminal_corridor_axis_frame_count": sum(
            item.terminal_corridor_axis_frame_count for item in items
        ),
        "total_terminal_corridor_axis_reset_count": sum(
            item.terminal_corridor_axis_reset_count for item in items
        ),
        "total_terminal_corridor_rolling_frame_count": sum(
            item.terminal_corridor_rolling_frame_count for item in items
        ),
        "total_terminal_corridor_handoff_count": sum(
            item.terminal_corridor_handoff_count for item in items
        ),
        "total_terminal_corridor_timeout_handoff_count": sum(
            item.terminal_corridor_timeout_handoff_count for item in items
        ),
        "total_terminal_corridor_reacquire_count": sum(
            item.terminal_corridor_reacquire_count for item in items
        ),
        "total_terminal_corridor_visual_coarse_frame_count": sum(
            item.terminal_corridor_visual_coarse_frame_count for item in items
        ),
        "total_terminal_corridor_visual_stale_frame_count": sum(
            item.terminal_corridor_visual_stale_frame_count for item in items
        ),
        "average_terminal_corridor_handoff_distance_m": _optional_mean(
            items, "terminal_corridor_last_handoff_distance_m"
        ),
        "average_terminal_corridor_handoff_abs_lateral_m": (
            mean(
                abs(float(item.terminal_corridor_last_handoff_lateral_m))
                for item in items
                if item.terminal_corridor_last_handoff_lateral_m is not None
            )
            if any(item.terminal_corridor_last_handoff_lateral_m is not None for item in items)
            else None
        ),
        "average_terminal_corridor_handoff_abs_yaw_deg": (
            mean(
                abs(float(item.terminal_corridor_last_handoff_yaw_deg))
                for item in items
                if item.terminal_corridor_last_handoff_yaw_deg is not None
            )
            if any(item.terminal_corridor_last_handoff_yaw_deg is not None for item in items)
            else None
        ),
        "total_vision_visual_takeover_count": sum(
            item.vision_visual_takeover_count for item in items
        ),
        "total_pickup_vision_visual_takeover_count": sum(
            item.pickup_vision_visual_takeover_count for item in items
        ),
        "total_vision_authority_lock_count": sum(
            item.vision_authority_lock_count for item in items
        ),
        "total_vision_authority_unlock_count": sum(
            item.vision_authority_unlock_count for item in items
        ),
        "total_pickup_vision_authority_lock_count": sum(
            item.pickup_vision_authority_lock_count for item in items
        ),
        "total_pickup_vision_authority_unlock_count": sum(
            item.pickup_vision_authority_unlock_count for item in items
        ),
        "carried_load_visual_authority_active_rate": (
            sum(item.carried_load_visual_authority_locked for item in items) / len(items)
        ),
        "total_carried_load_visual_lock_count": sum(
            item.carried_load_visual_lock_count for item in items
        ),
        "total_carried_load_visual_rgb_update_count": sum(
            item.carried_load_visual_rgb_update_count for item in items
        ),
        "total_carried_load_visual_guide_reject_count": sum(
            item.carried_load_visual_guide_reject_count for item in items
        ),
        "total_carried_load_visual_rigid_prediction_count": sum(
            item.carried_load_visual_rigid_prediction_count for item in items
        ),
        "total_carried_load_visual_handoff_seed_count": sum(
            item.carried_load_visual_handoff_seed_count for item in items
        ),
        "carried_load_yaw_anchor_used_episode_count": sum(
            int(item.carried_load_yaw_anchor_used) for item in items
        ),
        "carried_load_yaw_anchor_used_rate": sum(
            int(item.carried_load_yaw_anchor_used) for item in items
        ) / len(items),
        "average_carried_load_yaw_anchor_sample_count": mean(
            item.carried_load_yaw_anchor_sample_count for item in items
        ),
        "average_carried_load_yaw_anchor_spread_deg": _optional_mean(
            items, "carried_load_yaw_anchor_spread_deg"
        ),
        "average_carried_load_yaw_anchor_delta_from_latest_deg": _optional_mean(
            items, "carried_load_yaw_anchor_delta_from_latest_deg"
        ),
        "carried_load_seed_provenance_counts": seed_provenance_counts,
        "carried_load_seed_trusted_episode_count": sum(
            int(item.carried_load_seed_trusted_for_aggressive_risk) for item in items
        ),
        "controller_release_seed_provenance_counts": release_seed_provenance_counts,
        "controller_release_trusted_seed_count": sum(
            int(item.controller_release_seed_trusted_for_aggressive_risk is True) for item in items
        ),
        "controller_release_untrusted_seed_count": sum(
            int(item.controller_release_seed_trusted_for_aggressive_risk is False) for item in items
        ),
        "controller_release_risk_budget_mode_counts": release_risk_budget_mode_counts,
        "controller_release_yaw_risk_budget_mode_counts": release_yaw_risk_budget_mode_counts,
        "controller_release_target_source_counts": release_target_source_counts,
        "release_center_yaw_anchor_seen_rate": (
            sum(int(item.release_center_yaw_anchor_seen) for item in items) / len(items)
        ),
        "total_release_center_yaw_anchor_active_frame_count": sum(
            item.release_center_yaw_anchor_active_frame_count for item in items
        ),
        "total_strict_release_center_yaw_rss_frame_count": sum(
            item.strict_release_center_yaw_rss_frame_count for item in items
        ),
        "total_strict_release_center_yaw_conflict_count": sum(
            item.strict_release_center_yaw_conflict_count for item in items
        ),
        "total_strict_release_center_yaw_revalidation_count": sum(
            item.strict_release_center_yaw_revalidation_count for item in items
        ),
        "total_strict_release_center_yaw_conflict_fallback_frame_count": sum(
            item.strict_release_center_yaw_conflict_fallback_frame_count for item in items
        ),
        "max_strict_release_center_yaw_conflict_jump_deg": max(
            (
                float(item.strict_release_center_yaw_conflict_last_jump_deg)
                for item in items
                if item.strict_release_center_yaw_conflict_last_jump_deg is not None
            ),
            default=None,
        ),
        "max_strict_release_center_yaw_conflict_load_stale_seconds": max(
            (
                float(item.strict_release_center_yaw_conflict_last_load_stale_seconds)
                for item in items
                if item.strict_release_center_yaw_conflict_last_load_stale_seconds is not None
            ),
            default=None,
        ),
        "total_strict_release_certification_pass_count": sum(
            item.strict_release_certification_pass_count for item in items
        ),
        "total_strict_release_certification_reject_count": sum(
            item.strict_release_certification_reject_count for item in items
        ),
        "total_terminal_corridor_timeout_handoff_guard_reject_count": sum(
            item.terminal_corridor_timeout_handoff_guard_reject_count for item in items
        ),
        "total_carried_load_visual_handoff_fallback_seed_count": sum(
            item.carried_load_visual_handoff_fallback_seed_count for item in items
        ),
        "total_release_supervisor_settle_count": sum(
            item.release_supervisor_settle_count for item in items
        ),
        "total_release_supervisor_intent_count": sum(
            item.release_supervisor_intent_count for item in items
        ),
        "total_release_supervisor_intent_abort_count": sum(
            item.release_supervisor_intent_abort_count for item in items
        ),
        "total_release_supervisor_settle_timeout_count": sum(
            item.release_supervisor_settle_timeout_count for item in items
        ),
        "total_release_supervisor_mpc_resume_count": sum(
            item.release_supervisor_mpc_resume_count for item in items
        ),
        "total_release_supervisor_hold_seconds": sum(
            item.release_supervisor_hold_seconds for item in items
        ),
        "total_release_supervisor_certified_hold_seconds": sum(
            item.release_supervisor_certified_hold_seconds for item in items
        ),
        "average_release_supervisor_certification_to_release_seconds": _optional_mean(
            items, "release_supervisor_certification_to_release_seconds"
        ),
        "terminal_mpc_ownership_rate": (
            sum(item.terminal_ownership_mpc_entered for item in items) / len(items)
        ),
        "total_terminal_ownership_direct_mpc_count": sum(
            item.terminal_ownership_direct_mpc_count for item in items
        ),
        "total_terminal_ownership_forced_mpc_count": sum(
            item.terminal_ownership_forced_mpc_count for item in items
        ),
        "total_terminal_ownership_align_timeout_count": sum(
            item.terminal_ownership_align_timeout_count for item in items
        ),
        "total_terminal_ownership_reacquire_count": sum(
            item.terminal_ownership_reacquire_count for item in items
        ),
        "average_terminal_ownership_align_seconds": mean(
            item.terminal_ownership_total_align_seconds for item in items
        ),
        "maximum_terminal_ownership_align_seconds": max(
            (item.terminal_ownership_max_align_seconds for item in items), default=0.0
        ),
        "average_carried_load_belief_position_sigma_m": mean(
            item.carried_load_belief_position_sigma_m for item in items
        ),
        "average_carried_load_belief_yaw_sigma_deg": mean(
            item.carried_load_belief_yaw_sigma_deg for item in items
        ),
        "average_carried_load_motion_yaw_sigma_deg": mean(
            item.carried_load_motion_yaw_sigma_deg for item in items
        ),
        "average_carried_load_release_yaw_sigma_deg": mean(
            item.carried_load_release_yaw_sigma_deg for item in items
        ),
        "average_carried_load_yaw_anchor_seed_sigma_deg": _optional_mean(
            items, "carried_load_yaw_anchor_seed_sigma_deg"
        ),
        "carried_load_yaw_evidence_source_counts": _count_string_values(
            items, "carried_load_yaw_evidence_source"
        ),
        "average_carried_load_belief_distance_since_visual_m": mean(
            item.carried_load_belief_distance_since_visual_m for item in items
        ),
        "average_carried_load_belief_turn_since_visual_deg": mean(
            item.carried_load_belief_turn_since_visual_deg for item in items
        ),
        "total_carried_load_belief_transport_scaled_frames": sum(
            item.carried_load_belief_transport_scaled_frames for item in items
        ),
        "total_placement_mpc_yaw_escrow_activation_count": sum(
            item.placement_mpc_yaw_escrow_activation_count for item in items
        ),
        "total_certified_basin_enter_count": sum(item.certified_basin_enter_count for item in items),
        "total_certified_basin_exit_count": sum(item.certified_basin_exit_count for item in items),
        "total_certified_basin_strict_enter_count": sum(item.certified_basin_strict_enter_count for item in items),
        "total_certified_basin_consensus_enter_count": sum(item.certified_basin_consensus_enter_count for item in items),
        "total_certified_basin_persisted_pass_count": sum(item.certified_basin_persisted_pass_count for item in items),
        "maximum_certified_basin_active_seconds": max((item.certified_basin_longest_active_seconds for item in items), default=0.0),
        "certified_basin_consensus_false_positive_count": sum(bool(item.certified_basin_consensus_false_positive) for item in items),
        "strict_release_certification_blocker_counts": _sum_counter_dicts(items, "strict_release_certification_blocker_counts"),
        "total_placement_mpc_near_basin_escrow_activation_count": sum(item.placement_mpc_near_basin_escrow_activation_count for item in items),
        "total_placement_mpc_near_basin_escrow_accepted_plan_count": sum(item.placement_mpc_near_basin_escrow_accepted_plan_count for item in items),
        "average_placement_mpc_near_basin_last_deficit_improvement": mean(item.placement_mpc_near_basin_last_deficit_improvement for item in items),
        "total_terminal_load_reacquisition_sample_count": sum(item.terminal_load_reacquisition_sample_count for item in items),
        "total_terminal_load_reacquisition_raw_detection_count": sum(item.terminal_load_reacquisition_raw_detection_count for item in items),
        "total_terminal_load_reacquisition_consensus_update_count": sum(item.terminal_load_reacquisition_consensus_update_count for item in items),
        "total_terminal_load_reacquisition_observer_update_count": sum(item.terminal_load_reacquisition_observer_update_count for item in items),
        "total_terminal_load_reacquisition_observer_rejection_count": sum(item.terminal_load_reacquisition_observer_rejection_count for item in items),
        "total_terminal_load_reacquisition_position_only_update_count": sum(item.terminal_load_reacquisition_position_only_update_count for item in items),
        "total_terminal_load_reacquisition_yaw_suppressed_count": sum(item.terminal_load_reacquisition_yaw_suppressed_count for item in items),
        "terminal_load_reacquisition_yaw_authority_enabled_episode_count": sum(int(item.terminal_load_reacquisition_yaw_authority_enabled) for item in items),
        "average_terminal_load_reacquisition_last_measurement_yaw_deg": _optional_mean(items, "terminal_load_reacquisition_last_measurement_yaw_deg"),
        "average_terminal_load_reacquisition_last_posterior_yaw_deg": _optional_mean(items, "terminal_load_reacquisition_last_posterior_yaw_deg"),
        "total_terminal_load_reacquisition_rejected_innovation_count": sum(item.terminal_load_reacquisition_rejected_innovation_count for item in items),
        "total_terminal_load_reacquisition_rejected_spread_count": sum(item.terminal_load_reacquisition_rejected_spread_count for item in items),
        "maximum_terminal_load_reacquisition_stale_seconds": max((item.terminal_load_reacquisition_maximum_stale_seconds for item in items), default=0.0),
        "average_terminal_load_reacquisition_position_spread_m": _optional_mean(items, "terminal_load_reacquisition_last_position_spread_m"),
        "average_terminal_load_reacquisition_yaw_spread_deg": _optional_mean(items, "terminal_load_reacquisition_last_yaw_spread_deg"),
        "average_terminal_load_reacquisition_position_innovation_m": mean(item.terminal_load_reacquisition_last_position_innovation_m for item in items),
        "average_terminal_load_reacquisition_yaw_innovation_deg": mean(item.terminal_load_reacquisition_last_yaw_innovation_deg for item in items),
        "total_placement_micro_primitive_search_count": sum(item.placement_micro_primitive_search_count for item in items),
        "total_placement_micro_primitive_activation_count": sum(item.placement_micro_primitive_activation_count for item in items),
        "total_placement_micro_primitive_accepted_count": sum(item.placement_micro_primitive_accepted_count for item in items),
        "total_placement_micro_primitive_candidate_count": sum(item.placement_micro_primitive_candidate_count for item in items),
        "average_placement_micro_primitive_last_deficit_improvement": mean(item.placement_micro_primitive_last_deficit_improvement for item in items),
        "total_placement_strict_recovery_retention_search_count": sum(item.placement_strict_recovery_retention_search_count for item in items),
        "total_placement_strict_recovery_retention_activation_count": sum(item.placement_strict_recovery_retention_activation_count for item in items),
        "total_placement_strict_recovery_retention_candidate_count": sum(item.placement_strict_recovery_retention_candidate_count for item in items),
        "average_placement_strict_recovery_retention_last_deficit_improvement": mean(item.placement_strict_recovery_retention_last_deficit_improvement for item in items),
        "total_placement_strict_recovery_final_settle_count": sum(item.placement_strict_recovery_final_settle_count for item in items),
        "total_placement_fresh_rgb_yaw_closure_search_count": sum(item.placement_fresh_rgb_yaw_closure_search_count for item in items),
        "total_placement_fresh_rgb_yaw_closure_activation_count": sum(item.placement_fresh_rgb_yaw_closure_activation_count for item in items),
        "total_placement_fresh_rgb_yaw_closure_candidate_count": sum(item.placement_fresh_rgb_yaw_closure_candidate_count for item in items),
        "total_placement_fresh_rgb_yaw_closure_feedback_reject_count": sum(item.placement_fresh_rgb_yaw_closure_feedback_reject_count for item in items),
        "average_placement_fresh_rgb_yaw_closure_last_predicted_yaw_improvement_deg": mean(item.placement_fresh_rgb_yaw_closure_last_predicted_yaw_improvement_deg for item in items),
        "average_placement_fresh_rgb_yaw_closure_last_measured_yaw_improvement_deg": mean(item.placement_fresh_rgb_yaw_closure_last_measured_yaw_improvement_deg for item in items),
        "total_placement_fresh_rgb_yaw_closure_total_candidate_count": sum(item.placement_fresh_rgb_yaw_closure_total_candidate_count for item in items),
        "total_placement_fresh_rgb_yaw_closure_no_candidate_search_count": sum(item.placement_fresh_rgb_yaw_closure_no_candidate_search_count for item in items),
        "total_placement_post_closure_basin_ownership_entry_count": sum(item.placement_post_closure_basin_ownership_entry_count for item in items),
        "total_placement_post_closure_mpc_veto_count": sum(item.placement_post_closure_mpc_veto_count for item in items),
        "total_placement_post_closure_mpc_safe_allow_count": sum(item.placement_post_closure_mpc_safe_allow_count for item in items),
        "total_placement_post_closure_certification_handoff_count": sum(item.placement_post_closure_certification_handoff_count for item in items),
        "total_placement_post_closure_continuation_search_count": sum(item.placement_post_closure_continuation_search_count for item in items),
        "total_placement_post_closure_continuation_activation_count": sum(item.placement_post_closure_continuation_activation_count for item in items),
        "average_placement_post_closure_last_certification_position_m": _optional_mean(items, "placement_post_closure_last_certification_position_m"),
        "average_placement_post_closure_last_certification_yaw_deg": _optional_mean(items, "placement_post_closure_last_certification_yaw_deg"),
        "total_placement_post_closure_gray_zone_hold_count": sum(item.placement_post_closure_gray_zone_hold_count for item in items),
        "total_placement_certification_basin_closure_search_count": sum(item.placement_certification_basin_closure_search_count for item in items),
        "total_placement_certification_basin_closure_activation_count": sum(item.placement_certification_basin_closure_activation_count for item in items),
        "total_placement_certification_basin_closure_candidate_count": sum(item.placement_certification_basin_closure_candidate_count for item in items),
        "total_placement_certification_basin_closure_total_candidate_count": sum(item.placement_certification_basin_closure_total_candidate_count for item in items),
        "total_placement_certification_basin_closure_no_candidate_search_count": sum(item.placement_certification_basin_closure_no_candidate_search_count for item in items),
        "total_placement_certification_basin_closure_feedback_reject_count": sum(item.placement_certification_basin_closure_feedback_reject_count for item in items),
        "average_placement_certification_basin_closure_last_predicted_deficit_improvement": mean(item.placement_certification_basin_closure_last_predicted_deficit_improvement for item in items),
        "average_placement_certification_basin_closure_last_measured_deficit_improvement": mean(item.placement_certification_basin_closure_last_measured_deficit_improvement for item in items),
        "average_placement_certification_basin_closure_last_current_deficit": mean(item.placement_certification_basin_closure_last_current_deficit for item in items),
        "average_placement_certification_basin_closure_last_predicted_deficit": mean(item.placement_certification_basin_closure_last_predicted_deficit for item in items),
        "total_placement_certification_basin_closure_post_motion_rgb_updates": sum(item.placement_certification_basin_closure_post_motion_rgb_updates for item in items),
        "total_placement_certification_basin_closure_supervisor_retry_suppressed_count": sum(item.placement_certification_basin_closure_supervisor_retry_suppressed_count for item in items),
        "total_placement_certification_basin_closure_full_pose_search_count": sum(item.placement_certification_basin_closure_full_pose_search_count for item in items),
        "total_placement_certification_basin_closure_legacy_error_space_search_count": sum(item.placement_certification_basin_closure_legacy_error_space_search_count for item in items),
        "average_placement_certification_basin_closure_last_certification_longitudinal_m": _optional_mean(items, "placement_certification_basin_closure_last_certification_longitudinal_m"),
        "average_placement_certification_basin_closure_last_certification_lateral_m": _optional_mean(items, "placement_certification_basin_closure_last_certification_lateral_m"),
        "total_placement_position_blocker_recenter_search_count": sum(item.placement_position_blocker_recenter_search_count for item in items),
        "total_placement_position_blocker_recenter_activation_count": sum(item.placement_position_blocker_recenter_activation_count for item in items),
        "total_placement_position_blocker_recenter_candidate_count": sum(item.placement_position_blocker_recenter_candidate_count for item in items),
        "total_placement_position_blocker_recenter_total_candidate_count": sum(item.placement_position_blocker_recenter_total_candidate_count for item in items),
        "total_placement_position_blocker_recenter_return_replan_count": sum(item.placement_position_blocker_recenter_return_replan_count for item in items),
        "total_placement_position_blocker_recenter_return_candidate_count": sum(item.placement_position_blocker_recenter_return_candidate_count for item in items),
        "total_placement_position_blocker_recenter_feedback_reject_count": sum(item.placement_position_blocker_recenter_feedback_reject_count for item in items),
        "total_placement_position_blocker_recenter_abort_count": sum(item.placement_position_blocker_recenter_abort_count for item in items),
        "total_placement_position_blocker_recenter_midpoint_replan_fail_count": sum(item.placement_position_blocker_recenter_midpoint_replan_fail_count for item in items),
        "total_placement_position_blocker_recenter_mid_rgb_updates": sum(item.placement_position_blocker_recenter_mid_rgb_updates for item in items),
        "total_placement_position_blocker_recenter_final_rgb_updates": sum(item.placement_position_blocker_recenter_final_rgb_updates for item in items),
        "average_placement_position_blocker_recenter_last_predicted_effective_position_m": mean(item.placement_position_blocker_recenter_last_predicted_effective_position_m for item in items),
        "average_placement_position_blocker_recenter_last_predicted_effective_yaw_deg": mean(item.placement_position_blocker_recenter_last_predicted_effective_yaw_deg for item in items),
        "average_placement_position_blocker_recenter_last_measured_effective_position_m": mean(item.placement_position_blocker_recenter_last_measured_effective_position_m for item in items),
        "average_placement_position_blocker_recenter_last_measured_effective_yaw_deg": mean(item.placement_position_blocker_recenter_last_measured_effective_yaw_deg for item in items),
        "average_placement_position_blocker_recenter_last_measured_position_improvement_m": mean(item.placement_position_blocker_recenter_last_measured_position_improvement_m for item in items),
        "total_placement_position_blocker_recenter_presteer_timeout_count": sum(item.placement_position_blocker_recenter_presteer_timeout_count for item in items),
        "average_placement_position_blocker_recenter_last_effective_steering_deg": mean(item.placement_position_blocker_recenter_last_effective_steering_deg for item in items),
        "average_placement_position_blocker_recenter_last_departure_odometry_m": mean(item.placement_position_blocker_recenter_last_departure_odometry_m for item in items),
        "average_placement_position_blocker_recenter_last_return_odometry_m": mean(item.placement_position_blocker_recenter_last_return_odometry_m for item in items),
        "average_placement_position_blocker_recenter_midpoint_position_deviation_m": mean(item.placement_position_blocker_recenter_midpoint_position_deviation_m for item in items),
        "average_placement_position_blocker_recenter_midpoint_yaw_deviation_deg": mean(item.placement_position_blocker_recenter_midpoint_yaw_deviation_deg for item in items),
        "total_placement_position_blocker_recenter_full_pose_search_count": sum(item.placement_position_blocker_recenter_full_pose_search_count for item in items),
        "total_placement_position_blocker_recenter_full_pose_return_replan_count": sum(item.placement_position_blocker_recenter_full_pose_return_replan_count for item in items),
        "total_placement_position_blocker_recenter_legacy_error_space_search_count": sum(item.placement_position_blocker_recenter_legacy_error_space_search_count for item in items),
        "total_placement_position_blocker_recenter_rollback_count": sum(item.placement_position_blocker_recenter_rollback_count for item in items),
        "total_placement_position_blocker_recenter_rollback_success_count": sum(item.placement_position_blocker_recenter_rollback_success_count for item in items),
        "total_placement_position_blocker_recenter_rollback_failure_count": sum(item.placement_position_blocker_recenter_rollback_failure_count for item in items),
        "average_placement_position_blocker_recenter_rollback_target_odometry_m": mean(item.placement_position_blocker_recenter_rollback_target_odometry_m for item in items),
        "average_placement_position_blocker_recenter_last_rollback_odometry_m": mean(item.placement_position_blocker_recenter_last_rollback_odometry_m for item in items),
        "average_placement_position_blocker_recenter_last_return_unwind_odometry_m": mean(item.placement_position_blocker_recenter_last_return_unwind_odometry_m for item in items),
        "total_placement_position_blocker_recenter_rollback_rgb_updates": sum(item.placement_position_blocker_recenter_rollback_rgb_updates for item in items),
        "placement_position_blocker_recenter_rollback_reason_counts": dict(Counter(item.placement_position_blocker_recenter_rollback_reason for item in items if item.placement_position_blocker_recenter_rollback_reason)),
        "total_placement_position_blocker_recenter_yaw_handoff_count": sum(item.placement_position_blocker_recenter_yaw_handoff_count for item in items),
        "total_placement_position_blocker_recenter_retrace_candidate_reject_count": sum(item.placement_position_blocker_recenter_retrace_candidate_reject_count for item in items),
        "total_placement_position_blocker_recenter_topology_candidate_count": sum(item.placement_position_blocker_recenter_topology_candidate_count for item in items),
        "total_placement_position_blocker_recenter_final_evidence_consistent_rgb_updates": sum(item.placement_position_blocker_recenter_final_evidence_consistent_rgb_updates for item in items),
        "total_placement_position_blocker_recenter_final_live_strict_attempt_count": sum(item.placement_position_blocker_recenter_final_live_strict_attempt_count for item in items),
        "total_placement_position_blocker_recenter_final_evidence_timeout_count": sum(item.placement_position_blocker_recenter_final_evidence_timeout_count for item in items),
        "placement_target_multiview_ready_rate": (
            sum(bool(item.placement_target_multiview_ready) for item in items) / len(items)
        ),
        "average_placement_target_multiview_samples": mean(
            item.placement_target_multiview_samples for item in items
        ),
        "average_placement_target_multiview_position_spread_m": _optional_mean(
            items, "placement_target_multiview_position_spread_m"
        ),
        "average_placement_target_multiview_yaw_spread_deg": _optional_mean(
            items, "placement_target_multiview_yaw_spread_deg"
        ),
        "average_placement_target_fast_slow_position_disagreement_m": _optional_mean(
            items, "placement_target_fast_slow_position_disagreement_m"
        ),
        "average_placement_target_fast_slow_yaw_disagreement_deg": _optional_mean(
            items, "placement_target_fast_slow_yaw_disagreement_deg"
        ),
        "total_release_witness_capture_count": sum(
            item.release_witness_capture_count for item in items
        ),
        "total_release_witness_drift_abort_count": sum(
            item.release_witness_drift_abort_count for item in items
        ),
        "total_release_witness_instant_strict_gate_block_count": sum(
            item.release_witness_instant_strict_gate_block_count for item in items
        ),
        "release_witness_false_positive_count": sum(
            bool(item.release_witness_false_positive) for item in items
        ),
        "release_execution_false_positive_count": sum(
            bool(item.release_execution_false_positive) for item in items
        ),
        "average_release_witness_to_execute_seconds": _optional_mean(
            items, "release_witness_to_execute_seconds"
        ),
        "average_release_witness_estimated_position_error_m": _optional_mean(
            items, "release_witness_estimated_position_error_m"
        ),
        "average_release_witness_estimated_yaw_error_deg": _optional_mean(
            items, "release_witness_estimated_yaw_error_deg"
        ),
        "average_controller_release_target_raw_position_spread_m": _optional_mean(
            items, "controller_release_target_raw_position_spread_m"
        ),
        "average_controller_release_target_raw_yaw_spread_deg": _optional_mean(
            items, "controller_release_target_raw_yaw_spread_deg"
        ),
        "average_controller_release_target_position_margin_m": _optional_mean(
            items, "controller_release_target_position_margin_m"
        ),
        "average_controller_release_target_yaw_margin_deg": _optional_mean(
            items, "controller_release_target_yaw_margin_deg"
        ),
        "steering_exercised_rate": (
            sum(item.steering_exercised for item in items) / len(items)
        ),
        "average_duration_seconds": mean(
            item.duration_seconds for item in items
        ),
        "average_path_length_m": mean(
            item.path_length_m for item in items
        ),
        "average_success_duration_seconds": success_mean(
            "duration_seconds"
        ),
        "average_success_placement_error_m": success_mean(
            "final_placement_error_m"
        ),
        "maximum_success_placement_error_m": max(
            (
                item.final_placement_error_m
                for item in successes
            ),
            default=None,
        ),
        "maximum_load_tilt_deg": max(
            item.max_load_tilt_deg for item in items
        ),
        "average_pallet_position_rmse_m": mean(
            item.pallet_position_rmse_m for item in items
        ),
        "average_placement_position_rmse_m": mean(
            item.placement_position_rmse_m for item in items
        ),
        "average_pickup_vision_detection_rate": mean(
            item.pickup_vision_detection_rate for item in items
        ),
        # Backward-compatible names now contain the corrected raw PnP error.
        "average_pickup_vision_position_rmse_m": _optional_mean(
            items, "pickup_vision_position_rmse_m"
        ),
        "average_pickup_vision_yaw_rmse_deg": _optional_mean(
            items, "pickup_vision_yaw_rmse_deg"
        ),
        "average_pickup_vision_visible_detection_rate": mean(
            item.pickup_vision_visible_detection_rate
            for item in items
        ),
        "average_pickup_vision_detection_rate_approach": mean(
            item.pickup_vision_detection_rate_approach
            for item in items
        ),
        "average_pickup_vision_detection_rate_align": mean(
            item.pickup_vision_detection_rate_align
            for item in items
        ),
        "average_pickup_vision_detection_rate_insert": mean(
            item.pickup_vision_detection_rate_insert
            for item in items
        ),
        "average_pickup_vision_detection_rate_recovery": mean(
            item.pickup_vision_detection_rate_recovery
            for item in items
        ),
        "average_pickup_vision_raw_position_p95_m": _optional_mean(
            items, "pickup_vision_raw_position_p95_m"
        ),
        "average_pickup_vision_raw_yaw_p95_deg": _optional_mean(
            items, "pickup_vision_raw_yaw_p95_deg"
        ),
        "average_pickup_vision_fused_position_rmse_m": _optional_mean(
            items, "pickup_vision_fused_position_rmse_m"
        ),
        "average_pickup_vision_fused_yaw_rmse_deg": _optional_mean(
            items, "pickup_vision_fused_yaw_rmse_deg"
        ),
        "pickup_vision_acquisition_rate": (
            sum(
                item.pickup_vision_detection_acquired
                for item in items
            )
            / len(items)
        ),
        "average_pickup_vision_first_detection_seconds": _optional_mean(
            items, "pickup_vision_first_detection_seconds"
        ),
        "average_pickup_vision_longest_detection_streak_seconds": mean(
            item.pickup_vision_longest_detection_streak_seconds
            for item in items
        ),
        "average_pickup_vision_last_detection_distance_m": _optional_mean(
            items, "pickup_vision_last_detection_distance_m"
        ),
        "total_pickup_vision_accepted_outlier_count": sum(
            item.pickup_vision_accepted_outlier_count
            for item in items
        ),
        "average_pickup_vision_opportunity_detection_rate": mean(
            item.pickup_vision_opportunity_detection_rate
            for item in items
        ),
        "pickup_vision_preinsert_ready_rate": (
            sum(item.pickup_vision_ready_before_insert for item in items)
            / len(items)
        ),
        "average_pickup_vision_detections_before_insert": mean(
            item.pickup_vision_detections_before_insert
            for item in items
        ),
        "pickup_vision_first_detection_preinsert_rate": (
            sum(
                item.pickup_vision_first_detection_state
                in ("APPROACH", "ALIGN")
                for item in items
            )
            / len(items)
        ),
        "average_pickup_vision_fused_position_p95_m": _optional_mean(
            items, "pickup_vision_fused_position_p95_m"
        ),
        "average_pickup_vision_fused_yaw_p95_deg": _optional_mean(
            items, "pickup_vision_fused_yaw_p95_deg"
        ),
        "total_pickup_vision_raw_outlier_count": sum(
            item.pickup_vision_raw_outlier_count
            for item in items
        ),
        "total_pickup_vision_innovation_rejected_count": sum(
            item.pickup_vision_innovation_rejected_count
            for item in items
        ),
        "total_pickup_vision_measurement_guide_rejected_count": sum(
            item.pickup_vision_measurement_guide_rejected_count
            for item in items
        ),
        "total_pickup_vision_control_accepted_outlier_count": sum(
            item.pickup_vision_control_accepted_outlier_count
            for item in items
        ),
        "average_pickup_detector_raw_position_rmse_m": _optional_mean(
            items, "pickup_detector_raw_position_rmse_m"
        ),
        "average_pickup_detector_raw_yaw_rmse_deg": _optional_mean(
            items, "pickup_detector_raw_yaw_rmse_deg"
        ),
        "average_pickup_detector_raw_position_p95_m": _optional_mean(
            items, "pickup_detector_raw_position_p95_m"
        ),
        "average_pickup_detector_raw_yaw_p95_deg": _optional_mean(
            items, "pickup_detector_raw_yaw_p95_deg"
        ),
        "total_pickup_vision_control_accepted_measurement_count": sum(
            item.pickup_vision_control_accepted_measurement_count
            for item in items
        ),
        "average_pickup_vision_control_accepted_outlier_rate": mean(
            item.pickup_vision_control_accepted_outlier_rate
            for item in items
        ),
        "total_pickup_vision_control_accepted_severe_outlier_count": sum(
            item.pickup_vision_control_accepted_severe_outlier_count
            for item in items
        ),
        "average_pickup_vision_control_accepted_severe_outlier_rate": mean(
            item.pickup_vision_control_accepted_severe_outlier_rate
            for item in items
        ),
        "pickup_vision_use_rate": (
            sum(item.pickup_vision_used_for_pickup for item in items)
            / len(items)
        ),
        "average_vision_detection_rate": mean(
            item.vision_detection_rate for item in items
        ),
        "average_vision_position_rmse_m": _optional_mean(
            items, "vision_position_rmse_m"
        ),
        "average_vision_yaw_rmse_deg": _optional_mean(
            items, "vision_yaw_rmse_deg"
        ),
        "vision_terminal_use_rate": (
            sum(item.vision_used_for_terminal for item in items)
            / len(items)
        ),
        "render_attempt_count": sum(
            item.render_attempt_count for item in items
        ),
        "render_retry_count": sum(
            item.render_retry_count for item in items
        ),
        "render_failure_count": sum(
            item.render_failure_count for item in items
        ),
        "render_invalid_frame_count": sum(
            item.render_invalid_frame_count for item in items
        ),
        "render_context_warning_count": sum(
            item.render_context_warning_count for item in items
        ),
        "render_exception_count": sum(
            item.render_exception_count for item in items
        ),
        "appearance_frame_count": sum(
            item.appearance_frame_count for item in items
        ),
        "appearance_dropout_count": sum(
            item.appearance_dropout_count for item in items
        ),
        "appearance_blur_count": sum(
            item.appearance_blur_count for item in items
        ),
        "appearance_occlusion_count": sum(
            item.appearance_occlusion_count for item in items
        ),
        "appearance_noise_frame_count": sum(
            item.appearance_noise_frame_count for item in items
        ),
        "appearance_affine_frame_count": sum(
            item.appearance_affine_frame_count for item in items
        ),
        "maximum_appearance_camera_translation_m": max(
            item.appearance_maximum_camera_translation_m
            for item in items
        ),
        "maximum_appearance_camera_rotation_deg": max(
            item.appearance_maximum_camera_rotation_deg
            for item in items
        ),
        "pickup_vision_high_confidence_count": sum(
            item.pickup_vision_high_confidence_count for item in items
        ),
        "pickup_vision_medium_confidence_count": sum(
            item.pickup_vision_medium_confidence_count for item in items
        ),
        "pickup_vision_confidence_rejection_count": sum(
            item.pickup_vision_confidence_rejection_count for item in items
        ),
        "vision_high_confidence_count": sum(
            item.vision_high_confidence_count for item in items
        ),
        "vision_medium_confidence_count": sum(
            item.vision_medium_confidence_count for item in items
        ),
        "vision_confidence_rejection_count": sum(
            item.vision_confidence_rejection_count for item in items
        ),
        "vision_guide_rejection_count": sum(
            item.vision_guide_rejection_count for item in items
        ),
        "vision_innovation_rejection_count": sum(
            item.vision_innovation_rejection_count for item in items
        ),
        "failure_reasons": failures,
        "by_difficulty": by_difficulty,
        "by_profile": by_profile,
        "by_appearance_profile": by_appearance_profile,
    }


def write_dual_vision_results(
    output_dir: Path,
    results: Iterable[DualVisionMissionResult],
) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    items = list(results)
    summary = summarize_dual_vision_missions(items)

    with (output_dir / "episodes.jsonl").open(
        "w", encoding="utf-8"
    ) as stream:
        for item in items:
            stream.write(
                json.dumps(item.to_dict(), ensure_ascii=False) + "\n"
            )

    excluded = {
        "state_durations",
        "scenario",
        "pickup_vision_sample_count_by_state",
        "pickup_vision_detection_count_by_state",
        "pickup_vision_opportunity_count_by_state",
        "pickup_vision_opportunity_detection_count_by_state",
        "pickup_vision_raw_detection_rate_by_state",
        "pickup_vision_control_detection_rate_by_state",
        "render_channel_failures",
        "precision_diagnostics",
    }
    fields = [
        name
        for name in DualVisionMissionResult.__dataclass_fields__
        if name not in excluded
    ]
    with (output_dir / "episodes.csv").open(
        "w", newline="", encoding="utf-8-sig"
    ) as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for item in items:
            row = item.to_dict()
            writer.writerow({key: row[key] for key in fields})

    (output_dir / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return summary
