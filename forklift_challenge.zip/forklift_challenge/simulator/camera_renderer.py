"""Off-screen MuJoCo RGB camera rendering."""

from __future__ import annotations

import mujoco
import numpy as np


class MultiCameraRenderer:
    """Render named MuJoCo cameras at a common resolution."""

    def __init__(self, model: mujoco.MjModel, *, width: int, height: int) -> None:
        if width <= 0 or height <= 0:
            raise ValueError("Camera width and height must be positive")
        self._renderer = mujoco.Renderer(model, height=height, width=width)

    def render(self, data: mujoco.MjData, camera_name: str) -> np.ndarray:
        self._renderer.update_scene(data, camera=camera_name)
        return self._renderer.render().copy()

    def close(self) -> None:
        close = getattr(self._renderer, "close", None)
        if callable(close):
            close()
