"""Run focused V9.3.13 weak-guide finals qualification batches."""
from __future__ import annotations
import argparse
from pathlib import Path
import subprocess
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def run(episodes: int, difficulty: str, appearance: str, seed: int, trace_failures: bool) -> int:
    cmd = [
        sys.executable,
        str(PROJECT_ROOT / "scripts" / "run_v9_3_13_batch.py"),
        "--episodes", str(episodes),
        "--difficulty", difficulty,
        "--profile", "weak_guide",
        "--appearance-profile", appearance,
        "--seed", str(seed),
    ]
    if trace_failures:
        cmd.append("--trace-failures")
    print("\n>", " ".join(cmd))
    return subprocess.run(cmd, cwd=PROJECT_ROOT).returncode


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--episodes", type=int, default=10)
    parser.add_argument("--seed", type=int, default=20260810)
    parser.add_argument("--trace-failures", action="store_true")
    args = parser.parse_args()
    cases = (
        ("easy", "finals"),
        ("nominal", "finals"),
        ("easy", "combined"),
    )
    for difficulty, appearance in cases:
        code = run(args.episodes, difficulty, appearance, args.seed, args.trace_failures)
        if code:
            return int(code)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
