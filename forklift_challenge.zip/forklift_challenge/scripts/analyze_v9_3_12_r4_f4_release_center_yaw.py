from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from statistics import median


def wrap_angle(value: float) -> float:
    return (float(value) + math.pi) % (2.0 * math.pi) - math.pi


def _med(values):
    vals = [float(v) for v in values if v is not None and math.isfinite(float(v))]
    return None if not vals else float(median(vals))


def main() -> int:
    parser = argparse.ArgumentParser(description="Analyze V9.3.12-R4-F4 release centre-yaw certification")
    parser.add_argument("trace", type=Path)
    args = parser.parse_args()

    rows = [json.loads(line) for line in args.trace.read_text(encoding="utf-8").splitlines() if line.strip()]
    anchor_frames = 0
    yaw_rss_frames = 0
    strict_frames = 0
    truth_strict_times: list[float] = []
    target_biases: list[float] = []
    load_biases: list[float] = []
    relative_biases: list[float] = []
    yaw_margins: list[float] = []
    position_margins: list[float] = []
    anchor_spreads: list[float] = []
    anchor_ages: list[float] = []
    first_center_strict_time = None
    last_center_strict_time = None
    witness_captures = 0
    release_commits = 0

    for row in rows:
        gt = row.get("ground_truth_observation") or {}
        d = row.get("decision") or {}
        vm = row.get("vision_marker") or {}
        if vm.get("release_center_yaw_anchor_active"):
            anchor_frames += 1
            anchor_spreads.append(vm.get("release_center_yaw_anchor_spread_deg"))
            anchor_ages.append(vm.get("release_center_yaw_anchor_age_seconds"))
        if d.get("strict_release_yaw_risk_budget_mode") == "CENTER_YAW_RSS":
            yaw_rss_frames += 1
        if d.get("strict_release_certified"):
            strict_frames += 1
            if d.get("strict_release_certification_target_source") == "CENTER_YAW_ANCHOR":
                t = gt.get("sim_time")
                if t is not None:
                    first_center_strict_time = float(t) if first_center_strict_time is None else first_center_strict_time
                    last_center_strict_time = float(t)
        witness_captures = max(witness_captures, int(d.get("release_witness_capture_count") or 0))
        release_commits = max(release_commits, int(d.get("placement_release_commit_count") or 0))
        yaw_margins.append(d.get("strict_release_yaw_margin_deg"))
        position_margins.append(d.get("strict_release_position_margin_m"))

        pallet = gt.get("pallet_pose_in_base")
        target = gt.get("placement_pose_in_base")
        if not pallet or not target:
            continue
        truth_pos = math.hypot(float(target["x"]) - float(pallet["x"]), float(target["y"]) - float(pallet["y"]))
        truth_yaw = abs(math.degrees(wrap_angle(float(target["yaw"]) - float(pallet["yaw"]))))
        if truth_pos < 0.095 and truth_yaw < 4.6:
            truth_strict_times.append(float(gt.get("sim_time", 0.0)))
        target_yaw = d.get("strict_release_certification_target_yaw_deg")
        load_yaw = d.get("strict_release_certification_load_yaw_deg")
        if target_yaw is None or load_yaw is None:
            continue
        truth_target_deg = math.degrees(float(target["yaw"]))
        truth_load_deg = math.degrees(float(pallet["yaw"]))
        target_bias = math.degrees(wrap_angle(math.radians(float(target_yaw) - truth_target_deg)))
        load_bias = math.degrees(wrap_angle(math.radians(float(load_yaw) - truth_load_deg)))
        truth_rel = wrap_angle(float(target["yaw"]) - float(pallet["yaw"]))
        est_rel = wrap_angle(math.radians(float(target_yaw) - float(load_yaw)))
        relative_bias = math.degrees(wrap_angle(est_rel - truth_rel))
        target_biases.append(target_bias)
        load_biases.append(load_bias)
        relative_biases.append(relative_bias)

    longest_truth_span = 0.0
    if truth_strict_times:
        start = prev = truth_strict_times[0]
        for t in truth_strict_times[1:]:
            if t - prev > 0.15:
                longest_truth_span = max(longest_truth_span, prev - start + 0.1)
                start = t
            prev = t
        longest_truth_span = max(longest_truth_span, prev - start + 0.1)

    print("V9.3.12-R4-F4 release centre-yaw / guarded yaw-RSS")
    print(f"trace: {args.trace}")
    print(f"anchor frames / yaw-RSS frames: {anchor_frames} / {yaw_rss_frames}")
    print(f"anchor age/spread median: {_med(anchor_ages)} s / {_med(anchor_spreads)} deg")
    print(f"strict frames / witness captures / release commits: {strict_frames} / {witness_captures} / {release_commits}")
    print(f"first/last center-anchor strict: {first_center_strict_time} / {last_center_strict_time}")
    print(f"truth-strict longest span: {longest_truth_span:.3f} s")
    print(f"risk margin median pos/yaw: {_med(position_margins)} m / {_med(yaw_margins)} deg")
    print(
        "GT diagnostic target/load/relative yaw bias medians: "
        f"{_med(target_biases)} / {_med(load_biases)} / {_med(relative_biases)} deg"
    )
    if rows:
        d = rows[-1].get("decision") or {}
        print(
            "final strict/source/yaw-risk/blocker: "
            f"{d.get('strict_release_certified')} / {d.get('strict_release_certification_target_source')} / "
            f"{d.get('strict_release_yaw_risk_budget_mode')} / {d.get('strict_release_certification_blocker')}"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
