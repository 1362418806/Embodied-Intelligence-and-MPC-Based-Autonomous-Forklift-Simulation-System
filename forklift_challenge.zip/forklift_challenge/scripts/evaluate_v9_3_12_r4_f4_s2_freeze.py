"""Evaluate the V9.3.12-R4-F4-S2 final V9.3 freeze gate."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

SCHEMA = "v9_3_12_r4_f4_s2_1_freeze_gate_v1"


def evaluate(summary: dict[str, Any], source: str = "<memory>") -> dict[str, Any]:
    if not isinstance(summary, dict):
        raise ValueError("summary root must be a JSON object")

    episodes = int(summary.get("episode_count", 0))
    derived = (
        summary.get("precision_diagnostics", {}).get("derived", {})
        if isinstance(summary.get("precision_diagnostics", {}), dict)
        else {}
    )
    controller_fp = int(derived.get("controller_certified_release_false_positive_count", 999))
    witness_fp = int(summary.get("release_witness_false_positive_count", 999))
    execution_fp = int(summary.get("release_execution_false_positive_count", 999))
    conflicts = int(summary.get("total_strict_release_center_yaw_conflict_count", 0))
    revalidated = int(summary.get("total_strict_release_center_yaw_revalidation_count", 0))
    fallback_frames = int(summary.get("total_strict_release_center_yaw_conflict_fallback_frame_count", 0))

    checks = {
        "episodes>=10": episodes >= 10,
        "mission>=90%": float(summary.get("success_rate", 0.0)) >= 0.90,
        "competition_precision>=90%": float(summary.get("competition_precision_success_rate", 0.0)) >= 0.90,
        "terminal_budget<=10%": float(summary.get("terminal_budget_exhausted_rate", 1.0)) <= 0.10,
        "first_cert_to_release<3s": (
            summary.get("average_release_supervisor_certification_to_release_seconds") is not None
            and float(summary["average_release_supervisor_certification_to_release_seconds"]) < 3.0
        ),
        "controller_release_truth_fp=0": controller_fp == 0,
        "release_witness_truth_fp=0": witness_fp == 0,
        "release_execution_truth_fp=0": execution_fp == 0,
        "S2_telemetry_present": all(
            key in summary
            for key in (
                "total_strict_release_center_yaw_conflict_count",
                "total_strict_release_center_yaw_revalidation_count",
                "total_strict_release_center_yaw_conflict_fallback_frame_count",
            )
        ),
        "F2_terminal_yaw_authority_disabled": int(
            summary.get("terminal_load_reacquisition_yaw_authority_enabled_episode_count", 999)
        ) == 0,
        "F4_center_yaw_seen": int(summary.get("total_release_center_yaw_anchor_active_frame_count", 0)) > 0,
        "consensus_release_authority_off": int(summary.get("total_certified_basin_consensus_enter_count", 999)) == 0,
        "consensus_truth_fp=0": int(summary.get("certified_basin_consensus_false_positive_count", 999)) == 0,
    }

    decision = "FREEZE" if all(checks.values()) else "HOLD"
    return {
        "schema": SCHEMA,
        "version": "V9.3.12-R4-F4-S2.1",
        "source": source,
        "decision": decision,
        "passed": decision == "FREEZE",
        "checks": checks,
        "metrics": {
            "episodes": episodes,
            "mission_rate": float(summary.get("success_rate", 0.0)),
            "competition_precision_rate": float(summary.get("competition_precision_success_rate", 0.0)),
            "terminal_budget_rate": float(summary.get("terminal_budget_exhausted_rate", 0.0)),
            "first_cert_to_release_seconds": summary.get("average_release_supervisor_certification_to_release_seconds"),
            "controller_fp": controller_fp,
            "witness_fp": witness_fp,
            "execution_fp": execution_fp,
            "s2_conflicts": conflicts,
            "s2_revalidated": revalidated,
            "s2_fallback_frames": fallback_frames,
            "max_conflict_jump_deg": summary.get("max_strict_release_center_yaw_conflict_jump_deg"),
            "max_conflict_load_stale_seconds": summary.get("max_strict_release_center_yaw_conflict_load_stale_seconds"),
        },
    }


def render(report: dict[str, Any]) -> str:
    metrics = report["metrics"]
    lines = [
        f"# V9.3.12-R4-F4-S2.1 Freeze Decision: {report['decision']}",
        "",
        f"- Source: `{report['source']}`",
        f"- Gate: **{'PASS' if report['passed'] else 'FAIL'}**",
        "",
        "## Checks",
        "",
    ]
    for name, ok in report["checks"].items():
        lines.append(f"- {'PASS' if ok else 'FAIL'} — {name}")
    lines += [
        "",
        "## Metrics",
        "",
        f"- episodes: {metrics['episodes']}",
        f"- mission: {metrics['mission_rate']:.1%}",
        f"- competition precision: {metrics['competition_precision_rate']:.1%}",
        f"- terminal budget: {metrics['terminal_budget_rate']:.1%}",
        f"- first-cert to release: {metrics['first_cert_to_release_seconds']}",
        f"- controller/witness/execution FP: {metrics['controller_fp']}/{metrics['witness_fp']}/{metrics['execution_fp']}",
        f"- S2 conflicts/revalidated/fallback frames: {metrics['s2_conflicts']}/{metrics['s2_revalidated']}/{metrics['s2_fallback_frames']}",
    ]
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("summary", type=Path, help="Path to S2 batch summary.json")
    parser.add_argument("--json-out", type=Path)
    parser.add_argument("--md-out", type=Path)
    args = parser.parse_args()
    try:
        summary_path = args.summary.expanduser().resolve()
        summary = json.loads(summary_path.read_text(encoding="utf-8"))
        report = evaluate(summary, str(summary_path))
    except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
        parser.error(str(exc))

    print(f"V9.3.12-R4-F4-S2.1 freeze decision: {report['decision']}")
    for name, ok in report["checks"].items():
        print(f"  {'PASS' if ok else 'FAIL'} {name}")
    if args.json_out:
        args.json_out.parent.mkdir(parents=True, exist_ok=True)
        args.json_out.write_text(json.dumps(report, indent=2), encoding="utf-8")
    if args.md_out:
        args.md_out.parent.mkdir(parents=True, exist_ok=True)
        args.md_out.write_text(render(report), encoding="utf-8")
    return 0 if report["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
