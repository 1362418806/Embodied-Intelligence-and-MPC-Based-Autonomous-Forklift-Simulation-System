"""Interactive smoke test for the forklift v0 MuJoCo model.

Controls
--------
W / Up Arrow     Raise fork target.
S / Down Arrow   Lower fork target.
R                Reset the complete simulation.
Home             Set fork target to its minimum.
End              Set fork target to its maximum.
"""

from __future__ import annotations

import argparse
import sys
import threading
import time
from dataclasses import dataclass
from pathlib import Path

import glfw
import mujoco
import mujoco.viewer
import yaml


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = PROJECT_ROOT / "configs" / "vehicle.yaml"


@dataclass
class CommandState:
    """Thread-safe commands shared by the viewer callback and simulation loop."""

    lift_target: float
    reset_requested: bool = False


class SharedCommands:
    """Small synchronized command container."""

    def __init__(self, initial_target: float) -> None:
        self._state = CommandState(lift_target=initial_target)
        self._lock = threading.Lock()

    def adjust_lift(self, delta: float, minimum: float, maximum: float) -> None:
        with self._lock:
            value = self._state.lift_target + delta
            self._state.lift_target = min(max(value, minimum), maximum)

    def set_lift(self, value: float, minimum: float, maximum: float) -> None:
        with self._lock:
            self._state.lift_target = min(max(value, minimum), maximum)

    def request_reset(self) -> None:
        with self._lock:
            self._state.reset_requested = True

    def snapshot(self) -> CommandState:
        with self._lock:
            result = CommandState(
                lift_target=self._state.lift_target,
                reset_requested=self._state.reset_requested,
            )
            self._state.reset_requested = False
            return result


def load_config(path: Path) -> dict:
    """Load and minimally validate the YAML configuration."""
    if not path.is_file():
        raise FileNotFoundError(f"Configuration file does not exist: {path}")

    with path.open("r", encoding="utf-8") as stream:
        config = yaml.safe_load(stream)

    for section in ("model", "simulation", "lift"):
        if section not in config:
            raise KeyError(f"Missing required configuration section: {section}")

    return config


def resolve_model_path(config: dict) -> Path:
    """Resolve the model path relative to the project root."""
    model_path = PROJECT_ROOT / config["model"]["xml_path"]
    model_path = model_path.resolve()
    if not model_path.is_file():
        raise FileNotFoundError(f"MJCF model does not exist: {model_path}")
    return model_path


def require_id(model: mujoco.MjModel, object_type: mujoco.mjtObj, name: str) -> int:
    """Return a named MuJoCo object ID or raise a readable error."""
    object_id = mujoco.mj_name2id(model, object_type, name)
    if object_id < 0:
        raise RuntimeError(f"Required MuJoCo object was not found: {name}")
    return object_id


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        type=Path,
        default=DEFAULT_CONFIG,
        help="Path to vehicle YAML configuration.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    config = load_config(args.config.resolve())
    model_path = resolve_model_path(config)

    lift_minimum = float(config["lift"]["minimum_height"])
    lift_maximum = float(config["lift"]["maximum_height"])
    lift_step = float(config["lift"]["keyboard_step"])
    initial_target = float(config["lift"]["initial_target"])
    realtime_factor = float(config["simulation"]["realtime_factor"])
    status_interval = float(config["simulation"]["status_interval_seconds"])

    if not lift_minimum <= initial_target <= lift_maximum:
        raise ValueError("Initial lift target is outside the configured limits.")
    if realtime_factor <= 0:
        raise ValueError("realtime_factor must be positive.")

    model = mujoco.MjModel.from_xml_path(str(model_path))
    data = mujoco.MjData(model)

    lift_joint_id = require_id(model, mujoco.mjtObj.mjOBJ_JOINT, "lift_joint")
    lift_actuator_id = require_id(
        model, mujoco.mjtObj.mjOBJ_ACTUATOR, "lift_position"
    )
    lift_qpos_address = int(model.jnt_qposadr[lift_joint_id])

    commands = SharedCommands(initial_target=initial_target)

    def key_callback(keycode: int) -> None:
        if keycode in (glfw.KEY_W, glfw.KEY_UP):
            commands.adjust_lift(lift_step, lift_minimum, lift_maximum)
        elif keycode in (glfw.KEY_S, glfw.KEY_DOWN):
            commands.adjust_lift(-lift_step, lift_minimum, lift_maximum)
        elif keycode == glfw.KEY_HOME:
            commands.set_lift(lift_minimum, lift_minimum, lift_maximum)
        elif keycode == glfw.KEY_END:
            commands.set_lift(lift_maximum, lift_minimum, lift_maximum)
        elif keycode == glfw.KEY_R:
            commands.request_reset()

    data.ctrl[lift_actuator_id] = initial_target
    mujoco.mj_forward(model, data)

    print(f"Loaded model: {model_path}")
    print(f"MuJoCo version: {mujoco.__version__}")
    print("Controls: W/Up raise, S/Down lower, R reset, Home min, End max.")
    print("Close the viewer window to exit.")

    with mujoco.viewer.launch_passive(
        model, data, key_callback=key_callback
    ) as viewer:
        with viewer.lock():
            viewer.cam.lookat[:] = (0.55, 0.0, 0.65)
            viewer.cam.distance = 5.2
            viewer.cam.azimuth = 135
            viewer.cam.elevation = -20
        viewer.sync()

        last_status_time = time.perf_counter()

        while viewer.is_running():
            step_start = time.perf_counter()
            command = commands.snapshot()

            if command.reset_requested:
                mujoco.mj_resetData(model, data)
                commands.set_lift(initial_target, lift_minimum, lift_maximum)
                command.lift_target = initial_target
                mujoco.mj_forward(model, data)
                print("\nSimulation reset.")

            data.ctrl[lift_actuator_id] = command.lift_target
            mujoco.mj_step(model, data)
            viewer.sync()

            now = time.perf_counter()
            if now - last_status_time >= status_interval:
                lift_position = float(data.qpos[lift_qpos_address])
                print(
                    "\r"
                    f"lift={lift_position:5.3f} m  "
                    f"target={command.lift_target:5.3f} m  "
                    f"contacts={data.ncon:3d}",
                    end="",
                    flush=True,
                )
                last_status_time = now

            target_wall_step = model.opt.timestep / realtime_factor
            elapsed = time.perf_counter() - step_start
            if elapsed < target_wall_step:
                time.sleep(target_wall_step - elapsed)

    print("\nForklift v0 viewer closed successfully.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (FileNotFoundError, KeyError, RuntimeError, ValueError, yaml.YAMLError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
