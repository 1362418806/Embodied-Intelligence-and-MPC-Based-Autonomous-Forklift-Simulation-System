"""Evaluate the V9.3.12-R4-E7 strict-only terminal precision-closure promotion gate."""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("summary", type=Path, help="Path to batch summary.json")
    args = parser.parse_args()
    summary = json.loads(args.summary.read_text(encoding="utf-8"))
    episodes = int(summary.get("episode_count", 0))
    derived = (
        summary.get("precision_diagnostics", {}).get("derived", {})
        if isinstance(summary.get("precision_diagnostics", {}), dict)
        else {}
    )
    controller_fp = int(derived.get("controller_certified_release_false_positive_count", 999))
    truth_ready_uncertified = float(derived.get("controller_truth_ready_uncertified_rate", 1.0))
    checks = {
        "episodes>=10": episodes >= 10,
        "mission>=90%": float(summary.get("success_rate", 0.0)) >= 0.90,
        "strict>=90%": float(summary.get("competition_precision_success_rate", 0.0)) >= 0.90,
        "terminal_budget<=10%": float(summary.get("terminal_budget_exhausted_rate", 1.0)) <= 0.10,
        "mpc_ownership>=90%": float(summary.get("terminal_mpc_ownership_rate", 0.0)) >= 0.90,
        "multiview_ready>=90%": float(summary.get("placement_target_multiview_ready_rate", 0.0)) >= 0.90,
        "align_max<10s": float(summary.get("maximum_terminal_ownership_align_seconds", 1e9)) < 10.0,
        "first_cert_to_release<3s": (
            summary.get("average_release_supervisor_certification_to_release_seconds") is not None
            and float(summary["average_release_supervisor_certification_to_release_seconds"]) < 3.0
        ),
        # V9.3.12-R4-E7 safety contract: consensus has no release authority at all.
        "consensus_basin_entries=0": int(summary.get("total_certified_basin_consensus_enter_count", 999)) == 0,
        "consensus_basin_truth_fp=0": int(summary.get("certified_basin_consensus_false_positive_count", 999)) == 0,
        "controller_release_truth_fp=0": controller_fp == 0,
        "release_witness_truth_fp=0": int(summary.get("release_witness_false_positive_count", 999)) == 0,
        "release_execution_truth_fp=0": int(summary.get("release_execution_false_positive_count", 999)) == 0,
        "terminal_reacq_consensus>0": int(summary.get("total_terminal_load_reacquisition_consensus_update_count", 0)) > 0,
        "terminal_observer_updates>0": int(summary.get("total_terminal_load_reacquisition_observer_update_count", 0)) > 0,
        "R4E1_settle_not_rearmed_per_episode": int(summary.get("total_placement_strict_recovery_final_settle_count", 0)) <= episodes,
        "R4E1_post_closure_no_safety_regression": int(summary.get("release_execution_false_positive_count", 999)) == 0,
        "R4E7_position_recenter_abort=0": int(summary.get("total_placement_position_blocker_recenter_abort_count", 0)) == 0,
        "R4E7_midpoint_replan_fail=0": int(summary.get("total_placement_position_blocker_recenter_midpoint_replan_fail_count", 0)) == 0,
        "R4E7_presteer_timeout=0": int(summary.get("total_placement_position_blocker_recenter_presteer_timeout_count", 0)) == 0,
        "R4E7_feedback_reject=0": int(summary.get("total_placement_position_blocker_recenter_feedback_reject_count", 0)) == 0,
        "R4E7_legacy_error_space_runtime=0": int(summary.get("total_placement_position_blocker_recenter_legacy_error_space_search_count", 0)) == 0,
        "R4E7_yaw_closure_legacy_error_space_runtime=0": int(summary.get("total_placement_certification_basin_closure_legacy_error_space_search_count", 0)) == 0,
        "R4E7_rollback_failure=0": int(summary.get("total_placement_position_blocker_recenter_rollback_failure_count", 0)) == 0,
        "R4E7_final_evidence_timeout=0": int(summary.get("total_placement_position_blocker_recenter_final_evidence_timeout_count", 0)) == 0,
        "witness_to_execute<1s": (
            summary.get("average_release_witness_to_execute_seconds") is not None
            and float(summary["average_release_witness_to_execute_seconds"]) < 1.0
        ),
    }
    # The legacy episode-binary truth-ready metric remains diagnostic only in
    # R4-A; successful episodes can briefly become truth-ready before normal
    # certification. R4-C/final qualification will use duration-based liveness.
    passed = all(checks.values())
    print(f"V9.3.12-R4-E7 precision closure: {'PASS' if passed else 'FAIL'}")
    for name, ok in checks.items():
        print(f"  {'PASS' if ok else 'FAIL'} {name}")
    print(
        "  metrics: "
        f"mission={float(summary.get('success_rate', 0.0)):.1%}, "
        f"strict={float(summary.get('competition_precision_success_rate', 0.0)):.1%}, "
        f"terminal_budget={float(summary.get('terminal_budget_exhausted_rate', 0.0)):.1%}, "
        f"ownership={float(summary.get('terminal_mpc_ownership_rate', 0.0)):.1%}, "
        f"truth_ready_uncertified={truth_ready_uncertified:.1%}, "
        f"consensus_entries={summary.get('total_certified_basin_consensus_enter_count')}, "
        f"controller_fp={controller_fp}, "
        f"witness_fp={summary.get('release_witness_false_positive_count')}, "
        f"execution_fp={summary.get('release_execution_false_positive_count')}, "
        f"release_seed_modes={summary.get('controller_release_risk_budget_mode_counts')}, "
        f"release_untrusted={summary.get('controller_release_untrusted_seed_count')}"
    )
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
