"""Deterministic RGB appearance and camera-calibration stress for V8.2."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
import math
import zlib
from typing import Any, Mapping

import cv2
import numpy as np


def _stable_offset(name: str) -> int:
    return int(zlib.crc32(name.encode("utf-8")) & 0xFFFFFFFF)


def _clipped_normal(
    rng: np.random.Generator,
    sigma: float,
    clip: float,
    size: int,
) -> np.ndarray:
    if sigma <= 0.0 or clip <= 0.0:
        return np.zeros(size, dtype=np.float64)
    return np.clip(rng.normal(0.0, sigma, size=size), -clip, clip)


def _quat_mul(left: np.ndarray, right: np.ndarray) -> np.ndarray:
    w1, x1, y1, z1 = [float(v) for v in left]
    w2, x2, y2, z2 = [float(v) for v in right]
    return np.asarray(
        [
            w1*w2 - x1*x2 - y1*y2 - z1*z2,
            w1*x2 + x1*w2 + y1*z2 - z1*y2,
            w1*y2 - x1*z2 + y1*w2 + z1*x2,
            w1*z2 + x1*y2 - y1*x2 + z1*w2,
        ],
        dtype=np.float64,
    )


def _small_rpy_quat(rpy_rad: np.ndarray) -> np.ndarray:
    roll, pitch, yaw = [float(v) for v in rpy_rad]
    cr, sr = math.cos(roll/2.0), math.sin(roll/2.0)
    cp, sp = math.cos(pitch/2.0), math.sin(pitch/2.0)
    cy, sy = math.cos(yaw/2.0), math.sin(yaw/2.0)
    return np.asarray(
        [
            cr*cp*cy + sr*sp*sy,
            sr*cp*cy - cr*sp*sy,
            cr*sp*cy + sr*cp*sy,
            cr*cp*sy - sr*sp*cy,
        ],
        dtype=np.float64,
    )


@dataclass(frozen=True)
class AppearanceStressProfile:
    enabled: bool
    brightness_gain_min: float
    brightness_gain_max: float
    gamma_min: float
    gamma_max: float
    hue_shift_cv_min: float
    hue_shift_cv_max: float
    saturation_gain_min: float
    saturation_gain_max: float
    gaussian_noise_sigma_max: float
    motion_blur_probability: float
    motion_blur_kernel_max: int
    occlusion_probability: float
    occlusion_area_fraction_min: float
    occlusion_area_fraction_max: float
    frame_dropout_probability: float
    affine_shift_max_px: float
    affine_rotation_max_deg: float
    camera_translation_sigma_m: float
    camera_translation_clip_m: float
    camera_rotation_sigma_deg: float
    camera_rotation_clip_deg: float

    @classmethod
    def from_mapping(
        cls, values: Mapping[str, Any] | None
    ) -> "AppearanceStressProfile":
        v = values or {}
        result = cls(
            enabled=bool(v.get("enabled", True)),
            brightness_gain_min=float(v.get("brightness_gain_min", 1.0)),
            brightness_gain_max=float(v.get("brightness_gain_max", 1.0)),
            gamma_min=float(v.get("gamma_min", 1.0)),
            gamma_max=float(v.get("gamma_max", 1.0)),
            hue_shift_cv_min=float(v.get("hue_shift_cv_min", 0.0)),
            hue_shift_cv_max=float(v.get("hue_shift_cv_max", 0.0)),
            saturation_gain_min=float(v.get("saturation_gain_min", 1.0)),
            saturation_gain_max=float(v.get("saturation_gain_max", 1.0)),
            gaussian_noise_sigma_max=float(
                v.get("gaussian_noise_sigma_max", 0.0)
            ),
            motion_blur_probability=float(
                v.get("motion_blur_probability", 0.0)
            ),
            motion_blur_kernel_max=int(v.get("motion_blur_kernel_max", 1)),
            occlusion_probability=float(v.get("occlusion_probability", 0.0)),
            occlusion_area_fraction_min=float(
                v.get("occlusion_area_fraction_min", 0.0)
            ),
            occlusion_area_fraction_max=float(
                v.get("occlusion_area_fraction_max", 0.0)
            ),
            frame_dropout_probability=float(
                v.get("frame_dropout_probability", 0.0)
            ),
            affine_shift_max_px=float(v.get("affine_shift_max_px", 0.0)),
            affine_rotation_max_deg=float(
                v.get("affine_rotation_max_deg", 0.0)
            ),
            camera_translation_sigma_m=float(
                v.get("camera_translation_sigma_m", 0.0)
            ),
            camera_translation_clip_m=float(
                v.get("camera_translation_clip_m", 0.0)
            ),
            camera_rotation_sigma_deg=float(
                v.get("camera_rotation_sigma_deg", 0.0)
            ),
            camera_rotation_clip_deg=float(
                v.get("camera_rotation_clip_deg", 0.0)
            ),
        )
        result.validate()
        return result

    def validate(self) -> None:
        for low, high, name in (
            (
                self.brightness_gain_min,
                self.brightness_gain_max,
                "brightness",
            ),
            (self.gamma_min, self.gamma_max, "gamma"),
            (
                self.saturation_gain_min,
                self.saturation_gain_max,
                "saturation",
            ),
            (
                self.hue_shift_cv_min,
                self.hue_shift_cv_max,
                "hue",
            ),
            (
                self.occlusion_area_fraction_min,
                self.occlusion_area_fraction_max,
                "occlusion area",
            ),
        ):
            if high < low:
                raise ValueError(f"invalid {name} range")
        if self.brightness_gain_min <= 0.0 or self.gamma_min <= 0.0:
            raise ValueError("brightness and gamma must be positive")
        if self.saturation_gain_min < 0.0:
            raise ValueError("saturation gain must be non-negative")
        for value, name in (
            (self.motion_blur_probability, "motion blur probability"),
            (self.occlusion_probability, "occlusion probability"),
            (self.frame_dropout_probability, "frame dropout probability"),
        ):
            if not 0.0 <= value <= 1.0:
                raise ValueError(f"{name} must be in [0,1]")
        if self.gaussian_noise_sigma_max < 0.0:
            raise ValueError("noise sigma must be non-negative")
        if self.motion_blur_kernel_max <= 0:
            raise ValueError("motion blur kernel must be positive")
        if self.occlusion_area_fraction_min < 0.0:
            raise ValueError("occlusion fraction must be non-negative")
        if self.occlusion_area_fraction_max >= 1.0:
            raise ValueError("occlusion fraction must be < 1")
        for value in (
            self.affine_shift_max_px,
            self.affine_rotation_max_deg,
            self.camera_translation_sigma_m,
            self.camera_translation_clip_m,
            self.camera_rotation_sigma_deg,
            self.camera_rotation_clip_deg,
        ):
            if value < 0.0:
                raise ValueError("stress magnitudes must be non-negative")


@dataclass
class ChannelStressStats:
    frame_count: int = 0
    dropout_count: int = 0
    blur_count: int = 0
    occlusion_count: int = 0
    noise_frame_count: int = 0
    affine_frame_count: int = 0
    last_noise_sigma: float = 0.0
    last_blur_kernel: int = 1
    last_occlusion_fraction: float = 0.0
    last_dropped: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class AppearanceFrame:
    image: np.ndarray | None
    dropped: bool
    blurred: bool
    occluded: bool
    noise_sigma: float
    blur_kernel: int
    occlusion_fraction: float


class AppearanceStressPipeline:
    def __init__(
        self,
        *,
        profile_name: str,
        profile: AppearanceStressProfile,
        seed: int,
        image_width: int,
        image_height: int,
        seed_offset: int = 0,
    ) -> None:
        self.profile_name = str(profile_name)
        self.profile = profile
        self.seed = int(seed)
        self.seed_offset = int(seed_offset)
        self.image_width = int(image_width)
        self.image_height = int(image_height)
        master = np.random.default_rng(self.seed + self.seed_offset)
        self.brightness_gain = float(
            master.uniform(
                profile.brightness_gain_min,
                profile.brightness_gain_max,
            )
        )
        self.gamma = float(master.uniform(profile.gamma_min, profile.gamma_max))
        self.hue_shift_cv = float(
            master.uniform(
                profile.hue_shift_cv_min,
                profile.hue_shift_cv_max,
            )
        )
        self.saturation_gain = float(
            master.uniform(
                profile.saturation_gain_min,
                profile.saturation_gain_max,
            )
        )
        self._channel_rng: dict[str, np.random.Generator] = {}
        self._channel_affine: dict[str, tuple[float, float, float]] = {}
        self._stats: dict[str, ChannelStressStats] = {}
        self._camera_perturbations: dict[str, dict[str, Any]] = {}

    @classmethod
    def from_config(
        cls,
        config: Mapping[str, Any] | None,
        *,
        profile_name: str,
        seed: int,
        image_width: int,
        image_height: int,
    ) -> "AppearanceStressPipeline":
        config = config or {}
        profiles = config.get("profiles", {})
        if profile_name not in profiles:
            raise KeyError(f"appearance_stress.profiles.{profile_name}")
        return cls(
            profile_name=profile_name,
            profile=AppearanceStressProfile.from_mapping(
                profiles[profile_name]
            ),
            seed=seed,
            image_width=image_width,
            image_height=image_height,
            seed_offset=int(config.get("seed_offset", 0)),
        )

    def _rng(self, channel: str) -> np.random.Generator:
        if channel not in self._channel_rng:
            self._channel_rng[channel] = np.random.default_rng(
                self.seed
                + self.seed_offset
                + _stable_offset(channel)
            )
        return self._channel_rng[channel]

    def _affine(self, channel: str) -> tuple[float, float, float]:
        if channel not in self._channel_affine:
            rng = self._rng(channel)
            maximum_shift = self.profile.affine_shift_max_px
            maximum_rotation = self.profile.affine_rotation_max_deg
            self._channel_affine[channel] = (
                float(rng.uniform(-maximum_shift, maximum_shift)),
                float(rng.uniform(-maximum_shift, maximum_shift)),
                float(rng.uniform(-maximum_rotation, maximum_rotation)),
            )
        return self._channel_affine[channel]

    def _stats_for(self, channel: str) -> ChannelStressStats:
        return self._stats.setdefault(channel, ChannelStressStats())

    @staticmethod
    def _motion_kernel(size: int, direction: int) -> np.ndarray:
        size = max(1, int(size))
        if size % 2 == 0:
            size += 1
        kernel = np.zeros((size, size), dtype=np.float32)
        if direction == 0:
            kernel[size // 2, :] = 1.0
        elif direction == 1:
            kernel[:, size // 2] = 1.0
        elif direction == 2:
            np.fill_diagonal(kernel, 1.0)
        else:
            np.fill_diagonal(np.fliplr(kernel), 1.0)
        kernel /= max(float(kernel.sum()), 1.0)
        return kernel

    def apply(
        self,
        rgb: np.ndarray | None,
        *,
        channel: str,
    ) -> AppearanceFrame:
        stats = self._stats_for(channel)
        stats.last_dropped = False
        stats.last_noise_sigma = 0.0
        stats.last_blur_kernel = 1
        stats.last_occlusion_fraction = 0.0

        if rgb is None:
            return AppearanceFrame(
                image=None,
                dropped=False,
                blurred=False,
                occluded=False,
                noise_sigma=0.0,
                blur_kernel=1,
                occlusion_fraction=0.0,
            )

        image = np.asarray(rgb)
        if image.ndim != 3 or image.shape[2] != 3:
            raise ValueError("appearance stress expects HxWx3 RGB")
        stats.frame_count += 1

        if not self.profile.enabled:
            return AppearanceFrame(
                image=image.copy(),
                dropped=False,
                blurred=False,
                occluded=False,
                noise_sigma=0.0,
                blur_kernel=1,
                occlusion_fraction=0.0,
            )

        rng = self._rng(channel)
        if rng.random() < self.profile.frame_dropout_probability:
            stats.dropout_count += 1
            stats.last_dropped = True
            return AppearanceFrame(
                image=None,
                dropped=True,
                blurred=False,
                occluded=False,
                noise_sigma=0.0,
                blur_kernel=1,
                occlusion_fraction=0.0,
            )

        work = image.astype(np.float32) / 255.0
        work = np.clip(work * self.brightness_gain, 0.0, 1.0)
        work = np.power(work, self.gamma)
        work = np.clip(work * 255.0, 0.0, 255.0).astype(np.uint8)

        hsv = cv2.cvtColor(work, cv2.COLOR_RGB2HSV).astype(np.float32)
        hsv[..., 0] = np.mod(hsv[..., 0] + self.hue_shift_cv, 180.0)
        hsv[..., 1] = np.clip(
            hsv[..., 1] * self.saturation_gain,
            0.0,
            255.0,
        )
        work = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2RGB)

        dx, dy, angle = self._affine(channel)
        affine_applied = (
            abs(dx) > 1e-9 or abs(dy) > 1e-9 or abs(angle) > 1e-9
        )
        if affine_applied:
            center = (
                0.5 * (work.shape[1] - 1),
                0.5 * (work.shape[0] - 1),
            )
            matrix = cv2.getRotationMatrix2D(center, angle, 1.0)
            matrix[0, 2] += dx
            matrix[1, 2] += dy
            work = cv2.warpAffine(
                work,
                matrix,
                (work.shape[1], work.shape[0]),
                flags=cv2.INTER_LINEAR,
                borderMode=cv2.BORDER_REFLECT_101,
            )
            stats.affine_frame_count += 1

        blurred = False
        blur_kernel = 1
        if rng.random() < self.profile.motion_blur_probability:
            maximum = max(3, self.profile.motion_blur_kernel_max)
            sizes = [size for size in range(3, maximum + 1, 2)]
            blur_kernel = int(rng.choice(sizes))
            kernel = self._motion_kernel(
                blur_kernel,
                int(rng.integers(0, 4)),
            )
            work = cv2.filter2D(work, -1, kernel)
            blurred = True
            stats.blur_count += 1
            stats.last_blur_kernel = blur_kernel

        occluded = False
        occlusion_fraction = 0.0
        if rng.random() < self.profile.occlusion_probability:
            fraction = float(
                rng.uniform(
                    self.profile.occlusion_area_fraction_min,
                    self.profile.occlusion_area_fraction_max,
                )
            )
            if fraction > 0.0:
                height, width = work.shape[:2]
                aspect = float(rng.uniform(0.55, 1.8))
                target_area = fraction * width * height
                rect_w = max(
                    2,
                    min(width, int(round(math.sqrt(target_area * aspect)))),
                )
                rect_h = max(
                    2,
                    min(height, int(round(target_area / rect_w))),
                )
                x0 = int(rng.integers(0, max(1, width - rect_w + 1)))
                y0 = int(rng.integers(0, max(1, height - rect_h + 1)))
                fill = int(rng.integers(18, 95))
                work[y0 : y0 + rect_h, x0 : x0 + rect_w] = fill
                occluded = True
                occlusion_fraction = (
                    float(rect_w * rect_h) / float(width * height)
                )
                stats.occlusion_count += 1
                stats.last_occlusion_fraction = occlusion_fraction

        noise_sigma = 0.0
        if self.profile.gaussian_noise_sigma_max > 0.0:
            noise_sigma = float(
                rng.uniform(0.0, self.profile.gaussian_noise_sigma_max)
            )
            if noise_sigma > 1e-6:
                noise = rng.normal(
                    0.0,
                    noise_sigma,
                    size=work.shape,
                )
                work = np.clip(
                    work.astype(np.float32) + noise,
                    0.0,
                    255.0,
                ).astype(np.uint8)
                stats.noise_frame_count += 1
                stats.last_noise_sigma = noise_sigma

        return AppearanceFrame(
            image=work,
            dropped=False,
            blurred=blurred,
            occluded=occluded,
            noise_sigma=noise_sigma,
            blur_kernel=blur_kernel,
            occlusion_fraction=occlusion_fraction,
        )

    def apply_camera_extrinsics(
        self,
        model,
        mujoco_module,
        camera_names: list[str] | tuple[str, ...],
    ) -> dict[str, dict[str, Any]]:
        if not self.profile.enabled:
            self._camera_perturbations = {
                str(name): {
                    "translation_m": [0.0, 0.0, 0.0],
                    "translation_norm_m": 0.0,
                    "rotation_deg": [0.0, 0.0, 0.0],
                    "rotation_norm_deg": 0.0,
                }
                for name in camera_names
            }
            return dict(self._camera_perturbations)

        result: dict[str, dict[str, Any]] = {}
        for name in camera_names:
            rng = np.random.default_rng(
                self.seed
                + self.seed_offset
                + _stable_offset(f"camera:{name}")
            )
            camera_id = int(
                mujoco_module.mj_name2id(
                    model,
                    mujoco_module.mjtObj.mjOBJ_CAMERA,
                    str(name),
                )
            )
            if camera_id < 0:
                raise RuntimeError(f"camera not found for stress: {name}")

            translation = _clipped_normal(
                rng,
                self.profile.camera_translation_sigma_m,
                self.profile.camera_translation_clip_m,
                3,
            )
            rotation_deg = _clipped_normal(
                rng,
                self.profile.camera_rotation_sigma_deg,
                self.profile.camera_rotation_clip_deg,
                3,
            )
            model.cam_pos[camera_id, :] = (
                np.asarray(model.cam_pos[camera_id, :], dtype=np.float64)
                + translation
            )
            old_quat = np.asarray(
                model.cam_quat[camera_id, :],
                dtype=np.float64,
            )
            delta = _small_rpy_quat(np.radians(rotation_deg))
            new_quat = _quat_mul(old_quat, delta)
            norm = float(np.linalg.norm(new_quat))
            if norm <= 1e-12:
                raise RuntimeError("camera quaternion perturbation became invalid")
            model.cam_quat[camera_id, :] = new_quat / norm

            result[str(name)] = {
                "translation_m": [float(v) for v in translation],
                "translation_norm_m": float(np.linalg.norm(translation)),
                "rotation_deg": [float(v) for v in rotation_deg],
                "rotation_norm_deg": float(np.linalg.norm(rotation_deg)),
            }
        self._camera_perturbations = result
        return dict(result)

    def metrics(self) -> dict[str, Any]:
        stats = list(self._stats.values())
        camera = list(self._camera_perturbations.values())
        return {
            "profile": self.profile_name,
            "frame_count": sum(item.frame_count for item in stats),
            "dropout_count": sum(item.dropout_count for item in stats),
            "blur_count": sum(item.blur_count for item in stats),
            "occlusion_count": sum(item.occlusion_count for item in stats),
            "noise_frame_count": sum(item.noise_frame_count for item in stats),
            "affine_frame_count": sum(item.affine_frame_count for item in stats),
            "maximum_camera_translation_m": max(
                (float(item["translation_norm_m"]) for item in camera),
                default=0.0,
            ),
            "maximum_camera_rotation_deg": max(
                (float(item["rotation_norm_deg"]) for item in camera),
                default=0.0,
            ),
            "brightness_gain": self.brightness_gain,
            "gamma": self.gamma,
            "hue_shift_cv": self.hue_shift_cv,
            "saturation_gain": self.saturation_gain,
            "channels": {
                name: stats.to_dict()
                for name, stats in self._stats.items()
            },
            "camera_perturbations": dict(self._camera_perturbations),
        }

    def trace_snapshot(self) -> dict[str, Any]:
        result = self.metrics()
        # Cumulative counts are useful in failure traces, but keep the entry
        # compact by omitting per-channel duplicate detail.
        result.pop("channels", None)
        return result
