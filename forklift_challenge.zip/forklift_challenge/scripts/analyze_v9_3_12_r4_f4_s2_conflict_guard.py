"""Offline replay/audit for V9.3.12-R4-F4-S2 centre-yaw conflict guard.

The replay consumes existing F4/F4-S2 JSONL traces.  It reconstructs the
release centre-anchor world yaw from evaluator-visible vision telemetry and
applies the exact standalone S2 guard state machine.  Ground truth is used only
to classify historical risk; it is never part of runtime control.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import sys
from typing import Any

# Make direct execution independent of the caller's current working directory.
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from control.release_center_yaw_conflict_guard import (
    ReleaseCenterYawConflictGuard,
    ReleaseCenterYawConflictGuardConfig,
)


def _wrap(value: float) -> float:
    return math.atan2(math.sin(float(value)), math.cos(float(value)))


def _truth_release_error(row: dict[str, Any]) -> tuple[float | None, float | None]:
    gt = row.get("ground_truth_observation") or {}
    pallet = gt.get("pallet_pose_in_base") or {}
    target = gt.get("placement_pose_in_base") or {}
    if not pallet or not target:
        return None, None
    dx = float(target.get("x", 0.0)) - float(pallet.get("x", 0.0))
    dy = float(target.get("y", 0.0)) - float(pallet.get("y", 0.0))
    pos = math.hypot(dx, dy)
    yaw = abs(math.degrees(_wrap(float(target.get("yaw", 0.0)) - float(pallet.get("yaw", 0.0)))))
    return pos, yaw


def _proposal_world_yaw(row: dict[str, Any]) -> float | None:
    vm = row.get("vision_marker") or {}
    if not bool(vm.get("release_center_yaw_anchor_active")):
        return None
    target_yaw_deg = vm.get("release_center_yaw_anchor_target_yaw_deg")
    est = row.get("estimated_observation") or {}
    vehicle = est.get("vehicle_pose_world") or {}
    if target_yaw_deg is None or vehicle.get("yaw") is None:
        return None
    return _wrap(float(vehicle["yaw"]) + math.radians(float(target_yaw_deg)))


def analyze_trace(path: Path) -> dict[str, Any]:
    guard = ReleaseCenterYawConflictGuard(
        ReleaseCenterYawConflictGuardConfig(
            maximum_reanchor_jump_rad=math.radians(2.0),
            revalidation_seconds=0.75,
            revalidation_tolerance_rad=math.radians(0.5),
        )
    )
    conflicts: list[dict[str, Any]] = []
    revalidations: list[dict[str, Any]] = []
    original_release_time: float | None = None
    original_witness_time: float | None = None
    runtime_conflict_seen = False
    runtime_conflict_count = 0
    runtime_revalidation_count = 0

    with path.open("r", encoding="utf-8") as fh:
        for line in fh:
            if not line.strip():
                continue
            row = json.loads(line)
            gt = row.get("ground_truth_observation") or {}
            decision = row.get("decision") or {}
            t = float(gt.get("sim_time", 0.0))
            state = str(decision.get("state") or "")
            proposal = _proposal_world_yaw(row)
            update = guard.update(
                t,
                proposal_world_yaw_rad=proposal,
                release_precision_active=state == "PLACE_PRECISION",
            )
            if bool(decision.get("strict_release_center_yaw_conflict_active")):
                runtime_conflict_seen = True
            runtime_conflict_count = max(
                runtime_conflict_count,
                int(decision.get("strict_release_center_yaw_conflict_count") or 0),
            )
            runtime_revalidation_count = max(
                runtime_revalidation_count,
                int(decision.get("strict_release_center_yaw_revalidation_count") or 0),
            )
            if original_witness_time is None and bool(decision.get("release_witness_active")):
                original_witness_time = t
            if original_release_time is None and state == "LOWER_LOAD":
                original_release_time = t

            if update.conflict_started:
                pos, yaw = _truth_release_error(row)
                effective_yaw = None
                raw = decision.get("strict_release_certification_yaw_error_deg")
                margin = decision.get("strict_release_yaw_margin_deg")
                if raw is not None and margin is not None:
                    effective_yaw = abs(float(raw)) + float(margin)
                conflicts.append(
                    {
                        "sim_time": t,
                        "state": state,
                        "jump_deg": math.degrees(float(update.current_jump_rad or 0.0)),
                        "original_strict_certified": bool(decision.get("strict_release_certified")),
                        "original_target_source": decision.get("strict_release_certification_target_source"),
                        "original_yaw_risk_mode": decision.get("strict_release_yaw_risk_budget_mode"),
                        "original_raw_yaw_deg": raw,
                        "original_yaw_margin_deg": margin,
                        "original_effective_yaw_deg": effective_yaw,
                        "truth_position_m": pos,
                        "truth_yaw_deg": yaw,
                        "truth_official_pass": bool(
                            pos is not None and yaw is not None and pos < 0.10 and yaw < 5.0
                        ),
                        "load_yaw_stale_seconds": decision.get("carried_load_yaw_evidence_stale_seconds"),
                    }
                )
            if update.revalidated:
                revalidations.append({"sim_time": t})

    for event in conflicts:
        event["seconds_to_original_release"] = (
            None if original_release_time is None else original_release_time - float(event["sim_time"])
        )
        event["release_critical"] = bool(
            event["original_strict_certified"] and not event["truth_official_pass"]
        )

    return {
        "scenario_id": path.stem,
        "conflict_count": len(conflicts),
        "revalidation_count_on_original_trace": len(revalidations),
        "conflicts": conflicts,
        "revalidations": revalidations,
        "original_witness_time": original_witness_time,
        "original_release_time": original_release_time,
        "runtime_s2_conflict_seen": runtime_conflict_seen,
        "runtime_s2_conflict_count": runtime_conflict_count,
        "runtime_s2_revalidation_count": runtime_revalidation_count,
    }


def analyze(root: Path) -> dict[str, Any]:
    root = root.expanduser().resolve()
    if not root.exists():
        raise FileNotFoundError(f"replay input does not exist: {root}")
    trace_root = root / "traces" if (root / "traces").is_dir() else root
    traces = sorted(trace_root.glob("*.jsonl"))
    if not traces:
        raise FileNotFoundError(f"no JSONL traces found under: {trace_root}")
    episodes = [analyze_trace(path) for path in traces]
    critical = [
        (ep["scenario_id"], event)
        for ep in episodes
        for event in ep["conflicts"]
        if event["release_critical"]
    ]
    noncritical = [
        (ep["scenario_id"], event)
        for ep in episodes
        for event in ep["conflicts"]
        if not event["release_critical"]
    ]
    return {
        "schema": "v9_3_12_r4_f4_s2_conflict_guard_replay_v1",
        "root": str(root),
        "episode_count": len(episodes),
        "conflict_episode_count": sum(bool(ep["conflict_count"]) for ep in episodes),
        "total_conflict_count": sum(ep["conflict_count"] for ep in episodes),
        "release_critical_conflict_count": len(critical),
        "noncritical_conflict_count": len(noncritical),
        "release_critical_scenarios": [scenario for scenario, _ in critical],
        "episodes": episodes,
        "expected_gate": (
            "S2_SHOULD_BLOCK_HISTORICAL_FP"
            if len(critical) == 1 and critical[0][0] == "easy_0001"
            else "REVIEW_REPLAY_DISTRIBUTION"
        ),
    }


def _render(report: dict[str, Any]) -> str:
    lines = [
        "# V9.3.12-R4-F4-S2 Conflict-Guard Replay",
        "",
        f"- Episodes: **{report['episode_count']}**",
        f"- Conflict episodes: **{report['conflict_episode_count']}**",
        f"- Total conflicts: **{report['total_conflict_count']}**",
        f"- Release-critical conflicts: **{report['release_critical_conflict_count']}**",
        f"- Expected gate: **{report['expected_gate']}**",
        "",
    ]
    for ep in report["episodes"]:
        if not ep["conflicts"]:
            continue
        lines += [f"## {ep['scenario_id']}", ""]
        for event in ep["conflicts"]:
            lines.append(
                "- t={:.3f}s jump={:.3f}deg state={} original-strict={} truth-pass={} "
                "critical={} seconds-to-release={}".format(
                    event["sim_time"],
                    event["jump_deg"],
                    event["state"],
                    event["original_strict_certified"],
                    event["truth_official_pass"],
                    event["release_critical"],
                    event["seconds_to_original_release"],
                )
            )
        lines.append("")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path, help="Batch directory, traces directory, or trace directory")
    parser.add_argument("--json-out", type=Path, default=None)
    parser.add_argument("--md-out", type=Path, default=None)
    args = parser.parse_args()
    try:
        report = analyze(args.root)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        parser.error(str(exc))
    text = _render(report)
    print(text)
    if args.json_out is not None:
        args.json_out.parent.mkdir(parents=True, exist_ok=True)
        args.json_out.write_text(json.dumps(report, indent=2), encoding="utf-8")
    if args.md_out is not None:
        args.md_out.parent.mkdir(parents=True, exist_ok=True)
        args.md_out.write_text(text + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
