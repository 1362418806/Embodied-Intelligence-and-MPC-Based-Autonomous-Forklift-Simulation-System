"""Structural and observation-interface checks for forklift v3."""

from __future__ import annotations

import json
import math
from pathlib import Path

import mujoco

from simulator.observation_builder import ObservationBuilder


PROJECT_ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = PROJECT_ROOT / "assets" / "forklift" / "forklift_v3.xml"


def load_model() -> tuple[mujoco.MjModel, mujoco.MjData]:
    model = mujoco.MjModel.from_xml_path(str(MODEL_PATH))
    data = mujoco.MjData(model)
    mujoco.mj_forward(model, data)
    return model, data


def named_id(model: mujoco.MjModel, object_type: mujoco.mjtObj, name: str) -> int:
    object_id = mujoco.mj_name2id(model, object_type, name)
    assert object_id >= 0, f"Missing MuJoCo object: {name}"
    return object_id


def test_v3_model_contains_rgb_cameras_and_guidance_target() -> None:
    model, _ = load_model()

    named_id(model, mujoco.mjtObj.mjOBJ_CAMERA, "front_rgb")
    named_id(model, mujoco.mjtObj.mjOBJ_CAMERA, "fork_rgb")
    named_id(model, mujoco.mjtObj.mjOBJ_SITE, "placement_target")


def test_observation_builder_reports_initial_relative_target_pose() -> None:
    model, data = load_model()
    observation = ObservationBuilder(model).build(
        data,
        fork_contact_count=0,
        load_state="GROUND",
    )

    assert observation.sim_time == 0.0
    assert observation.pallet_pose_in_base.x > 2.5
    assert abs(observation.pallet_pose_in_base.y) < 0.1
    assert observation.placement_pose_in_base.x > 4.0
    assert observation.placement_pose_in_base.y < -1.0
    assert observation.load_state == "GROUND"


def test_observation_is_json_serializable() -> None:
    model, data = load_model()
    observation = ObservationBuilder(model).build(
        data,
        fork_contact_count=2,
        load_state="ENGAGED",
    )

    encoded = json.dumps(observation.to_dict())
    decoded = json.loads(encoded)

    assert decoded["fork_contact_count"] == 2
    assert decoded["load_state"] == "ENGAGED"
    assert math.isfinite(decoded["lift_position"])
    assert "pallet_pose_in_base" in decoded
    assert "placement_pose_in_base" in decoded


def test_observation_updates_after_vehicle_motion() -> None:
    model, data = load_model()
    builder = ObservationBuilder(model)
    initial = builder.build(data, fork_contact_count=0, load_state="GROUND")

    vehicle_joint = named_id(
        model, mujoco.mjtObj.mjOBJ_JOINT, "forklift_free"
    )
    qpos_address = int(model.jnt_qposadr[vehicle_joint])
    data.qpos[qpos_address] += 0.5
    mujoco.mj_forward(model, data)

    moved = builder.build(data, fork_contact_count=0, load_state="GROUND")
    assert moved.pallet_pose_in_base.x < initial.pallet_pose_in_base.x - 0.4
